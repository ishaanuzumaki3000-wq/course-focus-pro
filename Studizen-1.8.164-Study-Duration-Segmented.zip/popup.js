import { STATE_KEY, createStatePatch, focusElapsedMs, focusModeLabel, formatClock, formatDuration, getActiveCourse, mergeState, sessionRemainingMs } from "./shared.js";
const $ = (selector) => document.querySelector(selector);
const hasChrome = Boolean(globalThis.chrome?.storage?.local);
const systemThemeQuery = globalThis.matchMedia?.("(prefers-color-scheme: dark)");
const THEME_MODE_CACHE_KEY = "courseFocusProThemeMode";
let state = null;
let focusActionPending = false;
let popupCoursePickerOpen = false;
function sendMessage(message) { return hasChrome ? chrome.runtime.sendMessage(message) : Promise.resolve({ ok: false, message }); }
function resolvedTheme(mode = "dark") { const allowed = ["light", "dark", "midnight", "amoled", "beige"]; if (allowed.includes(mode)) return mode; if (mode === "system") return systemThemeQuery?.matches ? "dark" : "light"; return "dark"; }
function applyTheme() { const mode = state?.settings?.themeMode || "dark"; document.documentElement.dataset.theme = resolvedTheme(mode); document.documentElement.dataset.themeMode = mode; try { localStorage.setItem(THEME_MODE_CACHE_KEY, mode); } catch {} }
async function loadState() {
  if (hasChrome) {
    const response = await sendMessage({ type: "getState" });
    if (response?.ok) state = mergeState(response.response);
    else {
      const data = await chrome.storage.local.get(STATE_KEY);
      state = mergeState(data[STATE_KEY]);
    }
  } else {
    try { state = mergeState(JSON.parse(localStorage.getItem(STATE_KEY) || "null")); } catch { state = mergeState(); }
  }
  applyTheme();
  render();
}
function setAction(selector, visible, disabled = false) {
  const element = $(selector);
  if (!element) return;
  element.classList.toggle("hidden", !visible);
  element.disabled = disabled;
}
function renderPopupCoursePicker() {
  const picker = $("#popupCoursePicker");
  const list = $("#popupCoursePickerList");
  if (!picker || !list || !state) return;
  const sessionActive = Boolean(state.focusSession?.active);
  const visible = popupCoursePickerOpen && !sessionActive;
  picker.classList.toggle("hidden", !visible);
  if (!visible) return;
  const selectedId = getActiveCourse(state)?.id || "";
  list.innerHTML = "";
  state.courses.forEach((course) => {
    const item = document.createElement("button");
    item.type = "button";
    item.className = "popup-course-picker-item" + (course.id === selectedId ? " is-selected" : "");
    item.setAttribute("role", "option");
    item.setAttribute("aria-selected", String(course.id === selectedId));
    const title = document.createElement("strong");
    title.textContent = course.title || "Untitled course";
    title.title = course.title || "Untitled course";
    const subject = document.createElement("span");
    subject.textContent = course.subject || "Study course";
    item.append(title, subject);
    if (course.id === selectedId) { const marker = document.createElement("em"); marker.textContent = "Selected"; item.append(marker); }
    item.addEventListener("click", () => selectPopupCourse(course.id));
    list.append(item);
  });
  if (!state.courses.length) list.innerHTML = '<p class="popup-picker-empty">No courses yet. Add one to start focusing.</p>';
}
function renderPopupBreakDetails(session, endPending) {
  const section = $("#popupBreakDetails");
  const visible = Boolean(session?.active && session.mode === "breaks");
  section?.classList.toggle("hidden", !visible);
  if (!visible) return;

  const totalMs = Math.max(1, Number(session.durationMinutes) * 60000);
  const elapsedMs = Math.min(totalMs, focusElapsedMs(session));
  const blocksTotal = Math.max(1, Number(session.studyBlocksTotal) || Number(session.breaksTotal || 0) + 1);
  const blocksCompleted = Math.min(blocksTotal, Math.max(0, Number(session.studyBlocksCompleted) || 0));
  const isBreak = session.phase === "break";
  const currentBlock = Math.min(blocksTotal, blocksCompleted + 1);
  const breaksTotal = Math.max(1, Number(session.breaksTotal) || 0);
  const breakNumber = Math.max(1, Math.min(breaksTotal || 1, Number(session.cyclesCompleted) || blocksCompleted));

  $("#popupBreakPhase").textContent = endPending ? "Ending session" : isBreak ? "On break" : session.paused ? "Paused" : "Studying";
  $("#popupBreakBlock").textContent = isBreak ? `Break ${breakNumber} of ${breaksTotal}` : `Study block ${currentBlock} of ${blocksTotal}`;
  $("#popupBreakMessage").textContent = endPending
    ? "Undo to keep focusing, or end now."
    : isBreak
      ? "Study resumes automatically."
      : session.paused
        ? "Your study session is paused."
        : currentBlock < blocksTotal
          ? `Next: ${formatDuration(Number(session.breakDurationMinutes) || 0)} break.`
          : "Final study block. Your session ends when it finishes.";
  const progress = Math.max(0, Math.min(100, (elapsedMs / totalMs) * 100));
  $("#popupBreakProgress").style.width = `${progress}%`;
  $("#popupBreakProgressTrack").setAttribute("aria-valuenow", String(Math.round(progress)));
  section.dataset.phase = isBreak ? "break" : "study";
  section.dataset.pendingEnd = String(endPending);
}
function setPopupCoursePickerOpen(open) {
  popupCoursePickerOpen = Boolean(open);
  renderPopupCoursePicker();
}
async function selectPopupCourse(courseId) {
  if (!state || state.focusSession?.active) return;
  const next = { ...state, settings: { ...state.settings, defaultCourseId: courseId } };
  const result = await sendMessage({ type: "saveState", patch: createStatePatch(state, next) });
  if (result?.ok) state = mergeState(result.response);
  else await loadState();
  popupCoursePickerOpen = false;
  applyTheme();
  render();
}
async function clearWelcomeBack() {
  if (!state.focusSession?.welcomeBack) return;
  const next = { ...state, focusSession: { ...state.focusSession, welcomeBack: false } };
  const result = await sendMessage({ type: "saveState", patch: createStatePatch(state, next) });
  if (result?.ok) { state = mergeState(result.response); applyTheme(); render(); }
}
function render() {
  const course = getActiveCourse(state);
  const session = state.focusSession?.active ? state.focusSession : null;
  const hasCourse = Boolean(course);
  const running = Boolean(session && !session.paused);
  const paused = Boolean(session?.paused);
  const mode = session?.mode || state.settings.defaultFocusMode || "normal";
  const normalMode = mode === "normal";
  const breakPhase = session?.phase === "break";
  const endPending = Boolean(session && ["strict", "breaks"].includes(session.mode) && session.endConfirmationUntil > Date.now());
  const showWelcome = Boolean(session?.welcomeBack);
  document.body.dataset.focusState = session ? (endPending ? "ending" : paused ? "paused" : "running") : "ready";
  document.body.dataset.focusPhase = breakPhase ? "break" : "study";
  document.body.dataset.focusMode = session ? mode : "";
  $("#popupWelcomeBack").classList.toggle("hidden", !showWelcome);
  if (showWelcome) $("#popupWelcomeTime").textContent = formatClock(sessionRemainingMs(session)) + " remaining";
  const focusState = session ? (endPending ? "Ending" : mode === "breaks" ? "Focus with Breaks" : paused ? "Focus paused" : focusModeLabel(mode) + " · Active") : hasCourse ? "Ready to focus" : "Course needed";
  $("#popupFocusState").textContent = focusState;
  $("#popupStatus").textContent = session ? (endPending ? "Session ending. Undo to keep focusing." : breakPhase ? "On break. Study resumes automatically." : paused ? "Timer paused. Study-site protection remains on." : "Focus Mode is protecting your study time.") : hasCourse ? "Your next clean study block is ready." : "Add a course to start your first focus block.";
  const courseTitle = session?.courseTitle || course?.title || "No course yet";
  $("#popupCourse").textContent = courseTitle;
  $("#popupCourse").title = courseTitle;
  const breakEndCountdown = endPending && mode === "breaks" ? Math.max(0, session.endConfirmationUntil - Date.now()) : null;
  $("#popupTimer").textContent = session
    ? mode === "breaks"
      ? breakEndCountdown === null ? `\u23F1 ${formatClock(sessionRemainingMs(session))} Remaining` : `\u23F1 ${formatClock(breakEndCountdown)} to end`
      : (breakPhase ? "Break · " : "\u23F1 ") + formatClock(sessionRemainingMs(session)) + (breakPhase ? " remaining" : " Remaining")
    : hasCourse ? "Ready for " + formatDuration(state.settings.focusMinutesDefault || 50) + " focus" : "Choose a course to begin";
  $("#popupCourseState").textContent = session ? (breakPhase ? "Break" : paused ? "Paused" : mode === "strict" ? "Strict" : "Active") : hasCourse ? "Ready" : "Select course";
  $("#popupOpenBtn").textContent = hasCourse ? "Open course" : "Add a course";
  $("#popupOpenBtn").classList.toggle("is-add-course", !hasCourse);
  $("#popupOpenBtn").disabled = false;
  setAction("#popupStartBtn", !session && hasCourse, focusActionPending);
  setAction("#popupChangeCourseBtn", !session && hasCourse);
  setAction("#popupPauseBtn", Boolean(session && normalMode && !paused && !breakPhase), !running || focusActionPending);
  setAction("#popupResumeBtn", Boolean(session && normalMode && paused), focusActionPending);
  $("#popupStopBtn").textContent = normalMode ? "End Focus" : "End Session";
  setAction("#popupStopBtn", Boolean(session && !endPending), focusActionPending);
  setAction("#popupCancelStopBtn", endPending, focusActionPending);
  setAction("#popupEndNowBtn", endPending, focusActionPending);
  renderPopupBreakDetails(session, endPending);
  setAction("#popupDashboardBtn", true);
  if (session) popupCoursePickerOpen = false;
  renderPopupCoursePicker();
}
$("#popupDashboardBtn").addEventListener("click", () => sendMessage({ type: "openDashboard" }));
$("#popupRulesBtn").addEventListener("click", () => sendMessage({ type: "openDashboard", params: { section: "settings" } }));
$("#popupMusicNavBtn").addEventListener("click", () => sendMessage({ type: "openDashboard", params: { section: "music" } }));
$("#popupChangeCourseBtn").addEventListener("click", () => setPopupCoursePickerOpen(true));
$("#popupCoursePickerClose").addEventListener("click", () => setPopupCoursePickerOpen(false));
$("#popupCoursePickerAddBtn").addEventListener("click", () => sendMessage({ type: "openDashboard", params: { section: "courses" } }));
window.addEventListener("keydown", (event) => { if (event.key === "Escape") setPopupCoursePickerOpen(false); });
$("#popupOpenBtn").addEventListener("click", () => { const course = getActiveCourse(state); if (course) sendMessage({ type: "openCourse", url: course.url }); else sendMessage({ type: "openDashboard", params: { section: "courses" } }); });
$("#popupPauseBtn").addEventListener("click", async () => {
  const session = state.focusSession;
  if (!session?.active || session.paused || focusActionPending) return;
  focusActionPending = true;
  render();
  const result = await sendMessage({ type: "pauseFocus" });
  focusActionPending = false;
  if (result?.ok) state = mergeState(result.response);
  else await loadState();
  applyTheme();
  render();
});
$("#popupResumeBtn").addEventListener("click", async () => {
  const session = state.focusSession;
  if (!session?.active || !session.paused || focusActionPending) return;
  focusActionPending = true;
  render();
  const result = await sendMessage({ type: "resumeFocus" });
  focusActionPending = false;
  if (result?.ok) state = mergeState(result.response);
  else await loadState();
  applyTheme();
  render();
});
$("#popupStopBtn").addEventListener("click", async () => {
  if (focusActionPending) return;
  focusActionPending = true;
  const result = await sendMessage({ type: "stopFocus" });
  focusActionPending = false;
  if (result?.ok) { state = mergeState(result.response); applyTheme(); render(); }
});
$("#popupCancelStopBtn").textContent = "Undo";
$("#popupCancelStopBtn").addEventListener("click", async () => {
  if (focusActionPending) return;
  focusActionPending = true;
  render();
  const result = await sendMessage({ type: "cancelFocusEnd" });
  focusActionPending = false;
  if (result?.ok) state = mergeState(result.response);
  else await loadState();
  applyTheme();
  render();
});
$("#popupEndNowBtn").addEventListener("click", async () => {
  if (focusActionPending) return;
  focusActionPending = true;
  render();
  const result = await sendMessage({ type: "confirmFocusEnd" });
  focusActionPending = false;
  if (result?.ok) state = mergeState(result.response);
  else await loadState();
  applyTheme();
  render();
});
$("#popupStartBtn").addEventListener("click", async () => { const course = getActiveCourse(state); if (!course) return sendMessage({ type: "openDashboard", params: { section: "courses" } }); await sendMessage({ type: "openDashboard", params: { section: "focus", commitment: "1" } }); });
$("#popupWelcomeResumeBtn").addEventListener("click", async () => { if (state.focusSession?.paused) { const result = await sendMessage({ type: "resumeFocus" }); if (result?.ok) state = mergeState(result.response); } await clearWelcomeBack(); });
$("#popupWelcomeEndBtn").addEventListener("click", async () => { await clearWelcomeBack(); const result = await sendMessage({ type: "stopFocus" }); if (result?.ok) { state = mergeState(result.response); applyTheme(); render(); } });
$("#popupWelcomeDismissBtn").addEventListener("click", clearWelcomeBack);
if (hasChrome) chrome.storage.onChanged.addListener((changes, area) => { if (area === "local" && changes[STATE_KEY]?.newValue) { state = mergeState(changes[STATE_KEY].newValue); applyTheme(); render(); } });
await loadState();
setInterval(render, 1000);
