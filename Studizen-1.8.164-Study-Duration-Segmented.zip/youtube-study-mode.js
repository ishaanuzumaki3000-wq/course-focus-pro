(() => {
  if (window.__studizenYouTubeStudyMode) return;
  window.__studizenYouTubeStudyMode = true;

  const ACTIVE_CLASS = "studizen-youtube-study-active";
  const PROMPT_CLASS = "studizen-youtube-study-prompt";
  const PROMPT_ID = "studizen-youtube-study-message";
  let enabled = false;
  let lastUrl = "";

  function isVideoRoute() {
    try {
      const url = new URL(location.href);
      const host = url.hostname.toLowerCase().replace(/^www\./, "");
      const idPattern = /^[A-Za-z0-9_-]{11}$/;
      if (host === "youtu.be") return idPattern.test(url.pathname.split("/").filter(Boolean)[0] || "");
      if (host === "youtube.com" || host.endsWith(".youtube.com") || host === "youtube-nocookie.com" || host.endsWith(".youtube-nocookie.com")) {
        if (url.pathname === "/watch") return idPattern.test(url.searchParams.get("v") || "");
        const match = url.pathname.match(/^\/(?:live|embed)\/([^/?#]+)/i);
        return Boolean(match && idPattern.test(match[1]));
      }
    } catch {}
    return false;
  }

  function ensurePrompt() {
    if (document.getElementById(PROMPT_ID)) return;
    const prompt = document.createElement("main");
    prompt.id = PROMPT_ID;
    prompt.setAttribute("role", "status");
    const content = document.createElement("div");
    content.className = "studizen-youtube-study-message__content";
    const label = document.createElement("span");
    label.className = "studizen-youtube-study-message__label";
    label.textContent = "STUDIZEN · STUDY MODE";
    const heading = document.createElement("h1");
    heading.textContent = "Ready to learn?";
    const copy = document.createElement("p");
    copy.textContent = "Open a saved lecture from your Studizen Course Library.";
    const link = document.createElement("a");
    link.href = chrome.runtime.getURL("dashboard.html?section=courses");
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.textContent = "Open Course Library";
    content.append(label, heading, copy, link);
    prompt.append(content);
    (document.body || document.documentElement).append(prompt);
  }

  function render() {
    const root = document.documentElement;
    if (!root) return;
    const shouldApply = enabled;
    const promptPage = shouldApply && !isVideoRoute();
    root.classList.toggle(ACTIVE_CLASS, shouldApply);
    root.classList.toggle(PROMPT_CLASS, promptPage);
    if (promptPage) ensurePrompt();
    else document.getElementById(PROMPT_ID)?.remove();
    lastUrl = location.href;
  }

  function requestState() {
    chrome.runtime.sendMessage({ type: "getYouTubeStudyModeState" })
      .then((result) => {
        enabled = Boolean(result?.ok && result.response?.active);
        render();
      })
      .catch(() => {
        enabled = false;
        render();
      });
  }

  function onRouteChange() {
    if (location.href !== lastUrl) render();
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type !== "setYouTubeStudyMode") return;
    enabled = Boolean(message.active);
    render();
  });

  ["yt-navigate-finish", "yt-page-data-updated", "popstate", "hashchange", "pageshow"].forEach((name) => {
    window.addEventListener(name, onRouteChange, true);
  });
  document.addEventListener("readystatechange", () => {
    if (enabled && document.documentElement.classList.contains(PROMPT_CLASS)) ensurePrompt();
  });
  window.setInterval(onRouteChange, 700);
  requestState();
})();
