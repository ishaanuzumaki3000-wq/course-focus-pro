import {
  STATE_KEY,
  actualStudyMinutesForDate,
  buildTodayInsight,
  completedFocusAnalytics,
  completedPeriodAnalytics,
  canonicalYouTubeVideoUrl,
  courseHasVideo,
  STUDY_PROFILES,
  createStatePatch,
  dailySystemGoals,
  cleanPatterns,
  dateSeries,
  defaultState,
  dashboardHeaderPresentation,
  ensureToday,
  focusElapsedMinutes,
  formatClock,
  formatDuration,
  getActiveCourse,
  goalProgressPercent,
  mergeState,
  normalizeSubject,
  normalizeUrl,
  productivityScore,
  levelForXp,
  rankForLevel,
  recordFocusAnalytics,
  recordedStudyAnalytics,
  resolveStudyTargets,
  studyTargetSuggestions,
  normalizeGuidedTourHandoff,
  safeUrl,
  rewardXpTotal,
  safeYouTubeTitle,
  sessionRemainingMs,
  sessionXp,
  studyTargetProgress,
  subjectsForProfile,
  todayKey,
  uid
} from "./shared.js";

const hasChrome = Boolean(globalThis.chrome?.storage?.local);
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));
const systemThemeQuery = globalThis.matchMedia?.("(prefers-color-scheme: dark)");
const THEME_MODE_CACHE_KEY = "courseFocusProThemeMode";
const ONBOARDING_VERSION = 4;
const ONBOARDING_STEPS = ["welcome", "profile", "protection", "ready"];
const GUIDED_TOUR_VERSION = 1;
function guidedTourName() { return String(state?.profile?.name || "").trim().slice(0, 60); }
function guidedTourWelcomeText() {
  const name = guidedTourName();
  return name
    ? "Let's take a quick tour of the features you'll use most, " + name + "."
    : "Let's take a quick tour of the features you'll use most.";
}
const GUIDED_TOUR_STEPS = Object.freeze([
  { tab: "focus", selector: "#mainTitle", title: "Welcome to Studizen 👋", text: guidedTourWelcomeText, action: "start" },
  { tab: "focus", selector: "#focusWorkspaceTourTarget", spotlight: "focus", title: "Focus Mode", text: "Focus Mode is where you study. Choose a course, set your session time, and start focusing." },
  {
    tab: "courses",
    selector: "#addCourseTourTarget",
    title: "Add a study video",
    text: "Find an educational video on YouTube, right-click it, and choose Add to Studizen.",
    action: "courses",
    waitForCourse: true
  },
  { tab: "music", selector: "#studyMusicTourTarget", title: "Music", text: "Choose a sound to play while you study." },
  { tab: "analytics", selector: null, title: "Analytics", text: "Analytics shows how much you study and how you're progressing.", action: "analytics" },
  { tab: "settings", selector: "#distractionProtectionTourTarget", title: "Settings", text: "Settings is where you change how Studizen works for you.", action: "settings" },
  { tab: "focus", selector: null, title: "Quick access", text: "Use the Studizen popup for quick actions without opening the dashboard.", action: "popup" },
  {
    tab: () => state.courses.length ? "focus" : "courses",
    selector: () => state.courses.length ? "#startFocusBtn" : "#courseForm button[type='submit']",
    title: () => guidedTourName() ? "You're ready to focus, " + guidedTourName() + "." : "You're ready to focus.",
    text: () => state.courses.length
      ? "You know the basics. Start your first session whenever you're ready."
      : "Add a course first, then you can start your first session whenever you're ready.",
    action: "completion"
  }
]);
const GUIDED_TOUR_TAB_STEPS = Object.freeze({ focus: 1, courses: 2, music: 3, analytics: 4, settings: 5 });
const ONBOARDING_PROFILE_OPTIONS = Object.freeze({
  jee: { profileId: "jee", name: "JEE" },
  neet: { profileId: "neet", name: "NEET" },
  school: { profileId: "school", name: "School" },
  college: { profileId: "college", name: "College" },
  upsc: { profileId: "upsc", name: "UPSC" },
  "self-learner": { profileId: "custom", name: "Self Learner" }
});
const ONBOARDING_THEME_NAMES = Object.freeze({ system: "System", light: "Light", dark: "Dark", midnight: "Midnight Blue", amoled: "AMOLED Black", beige: "Warm Beige" });
let state = defaultState();
let toastTimer = null;
let undoTimer = null;
let undoSnapshot = null;
let undoLocalStorageSnapshot = null;
let lastSeenAttentionReminderAt = 0;
let onboardingStep = "welcome";
let onboardingProfileChoice = null;
let onboardingNameDraft = null;
let onboardingThemeChoice = null;
let onboardingDurationDraft = null;
let onboardingTargetsDraft = null;
let onboardingTargetsProfileId = null;
let onboardingTargetsTouched = false;
let guidedTourStepIndex = 0;
let guidedTourActive = false;
let guidedTourSuspended = false;
let guidedTourTabId = null;
let guidedTourAutoStartHandled = false;
let guidedTourPositionFrame = 0;
let guidedTourTransition = false;
let charts = {};
let focusActionPending = false;
let allowedSiteQuery = "";
let blockedSiteQuery = "";
let siteControlExpanded = false;
let incognitoAccessAllowed = null;
try { siteControlExpanded = sessionStorage.getItem("courseFocusProSiteControlExpanded") === "true"; } catch {}
let settingsDisclosureExpanded = { general: false, privacy: false, backup: false };
try {
  const savedSettingsDisclosures = JSON.parse(sessionStorage.getItem("studizenSettingsDisclosureExpanded") || "{}");
  ["general", "backup"].forEach((key) => { settingsDisclosureExpanded[key] = savedSettingsDisclosures[key] === true; });
  settingsDisclosureExpanded.privacy = savedSettingsDisclosures.privacy === true || savedSettingsDisclosures.camera === true;
} catch {}
let completedAnalyticsCache = { signature: "", summary: null };
let recordedAnalyticsCache = { signature: "", summary: null };
let courseHistoryQuery = "";
let courseHistorySort = "time";
let courseHistoryExpanded = sessionStorage.getItem("courseFocusProCourseHistoryExpanded") === "true";
let analyticsHistoryPeriod = null;
let pendingYouTubeVideo = null;
let lastLiveFocusMinutes = null;
let courseLibraryQuery = "";
let courseLibrarySource = "all";
let courseLibrarySort = "priority";
let courseLibraryLimit = 60;
let courseLibraryExpanded = false;
let activeStudyLinkMenu = null;
try { courseLibraryExpanded = sessionStorage.getItem("courseFocusProStudyLinkLibraryExpanded") === "true"; } catch {}
const FOCUS_QUOTES = Object.freeze([
  "A clear hour can change the shape of a difficult topic.",
  "Protect the next small step. It is enough to begin.",
  "Return to the page. The work becomes lighter once it has your attention.",
  "Understanding grows where distraction ends.",
  "Make the next twenty minutes honest.",
  "Progress is often quiet: one concept, one page, one problem at a time.",
  "Do the part that makes tomorrow easier.",
  "Give the difficult idea enough uninterrupted time to become familiar.",
  "Consistency is built from the sessions you choose not to skip."
]);
let focusQuoteIndex = -1;
let focusQuoteShown = false;
let lastShownLevel = Number(sessionStorage.getItem("courseFocusProLastLevel") || 1);
if (globalThis.Chart?.register && !globalThis.Chart.registry.plugins.get("goalLine")) {
  globalThis.Chart.register({
    id: "goalLine",
    afterDraw(chart, _args, options) {
      const value = Number(options?.value);
      if (!Number.isFinite(value) || value <= 0) return;
      const scale = chart.options.indexAxis === "y" ? chart.scales.x : chart.scales.y;
      if (!scale) return;
      const pixel = scale.getPixelForValue(value);
      const { ctx, chartArea } = chart;
      ctx.save();
      ctx.strokeStyle = options.color || "#e59b23";
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 5]);
      ctx.beginPath();
      if (chart.options.indexAxis === "y") { ctx.moveTo(pixel, chartArea.top); ctx.lineTo(pixel, chartArea.bottom); }
      else { ctx.moveTo(chartArea.left, pixel); ctx.lineTo(chartArea.right, pixel); }
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = ctx.strokeStyle;
      ctx.font = "700 10px Inter, system-ui, sans-serif";
      ctx.textAlign = chart.options.indexAxis === "y" ? "left" : "right";
      ctx.textBaseline = "bottom";
      if (chart.options.indexAxis === "y") ctx.fillText(options.label || "Goal", Math.min(chartArea.right - 4, pixel + 5), chartArea.top + 13);
      else ctx.fillText(options.label || "Goal", chartArea.right - 4, Math.max(chartArea.top + 12, pixel - 5));
      ctx.restore();
    }
  });
}
let music = { ctx: null, gain: null, nodes: [], index: 0, playing: false, loop: true, shuffle: false, volume: 0.35, endTimer: null, imported: [], audio: null, source: "built-in", currentImportedId: null };
let uiSoundCtx = null;
const MUSIC_LIBRARY_KEY = "courseFocusProMusicLibrary";
const MUSIC_COMMAND_KEY = "courseFocusProMusicCommand";
const MUSIC_TRACKS = [
  { id: "lofi", title: "Lo-fi", description: "Soft warm tones for quiet study.", type: "tone", frequency: 196, wave: "triangle" },
  { id: "piano", title: "Piano", description: "Gentle piano-like pulses.", type: "tone", frequency: 261.63, wave: "sine" },
  { id: "nature", title: "Nature Sounds", description: "Light filtered ambience for calm focus.", type: "noise", filter: 1200 },
  { id: "white", title: "White Noise", description: "Even noise for blocking distractions.", type: "noise", filter: 5000 },
  { id: "rain", title: "Rain + Thunder", description: "Layered rain with soft distant thunder.", type: "rain" },
  { id: "brown", title: "Brown Noise", description: "Low smooth noise for concentration.", type: "noise", filter: 420 },
  { id: "deep", title: "Deep Focus", description: "Lower steady tone for long sessions.", type: "tone", frequency: 174, wave: "sine" },
  { id: "ocean", title: "Ocean Air", description: "Soft filtered wash for reading.", type: "noise", filter: 900 },
  { id: "wind", title: "Soft Wind", description: "Light airy texture for calm study.", type: "noise", filter: 2600 },
  { id: "warm", title: "Warm Pad", description: "Gentle pad for quiet problem solving.", type: "tone", frequency: 220, wave: "triangle" },
  { id: "coffee", title: "Coffee Shop Ambience", description: "Soft cafe room tone with warm background hum.", type: "coffee" },
  { id: "oceanwave", title: "Ocean Wave", description: "Slow breathing waves for relaxed study.", type: "oceanwave" },
  { id: "beat852", title: "852 Hz Beat", description: "A very subtle 852 Hz focus tone.", type: "tone", frequency: 852, wave: "sine", gain: 0.035, lfoFrequency: 3.2, lfoGain: 0.012 }
];

const el = {
  connectionLabel: $("#connectionLabel"), stateEyebrow: $("#stateEyebrow"), mainTitle: $("#mainTitle"), activeFocusIndicator: $("#activeFocusIndicator"), activeFocusStatus: $("#activeFocusStatus"), activeFocusCourse: $("#activeFocusCourse"), activeFocusViewBtn: $("#activeFocusViewBtn"), liveClock: $("#liveClock"), focusOpenCourseBtn: $("#focusOpenCourseBtn"),
  sidebarMoreNav: $("#sidebarMoreNav"), focusHeadline: $("#focusHeadline"), focusPill: $("#focusPill"), timerProgress: $("#timerProgress"), timerText: $("#timerText"), timerCaption: $("#timerCaption"), selectedCourseTitle: $("#selectedCourseTitle"), selectedCourseMeta: $("#selectedCourseMeta"), changeCourseBtn: $("#changeCourseBtn"), startFocusBtn: $("#startFocusBtn"), focusQuote: $("#focusQuote"),
  startForm: $("#startForm"), courseSelect: $("#courseSelect"), durationInput: $("#durationInput"), pauseFocusBtn: $("#pauseFocusBtn"), resumeFocusBtn: $("#resumeFocusBtn"), stopFocusBtn: $("#stopFocusBtn"), redirectEnabledInput: $("#redirectEnabledInput"), focusRemainingText: $("#focusRemainingText"), cameraFocusStatus: $("#cameraFocusStatus"), cameraStatusIcon: $("#cameraStatusIcon"), cameraStatusTitle: $("#cameraStatusTitle"), cameraStatusMessage: $("#cameraStatusMessage"), cameraStatusState: $("#cameraStatusState"), cameraStatusSettingsBtn: $("#cameraStatusSettingsBtn"),
  todayFocus: $("#todayFocus"), todaySessions: $("#todaySessions"), todayBlocks: $("#todayBlocks"), todayScore: $("#todayScore"), todayInsightTitle: $("#todayInsightTitle"), todayInsightText: $("#todayInsightText"),
  courseForm: $("#courseForm"), courseTitleInput: $("#courseTitleInput"), courseSubjectInput: $("#courseSubjectInput"), courseLibraryInput: $("#courseLibraryInput"), courseUrlInput: $("#courseUrlInput"), courseOverview: $("#courseOverview"), studyLinkLibraryPanel: $("#studyLinkLibraryPanel"), studyLinkLibraryToggle: $("#studyLinkLibraryToggle"), courseLibrariesList: $("#courseLibrariesList"), courseCount: $("#courseCount"), courseLibrarySearch: $("#courseLibrarySearch"), courseLibrarySource: $("#courseLibrarySource"), courseLibrarySort: $("#courseLibrarySort"), libraryForm: $("#libraryForm"), libraryNameInput: $("#libraryNameInput"),
  siteControlSection: $("#siteControlSection"), siteControlToggle: $("#siteControlToggle"), siteControlBody: $("#siteControlBody"),
  allowedForm: $("#allowedForm"), allowedInput: $("#allowedInput"), allowedList: $("#allowedList"), allowedCount: $("#allowedCount"), allowedSearch: $("#allowedSearch"), addSupportingSiteBtn: $("#addSupportingSiteBtn"), addCurrentSiteBtn: $("#addCurrentSiteBtn"), blockedForm: $("#blockedForm"), blockedInput: $("#blockedInput"), blockedList: $("#blockedList"), blockedCount: $("#blockedCount"), blockedSearch: $("#blockedSearch"), addBlockedSiteBtn: $("#addBlockedSiteBtn"), distractionProtectionInput: $("#distractionProtectionInput"), distractionProtectionState: $("#distractionProtectionState"), incognitoProtectionInput: $("#incognitoProtectionInput"), incognitoProtectionState: $("#incognitoProtectionState"), incognitoAccessRow: $("#incognitoAccessRow"), incognitoAccessTitle: $("#incognitoAccessTitle"), incognitoAccessState: $("#incognitoAccessState"), openIncognitoSettingsBtn: $("#openIncognitoSettingsBtn"),
  currentStreak: $("#currentStreak"), analyticsToday: $("#analyticsToday"), analyticsWeek: $("#analyticsWeek"), analyticsWeekLabel: $("#analyticsWeekLabel"), analyticsWeekHint: $("#analyticsWeekHint"), analyticsSessions: $("#analyticsSessions"), analyticsSessionsHint: $("#analyticsSessionsHint"), analyticsGoalHint: $("#analyticsGoalHint"), weeklyHours: $("#weeklyHours"), averageStudy: $("#averageStudy"), goalProgress: $("#goalProgress"), dailyComparison: $("#dailyComparison"), xpPanel: $("#analyticsXpPopover"), analyticsXpBtn: $("#analyticsXpBtn"), analyticsXpPopover: $("#analyticsXpPopover"), analyticsXpCloseBtn: $("#analyticsXpCloseBtn"), rankTitle: $("#rankTitle"), rankMeta: $("#rankMeta"), xpProgressFill: $("#xpProgressFill"), badgeRow: $("#badgeRow"), dailyChart: $("#dailyChart"), dailyChartMeta: $("#dailyChartMeta"), dailyChartGoal: $("#dailyChartGoal"), dailyChartEmpty: $("#dailyChartEmpty"), courseDistributionList: $("#courseDistributionList"), courseDistributionMeta: $("#courseDistributionMeta"), courseDistributionEmpty: $("#courseDistributionEmpty"), consistencyMeta: $("#consistencyMeta"), consistencyGoalLabel: $("#consistencyGoalLabel"), consistencyGoalValue: $("#consistencyGoalValue"), consistencyGoalPercent: $("#consistencyGoalPercent"), consistencyGoalFill: $("#consistencyGoalFill"), consistencyDailyAverage: $("#consistencyDailyAverage"), consistencySessions: $("#consistencySessions"), consistencyAverageSession: $("#consistencyAverageSession"), consistencyLongestSession: $("#consistencyLongestSession"), courseHistoryPanel: $("#courseHistoryPanel"), courseHistoryToggle: $("#courseHistoryToggle"), courseHistoryCount: $("#courseHistoryCount"), courseHistorySearch: $("#courseHistorySearch"), courseHistorySort: $("#courseHistorySort"), courseHistoryList: $("#courseHistoryList"), analyticsCurrentBtn: $("#analyticsCurrentBtn"), analyticsPreviousWeekBtn: $("#analyticsPreviousWeekBtn"), analyticsPreviousMonthBtn: $("#analyticsPreviousMonthBtn"), analyticsHistoryDrawer: $("#analyticsHistoryDrawer"), analyticsHistoryTitle: $("#analyticsHistoryTitle"), analyticsHistoryComparison: $("#analyticsHistoryComparison"), analyticsHistoryTotal: $("#analyticsHistoryTotal"), analyticsHistorySessions: $("#analyticsHistorySessions"), analyticsHistoryAverage: $("#analyticsHistoryAverage"), analyticsHistoryGoal: $("#analyticsHistoryGoal"), analyticsHistoryCourses: $("#analyticsHistoryCourses"), analyticsHistoryCloseBtn: $("#analyticsHistoryCloseBtn"),
  currentStreak: $("#currentStreak"), analyticsToday: $("#analyticsToday"), analyticsWeek: $("#analyticsWeek"), analyticsWeekLabel: $("#analyticsWeekLabel"), analyticsWeekHint: $("#analyticsWeekHint"), analyticsSessions: $("#analyticsSessions"), analyticsSessionsHint: $("#analyticsSessionsHint"), analyticsGoalHint: $("#analyticsGoalHint"), weeklyHours: $("#weeklyHours"), averageStudy: $("#averageStudy"), goalProgress: $("#goalProgress"), dailyComparison: $("#dailyComparison"), xpPanel: $("#analyticsXpPopover"), analyticsXpBtn: $("#analyticsXpBtn"), analyticsXpPopover: $("#analyticsXpPopover"), analyticsXpCloseBtn: $("#analyticsXpCloseBtn"), rankTitle: $("#rankTitle"), rankMeta: $("#rankMeta"), xpProgressFill: $("#xpProgressFill"), badgeRow: $("#badgeRow"), dailyChart: $("#dailyChart"), dailyChartMeta: $("#dailyChartMeta"), dailyChartGoal: $("#dailyChartGoal"), dailyChartEmpty: $("#dailyChartEmpty"), courseDistributionList: $("#courseDistributionList"), courseDistributionMeta: $("#courseDistributionMeta"), courseDistributionEmpty: $("#courseDistributionEmpty"), subjectTargetSummary: $("#subjectTargetSummary"), subjectChartSort: $("#subjectChartSort"), analyticsTargetsToggle: $("#analyticsTargetsToggle"), analyticsTargetsEditor: $("#analyticsTargetsEditor"), analyticsTargetsForm: $("#analyticsTargetsForm"), analyticsTargetsProfileNote: $("#analyticsTargetsProfileNote"), analyticsDailyTargetInput: $("#analyticsDailyTargetInput"), analyticsWeeklyTargetInput: $("#analyticsWeeklyTargetInput"), analyticsTargetSubjectList: $("#analyticsTargetSubjectList"), analyticsTargetsClose: $("#analyticsTargetsClose"), analyticsTargetsCancel: $("#analyticsTargetsCancel"), analyticsTargetsRestore: $("#analyticsRestoreTargets"), analyticsAddSubjectBtn: $("#analyticsAddSubjectBtn"), analyticsAddSubjectRow: $("#analyticsAddSubjectRow"), analyticsNewSubjectInput: $("#analyticsNewSubjectInput"), analyticsConfirmAddSubject: $("#analyticsConfirmAddSubject"), consistencyMeta: $("#consistencyMeta"), consistencyGoalLabel: $("#consistencyGoalLabel"), consistencyGoalValue: $("#consistencyGoalValue"), consistencyGoalPercent: $("#consistencyGoalPercent"), consistencyGoalFill: $("#consistencyGoalFill"), consistencyDailyAverage: $("#consistencyDailyAverage"), consistencySessions: $("#consistencySessions"), consistencyAverageSession: $("#consistencyAverageSession"), consistencyLongestSession: $("#consistencyLongestSession"), courseHistoryPanel: $("#courseHistoryPanel"), courseHistoryToggle: $("#courseHistoryToggle"), courseHistoryCount: $("#courseHistoryCount"), courseHistorySearch: $("#courseHistorySearch"), courseHistorySort: $("#courseHistorySort"), courseHistoryList: $("#courseHistoryList"), analyticsCurrentBtn: $("#analyticsCurrentBtn"), analyticsPreviousWeekBtn: $("#analyticsPreviousWeekBtn"), analyticsPreviousMonthBtn: $("#analyticsPreviousMonthBtn"), analyticsHistoryDrawer: $("#analyticsHistoryDrawer"), analyticsHistoryTitle: $("#analyticsHistoryTitle"), analyticsHistoryComparison: $("#analyticsHistoryComparison"), analyticsHistoryTotal: $("#analyticsHistoryTotal"), analyticsHistorySessions: $("#analyticsHistorySessions"), analyticsHistoryAverage: $("#analyticsHistoryAverage"), analyticsHistoryGoal: $("#analyticsHistoryGoal"), analyticsHistoryCourses: $("#analyticsHistoryCourses"), analyticsHistoryCloseBtn: $("#analyticsHistoryCloseBtn"),
  missionForm: $("#missionForm"), missionTitleInput: $("#missionTitleInput"), missionAreaInput: $("#missionAreaInput"), missionMinutesInput: $("#missionMinutesInput"), missionNoteInput: $("#missionNoteInput"), systemGoalsList: $("#systemGoalsList"), personalTaskList: $("#personalTaskList"), missionProgressText: $("#missionProgressText"), missionProgressFill: $("#missionProgressFill"), resetTasksBtn: $("#resetTasksBtn"),
  musicCategories: $("#musicCategories"), musicStatus: $("#musicStatus"), musicTitle: $("#musicTitle"), musicDescription: $("#musicDescription"), musicVolumeLabel: $("#musicVolumeLabel"), musicPrevBtn: $("#musicPrevBtn"), musicBackBtn: $("#musicBackBtn"), musicForwardBtn: $("#musicForwardBtn"), musicPlayBtn: $("#musicPlayBtn"), musicPlayIcon: $("#musicPlayIcon"), musicPlayLabel: $("#musicPlayLabel"), musicNextBtn: $("#musicNextBtn"), musicShuffleBtn: $("#musicShuffleBtn"), musicVolumeInput: $("#musicVolumeInput"), musicLoopInput: $("#musicLoopInput"), musicImportInput: $("#musicImportInput"), myMusicList: $("#myMusicList"),
  studyProfileSelect: $("#studyProfileSelect"), themeModeSelect: $("#themeModeSelect"), soundEnabledInput: $("#soundEnabledInput"), soundVolumeInput: $("#soundVolumeInput"), soundVolumeLabel: $("#soundVolumeLabel"), cameraAttentionEnabledInput: $("#cameraAttentionEnabledInput"), cameraAttentionSensitivityInput: $("#cameraAttentionSensitivityInput"), cameraAttentionGraceInput: $("#cameraAttentionGraceInput"), cameraAttentionVoiceInput: $("#cameraAttentionVoiceInput"), cameraPermissionBtn: $("#cameraPermissionBtn"), cameraSettingsState: $("#cameraSettingsState"), settingsFocusMinutesInput: $("#settingsFocusMinutesInput"), settingsForm: $("#settingsForm"), resetAnalyticsBtn: $("#resetAnalyticsBtn"), clearAllDataBtn: $("#clearAllDataBtn"), exportJsonBtn: $("#exportJsonBtn"), restoreBackupBtn: $("#restoreBackupBtn"), restoreBackupInput: $("#restoreBackupInput"), backupStatus: $("#backupStatus"),
  helpPopover: $("#helpPopover"), toast: $("#toast"), undoBar: $("#undoBar"), undoText: $("#undoText"), undoBtn: $("#undoBtn"), completionModal: $("#completionModal"), completionSubject: $("#completionSubject"), completionDuration: $("#completionDuration"), completionXp: $("#completionXp"), completionToday: $("#completionToday"), completionStreak: $("#completionStreak"), completionStartBtn: $("#completionStartBtn"), completionBreakBtn: $("#completionBreakBtn"), completionCloseBtn: $("#completionCloseBtn"), welcomeBackModal: $("#welcomeBackModal"), welcomeBackTime: $("#welcomeBackTime"), welcomeResumeBtn: $("#welcomeResumeBtn"), welcomeEndBtn: $("#welcomeEndBtn"), welcomeDismissBtn: $("#welcomeDismissBtn"), courseModal: $("#courseModal"), courseModalClose: $("#courseModalClose"), courseSwitchList: $("#courseSwitchList"), youtubeAddModal: $("#youtubeAddModal"), youtubeAddCloseBtn: $("#youtubeAddCloseBtn"), youtubeAddVideoTitle: $("#youtubeAddVideoTitle"), youtubeNewForm: $("#youtubeNewForm"), youtubeNewTitleInput: $("#youtubeNewTitleInput"), youtubeNewSubjectSelect: $("#youtubeNewSubjectSelect"), youtubeNewLibrarySelect: $("#youtubeNewLibrarySelect"), onboardingOverlay: $("#onboardingOverlay"), onboardingCard: $("#onboardingCard"), onboardingProgressText: $("#onboardingProgressText"), onboardingProgressFill: $("#onboardingProgressFill"), onboardingGetStartedBtn: $("#onboardingGetStartedBtn"), onboardingNameInput: $("#onboardingNameInput"), onboardingThemeOptions: $("#onboardingThemeOptions"), onboardingFocusMinutesInput: $("#onboardingFocusMinutesInput"), onboardingProfileCards: $("#onboardingProfileCards"), onboardingProfileNextBtn: $("#onboardingProfileNextBtn"), onboardingTargetEditor: $("#onboardingTargetEditor"), onboardingDailyTargetInput: $("#onboardingDailyTargetInput"), onboardingWeeklyTargetInput: $("#onboardingWeeklyTargetInput"), onboardingTargetSubjectList: $("#onboardingTargetSubjectList"), onboardingAddSubjectBtn: $("#onboardingAddSubjectBtn"), onboardingAddSubjectRow: $("#onboardingAddSubjectRow"), onboardingNewSubjectInput: $("#onboardingNewSubjectInput"), onboardingConfirmAddSubject: $("#onboardingConfirmAddSubject"), onboardingProtectionNextBtn: $("#onboardingProtectionNextBtn"), onboardingReadyName: $("#onboardingReadyName"), onboardingReadyProfile: $("#onboardingReadyProfile"), onboardingReadyTheme: $("#onboardingReadyTheme"), onboardingReadyDuration: $("#onboardingReadyDuration"), onboardingReadyDailyTarget: $("#onboardingReadyDailyTarget"), onboardingReadyWeeklyTarget: $("#onboardingReadyWeeklyTarget"), onboardingReadySubjects: $("#onboardingReadySubjects"), onboardingReadyMessage: $("#onboardingReadyMessage"), finishTutorialBtn: $("#finishTutorialBtn"), showOnboardingBtn: $("#showOnboardingBtn"), startGuidedTourBtn: $("#startGuidedTourBtn"), guidedTour: $("#guidedTour"), guidedTourBackdrop: $("#guidedTourBackdrop"), guidedTourSpotlight: $("#guidedTourSpotlight"), guidedTourCard: $("#guidedTourCard"), guidedTourTitle: $("#guidedTourTitle"), guidedTourDescription: $("#guidedTourDescription"), guidedTourCoursesFlow: $("#guidedTourCoursesFlow"), guidedTourAnalyticsPreview: $("#guidedTourAnalyticsPreview"), guidedTourPopupGuide: $("#guidedTourPopupGuide"), guidedTourDistractionGuide: $("#guidedTourDistractionGuide"), guidedTourProgressText: $("#guidedTourProgressText"), guidedTourProgressFill: $("#guidedTourProgressFill"), guidedTourBackBtn: $("#guidedTourBackBtn"), guidedTourNextBtn: $("#guidedTourNextBtn"), guidedTourYouTubeBtn: $("#guidedTourYouTubeBtn"), guidedTourPopupBtn: $("#guidedTourPopupBtn"), guidedTourSkipBtn: $("#guidedTourSkipBtn"), developerEmail: $("#developerEmail")
};

function sendMessage(message) { return hasChrome ? chrome.runtime.sendMessage(message) : Promise.resolve({ ok: false }); }
function resolvedTheme(mode) { const allowed = ["light", "dark", "midnight", "amoled", "beige"]; if (allowed.includes(mode)) return mode; if (mode === "system") return systemThemeQuery?.matches ? "dark" : "light"; return "dark"; }
function applyTheme() { const mode = state.settings.themeMode || "dark"; document.documentElement.dataset.theme = resolvedTheme(mode); document.documentElement.dataset.themeMode = mode; try { localStorage.setItem(THEME_MODE_CACHE_KEY, mode); } catch {} if (el.themeModeSelect) el.themeModeSelect.value = mode; }
function showToast(message) { el.toast.textContent = message; el.toast.classList.add("show"); clearTimeout(toastTimer); toastTimer = setTimeout(() => el.toast.classList.remove("show"), 2400); }
function showUndo(message, snapshot, localSnapshot = null) { undoSnapshot = snapshot ? JSON.parse(JSON.stringify(snapshot)) : null; undoLocalStorageSnapshot = localSnapshot; if (!undoSnapshot) return; el.undoText.textContent = message; el.undoBar.classList.remove("hidden"); clearTimeout(undoTimer); undoTimer = setTimeout(() => { el.undoBar.classList.add("hidden"); undoSnapshot = null; undoLocalStorageSnapshot = null; }, 7000); }
function hours(minutes) { return Math.round((Number(minutes || 0) / 60) * 10) / 10 + "h"; }
function activeSession() { const session = state.focusSession; return session?.active && (session.paused || sessionRemainingMs(session) > 0) ? session : null; }
function cameraAttentionLabel(session = activeSession()) {
  const attention = state.attention || {};
  if (!state.settings.cameraAttentionEnabled) return "Camera Focus Check is off. Enable it in Settings to use attention checks during Focus.";
  if (!session) return "Camera Focus Check beta is ready for your next focus session";
  if (session.paused) return "Camera is off while Focus Mode is paused";
  const labels = {
    starting: "Starting",
    calibrating: "Calibrating",
    watching: "Watching",
    "attention-lost": "Attention detected",
    "needs-position": "Needs positioning",
    "permission-denied": "Camera permission denied",
    unsupported: "Not available in this Chrome version",
    error: attention.error || "Camera check error"
  };
  return labels[attention.status] || "Camera check is preparing";
}
function cameraAttentionIcon(session = activeSession()) {
  const status = state.attention?.status || "off";
  if (!state.settings.cameraAttentionEnabled || !session) return "⚪";
  if (session.paused) return "⏸";
  return { starting: "◌", calibrating: "🟡", watching: "🟢", "attention-lost": "🔴", "needs-position": "⚠️", "permission-denied": "❌", unsupported: "❌", error: "❌" }[status] || "◌";
}
function attentionReminderText(reason) {
  if (reason === "eyes closed") return "Attention: your eyes have been closed for a while.";
  if (reason === "eyes away from screen") return "Attention: bring your gaze back to the lesson.";
  return "Attention: you have been away from the course for a while.";
}
function renderCameraAttention(session = activeSession()) {
  if (el.cameraFocusStatus) {
    const status = state.attention?.status || "off";
    const enabled = Boolean(state.settings.cameraAttentionEnabled);
    el.cameraStatusIcon.textContent = "●";
    el.cameraStatusTitle.textContent = "Camera Focus Check";
    el.cameraStatusState.textContent = enabled ? "On" : "Off";
    el.cameraStatusMessage.textContent = enabled
      ? "Attention checks are active during Focus"
      : "Optional attention checks during Focus";
    el.cameraStatusSettingsBtn.classList.toggle("hidden", enabled);
    el.cameraFocusStatus.classList.toggle("is-enabled", enabled);
    el.cameraFocusStatus.dataset.status = status;
    el.cameraFocusStatus.classList.toggle("is-active", Boolean(session && enabled && !session.paused && status === "watching"));
  }
  if (el.cameraSettingsState) el.cameraSettingsState.textContent = cameraAttentionLabel(session);
}
function validUrl(raw) { const url = safeUrl(raw); return url && /^https?:/.test(url.protocol) ? url.href : ""; }
function inferTitle(url) { const host = safeUrl(url)?.hostname.replace(/^www\./, "") || "Study"; return host.includes("youtube") || host.includes("youtu.be") ? "YouTube Course" : host; }
function completedAnalytics() { const history = state.analytics?.focusHistory || []; const signature = String(state.profile?.studyProfile || "") + "|" + history.map((item) => [item?.id, item?.status, item?.completed, item?.actualMinutes, item?.endedAt, item?.recordedDate].join(":" )).join("|"); if (completedAnalyticsCache.signature !== signature) completedAnalyticsCache = { signature, summary: completedFocusAnalytics(state) }; return completedAnalyticsCache.summary; }
function recordedAnalytics() { const history = state.analytics?.focusHistory || []; const signature = String(state.profile?.studyProfile || "") + "|" + String(state.goals?.analyticsTargets?.customSubjects || "") + "|" + (state.courses || []).map((course) => [course.id, course.subject].join(":" )).join("|") + "|" + history.map((item) => [item?.id, item?.actualTracked, item?.status, item?.actualMinutes, item?.durationMinutes, item?.endedAt, item?.recordedDate, item?.subject, item?.courseId, item?.courseTitle].join(":" )).join("|"); if (recordedAnalyticsCache.signature !== signature) recordedAnalyticsCache = { signature, summary: recordedStudyAnalytics(state) }; return recordedAnalyticsCache.summary; }
function completedFocusSessions(days = null) { const summary = completedAnalytics(); if (!days) return summary.sessions; const keys = new Set(dateSeries(days)); return summary.sessions.filter((item) => keys.has(item.recordedDate)); }
function actualFocusSessions(days = null) { return completedFocusSessions(days); }
function sessionActualMinutes(item) { return Math.max(0, Number(item?.actualMinutes ?? item?.durationMinutes) || 0); }
function actualMinutesToday() { return actualStudyMinutesForDate(state, todayKey()); }
function completedMinutesToday() { return completedAnalytics().todayMinutes; }
function completedSessionsToday() { const today = completedAnalytics().today; return completedFocusSessions().filter((item) => item.recordedDate === today).length; }
function currentSubjects() { return [...new Set([...subjectsForProfile(state.profile?.studyProfile), ...(state.goals?.analyticsTargets?.customSubjects || []), ...(state.courses || []).map((course) => String(course.subject || "").trim()), ...(state.analytics?.focusHistory || []).map((item) => String(item.subject || "").trim())].filter(Boolean))]; }
function subjectTotalsFromHistory(days = null) { const subjects = currentSubjects(); const totals = Object.fromEntries(subjects.map((subject) => [subject, { minutes: 0, sessions: 0 }])); const keys = days ? new Set(dateSeries(days)) : null; completedFocusSessions().forEach((item) => { if (keys && !keys.has(item.recordedDate)) return; const subject = normalizeSubject(item.subject, state.profile?.studyProfile); if (!totals[subject]) totals[subject] = { minutes: 0, sessions: 0 }; totals[subject].minutes += sessionActualMinutes(item); totals[subject].sessions += 1; }); return totals; }
function courseStudyMinutes(courseId) { const course = state.courses.find((item) => item.id === courseId); return completedFocusSessions().filter((item) => item.courseId === courseId || (!item.courseId && item.courseTitle === course?.title)).reduce((sum, item) => sum + sessionActualMinutes(item), 0); }
function playUiSound(kind = "soft") {
  if (!state.settings.soundEnabled || Number(state.settings.soundVolume || 0) <= 0) return;
  try {
    uiSoundCtx ||= new (window.AudioContext || window.webkitAudioContext)();
    const ctx = uiSoundCtx;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const volume = Math.max(0, Math.min(0.18, Number(state.settings.soundVolume || 35) / 600));
    osc.type = "sine";
    osc.frequency.value = kind === "complete" ? 740 : 440;
    gain.gain.setValueAtTime(0, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(volume, ctx.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.22);
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.24);
  } catch {}
}
function setActiveTab(tab) {
  const button = document.querySelector(".tab-button[data-tab='" + tab + "']");
  const panel = $("#tab-" + tab);
  if (!button || !panel) return;
  setAnalyticsXpOpen(false);
  if (button.closest(".secondary-nav") && el.sidebarMoreNav) el.sidebarMoreNav.open = true;
  $$(".tab-button").forEach((b) => b.classList.toggle("active", b === button));
  $$(".tab-panel").forEach((p) => p.classList.toggle("active", p === panel));
  renderHeader();
  if (tab === "focus") rotateFocusQuote();
  if (tab === "analytics") requestAnimationFrame(() => renderAnalytics());
  if (tab === "daily") requestAnimationFrame(() => renderMissions());
}

function guidedTourIsEligible() {
  const profile = state.profile || {};
  return Boolean(profile.onboarded)
    && profile.guidedTourStatus === "not_started"
    && Number(profile.guidedTourVersion) === GUIDED_TOUR_VERSION;
}

function guidedTourStoredStep() {
  return Math.max(0, Math.min(GUIDED_TOUR_STEPS.length - 1, Number(state.profile?.guidedTourStep) || 0));
}

function guidedTourHandoff() {
  return normalizeGuidedTourHandoff(state.profile?.guidedTourHandoff);
}

function guidedTourCourseRequirementMet() {
  const handoff = guidedTourHandoff();
  return handoff ? Boolean(savedVideoCourse(handoff.url)) : state.courses.length > 0;
}

function guidedTourCourseFormIsReady() {
  const handoff = guidedTourHandoff();
  return Boolean(handoff && canonicalYouTubeVideoUrl(el.courseUrlInput?.value || "") === handoff.url && !savedVideoCourse(handoff.url));
}

async function clearGuidedTourHandoff(handoffId = null) {
  const handoff = guidedTourHandoff();
  if (!handoff || (handoffId && handoff.id !== handoffId)) return false;
  await saveState({ ...state, profile: { ...(state.profile || {}), guidedTourHandoff: null } }, { skipGuidedTourRender: true });
  return true;
}

function currentDashboardTabId() {
  if (!hasChrome || !chrome.tabs) return Promise.resolve(null);
  return new Promise((resolve) => {
    if (!chrome.tabs.getCurrent) return resolve(null);
    try {
      chrome.tabs.getCurrent((tab) => {
        void chrome.runtime.lastError;
        resolve(Number.isInteger(tab?.id) && tab.id >= 0 ? tab.id : null);
      });
    } catch { resolve(null); }
  });
}

async function dashboardTabExists(tabId) {
  if (!Number.isInteger(tabId) || !hasChrome || !chrome.tabs?.get) return false;
  try {
    const tab = await chrome.tabs.get(tabId);
    return Boolean(tab?.url?.startsWith(chrome.runtime.getURL("dashboard.html")));
  } catch {
    return false;
  }
}

async function guidedTourOwnedByAnotherTab() {
  const storedTabId = Number(state.profile?.guidedTourTabId);
  if (!state.profile?.guidedTourActive || !Number.isInteger(storedTabId)) return false;
  if (guidedTourTabId && storedTabId === guidedTourTabId) return false;
  return dashboardTabExists(storedTabId);
}

async function persistGuidedTourSession(active, step = guidedTourStepIndex, tabId = guidedTourTabId) {
  const previousSessionId = state.profile?.guidedTourSessionId || null;
  const sessionId = active ? previousSessionId || uid("guided-tour-session") : previousSessionId;
  const nextProfile = {
    ...(state.profile || {}),
    guidedTourStatus: active ? "not_started" : (state.profile?.guidedTourStatus || "completed"),
    guidedTourVersion: GUIDED_TOUR_VERSION,
    guidedTourActive: Boolean(active),
    guidedTourStep: Math.max(0, Math.min(GUIDED_TOUR_STEPS.length - 1, Number(step) || 0)),
    guidedTourTabId: active && Number.isInteger(tabId) ? tabId : null,
    guidedTourSessionId: active ? sessionId : null,
    guidedTourUpdatedAt: Date.now()
  };
  await saveState({ ...state, profile: nextProfile }, { skipGuidedTourRender: true });
  if (hasChrome && sessionId) {
    try {
      await sendMessage({ type: "syncGuidedTourSession", payload: { active: Boolean(active), sessionId, step: nextProfile.guidedTourStep, tabId } });
    } catch {}
  }
}

function setGuidedTourSuspended(suspended) {
  guidedTourSuspended = Boolean(suspended);
  if (!el.guidedTour) return;
  el.guidedTour.classList.toggle("hidden", guidedTourSuspended || !guidedTourActive);
}

function nextAnimationFrame() {
  return new Promise((resolve) => requestAnimationFrame(resolve));
}

async function settleGuidedTourLayout() {
  // A tab change may schedule chart/list rendering for the following frame.
  await nextAnimationFrame();
  await nextAnimationFrame();
}

function guidedTourValue(value, step) {
  return typeof value === "function" ? value(step) : value;
}

function guidedTourTarget(step = GUIDED_TOUR_STEPS[guidedTourStepIndex]) {
  const selector = guidedTourValue(step?.selector, step);
  return selector ? document.querySelector(selector) : null;
}

function isGuidedTourTargetVisible(target) {
  if (!target?.isConnected || !target.getClientRects().length) return false;
  const rect = target.getBoundingClientRect();
  return rect.width > 1 && rect.height > 1;
}

function guidedTourSpotlightRect(target, step = GUIDED_TOUR_STEPS[guidedTourStepIndex], reservedBelow = 0) {
  if (!isGuidedTourTargetVisible(target)) return null;
  const rect = target.getBoundingClientRect();
  const inset = 7;
  const edge = 8;
  const left = Math.max(edge, rect.left - inset);
  const top = Math.max(edge, rect.top - inset);
  const right = Math.min(window.innerWidth - edge, rect.right + inset);
  let bottom = Math.min(window.innerHeight - edge, rect.bottom + inset);
  // Workspace steps show the real dashboard area, but intentionally leave a
  // usable strip below it for the coach mark and its navigation controls.
  if (guidedTourValue(step?.spotlight, step) === "workspace") {
    const minimumHeight = 112;
    const preferredBottom = top + Math.max(190, Math.floor(window.innerHeight * .56));
    const reservedBottom = window.innerHeight - 12 - Math.max(0, reservedBelow);
    const availableBottom = reservedBottom > top + minimumHeight ? reservedBottom : preferredBottom;
    bottom = Math.min(bottom, preferredBottom, availableBottom);
  }
  if (right <= left || bottom <= top) return null;
  return { left, top, right, bottom, width: right - left, height: bottom - top };
}

function guidedTourRectsOverlap(first, second) {
  return first.left < second.right && first.right > second.left && first.top < second.bottom && first.bottom > second.top;
}

async function settleGuidedTourTarget(step) {
  await settleGuidedTourLayout();
  let target = guidedTourTarget(step);
  if (!isGuidedTourTargetVisible(target)) return null;
  const initialRect = target.getBoundingClientRect();
  const edge = 18;
  const spotlightMode = guidedTourValue(step?.spotlight, step);
  const workspaceStep = spotlightMode === "workspace";
  const focusStep = spotlightMode === "focus";
  const needsWorkspaceTopRoom = (workspaceStep || focusStep) && initialRect.top > Math.max(90, Math.floor(window.innerHeight * .22));
  const outsideViewport = initialRect.left < edge || initialRect.right > window.innerWidth - edge
    || (workspaceStep ? initialRect.bottom < edge || initialRect.top > window.innerHeight - edge : initialRect.top < edge || initialRect.bottom > window.innerHeight - edge);
  if (outsideViewport || needsWorkspaceTopRoom) {
    target.scrollIntoView({ block: workspaceStep || focusStep ? "start" : "center", inline: "nearest", behavior: "auto" });
    await settleGuidedTourLayout();
    target = guidedTourTarget(step);
  }
  return isGuidedTourTargetVisible(target) ? target : null;
}

function positionGuidedTour(target = null, step = GUIDED_TOUR_STEPS[guidedTourStepIndex]) {
  if (!guidedTourActive || !el.guidedTourCard || !el.guidedTourSpotlight || !el.guidedTour) return;
  const card = el.guidedTourCard;
  const spotlight = el.guidedTourSpotlight;
  const workspaceStep = guidedTourValue(step?.spotlight, step) === "workspace";
  card.style.removeProperty("visibility");
  if (workspaceStep) {
    card.style.maxHeight = Math.max(180, Math.floor(window.innerHeight * .42)) + "px";
  } else {
    card.style.removeProperty("max-height");
  }
  const cardWidth = card.getBoundingClientRect().width || Math.min(360, window.innerWidth - 24);
  const cardHeight = card.getBoundingClientRect().height || 220;
  const gap = 14;
  const spotlightRect = guidedTourSpotlightRect(target, step, workspaceStep ? cardHeight + gap : 0);
  const hasTarget = Boolean(spotlightRect);
  el.guidedTour.classList.toggle("has-spotlight", hasTarget);
  el.guidedTour.classList.toggle("is-centered", !hasTarget);
  el.guidedTour.classList.remove("is-fallback");
  if (!hasTarget) {
    ["left", "top", "width", "height"].forEach((property) => spotlight.style.removeProperty(property));
    card.style.removeProperty("left");
    card.style.removeProperty("top");
    card.style.removeProperty("max-height");
    card.style.removeProperty("visibility");
    return;
  }
  const { left, top, right, bottom, width, height } = spotlightRect;
  spotlight.style.left = left + "px";
  spotlight.style.top = top + "px";
  spotlight.style.width = width + "px";
  spotlight.style.height = height + "px";
  const edge = 12;
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const centeredLeft = clamp(left + (width - cardWidth) / 2, edge, window.innerWidth - cardWidth - edge);
  const candidates = [
    { left: centeredLeft, top: bottom + gap },
    { left: centeredLeft, top: top - cardHeight - gap },
    { left: right + gap, top: clamp(top, edge, window.innerHeight - cardHeight - edge) },
    { left: left - cardWidth - gap, top: clamp(top, edge, window.innerHeight - cardHeight - edge) }
  ];
  const fitsWithoutOverlap = (candidate) => {
    const cardRect = { left: candidate.left, top: candidate.top, right: candidate.left + cardWidth, bottom: candidate.top + cardHeight };
    return candidate.left >= edge && candidate.top >= edge
      && cardRect.right <= window.innerWidth - edge && cardRect.bottom <= window.innerHeight - edge
      && !guidedTourRectsOverlap(cardRect, spotlightRect);
  };
  const position = candidates.find(fitsWithoutOverlap);
  const cornerPositions = [
    { left: edge, top: edge },
    { left: window.innerWidth - cardWidth - edge, top: edge },
    { left: edge, top: window.innerHeight - cardHeight - edge },
    { left: window.innerWidth - cardWidth - edge, top: window.innerHeight - cardHeight - edge }
  ];
  const fallback = cornerPositions.find(fitsWithoutOverlap);
  const resolvedPosition = position || fallback;
  if (!resolvedPosition) {
    // Exact controls are deliberately small; this only occurs in an unusually short viewport.
    // Keep the card visible without ever placing it over the highlighted control.
    el.guidedTour.classList.add("is-fallback");
    card.style.maxHeight = Math.max(154, Math.floor(window.innerHeight * .42)) + "px";
    const reducedHeight = card.getBoundingClientRect().height;
    const reducedCorners = [
      { left: edge, top: edge },
      { left: window.innerWidth - cardWidth - edge, top: edge },
      { left: edge, top: window.innerHeight - reducedHeight - edge },
      { left: window.innerWidth - cardWidth - edge, top: window.innerHeight - reducedHeight - edge }
    ].find((candidate) => {
      const cardRect = { left: candidate.left, top: candidate.top, right: candidate.left + cardWidth, bottom: candidate.top + reducedHeight };
      return candidate.left >= edge && candidate.top >= edge && cardRect.right <= window.innerWidth - edge && cardRect.bottom <= window.innerHeight - edge && !guidedTourRectsOverlap(cardRect, spotlightRect);
    });
    if (reducedCorners) {
      card.style.left = reducedCorners.left + "px";
      card.style.top = reducedCorners.top + "px";
    } else {
      // Keep the coach mark usable even when the target fills an unusually short viewport.
      // The body scrolls independently, so the footer remains available at normal zoom.
      const visibleHeight = Math.min(reducedHeight, Math.max(120, window.innerHeight - edge * 2));
      card.style.maxHeight = visibleHeight + "px";
      card.style.left = clamp(centeredLeft, edge, window.innerWidth - cardWidth - edge) + "px";
      card.style.top = clamp(window.innerHeight - visibleHeight - edge, edge, window.innerHeight - edge) + "px";
    }
    return;
  }
  if (!workspaceStep) card.style.removeProperty("max-height");
  card.style.left = resolvedPosition.left + "px";
  card.style.top = resolvedPosition.top + "px";
}

function queueGuidedTourPosition() {
  if (!guidedTourActive || guidedTourSuspended || guidedTourPositionFrame) return;
  guidedTourPositionFrame = requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      guidedTourPositionFrame = 0;
      positionGuidedTour(guidedTourTarget(), GUIDED_TOUR_STEPS[guidedTourStepIndex]);
    });
  });
}

async function renderGuidedTourStep() {
  if (!guidedTourActive || guidedTourSuspended || !el.guidedTour) return;
  const step = GUIDED_TOUR_STEPS[guidedTourStepIndex] || GUIDED_TOUR_STEPS[0];
  const stepTab = guidedTourValue(step.tab, step);
  if (stepTab) setActiveTab(stepTab);
  const courseFormReady = guidedTourCourseFormIsReady();
  const courseFormTitleMissing = courseFormReady && !safeYouTubeTitle(el.courseTitleInput?.value, "");
  const waitingForCourse = Boolean(step.waitForCourse && !guidedTourCourseRequirementMet());
  const isCoursesStep = step.action === "courses";
  const isAnalyticsStep = step.action === "analytics";
  const isPopupStep = step.action === "popup";
  const isSettingsStep = step.action === "settings";
  if (isSettingsStep && !siteControlExpanded) {
    setSiteControlExpanded(true);
    await new Promise((resolve) => setTimeout(resolve, 260));
  }
  el.guidedTourTitle.textContent = courseFormReady ? (courseFormTitleMissing ? "Add the video title" : "Your video is ready") : guidedTourValue(step.title, step);
  el.guidedTourDescription.textContent = courseFormReady
    ? (courseFormTitleMissing ? "Enter the title in Name, then click Add Course to save your video." : "Your video is ready. Now click Add Course to save it.")
    : guidedTourValue(step.text, step);
  el.guidedTourProgressText.textContent = (guidedTourStepIndex + 1) + " of " + GUIDED_TOUR_STEPS.length;
  el.guidedTourProgressFill.style.width = ((guidedTourStepIndex + 1) / GUIDED_TOUR_STEPS.length * 100) + "%";
  el.guidedTourBackBtn.disabled = guidedTourStepIndex === 0;
  el.guidedTourNextBtn.disabled = waitingForCourse;
  el.guidedTourNextBtn.textContent = step.action === "start" ? "Start guided tour" : step.action === "completion" ? (state.courses.length ? "Start focusing" : "Add a course") : isCoursesStep ? "Continue" : "Next";
  el.guidedTourCoursesFlow?.classList.toggle("hidden", !isCoursesStep);
  el.guidedTourAnalyticsPreview?.classList.toggle("hidden", !isAnalyticsStep);
  el.guidedTourPopupGuide?.classList.toggle("hidden", !isPopupStep);
  el.guidedTourDistractionGuide?.classList.toggle("hidden", !isSettingsStep);
  el.guidedTour.classList.toggle("is-external-step", isPopupStep);
  el.guidedTourYouTubeBtn?.classList.toggle("hidden", !isCoursesStep);
  const courseNeedsYouTube = isCoursesStep && !courseFormReady && waitingForCourse;
  el.guidedTourYouTubeBtn?.classList.toggle("primary", courseNeedsYouTube);
  el.guidedTourYouTubeBtn?.classList.toggle("secondary", !courseNeedsYouTube);
  el.guidedTourNextBtn?.classList.toggle("primary", !courseNeedsYouTube);
  el.guidedTourNextBtn?.classList.toggle("secondary", courseNeedsYouTube);
  const canOpenPopup = Boolean(globalThis.chrome?.action?.openPopup);
  el.guidedTourPopupBtn?.classList.toggle("hidden", !isPopupStep || !canOpenPopup);
  const target = await settleGuidedTourTarget(step);
  if (!guidedTourActive || guidedTourSuspended) return;
  positionGuidedTour(target, step);
  if (!waitingForCourse) el.guidedTourNextBtn.focus({ preventScroll: true });
}

async function startGuidedTour({ restart = false } = {}) {
  if (!el.guidedTour || guidedTourActive || !state.profile?.onboarded) return;
  if (!el.onboardingOverlay?.classList.contains("hidden")) return;
  guidedTourTabId = await currentDashboardTabId();
  if (hasChrome && !Number.isInteger(guidedTourTabId)) {
    showToast("Open Studizen in a browser tab before starting the guided tour.");
    return;
  }
  if (restart) {
    if (await guidedTourOwnedByAnotherTab()) return;
    await saveState({ ...state, profile: { ...(state.profile || {}), guidedTourStatus: "not_started", guidedTourVersion: GUIDED_TOUR_VERSION, guidedTourActive: false, guidedTourStep: 0, guidedTourTabId: null, guidedTourSessionId: null, guidedTourHandoff: null, guidedTourUpdatedAt: Date.now() } }, { skipGuidedTourRender: true });
  }
  if (!guidedTourIsEligible()) return;
  if (await guidedTourOwnedByAnotherTab()) return;
  guidedTourAutoStartHandled = true;
  guidedTourActive = true;
  guidedTourStepIndex = state.profile?.guidedTourActive ? guidedTourStoredStep() : 0;
  await persistGuidedTourSession(true, guidedTourStepIndex, guidedTourTabId);
  document.body.classList.add("guided-tour-active");
  el.guidedTour.classList.remove("hidden");
  await renderGuidedTourStep();
}

async function finishGuidedTour(status) {
  if (!guidedTourActive) return;
  const nextStatus = status === "completed" ? "completed" : "skipped";
  guidedTourActive = false;
  guidedTourSuspended = false;
  guidedTourTransition = false;
  if (guidedTourPositionFrame) cancelAnimationFrame(guidedTourPositionFrame);
  guidedTourPositionFrame = 0;
  document.body.classList.remove("guided-tour-active");
  el.guidedTour?.classList.add("hidden");
  const endedSessionId = state.profile?.guidedTourSessionId || null;
  await saveState({ ...state, profile: { ...(state.profile || {}), guidedTourStatus: nextStatus, guidedTourVersion: GUIDED_TOUR_VERSION, guidedTourActive: false, guidedTourStep: 0, guidedTourTabId: null, guidedTourSessionId: null, guidedTourHandoff: null, guidedTourUpdatedAt: Date.now() } }, { skipGuidedTourRender: true });
  if (hasChrome && endedSessionId) {
    try { await sendMessage({ type: "syncGuidedTourSession", payload: { active: false, sessionId: endedSessionId, tabId: guidedTourTabId } }); } catch {}
  }
  showToast(nextStatus === "completed" ? "Guided tour complete." : "Guided tour skipped. Start it again from Settings whenever you want.");
}

async function maybeStartGuidedTour() {
  if (guidedTourAutoStartHandled || guidedTourActive || !guidedTourIsEligible()) return;
  guidedTourTabId ||= await currentDashboardTabId();
  if (await guidedTourOwnedByAnotherTab()) {
    guidedTourAutoStartHandled = true;
    return;
  }
  guidedTourAutoStartHandled = true;
  setTimeout(() => { void startGuidedTour(); }, 260);
}

async function moveGuidedTour(stepChange) {
  if (!guidedTourActive || guidedTourTransition) return;
  const currentStep = GUIDED_TOUR_STEPS[guidedTourStepIndex];
  if (stepChange > 0 && currentStep?.waitForCourse && !guidedTourCourseRequirementMet()) return;
  guidedTourTransition = true;
  try {
    const nextIndex = guidedTourStepIndex + stepChange;
    if (nextIndex >= GUIDED_TOUR_STEPS.length) {
      if (currentStep?.action === "completion" && !state.courses.length) setActiveTab("courses");
      return finishGuidedTour("completed");
    }
    guidedTourStepIndex = Math.max(0, nextIndex);
    await persistGuidedTourSession(true, guidedTourStepIndex, guidedTourTabId);
    const nextStep = GUIDED_TOUR_STEPS[guidedTourStepIndex];
    if (nextStep?.action === "completion") setActiveTab(guidedTourValue(nextStep.tab, nextStep));
    await renderGuidedTourStep();
  } finally {
    guidedTourTransition = false;
  }
}

function syncGuidedTourToManualTab(tab) {
  if (!guidedTourActive) return;
  const currentStep = GUIDED_TOUR_STEPS[guidedTourStepIndex];
  if (currentStep?.waitForCourse && !guidedTourCourseRequirementMet() && tab !== "courses") {
    setActiveTab("courses");
    void renderGuidedTourStep();
    return;
  }
  const stepIndex = GUIDED_TOUR_TAB_STEPS[tab];
  if (stepIndex === undefined || stepIndex === guidedTourStepIndex) {
    queueGuidedTourPosition();
    return;
  }
  guidedTourStepIndex = stepIndex;
  void persistGuidedTourSession(true, guidedTourStepIndex, guidedTourTabId);
  void renderGuidedTourStep();
}

async function openGuidedTourPopup() {
  if (!globalThis.chrome?.action?.openPopup) {
    showToast("Click the Studizen icon in Chrome's toolbar to open the popup.");
    return;
  }
  try {
    await chrome.action.openPopup();
  } catch {
    showToast("Click the Studizen icon in Chrome's toolbar to open the popup.");
  }
}

async function openGuidedTourYouTube() {
  if (!guidedTourActive) return;
  await persistGuidedTourSession(true, guidedTourStepIndex, guidedTourTabId);
  if (!hasChrome || !chrome.tabs?.create) {
    showToast("Open YouTube in another tab, then use Add to Studizen on a video thumbnail.");
    return;
  }
  try {
    await chrome.tabs.create({ url: "https://www.youtube.com/", active: true });
  } catch {
    showToast("Could not open YouTube. Use the Studizen shortcut from a YouTube video instead.");
  }
}

async function resumeGuidedTourYouTubeHandoff(handoffId, expectedTabId = null, expectedSessionId = null, expectedVideoUrl = "", expectedVideoTitle = null) {
  await loadState();
  const handoff = guidedTourHandoff();
  const ownTabId = await currentDashboardTabId();
  if (!handoff || handoff.id !== handoffId || handoff.step !== 2) return false;
  if (expectedTabId && ownTabId !== Number(expectedTabId)) return false;
  if (expectedSessionId && handoff.sessionId !== expectedSessionId) return false;
  if (state.profile?.guidedTourSessionId && handoff.sessionId !== state.profile.guidedTourSessionId) return false;
  if (expectedVideoUrl && canonicalYouTubeVideoUrl(expectedVideoUrl) !== handoff.url) return false;
  if (expectedVideoTitle !== null && safeYouTubeTitle(expectedVideoTitle, "") !== handoff.title) return false;
  if (!state.profile?.guidedTourActive || state.profile.guidedTourStatus !== "not_started") return false;
  guidedTourTabId = ownTabId || handoff.tabId || guidedTourTabId;
  guidedTourStepIndex = handoff.step;
  guidedTourActive = true;
  guidedTourSuspended = false;
  document.body.classList.add("guided-tour-active");
  el.guidedTour?.classList.remove("hidden");
  await persistGuidedTourSession(true, guidedTourStepIndex, guidedTourTabId);
  setActiveTab("courses");
  return prepareGuidedTourCourseAdd(handoff.url, handoff.title, handoff.id);
}

function rotateFocusQuote() {
  if (!el.focusQuote || !FOCUS_QUOTES.length) return;
  let index = Math.floor(Math.random() * FOCUS_QUOTES.length);
  if (FOCUS_QUOTES.length > 1 && index === focusQuoteIndex) index = (index + 1) % FOCUS_QUOTES.length;
  focusQuoteIndex = index;
  focusQuoteShown = true;
  el.focusQuote.textContent = FOCUS_QUOTES[index];
}

async function loadState() {
  document.body.classList.add("is-loading");
  if (hasChrome) {
    const result = await sendMessage({ type: "getState" });
    if (result?.ok) state = ensureToday(mergeState(result.response));
    else {
      const data = await chrome.storage.local.get(STATE_KEY);
      state = ensureToday(mergeState(data[STATE_KEY]));
    }
  } else {
    try { state = ensureToday(mergeState(JSON.parse(localStorage.getItem(STATE_KEY) || "null"))); } catch { state = defaultState(); }
  }
  applyTheme();
  render();
  void refreshIncognitoAccessStatus();
  document.body.classList.remove("is-loading");
}
async function saveState(next, options = {}) {
  const candidate = ensureToday(mergeState(next));
  if (hasChrome) {
    const result = await sendMessage({ type: "saveState", patch: createStatePatch(state, candidate) });
    if (!result?.ok) throw new Error(result?.error || "Could not save your changes.");
    state = ensureToday(mergeState(result.response));
  } else {
    state = candidate;
    localStorage.setItem(STATE_KEY, JSON.stringify(state));
  }
  applyTheme();
  render();
  if (guidedTourActive && !options.skipGuidedTourRender) void renderGuidedTourStep();
}
async function updateSettings(patch, options = {}) { await saveState({ ...state, settings: { ...state.settings, ...patch } }, options); }
async function addCurrentSupportingSite() {
  if (!hasChrome || !chrome.tabs?.query) return showToast("Open this in Chrome to add a supporting site.");
  const tabs = await chrome.tabs.query({});
  const candidate = tabs
    .filter((tab) => {
      const url = safeUrl(tab.url);
      return url && ["http:", "https:"].includes(url.protocol);
    })
    .sort((a, b) => Number(b.lastAccessed || 0) - Number(a.lastAccessed || 0))[0];
  const url = safeUrl(candidate?.url);
  if (!url) return showToast("Open a website first, then add it as a supporting site.");
  const domain = url.hostname.replace(/^www\./, "").toLowerCase();
  if (state.settings.allowedSites.includes(domain)) return showToast(domain + " is already allowed.");
  await updateSettings({ allowedSites: cleanPatterns([...state.settings.allowedSites, domain]) });
  showToast(domain + " is now allowed during Focus Mode.");
}

function fillSelects() {
  [el.studyProfileSelect].forEach((select) => {
    if (!select) return;
    const selected = state.profile?.studyProfile || "jee";
    select.innerHTML = "";
    STUDY_PROFILES.forEach((profile) => { const option = document.createElement("option"); option.value = profile.id; option.textContent = profile.name; option.selected = profile.id === selected; select.append(option); });
  });
  [el.courseSubjectInput].forEach((select) => {
    if (!select) return;
    const selected = normalizeSubject(select.value || "Other", state.profile?.studyProfile, currentSubjects());
    select.innerHTML = "";
    currentSubjects().forEach((subject) => { const option = document.createElement("option"); option.value = subject; option.textContent = subject; option.selected = subject === selected; select.append(option); });
  });
  if (el.courseLibraryInput) {
    const selected = el.courseLibraryInput.value || state.courseLibraries?.[0]?.id || "library-main";
    el.courseLibraryInput.innerHTML = "";
    (state.courseLibraries || []).forEach((library) => {
      const option = document.createElement("option");
      option.value = library.id;
      option.textContent = library.name;
      option.selected = library.id === selected;
      el.courseLibraryInput.append(option);
    });
  }
}

function renderHeader() {
  const session = activeSession();
  const course = getActiveCourse(state);
  const activeTab = document.querySelector(".tab-panel.active")?.id.replace("tab-", "") || "focus";
  const header = dashboardHeaderPresentation({ tab: activeTab, session, course, profileName: state.profile?.name });
  el.connectionLabel.textContent = hasChrome ? "Chrome extension active" : "Preview mode";
  el.stateEyebrow.textContent = header.eyebrow;
  el.mainTitle.textContent = header.title;
  if (el.activeFocusIndicator) el.activeFocusIndicator.hidden = !header.showSessionIndicator;
  if (header.showSessionIndicator) {
    if (el.activeFocusStatus) el.activeFocusStatus.textContent = header.sessionStatus;
    if (el.activeFocusCourse) {
      el.activeFocusCourse.textContent = header.sessionTitle;
      el.activeFocusCourse.title = el.activeFocusCourse.textContent;
    }
  }
  if (el.focusOpenCourseBtn) el.focusOpenCourseBtn.disabled = !course;
  el.stopFocusBtn.classList.toggle("hidden", !session);
}
function renderClock() {
  if (!el.liveClock) return;
  el.liveClock.textContent = "\uD83D\uDD52 " + new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  if ($("#tab-focus")?.classList.contains("active")) renderHeader();
}
function renderFocus() {
  const session = activeSession();
  const course = getActiveCourse(state);
  el.courseSelect.value = course?.id || "";
  el.durationInput.value = state.settings.focusMinutesDefault || 50;
  el.redirectEnabledInput.checked = Boolean(state.settings.redirectEnabled);
  el.todayFocus.textContent = formatDuration(actualMinutesToday());
  el.todaySessions.textContent = String(completedSessionsToday());
  if (el.todayBlocks) el.todayBlocks.textContent = String(state.stats.distractions || 0);
  el.todayScore.textContent = String(productivityScore(state));
  el.selectedCourseTitle.textContent = course?.title || "No course selected";
  el.selectedCourseMeta.textContent = course ? (course.subject || "Other") + " - " + safeUrl(course.url)?.hostname.replace(/^www\./, "") : "Choose a course in the Courses tab.";
  const circumference = 427;
  if (!session) {
    lastLiveFocusMinutes = null;
    el.focusHeadline.textContent = course ? "Ready to focus?" : "Choose a course";
    el.focusPill.textContent = course ? "Ready" : "Choose course";
    el.focusPill.classList.remove("active");
    el.startFocusBtn.disabled = !course || focusActionPending;
    el.startFocusBtn.textContent = "Start Focus";
    el.pauseFocusBtn?.classList.remove("hidden");
    if (el.pauseFocusBtn) el.pauseFocusBtn.disabled = true;
    el.resumeFocusBtn?.classList.add("hidden");
    el.stopFocusBtn.classList.add("hidden");
    el.focusRemainingText?.classList.add("hidden");
    el.timerProgress.style.strokeDashoffset = String(circumference);
    el.timerText.textContent = "00:00";
    el.timerCaption.textContent = course ? "Ready to begin" : "Choose a course";
    renderCameraAttention(null);
    return;
  }
  const totalMs = session.durationMinutes * 60000;
  const remainingMs = sessionRemainingMs(session);
  const ratio = Math.min(1, Math.max(0, 1 - remainingMs / Math.max(1, totalMs)));
  const remainingText = formatClock(remainingMs) + " remaining";
  el.focusHeadline.textContent = session.paused ? "Focus Paused" : "Focus Session Active";
  el.focusPill.textContent = session.paused ? "Paused" : "Active";
  el.startFocusBtn.disabled = true;
  el.startFocusBtn.textContent = session.paused ? "Focus Paused" : "Focus Session Active";
  el.pauseFocusBtn?.classList.toggle("hidden", session.paused);
  if (el.pauseFocusBtn) el.pauseFocusBtn.disabled = session.paused || focusActionPending;
  el.resumeFocusBtn?.classList.toggle("hidden", !session.paused);
  if (el.resumeFocusBtn) el.resumeFocusBtn.disabled = !session.paused || focusActionPending;
  el.stopFocusBtn.classList.remove("hidden");
  el.focusPill.classList.add("active");
  el.timerProgress.style.strokeDashoffset = String(circumference - circumference * ratio);
  el.timerText.textContent = formatClock(remainingMs);
  const percentComplete = Math.round(ratio * 100);
  el.timerCaption.textContent = session.paused ? percentComplete + "% complete - paused" : percentComplete + "% complete";
  if (el.focusRemainingText) {
    el.focusRemainingText.textContent = remainingText;
    el.focusRemainingText.classList.remove("hidden");
  }
  renderCameraAttention(session);
}
function renderFocusTick() {
  const session = activeSession();
  if (!session) return;
  const circumference = 427;
  const totalMs = Math.max(1, Number(session.durationMinutes || 0) * 60000);
  const remainingMs = sessionRemainingMs(session);
  const ratio = Math.min(1, Math.max(0, 1 - remainingMs / totalMs));
  const percentComplete = Math.round(ratio * 100);
  el.timerProgress.style.strokeDashoffset = String(circumference - circumference * ratio);
  el.timerText.textContent = formatClock(remainingMs);
  el.timerCaption.textContent = session.paused ? percentComplete + "% complete - paused" : percentComplete + "% complete";
  if (el.focusRemainingText) {
    el.focusRemainingText.textContent = formatClock(remainingMs) + " remaining";
    el.focusRemainingText.classList.remove("hidden");
  }
  const liveMinutes = actualMinutesToday();
  if (liveMinutes !== lastLiveFocusMinutes) {
    lastLiveFocusMinutes = liveMinutes;
    el.todayFocus.textContent = formatDuration(liveMinutes);
    el.todayScore.textContent = String(productivityScore(state));
    renderTodayInsight();
    if ($("#tab-daily")?.classList.contains("active")) renderSystemGoals();
    if ($("#tab-analytics")?.classList.contains("active")) {
      el.goalProgress.textContent = goalProgressPercent(state) + "%";
      const weeklyMinutes = actualFocusSessions(7).reduce((sum, item) => sum + sessionActualMinutes(item), 0) + focusElapsedMinutes(session);
      const avgMinutes = Math.round(weeklyMinutes / 7);
      if (el.averageStudy) el.averageStudy.textContent = hours(avgMinutes);
      const todayMinutes = liveMinutes;
      if (el.dailyComparison) el.dailyComparison.textContent = (todayMinutes >= avgMinutes ? "+" : "-") + formatDuration(Math.abs(todayMinutes - avgMinutes));
    }
  }
}
function renderTodayInsight() {
  if (!el.todayInsightTitle || !el.todayInsightText) return;
  const insight = buildTodayInsight(state);
  el.todayInsightTitle.textContent = insight.title;
  el.todayInsightText.textContent = insight.text;
}
function renderCourses() {
  fillSelects();
  el.courseCount.textContent = state.courses.length + (state.courses.length === 1 ? " course" : " courses");
  renderCourseOverview();
  renderCourseLibraries();
}
function courseName(courseId) { return state.courses.find((course) => course.id === courseId)?.title || "General study"; }
function escapeHtml(value = "") { return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;"); }
function inlineMarkdown(value = "") {
  return escapeHtml(value)
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/\*([^*]+)\*/g, "<em>$1</em>")
    .replace(/\[([^\]]+)]\((https?:\/\/[^\s)]+)\)/g, "<a href=\"$2\" target=\"_blank\" rel=\"noopener\">$1</a>");
}
function renderMarkdownPreview(value = "") {
  return String(value).split(/\r?\n/).map((line) => {
    if (/^###\s+/.test(line)) return "<h5>" + inlineMarkdown(line.replace(/^###\s+/, "")) + "</h5>";
    if (/^##\s+/.test(line)) return "<h4>" + inlineMarkdown(line.replace(/^##\s+/, "")) + "</h4>";
    if (/^#\s+/.test(line)) return "<h3>" + inlineMarkdown(line.replace(/^#\s+/, "")) + "</h3>";
    if (/^-\s+/.test(line)) return "<p class=\"markdown-bullet\">• " + inlineMarkdown(line.replace(/^-\s+/, "")) + "</p>";
    return line ? "<p>" + inlineMarkdown(line) + "</p>" : "<br>";
  }).join("");
}
function readNoteDraft() { try { return JSON.parse(localStorage.getItem(NOTE_DRAFT_KEY) || "null"); } catch { return null; } }
function clearNoteDraft() { clearTimeout(noteDraftTimer); localStorage.removeItem(NOTE_DRAFT_KEY); }
function queueNoteDraft() {
  clearTimeout(noteDraftTimer);
  noteDraftTimer = setTimeout(() => {
    const draft = {
      courseId: el.noteCourseInput?.value || "",
      title: el.noteTitleInput?.value || "",
      body: el.noteBodyInput?.value || "",
      checklist: el.noteChecklistInput?.value || "",
      pinned: Boolean(el.notePinnedInput?.checked),
      selectedNoteId
    };
    if (draft.title || draft.body || draft.checklist) localStorage.setItem(NOTE_DRAFT_KEY, JSON.stringify(draft));
  }, 450);
}
function noteChecklistFromInput(value) { return String(value || "").split("|").map((item) => item.trim()).filter(Boolean).slice(0, 80).map((text) => ({ id: uid("check"), text, done: false })); }
function setNoteEditor(note = null) {
  const draft = note ? null : readNoteDraft();
  selectedNoteId = note?.id || draft?.selectedNoteId || null;
  if (!el.noteForm) return;
  el.noteCourseInput.value = note?.courseId || draft?.courseId || state.settings.defaultCourseId || "";
  el.noteTitleInput.value = note?.title || draft?.title || "";
  el.noteBodyInput.value = note?.body || draft?.body || "";
  el.noteChecklistInput.value = note ? (note.checklist || []).map((item) => item.text).join(" | ") : (draft?.checklist || "");
  el.notePinnedInput.checked = note ? Boolean(note.pinned) : Boolean(draft?.pinned);
  el.noteSaveBtn.textContent = note ? "Update Note" : "Save Note";
  renderNoteCharacterCount();
}
function renderNoteCharacterCount() {
  if (el.noteCharacterCount) el.noteCharacterCount.textContent = (el.noteBodyInput?.value?.length || 0).toLocaleString() + " / 50,000";
}
function renderNotes() {
  if (!el.noteList) return;
  renderNoteCharacterCount();
  const search = String(el.noteSearchInput?.value || "").trim().toLowerCase();
  const notes = [...state.notes].filter((note) => !search || [note.title, note.body, note.checklist.map((item) => item.text).join(" "), courseName(note.courseId)].join(" ").toLowerCase().includes(search)).sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt - a.updatedAt);
  el.noteList.innerHTML = "";
  if (!notes.length) {
    el.noteList.innerHTML = "<div class='empty-state compact-empty'><h4>No notes yet</h4><p>Save a short summary, formula, or checklist for the course you are studying.</p></div>";
    return;
  }
  notes.forEach((note) => {
    const card = document.createElement("article");
    card.className = "note-card" + (note.pinned ? " pinned" : "");
    card.innerHTML = "<div class='note-card-header'><div><span class='tag'></span><h4></h4><p></p></div><div class='note-actions'><button class='button secondary compact-button edit' type='button'>Edit</button><button class='icon-button danger remove' type='button' aria-label='Delete note'>x</button></div></div><div class='note-body'></div><div class='note-checklist'></div>";
    card.querySelector(".tag").textContent = note.pinned ? "Pinned" : courseName(note.courseId);
    card.querySelector("h4").textContent = note.title;
    card.querySelector(".note-card-header p").textContent = "Updated " + new Date(note.updatedAt).toLocaleDateString();
    card.querySelector(".note-body").innerHTML = note.body ? renderMarkdownPreview(note.body) : "<p>Checklist only</p>";
    const checklist = card.querySelector(".note-checklist");
    (note.checklist || []).forEach((item) => {
      const label = document.createElement("label");
      const check = document.createElement("input");
      check.type = "checkbox";
      check.checked = item.done;
      check.addEventListener("change", () => updateNote(note.id, { checklist: note.checklist.map((entry) => entry.id === item.id ? { ...entry, done: check.checked } : entry) }));
      const text = document.createElement("span");
      text.textContent = item.text;
      label.append(check, text);
      checklist.append(label);
    });
    card.querySelector(".edit").addEventListener("click", () => setNoteEditor(note));
    card.querySelector(".remove").addEventListener("click", () => deleteNote(note.id));
    el.noteList.append(card);
  });
}
async function updateNote(id, patch) {
  await saveState({ ...state, notes: state.notes.map((note) => note.id === id ? { ...note, ...patch, updatedAt: Date.now() } : note) });
}
async function saveNote(event) {
  event.preventDefault();
  const title = el.noteTitleInput.value.trim();
  const body = el.noteBodyInput.value.trim();
  const checklist = noteChecklistFromInput(el.noteChecklistInput.value);
  if (!title && !body && !checklist.length) return showToast("Add a title, note, or checklist first.");
  const previous = state.notes.find((note) => note.id === selectedNoteId);
  const next = {
    id: previous?.id || uid("note"),
    courseId: el.noteCourseInput.value || null,
    title: title || "Untitled note",
    body,
    checklist: previous?.checklist?.length && el.noteChecklistInput.value === previous.checklist.map((item) => item.text).join(" | ") ? previous.checklist : checklist,
    pinned: el.notePinnedInput.checked,
    createdAt: previous?.createdAt || Date.now(),
    updatedAt: Date.now()
  };
  await saveState({ ...state, notes: previous ? state.notes.map((note) => note.id === previous.id ? next : note) : [next, ...state.notes] });
  clearNoteDraft();
  setNoteEditor(null);
  showToast(previous ? "Note updated." : "Note saved.");
}
async function deleteNote(id) {
  const note = state.notes.find((item) => item.id === id);
  if (!note || !confirm("Delete note '" + note.title + "'?")) return;
  const previous = state;
  await saveState({ ...state, notes: state.notes.filter((item) => item.id !== id) });
  if (selectedNoteId === id) setNoteEditor(null);
  showUndo("Note deleted.", previous);
}
function exportNotes() {
  const blob = new Blob([JSON.stringify({ notes: state.notes }, null, 2)], { type: "application/json" });
  const anchor = document.createElement("a");
  anchor.href = URL.createObjectURL(blob);
  anchor.download = "studizen-notes.json";
  anchor.click();
  URL.revokeObjectURL(anchor.href);
}
async function importNotes(event) {
  const file = event.target.files?.[0];
  if (!file) return;
  try {
    const parsed = JSON.parse(await file.text());
    const incoming = Array.isArray(parsed) ? parsed : parsed.notes;
    if (!Array.isArray(incoming)) throw new Error("Invalid note backup.");
    const merged = [...state.notes];
    incoming.forEach((note) => {
      const index = merged.findIndex((item) => item.id === note.id);
      if (index >= 0) merged[index] = note; else merged.push(note);
    });
    await saveState({ ...state, notes: merged });
    showToast("Notes imported.");
  } catch { showToast("That note backup could not be imported."); }
  event.target.value = "";
}
function nextReviewCard() {
  const cards = state.flashcards || [];
  if (!cards.length) return null;
  const current = cards.find((card) => card.id === reviewFlashcardId);
  if (current) return current;
  return [...cards].sort((a, b) => (a.lastReviewedAt || 0) - (b.lastReviewedAt || 0))[0];
}
function renderFlashcards() {
  if (!el.flashcardReview || !el.flashcardList) return;
  const cards = state.flashcards || [];
  el.flashcardCount.textContent = cards.length + (cards.length === 1 ? " card" : " cards");
  const review = nextReviewCard();
  el.flashcardReview.innerHTML = "";
  if (!review) el.flashcardReview.innerHTML = "<div class='empty-state compact-empty'><h4>Ready when you are</h4><p>Add a question and answer pair to begin a quick revision.</p></div>";
  else {
    const card = document.createElement("article");
    card.className = "flashcard-review-card" + (flashcardAnswerVisible ? " revealed" : "");
    card.innerHTML = "<span></span><strong></strong><p></p><div class='flashcard-actions'></div>";
    card.querySelector("span").textContent = review.category + " - " + courseName(review.courseId);
    card.querySelector("strong").textContent = flashcardAnswerVisible ? "Answer" : "Question";
    card.querySelector("p").textContent = flashcardAnswerVisible ? review.back : review.front;
    const actions = card.querySelector(".flashcard-actions");
    if (!flashcardAnswerVisible) {
      const reveal = document.createElement("button");
      reveal.className = "button primary";
      reveal.type = "button";
      reveal.textContent = "Reveal Answer";
      reveal.addEventListener("click", () => { flashcardAnswerVisible = true; renderFlashcards(); });
      actions.append(reveal);
    } else {
      [["Again", "secondary"], ["I knew it", "primary"]].forEach(([label, tone]) => {
        const button = document.createElement("button");
        button.className = "button " + tone;
        button.type = "button";
        button.textContent = label;
        button.addEventListener("click", () => reviewFlashcard(review.id));
        actions.append(button);
      });
    }
    el.flashcardReview.append(card);
  }
  el.flashcardList.innerHTML = "";
  cards.slice().sort((a, b) => (b.lastReviewedAt || 0) - (a.lastReviewedAt || 0)).slice(0, 10).forEach((card) => {
    const row = document.createElement("article");
    row.className = "flashcard-row";
    row.innerHTML = "<div><span></span><strong></strong><p></p></div><button class='button secondary compact-button review' type='button'>Review</button><button class='icon-button danger remove' type='button' aria-label='Delete flashcard'>x</button>";
    row.querySelector("span").textContent = card.category;
    row.querySelector("strong").textContent = card.front;
    row.querySelector("p").textContent = card.reviews + " reviews";
    row.querySelector(".review").addEventListener("click", () => { reviewFlashcardId = card.id; flashcardAnswerVisible = false; renderFlashcards(); });
    row.querySelector(".remove").addEventListener("click", () => deleteFlashcard(card.id));
    el.flashcardList.append(row);
  });
}
async function addFlashcard(event) {
  event.preventDefault();
  const front = el.flashcardFrontInput.value.trim();
  const back = el.flashcardBackInput.value.trim();
  if (!front || !back) return showToast("Add both a question and an answer.");
  const card = { id: uid("card"), courseId: el.flashcardCourseInput.value || null, category: el.flashcardCategoryInput.value.trim() || "General", front, back, reviews: 0, lastReviewedAt: null, createdAt: Date.now() };
  await saveState({ ...state, flashcards: [card, ...state.flashcards] });
  el.flashcardForm.reset();
  flashcardAnswerVisible = false;
  reviewFlashcardId = card.id;
  showToast("Flashcard added.");
}
async function reviewFlashcard(id) {
  await saveState({ ...state, flashcards: state.flashcards.map((card) => card.id === id ? { ...card, reviews: (card.reviews || 0) + 1, lastReviewedAt: Date.now() } : card) });
  reviewFlashcardId = null;
  flashcardAnswerVisible = false;
}
async function deleteFlashcard(id) {
  if (!confirm("Delete this flashcard?")) return;
  await saveState({ ...state, flashcards: state.flashcards.filter((card) => card.id !== id) });
  if (reviewFlashcardId === id) reviewFlashcardId = null;
}
function resourceSource(url) {
  const host = safeUrl(url)?.hostname.replace(/^www\./, "").toLowerCase() || "resource";
  if (host === "youtu.be" || host.endsWith("youtube.com")) return { type: "youtube", label: "YouTube", host, mark: "YT" };
  return { type: "web", label: host, host, mark: host.slice(0, 2).toUpperCase() || "WEB" };
}
function studyLinkRecords() {
  return state.courses.flatMap((course) => {
    const primary = [{ id: "course:" + course.id, kind: "course", course, title: course.title, url: course.url, addedAt: Number(course.createdAt || 0), source: resourceSource(course.url) }];
    const videos = (Array.isArray(course.videos) ? course.videos : []).map((video) => ({ id: "video:" + course.id + ":" + video.id, kind: "video", course, video, title: video.title || "YouTube video", url: video.url, addedAt: Number(video.addedAt || course.createdAt || 0), source: resourceSource(video.url) }));
    return [...primary, ...videos];
  });
}
function resetStudyLinkFilters() {
  courseLibraryQuery = "";
  courseLibrarySource = "all";
  courseLibrarySort = "priority";
  courseLibraryLimit = 60;
  renderCourseLibraries();
}
function setCourseLibraryExpanded(expanded) {
  courseLibraryExpanded = Boolean(expanded);
  try { sessionStorage.setItem("courseFocusProStudyLinkLibraryExpanded", String(courseLibraryExpanded)); } catch {}
  if (el.studyLinkLibraryPanel) el.studyLinkLibraryPanel.dataset.expanded = String(courseLibraryExpanded);
  if (el.studyLinkLibraryToggle) el.studyLinkLibraryToggle.setAttribute("aria-expanded", String(courseLibraryExpanded));
}
function setSiteControlExpanded(expanded) {
  siteControlExpanded = Boolean(expanded);
  try { sessionStorage.setItem("courseFocusProSiteControlExpanded", String(siteControlExpanded)); } catch {}
  if (el.siteControlSection) el.siteControlSection.dataset.expanded = String(siteControlExpanded);
  if (el.siteControlToggle) el.siteControlToggle.setAttribute("aria-expanded", String(siteControlExpanded));
  if (el.siteControlBody) {
    el.siteControlBody.classList.toggle("is-expanded", siteControlExpanded);
    el.siteControlBody.setAttribute("aria-hidden", String(!siteControlExpanded));
    el.siteControlBody.toggleAttribute("inert", !siteControlExpanded);
  }
}
function setSettingsDisclosureExpanded(key, expanded) {
  if (!Object.hasOwn(settingsDisclosureExpanded, key)) return;
  settingsDisclosureExpanded[key] = Boolean(expanded);
  try { sessionStorage.setItem("studizenSettingsDisclosureExpanded", JSON.stringify(settingsDisclosureExpanded)); } catch {}
  const panel = document.querySelector("[data-settings-disclosure='" + key + "']");
  const toggles = document.querySelectorAll("[data-settings-disclosure-toggle='" + key + "']");
  const body = panel?.querySelector(".settings-disclosure-body");
  if (panel) panel.dataset.expanded = String(settingsDisclosureExpanded[key]);
  toggles.forEach((toggle) => toggle.setAttribute("aria-expanded", String(settingsDisclosureExpanded[key])));
  if (body) {
    body.classList.toggle("is-expanded", settingsDisclosureExpanded[key]);
    body.setAttribute("aria-hidden", String(!settingsDisclosureExpanded[key]));
    body.toggleAttribute("inert", !settingsDisclosureExpanded[key]);
  }
}
function sortStudyLinks(links) {
  const sorted = [...links];
  if (courseLibrarySort === "alpha") return sorted.sort((a, b) => a.title.localeCompare(b.title) || a.source.label.localeCompare(b.source.label));
  if (courseLibrarySort === "recent") return sorted.sort((a, b) => b.addedAt - a.addedAt || a.title.localeCompare(b.title));
  return sorted.sort((a, b) => {
    const aPriority = (a.course.id === state.settings.defaultCourseId ? 4 : 0) + (a.kind === "course" ? 2 : 0) + (a.course.lastUsedAt ? 1 : 0);
    const bPriority = (b.course.id === state.settings.defaultCourseId ? 4 : 0) + (b.kind === "course" ? 2 : 0) + (b.course.lastUsedAt ? 1 : 0);
    return bPriority - aPriority || b.addedAt - a.addedAt || a.title.localeCompare(b.title);
  });
}
function visibleStudyLinks() {
  const query = courseLibraryQuery.trim().toLowerCase();
  const filtered = studyLinkRecords().filter((link) => {
    if (courseLibrarySource !== "all" && link.source.type !== courseLibrarySource) return false;
    if (!query) return true;
    return [link.title, link.url, link.source.label, link.course.title, link.course.subject].some((value) => String(value || "").toLowerCase().includes(query));
  });
  return { all: filtered, visible: sortStudyLinks(filtered).slice(0, courseLibraryLimit) };
}
function actionButton(label, handler, danger = false) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "study-link-menu-button" + (danger ? " danger" : "");
  button.textContent = label;
  button.addEventListener("click", handler);
  return button;
}
function closeStudyLinkMenu() {
  if (!activeStudyLinkMenu) return;
  activeStudyLinkMenu.trigger.setAttribute("aria-expanded", "false");
  activeStudyLinkMenu.menu.remove();
  activeStudyLinkMenu = null;
}
function positionStudyLinkMenu(menu, trigger) {
  const margin = 8;
  const triggerRect = trigger.getBoundingClientRect();
  const menuRect = menu.getBoundingClientRect();
  const maxLeft = Math.max(margin, window.innerWidth - menuRect.width - margin);
  const maxTop = Math.max(margin, window.innerHeight - menuRect.height - margin);
  const left = Math.max(margin, Math.min(maxLeft, triggerRect.right - menuRect.width));
  const below = triggerRect.bottom + 6;
  const above = triggerRect.top - menuRect.height - 6;
  const top = below <= maxTop ? below : Math.max(margin, Math.min(maxTop, above));
  menu.style.left = Math.round(left) + "px";
  menu.style.top = Math.round(top) + "px";
  menu.style.visibility = "visible";
}
function openStudyLinkMenu(trigger, link) {
  if (activeStudyLinkMenu?.linkId === link.id) {
    closeStudyLinkMenu();
    return;
  }
  closeStudyLinkMenu();
  const menu = document.createElement("div");
  menu.className = "study-link-menu-items";
  menu.setAttribute("role", "menu");
  menu.setAttribute("aria-label", "Actions for " + link.title);
  menu.style.visibility = "hidden";
  menu.append(studyLinkMenuItems(link));
  menu.addEventListener("click", (event) => {
    event.stopPropagation();
    if (event.target.closest?.(".study-link-menu-button")) queueMicrotask(closeStudyLinkMenu);
  });
  document.body.append(menu);
  activeStudyLinkMenu = { linkId: link.id, menu, trigger };
  trigger.setAttribute("aria-expanded", "true");
  positionStudyLinkMenu(menu, trigger);
}
async function editStudyLink(link) {
  if (link.kind === "course") {
    const title = prompt("Course title", link.course.title)?.trim();
    if (!title) return;
    const url = validUrl(prompt("Course link", link.course.url) || "");
    if (!url) return showToast("Paste a valid course link.");
    await saveState({ ...state, courses: state.courses.map((course) => course.id === link.course.id ? { ...course, title: title.slice(0, 180), url: normalizeUrl(url) } : course) });
    showToast("Course link updated.");
    return;
  }
  const title = prompt("Video title", link.video.title)?.trim();
  if (!title) return;
  const url = canonicalYouTubeVideoUrl(prompt("YouTube video link", link.video.url) || "");
  if (!url) return showToast("Paste a supported YouTube video link.");
  const duplicate = state.courses.some((course) => canonicalYouTubeVideoUrl(course.url) === url || (course.videos || []).some((video) => video.id !== link.video.id && canonicalYouTubeVideoUrl(video.url) === url));
  if (duplicate) return showToast("This video is already in Studizen.");
  await saveState({ ...state, courses: state.courses.map((course) => course.id === link.course.id ? { ...course, videos: (course.videos || []).map((video) => video.id === link.video.id ? { ...video, title: title.slice(0, 180), url } : video) } : course) });
  showToast("Video updated.");
}
function studyLinkMenuItems(link) {
  const actions = document.createElement("div");
  actions.className = "study-link-menu-actions";
  actions.append(actionButton("Edit", () => editStudyLink(link)));
  if (link.kind === "course") {
    actions.append(actionButton(link.course.id === state.settings.defaultCourseId ? "Current course" : "Set as current", () => updateSettings({ defaultCourseId: link.course.id }).then(() => showToast("Course selected."))));
    actions.append(actionButton("Start focus", () => startFocus(link.course.id)));
    const move = document.createElement("label");
    move.className = "study-link-menu-select";
    move.textContent = "Move to";
    const select = document.createElement("select");
    state.courseLibraries.forEach((library) => {
      const option = document.createElement("option");
      option.value = library.id;
      option.textContent = library.name;
      option.selected = library.id === link.course.libraryId;
      select.append(option);
    });
    select.addEventListener("change", () => { moveCourseToLibrary(link.course.id, select.value); closeStudyLinkMenu(); });
    move.append(select);
    actions.append(move);
    actions.append(actionButton("Delete course", () => deleteCourse(link.course.id), true));
  } else actions.append(actionButton("Delete link", () => removeCourseVideo(link.course.id, link.video.id), true));
  return actions;
}
function studyLinkMenu(link) {
  const menu = document.createElement("div");
  menu.className = "study-link-action-menu";
  const trigger = document.createElement("button");
  trigger.type = "button";
  trigger.className = "study-link-menu-trigger";
  trigger.setAttribute("aria-label", "More actions for " + link.title);
  trigger.setAttribute("aria-haspopup", "menu");
  trigger.setAttribute("aria-expanded", "false");
  trigger.title = "More actions";
  trigger.textContent = "...";
  trigger.addEventListener("click", (event) => { event.stopPropagation(); openStudyLinkMenu(trigger, link); });
  menu.append(trigger);
  return menu;
}
function studyLinkRow(link) {
  const row = document.createElement("article");
  row.className = "study-link-row" + (link.course.id === state.settings.defaultCourseId && link.kind === "course" ? " is-current" : "");
  const icon = document.createElement("span");
  icon.className = "study-link-source" + (link.source.type === "youtube" ? " youtube" : "");
  icon.textContent = link.source.mark;
  icon.setAttribute("aria-hidden", "true");
  const copy = document.createElement("div");
  copy.className = "study-link-copy";
  const subject = document.createElement("span");
  subject.className = "study-link-subject";
  subject.textContent = link.course.subject || "Study resource";
  const title = document.createElement("strong");
  title.textContent = link.title;
  title.title = link.title;
  const meta = document.createElement("span");
  const status = link.course.id === state.settings.defaultCourseId ? "Current" : "Saved";
  meta.className = "study-link-meta";
  meta.textContent = link.source.label + " · " + status;
  copy.append(subject, title, meta);
  const open = document.createElement("button");
  open.type = "button";
  open.className = "button secondary compact-button study-link-open";
  open.textContent = "Open";
  open.addEventListener("click", () => openCourse(link.url));
  row.append(icon, copy, open, studyLinkMenu(link));
  return row;
}
function courseLinkGroup(course, links) {
  const group = document.createElement("section");
  group.className = "study-link-course-group";
  const rows = document.createElement("div");
  rows.className = "study-link-list";
  links.forEach((link) => rows.append(studyLinkRow(link)));
  group.append(rows);
  return group;
}
function renderCourseOverview() {
  if (!el.courseOverview) return;
  el.courseOverview.innerHTML = "";
  const coursesById = new Map(state.courses.map((course) => [course.id, course]));
  const recentByCourse = new Map();
  (Array.isArray(state.analytics?.focusHistory) ? state.analytics.focusHistory : []).forEach((session) => {
    const minutes = sessionActualMinutes(session);
    const endedAt = Number(session?.endedAt || session?.startedAt || 0);
    if (!minutes || !Number.isFinite(endedAt) || endedAt <= 0) return;
    const course = coursesById.get(session.courseId) || state.courses.find((item) => item.title === session.courseTitle);
    if (!course) return;
    const existing = recentByCourse.get(course.id);
    if (!existing || endedAt > existing.endedAt) recentByCourse.set(course.id, { course, session, minutes, endedAt });
  });
  const recent = [...recentByCourse.values()].sort((a, b) => b.endedAt - a.endedAt).slice(0, 3);
  if (!recent.length) {
    el.courseOverview.innerHTML = "<div class='recent-study-empty'><strong>No recent study yet</strong><span>Your recent study activity will appear here after your first Focus session.</span></div>";
    return;
  }
  const list = document.createElement("div");
  list.className = "recent-study-list";
  recent.forEach(({ course, session, minutes, endedAt }) => {
    const row = document.createElement("section");
    row.className = "recent-study-row";
    const date = new Date(endedAt);
    const dateKey = session.recordedDate || todayKey(date);
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const day = dateKey === todayKey() ? "Today" : dateKey === todayKey(yesterday) ? "Yesterday" : date.toLocaleDateString([], { month: "short", day: "numeric", year: date.getFullYear() === new Date().getFullYear() ? undefined : "numeric" });
    row.innerHTML = "<div class='recent-study-copy'><span class='recent-study-subject'></span><h4 title=''></h4><p></p></div><button class='button secondary recent-study-open' type='button'>Open course</button>";
    row.querySelector(".recent-study-subject").textContent = course.subject || session.subject || "Study course";
    const title = row.querySelector("h4");
    title.textContent = course.title;
    title.title = course.title;
    row.querySelector("p").textContent = "Studied " + formatDuration(minutes) + " · " + day;
    row.querySelector(".recent-study-open").addEventListener("click", () => openCourse(course.url));
    list.append(row);
  });
  el.courseOverview.append(list);
}
function renderCourseLibraries() {
  if (!el.courseLibrariesList) return;
  closeStudyLinkMenu();
  setCourseLibraryExpanded(courseLibraryExpanded);
  el.courseLibrariesList.innerHTML = "";
  const totalLinks = studyLinkRecords().length;
  if (el.courseCount) el.courseCount.textContent = state.courses.length + (state.courses.length === 1 ? " course" : " courses") + " · " + totalLinks + (totalLinks === 1 ? " link" : " links");
  if (el.courseLibrarySearch) el.courseLibrarySearch.value = courseLibraryQuery;
  if (el.courseLibrarySource) el.courseLibrarySource.value = courseLibrarySource;
  if (el.courseLibrarySort) el.courseLibrarySort.value = courseLibrarySort;
  if (!state.courses.length) { el.courseLibrariesList.innerHTML = "<div class='empty-state study-link-empty'><h4>No saved study links yet</h4><p>Add a course above, or right-click a YouTube video and choose Add to Studizen.</p></div>"; return; }
  const { all, visible } = visibleStudyLinks();
  if (!all.length) {
    const empty = document.createElement("div");
    empty.className = "empty-state study-link-empty";
    empty.innerHTML = "<h4>No matching study links</h4><p>Try another title, source, or sort option.</p>";
    const clear = document.createElement("button");
    clear.type = "button";
    clear.className = "button secondary compact-button";
    clear.textContent = "Clear filters";
    clear.addEventListener("click", resetStudyLinkFilters);
    empty.append(clear);
    el.courseLibrariesList.append(empty);
    return;
  }
  state.courseLibraries.forEach((library) => {
    const links = visible.filter((link) => link.course.libraryId === library.id);
    const totalInLibrary = all.filter((link) => link.course.libraryId === library.id).length;
    if (!links.length && !totalInLibrary) return;
    const section = document.createElement("details");
    section.className = "course-library study-link-library";
    section.open = courseLibraryQuery || courseLibrarySource !== "all" ? true : !library.collapsed;
    section.innerHTML = "<summary><span></span><strong></strong><div class='course-library-actions'><button class='icon-button rename' type='button' aria-label='Rename library'>Edit</button><button class='icon-button danger delete' type='button' aria-label='Delete library'>x</button></div></summary><div class='course-library-list'></div>";
    section.querySelector("span").textContent = library.name;
    section.querySelector("strong").textContent = totalInLibrary + (totalInLibrary === 1 ? " link" : " links");
    section.addEventListener("toggle", () => setLibraryCollapsed(library.id, !section.open));
    section.querySelector(".rename").addEventListener("click", (event) => { event.preventDefault(); event.stopPropagation(); renameLibrary(library.id); });
    section.querySelector(".delete").addEventListener("click", (event) => { event.preventDefault(); event.stopPropagation(); deleteLibrary(library.id); });
    const list = section.querySelector(".course-library-list");
    if (!links.length) list.innerHTML = "<div class='empty-state compact-empty'><p>Matching links are outside the current view. Load more to see them.</p></div>";
    const courseIds = [...new Set(links.map((link) => link.course.id))];
    courseIds.forEach((courseId) => {
      const course = state.courses.find((item) => item.id === courseId);
      const courseLinks = links.filter((link) => link.course.id === courseId);
      if (course && courseLinks.length) list.append(courseLinkGroup(course, courseLinks));
    });
    el.courseLibrariesList.append(section);
  });
  if (all.length > visible.length) {
    const more = document.createElement("button");
    more.type = "button";
    more.className = "button secondary study-link-load-more";
    more.textContent = "Show 60 more links (" + (all.length - visible.length) + " remaining)";
    more.addEventListener("click", () => { courseLibraryLimit += 60; renderCourseLibraries(); });
    el.courseLibrariesList.append(more);
  }
}
function siteRuleInfo(pattern) {
  const domain = String(pattern || "").replace(/^https?:\/\//, "").replace(/^www\./, "");
  const host = domain.split("/")[0];
  const named = { "docs.google.com": "Google Docs", "drive.google.com": "Google Drive", "classroom.google.com": "Google Classroom", "youtube.com": "YouTube", "wikipedia.org": "Wikipedia", "github.com": "GitHub", "instagram.com": "Instagram", "reddit.com": "Reddit", "facebook.com": "Facebook", "netflix.com": "Netflix", "discord.com": "Discord", "twitter.com": "X / Twitter", "x.com": "X / Twitter" };
  const key = Object.keys(named).find((item) => host === item || host.endsWith("." + item));
  const name = key ? named[key] : host.replace(/^www\./, "").split(".")[0].replace(/[-_]/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
  return { domain, name, mark: name.slice(0, 2).toUpperCase() };
}
function renderSiteRuleList(container, patterns, query, mode) {
  if (!container) return;
  const all = cleanPatterns(patterns);
  const visible = all.filter((pattern) => (siteRuleInfo(pattern).name + " " + pattern).toLowerCase().includes(query.toLowerCase()));
  container.innerHTML = "";
  if (!visible.length) { const empty = document.createElement("div"); empty.className = "site-rule-empty"; empty.innerHTML = "<strong>" + (all.length ? "No matching sites" : mode === "allowed" ? "No supporting sites yet" : "No distracting sites saved") + "</strong><span>" + (all.length ? "Try a different search." : mode === "allowed" ? "Add the study tools you need during Focus Mode." : "Add a site to keep it visible in your distraction watchlist.") + "</span>"; container.append(empty); return; }
  visible.slice(0, 80).forEach((pattern) => {
    const info = siteRuleInfo(pattern); const row = document.createElement("article"); row.className = "site-rule-row " + mode; row.title = info.domain;
    const badge = document.createElement("span"); badge.className = "site-rule-icon"; badge.textContent = info.mark;
    const copy = document.createElement("div"); copy.className = "site-rule-copy"; const title = document.createElement("strong"); title.textContent = info.name; const domain = document.createElement("span"); domain.textContent = info.domain; domain.title = info.domain; copy.append(title, domain);
    const status = document.createElement("span"); status.className = "site-rule-status"; status.textContent = mode === "allowed" ? "Focus Mode" : state.settings.guardBlockedOutsideFocus ? "Protected" : "Off";
    const actions = document.createElement("div"); actions.className = "site-rule-actions";
    const open = actionButton("Open", () => openCourse("https://" + info.domain)); const edit = actionButton("Edit", async () => { const next = prompt("Edit site domain", pattern)?.trim().toLowerCase(); if (!next || next === pattern) return; const key = mode === "allowed" ? "allowedSites" : "blockedSites"; await updateSettings({ [key]: cleanPatterns(state.settings[key].map((item) => item === pattern ? next : item)) }); }); const remove = actionButton("Remove", () => { const key = mode === "allowed" ? "allowedSites" : "blockedSites"; updateSettings({ [key]: state.settings[key].filter((item) => item !== pattern) }); });
    [open, edit, remove].forEach((button) => button.classList.add("site-rule-action")); remove.classList.add("danger"); actions.append(open, edit, remove); row.append(badge, copy, status, actions); container.append(row);
  });
  if (visible.length > 80) { const note = document.createElement("p"); note.className = "site-rule-limit"; note.textContent = "Showing the first 80 matching sites. Refine your search to narrow the list."; container.append(note); }
}
function renderShield() {
  if (el.allowedCount) el.allowedCount.textContent = String(state.settings.allowedSites.length);
  if (el.blockedCount) el.blockedCount.textContent = String(state.settings.blockedSites.length);
  if (el.distractionProtectionInput) el.distractionProtectionInput.checked = Boolean(state.settings.guardBlockedOutsideFocus);
  if (el.distractionProtectionState) el.distractionProtectionState.textContent = state.settings.guardBlockedOutsideFocus ? "On" : "Off";
  if (el.incognitoProtectionInput) el.incognitoProtectionInput.checked = Boolean(state.settings.incognitoProtection);
  if (el.incognitoProtectionState) el.incognitoProtectionState.textContent = state.settings.incognitoProtection ? "On" : "Off";
  if (el.incognitoAccessTitle) el.incognitoAccessTitle.textContent = !hasChrome ? "Available in Chrome" : incognitoAccessAllowed === null ? "Checking Incognito access..." : incognitoAccessAllowed ? "Incognito access ready" : "Allow Studizen in Incognito";
  if (el.incognitoAccessState) el.incognitoAccessState.textContent = !hasChrome ? "Open Studizen in Chrome to configure this setting." : incognitoAccessAllowed === null ? "Checking Chrome access..." : incognitoAccessAllowed ? "Chrome permission is ready. Turn this setting on when you want protection." : "Chrome needs permission before Studizen can protect Incognito windows.";
  if (el.openIncognitoSettingsBtn) el.openIncognitoSettingsBtn.hidden = !hasChrome || incognitoAccessAllowed === true;
  renderSiteRuleList(el.allowedList, state.settings.allowedSites, allowedSiteQuery, "allowed");
  renderSiteRuleList(el.blockedList, state.settings.blockedSites, blockedSiteQuery, "blocked");
}
async function refreshIncognitoAccessStatus() {
  if (!hasChrome) { incognitoAccessAllowed = false; renderShield(); return false; }
  const result = await sendMessage({ type: "getIncognitoAccess" });
  incognitoAccessAllowed = Boolean(result?.ok && result.response?.allowed);
  if (!incognitoAccessAllowed && state.settings.incognitoProtection) await updateSettings({ incognitoProtection: false });
  renderShield();
  return incognitoAccessAllowed;
}
async function openIncognitoSettings() {
  const result = await sendMessage({ type: "openIncognitoSettings" });
  if (!result?.ok) return showToast("Chrome settings could not be opened.");
  showToast("In Chrome, turn on Allow in Incognito for Studizen.");
}
function cssVar(name) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim(); }
function chartPalette() { return { blue: cssVar("--chart-blue") || cssVar("--blue") || "#2f7cf6", muted: cssVar("--muted") || "#687789", grid: cssVar("--chart-grid") || "rgba(100,116,139,.16)", text: cssVar("--ink") || "#142033", surface: cssVar("--surface-raised") || cssVar("--surface") || "#fff", font: cssVar("--font-display") || "Manrope, Arial, sans-serif" }; }
function chartAlpha(color, alpha) {
  if (!color) return "rgba(47,124,246," + alpha + ")";
  const hex = color.trim();
  if (/^#[0-9a-f]{6}$/i.test(hex)) {
    const n = parseInt(hex.slice(1), 16);
    return "rgba(" + ((n >> 16) & 255) + "," + ((n >> 8) & 255) + "," + (n & 255) + "," + alpha + ")";
  }
  return color;
}
function destroyChart(key) { if (!charts[key]) return; charts[key].destroy(); delete charts[key]; }
function chart(key, canvas, config) {
  if (!canvas || !globalThis.Chart) return;
  const existing = charts[key];
  if (existing?.canvas === canvas && existing.config.type === config.type) {
    existing.data = config.data;
    existing.options = config.options;
    existing.update();
    return;
  }
  destroyChart(key);
  charts[key] = new Chart(canvas, config);
}
function gamificationStats() {
  const history = completedFocusSessions();
  const focusXp = history.reduce((sum, item) => sum + (Number.isFinite(Number(item.xpEarned)) ? Number(item.xpEarned) : sessionXp(item.durationMinutes, item.completed)), 0);
  const xp = Math.round(focusXp + rewardXpTotal(state));
  const level = levelForXp(xp);
  const levelStart = (level - 1) * 300;
  const nextLevel = level * 300;
  const progress = Math.min(100, Math.round(((xp - levelStart) / Math.max(1, nextLevel - levelStart)) * 100));
  const rank = rankForLevel(level);
  const badges = [];
  if (history.length >= 1) badges.push("First Focus");
  if ((state.analytics.streak?.current || 0) >= 3) badges.push("3-Day Streak");
  if (completedMinutesToday() >= 120) badges.push("Deep Work Day");
  if ((state.stats.distractions || 0) === 0 && (state.stats.focusMinutes || 0) > 0) badges.push("Clean Session");
  return { xp, level, progress, rank, badges };
}
function renderGamification() {
  const stats = gamificationStats();
  if (stats.level > lastShownLevel) {
    lastShownLevel = stats.level;
    sessionStorage.setItem("courseFocusProLastLevel", String(stats.level));
    el.xpPanel?.classList.remove("level-up");
    void el.xpPanel?.offsetWidth;
    el.xpPanel?.classList.add("level-up");
    showToast("Level " + stats.level + " reached - " + stats.rank + ".");
  } else if (stats.level < lastShownLevel) {
    lastShownLevel = stats.level;
    sessionStorage.setItem("courseFocusProLastLevel", String(stats.level));
  }
  el.rankTitle.textContent = "Level " + stats.level + " - " + stats.rank;
  el.rankMeta.textContent = stats.xp + " XP earned from verified focus sessions, system goals, and streaks";
  el.xpProgressFill.style.width = stats.progress + "%";
  el.badgeRow.innerHTML = "";
  if (!stats.badges.length) {
    el.badgeRow.innerHTML = "<span class='badge muted'>Badges appear as you study</span>";
    return;
  }
  stats.badges.slice(0, 5).forEach((badge) => {
    const item = document.createElement("span");
    item.className = "badge";
    item.textContent = badge;
    el.badgeRow.append(item);
  });
}
function setAnalyticsXpOpen(open, restoreFocus = false) {
  if (!el.analyticsXpPopover || !el.analyticsXpBtn) return;
  const wasOpen = !el.analyticsXpPopover.classList.contains("hidden");
  const next = Boolean(open);
  el.analyticsXpPopover.classList.toggle("hidden", !next);
  el.analyticsXpBtn.setAttribute("aria-expanded", String(next));
  if (!next && restoreFocus && wasOpen) el.analyticsXpBtn.focus();
}

function selectedAnalyticsVisualPeriod() {
  return analyticsHistoryPeriod || "current-week";
}

function analyticsVisualPeriodLabel(period) {
  if (period === "previous-month") return "Previous month";
  if (period === "previous-week") return "Previous week";
  return "This week";
}

function localDateFromKey(key) {
  const [year, month, day] = String(key || "").split("-").map(Number);
  return new Date(year || 1970, Math.max(0, (month || 1) - 1), day || 1);
}

function fullWeekKeys(now = new Date(), weekOffset = 0) {
  const day = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  day.setDate(day.getDate() - ((day.getDay() + 6) % 7) + weekOffset * 7);
  return Array.from({ length: 7 }, (_, index) => {
    const next = new Date(day);
    next.setDate(day.getDate() + index);
    return todayKey(next);
  });
}

function sessionsForDateKeys(summary, keys = []) {
  const keySet = new Set(keys);
  const counts = new Map();
  (summary.sessions || []).forEach((session) => {
    if (!keySet.has(session?.recordedDate)) return;
    counts.set(session.recordedDate, (counts.get(session.recordedDate) || 0) + 1);
  });
  return counts;
}

function monthlyActivityBuckets(summary, period, dailyGoalMinutes = 0) {
  const groups = new Map();
  (period.keys || []).forEach((key) => {
    const date = localDateFromKey(key);
    date.setDate(date.getDate() - ((date.getDay() + 6) % 7));
    const weekKey = todayKey(date);
    if (!groups.has(weekKey)) groups.set(weekKey, []);
    groups.get(weekKey).push(key);
  });
  return [...groups.values()].map((keys, index) => {
    const sessions = sessionsForDateKeys(summary, keys);
    const first = localDateFromKey(keys[0]);
    const last = localDateFromKey(keys[keys.length - 1]);
    const startLabel = first.toLocaleDateString(undefined, { month: "short", day: "numeric" });
    const endLabel = last.toLocaleDateString(undefined, { month: "short", day: "numeric" });
    return {
      label: startLabel,
      range: startLabel + " – " + endLabel,
      minutes: keys.reduce((total, key) => total + (summary.byDate.get(key) || 0), 0),
      sessions: [...sessions.values()].reduce((total, count) => total + count, 0),
      goalMinutes: dailyGoalMinutes * keys.length
    };
  });
}

function activityBucketsForPeriod(summary, periodName, now = new Date(), dailyGoalMinutes = 0) {
  if (periodName === "previous-month") {
    const period = completedPeriodAnalytics(summary, periodName, now, state.goals?.studyHours);
    return { label: analyticsVisualPeriodLabel(periodName) + " - weekly activity", grouped: true, buckets: monthlyActivityBuckets(summary, period, dailyGoalMinutes) };
  }
  const keys = fullWeekKeys(now, periodName === "previous-week" ? -1 : 0);
  const sessions = sessionsForDateKeys(summary, keys);
  const labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  return {
    label: analyticsVisualPeriodLabel(periodName),
    grouped: false,
    buckets: keys.map((key, index) => ({ label: labels[index], range: key, minutes: summary.byDate.get(key) || 0, sessions: sessions.get(key) || 0, goalMinutes: dailyGoalMinutes }))
  };
}

function chartDurationMaximum(observedMinutes) {
  const target = Math.max(5, observedMinutes) * 1.12;
  const stepTarget = target / 4;
  const magnitude = 10 ** Math.floor(Math.log10(stepTarget));
  const normalized = stepTarget / magnitude;
  const step = Math.max(1, (normalized <= 1.5 ? 1 : normalized <= 3 ? 2 : normalized <= 7 ? 5 : 10) * magnitude);
  return Math.max(step, Math.ceil(target / step) * step);
}

function setAnalyticsChartEmpty(canvas, empty, isEmpty) {
  canvas?.classList.remove("hidden");
  empty?.classList.toggle("hidden", !isEmpty);
}

function setAnalyticsEmptyCopy(container, hasHistory, emptyText, historyText) {
  if (!container) return;
  container.textContent = hasHistory ? historyText : emptyText;
}

function renderStudyActivity(summary, periodName, now = new Date()) {
  const dailyGoalMinutes = resolveStudyTargets(state).dailyMinutes;
  const activity = activityBucketsForPeriod(summary, periodName, now, dailyGoalMinutes);
  const hasActivity = activity.buckets.some((bucket) => bucket.minutes > 0);
  if (el.dailyChartMeta) el.dailyChartMeta.textContent = analyticsVisualPeriodLabel(periodName) + (activity.grouped ? " · Study time by week" : " · Study time per day");
  if (el.dailyChartGoal) el.dailyChartGoal.textContent = dailyGoalMinutes ? "Daily goal: " + formatDuration(dailyGoalMinutes) + (activity.grouped ? " · weekly totals" : "") : "No daily goal set";
  setAnalyticsChartEmpty(el.dailyChart, el.dailyChartEmpty, !hasActivity);
  setAnalyticsEmptyCopy(el.dailyChartEmpty, summary.recordedSessions > 0, "Complete a Focus session to see your daily study time.", "No study time recorded in this period.");
  const observedMaximum = Math.max(...activity.buckets.map((bucket) => bucket.minutes));
  const axisMaximum = chartDurationMaximum(observedMaximum);
  const hasGoalLine = activity.buckets.some((bucket) => bucket.goalMinutes > 0);
  const goalAboveScale = activity.buckets.some((bucket) => bucket.goalMinutes > axisMaximum);
  if (el.dailyChartGoal && goalAboveScale) el.dailyChartGoal.textContent += " · goal above chart scale";
  const colors = chartPalette();
  const dailyGoalDataset = hasGoalLine ? [{
    type: "line",
    label: "Daily goal",
    data: activity.buckets.map((bucket) => Math.min(bucket.goalMinutes, axisMaximum)),
    borderColor: chartAlpha(colors.blue, .48),
    borderDash: [5, 4],
    borderWidth: 1,
    pointRadius: 0,
    pointHoverRadius: 0,
    tension: 0,
    order: 0
  }] : [];
  chart("daily", el.dailyChart, {
    type: "bar",
    data: {
      labels: activity.buckets.map((bucket) => bucket.label),
      datasets: [{
        label: "Study time",
        data: activity.buckets.map((bucket) => bucket.minutes),
        backgroundColor: activity.buckets.map((bucket) => bucket.minutes ? chartAlpha(colors.blue, .84) : chartAlpha(colors.blue, .10)),
        hoverBackgroundColor: chartAlpha(colors.blue, .98),
        minBarLength: 0,
        borderColor: colors.blue,
        borderWidth: 0,
        borderRadius: 6,
        borderSkipped: false,
        maxBarThickness: 36,
        categoryPercentage: .72,
        barPercentage: .82,
        order: 1
      }, ...dailyGoalDataset]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 240, easing: "easeOutQuart" },
      interaction: { mode: "index", intersect: false },
      hover: { mode: "index", intersect: false },
      layout: { padding: { top: 4, right: 2, bottom: 0, left: 0 } },
      plugins: {
        legend: { display: false },
        tooltip: {
          displayColors: false,
          filter: (item) => item.datasetIndex === 0,
          backgroundColor: colors.surface,
          borderColor: chartAlpha(colors.blue, .26),
          borderWidth: 1,
          titleColor: colors.text,
          bodyColor: colors.muted,
          titleFont: { family: colors.font, size: 12, weight: "600" },
          bodyFont: { family: colors.font, size: 11, weight: "500" },
          padding: 10,
          cornerRadius: 7,
          callbacks: {
            title: (items) => {
              const range = activity.buckets[items[0]?.dataIndex]?.range;
              if (!range) return "Study time";
              if (activity.grouped) return range;
              return localDateFromKey(range).toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric" });
            },
            label: (item) => "Study time: " + formatDuration(item.parsed.y || 0),
            afterLabel: (item) => {
              const count = activity.buckets[item.dataIndex]?.sessions || 0;
              return "Sessions: " + count;
            }
          }
        }
      },
      scales: {
        x: { grid: { display: false }, border: { display: false }, ticks: { color: colors.muted, font: { family: colors.font, size: 11, weight: "600" }, padding: 8 } },
        y: {
          beginAtZero: true,
          max: axisMaximum,
          border: { display: false },
          grid: { color: colors.grid, drawTicks: false, lineWidth: 1 },
          ticks: { color: colors.muted, font: { family: colors.font, size: 10, weight: "500" }, maxTicksLimit: 4, padding: 8, callback: (value) => formatDuration(Number(value) || 0) }
        }
      }
    }
  });
}

function subjectEntriesForPeriod(period) {
  const subjects = new Map();
  (Array.isArray(period.sessions) ? period.sessions : []).forEach((session) => {
    const title = String(session?.subject || "Other").trim() || "Other";
    const entry = subjects.get(title) || { title, minutes: 0, sessions: 0 };
    entry.minutes += sessionActualMinutes(session);
    entry.sessions += 1;
    subjects.set(title, entry);
  });
  [...currentSubjects(), ...Object.keys(resolveStudyTargets(state).subjectTargets)].forEach((title) => {
    if (title && title !== "Other" && !subjects.has(title)) subjects.set(title, { title, minutes: 0, sessions: 0 });
  });
  return [...subjects.values()];
}

function renderCourseDistribution(period, periodName, summary) {
  const targets = resolveStudyTargets(state);
  const periodTargetScale = periodName === "previous-month" ? period.keys.length / 7 : 1;
  const entries = subjectEntriesForPeriod(period).map((subject) => {
    const targetMinutes = Math.round(Math.max(0, Number(targets.subjectTargets[subject.title]) || 0) * periodTargetScale);
    return { ...subject, targetMinutes, targetProgress: studyTargetProgress(subject.minutes, targetMinutes) };
  });
  const sortBy = el.subjectChartSort?.value || targets.sortBy;
  entries.sort(sortBy === "target"
    ? (a, b) => (a.targetProgress === null ? 1 : b.targetProgress === null ? -1 : a.targetProgress - b.targetProgress) || b.minutes - a.minutes || a.title.localeCompare(b.title)
    : (a, b) => b.minutes - a.minutes || b.sessions - a.sessions || a.title.localeCompare(b.title));
  const visibleEntries = entries.slice(0, 40);
  if (el.courseDistributionMeta) el.courseDistributionMeta.textContent = analyticsVisualPeriodLabel(periodName) + " · Subject hours";
  const hasActivity = visibleEntries.some((subject) => subject.minutes > 0);
  if (el.subjectTargetSummary) el.subjectTargetSummary.textContent = Object.values(targets.subjectTargets).some((minutes) => Number(minutes) > 0) ? "Personalized targets · " + (periodName === "previous-month" ? "monthly equivalent" : "weekly") : "Set subject targets to track your plan";
  el.courseDistributionList?.classList.toggle("hidden", visibleEntries.length === 0);
  el.courseDistributionEmpty?.classList.toggle("hidden", hasActivity);
  setAnalyticsEmptyCopy(el.courseDistributionEmpty, summary.recordedSessions > 0, "Complete a Focus session to see your subject study time.", "No subject study time recorded in this period.");
  if (!el.courseDistributionList) return;
  el.courseDistributionList.innerHTML = "";
  if (!visibleEntries.length) return;
  visibleEntries.forEach((subject, index) => {
    const share = period.minutes ? Math.round((subject.minutes / period.minutes) * 100) : 0;
    const row = document.createElement("div");
    row.className = "course-distribution-row";
    row.style.setProperty("--distribution-index", Math.min(index, 8));
    const targetLabel = subject.targetMinutes ? formatDuration(subject.targetMinutes) : "No target";
    const progressLabel = subject.targetProgress === null ? "—" : subject.targetProgress + "%";
    row.setAttribute("aria-label", subject.title + ": " + formatDuration(subject.minutes) + " studied, target " + targetLabel + ", " + progressLabel + " of target. " + subject.sessions + " recorded sessions.");
    row.innerHTML = "<div class='course-distribution-row-heading'><div class='course-distribution-copy'><strong title=''></strong><span></span></div><div class='course-distribution-actual'><strong></strong><span></span></div><div class='course-distribution-target'><strong></strong><span>of target</span></div></div><div class='course-distribution-bar' role='progressbar' aria-valuemin='0' aria-valuemax='100'><i></i></div>";
    const title = row.querySelector(".course-distribution-copy strong");
    title.textContent = subject.title;
    title.title = subject.title;
    row.querySelector(".course-distribution-copy span").textContent = subject.sessions + " recorded session" + (subject.sessions === 1 ? "" : "s");
    row.querySelector(".course-distribution-actual strong").textContent = formatDuration(subject.minutes);
    row.querySelector(".course-distribution-actual span").textContent = "actual";
    row.querySelector(".course-distribution-target strong").textContent = targetLabel;
    row.querySelector(".course-distribution-target span").textContent = subject.targetProgress === null ? "target not set" : progressLabel + " of target";
    const fill = row.querySelector(".course-distribution-bar i");
    const width = subject.targetProgress === null ? "0%" : Math.max(0, Math.min(100, subject.targetProgress)) + "%";
    fill.style.width = "0%";
    const track = row.querySelector(".course-distribution-bar");
    track.setAttribute("aria-valuenow", String(Math.max(0, Math.min(100, subject.targetProgress || 0))));
    track.setAttribute("aria-valuetext", subject.targetProgress === null ? "No target set" : progressLabel + " of " + targetLabel);
    row.title = period.minutes ? share + "% of selected-period study time" : "No study time recorded in this period";
    el.courseDistributionList.append(row);
    requestAnimationFrame(() => { fill.style.width = width; });
  });
}

function renderGoalConsistency(period, periodName) {
  const targets = resolveStudyTargets(state);
  const goalMinutes = Math.round(targets.weeklyMinutes * (periodName === "previous-month" ? period.keys.length / 7 : 1));
  const progress = studyTargetProgress(period.minutes, goalMinutes);
  const averageSession = period.recordedSessions ? Math.round(period.minutes / period.recordedSessions) : 0;
  const longest = (period.sessions || []).reduce((maximum, session) => Math.max(maximum, sessionActualMinutes(session)), 0);
  if (el.consistencyMeta) el.consistencyMeta.textContent = analyticsVisualPeriodLabel(periodName);
  if (el.consistencyGoalLabel) el.consistencyGoalLabel.textContent = periodName === "previous-month" ? "Monthly goal" : "Weekly goal";
  if (el.consistencyGoalValue) el.consistencyGoalValue.textContent = goalMinutes ? formatDuration(period.minutes) + " / " + formatDuration(goalMinutes) : formatDuration(period.minutes) + " · no goal set";
  if (el.consistencyGoalPercent) el.consistencyGoalPercent.textContent = progress === null ? "—" : progress + "%";
  if (el.consistencyGoalFill) el.consistencyGoalFill.style.width = Math.min(100, progress || 0) + "%";
  if (el.consistencyDailyAverage) el.consistencyDailyAverage.textContent = formatDuration(period.dailyAverageMinutes);
  if (el.consistencySessions) el.consistencySessions.textContent = String(period.completedSessions);
  if (el.consistencyAverageSession) el.consistencyAverageSession.textContent = formatDuration(averageSession);
  if (el.consistencyLongestSession) el.consistencyLongestSession.textContent = formatDuration(longest);
}

function makeAnalyticsTargetSubjectRow(subject, targetMinutes = 0, custom = false) {
  const row = document.createElement("div");
  row.className = "analytics-target-subject-row";
  row.dataset.subjectName = subject;
  row.dataset.custom = String(custom);
  const copy = document.createElement("div");
  copy.className = "analytics-target-subject-copy";
  if (custom) {
    const name = document.createElement("input");
    name.className = "analytics-target-subject-name";
    name.type = "text";
    name.maxLength = 48;
    name.value = subject;
    name.setAttribute("aria-label", "Subject name");
    copy.append(name);
  } else {
    const name = document.createElement("strong");
    name.textContent = subject;
    copy.append(name);
  }
  const target = document.createElement("label");
  target.className = "analytics-target-subject-hours";
  target.append(document.createTextNode("Hours / week"));
  const input = document.createElement("input");
  input.className = "analytics-target-subject-input";
  input.type = "number";
  input.min = "0";
  input.max = "168";
  input.step = "0.25";
  input.inputMode = "decimal";
  input.value = String(Number(((Number(targetMinutes) || 0) / 60).toFixed(2)));
  input.setAttribute("aria-label", subject + " weekly target in hours");
  target.append(input);
  row.append(copy, target);
  if (custom) {
    const remove = document.createElement("button");
    remove.className = "button secondary analytics-target-subject-remove";
    remove.type = "button";
    remove.textContent = "Remove";
    remove.setAttribute("aria-label", "Remove " + subject + " from study targets");
    row.append(remove);
  }
  return row;
}

function renderAnalyticsTargetEditor() {
  if (!el.analyticsTargetSubjectList) return;
  const targets = resolveStudyTargets(state);
  const profileId = state.profile?.studyProfile || "jee";
  const profile = STUDY_PROFILES.find((item) => item.id === profileId);
  if (el.analyticsTargetsProfileNote) el.analyticsTargetsProfileNote.textContent = (profile?.name || "Your profile") + " suggestions are a starting point. Edit them to fit your schedule.";
  if (el.analyticsDailyTargetInput) el.analyticsDailyTargetInput.value = String(Number((targets.dailyMinutes / 60).toFixed(2)));
  if (el.analyticsWeeklyTargetInput) el.analyticsWeeklyTargetInput.value = String(Number((targets.weeklyMinutes / 60).toFixed(2)));
  if (el.subjectChartSort) el.subjectChartSort.value = targets.sortBy;
  const profileSubjects = new Set(subjectsForProfile(profileId).filter((subject) => subject !== "Other"));
  const names = [...new Set([
    ...subjectsForProfile(profileId).filter((subject) => subject !== "Other"),
    ...Object.keys(targets.subjectTargets),
    ...targets.customSubjects
  ])].slice(0, 80);
  el.analyticsTargetSubjectList.innerHTML = "";
  names.forEach((name) => el.analyticsTargetSubjectList.append(makeAnalyticsTargetSubjectRow(name, targets.subjectTargets[name] || 0, targets.customSubjects.includes(name) || !profileSubjects.has(name))));
}

function setAnalyticsTargetsEditor(open) {
  const isOpen = Boolean(open);
  el.analyticsTargetsEditor?.classList.toggle("hidden", !isOpen);
  el.analyticsTargetsToggle?.setAttribute("aria-expanded", String(isOpen));
  if (isOpen) {
    renderAnalyticsTargetEditor();
    el.analyticsTargetsEditor?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  } else {
    el.analyticsAddSubjectRow?.classList.add("hidden");
  }
}

function renameTrackedSubject(source, previousName, nextName) {
  if (!previousName || !nextName || previousName === nextName) return source;
  const courses = (source.courses || []).map((course) => course.subject === previousName ? { ...course, subject: nextName } : course);
  const analytics = { ...(source.analytics || {}) };
  analytics.focusHistory = (analytics.focusHistory || []).map((session) => session.subject === previousName ? { ...session, subject: nextName } : session);
  analytics.daily = Object.fromEntries(Object.entries(analytics.daily || {}).map(([date, day]) => {
    const subjects = { ...(day.subjects || {}) };
    if (subjects[previousName]) {
      const oldEntry = subjects[previousName];
      const current = subjects[nextName] || { subject: nextName, studyMinutes: 0, sessions: 0, completion: 0 };
      subjects[nextName] = { ...current, subject: nextName, studyMinutes: Number(current.studyMinutes || 0) + Number(oldEntry.studyMinutes || 0), sessions: Number(current.sessions || 0) + Number(oldEntry.sessions || 0), completion: Math.max(Number(current.completion || 0), Number(oldEntry.completion || 0)) };
      delete subjects[previousName];
    }
    return [date, { ...day, subjects }];
  }));
  return { ...source, courses, analytics };
}

async function saveAnalyticsTargets(event) {
  event.preventDefault();
  const rows = [...(el.analyticsTargetSubjectList?.querySelectorAll(".analytics-target-subject-row") || [])];
  const seen = new Set(); const subjectTargets = {}; const customSubjects = []; const renames = [];
  for (const row of rows) {
    const original = String(row.dataset.subjectName || "").trim();
    const name = String(row.querySelector(".analytics-target-subject-name")?.value || original).trim().replace(/\s+/g, " ").slice(0, 48);
    if (!name) { showToast("Enter a name for each subject."); return; }
    const key = name.toLocaleLowerCase();
    if (seen.has(key)) { showToast("Each subject name must be unique."); return; }
    seen.add(key);
    const hoursValue = Number(row.querySelector(".analytics-target-subject-input")?.value || 0);
    subjectTargets[name] = Math.round(Math.max(0, Math.min(168, Number.isFinite(hoursValue) ? hoursValue : 0)) * 60);
    if (row.dataset.custom === "true") {
      customSubjects.push(name);
      if (original && original !== name) renames.push([original, name]);
    }
  }
  let nextState = state;
  renames.forEach(([from, to]) => { nextState = renameTrackedSubject(nextState, from, to); });
  const dailyHours = Number(el.analyticsDailyTargetInput?.value || 0);
  const weeklyHours = Number(el.analyticsWeeklyTargetInput?.value || 0);
  const goals = {
    ...nextState.goals,
    studyHours: Math.max(0, Math.min(24, Number.isFinite(dailyHours) ? dailyHours : 0)),
    analyticsTargets: {
      profileId: nextState.profile?.studyProfile || "jee",
      weeklyMinutes: Math.round(Math.max(0, Math.min(168, Number.isFinite(weeklyHours) ? weeklyHours : 0)) * 60),
      subjectTargets,
      customSubjects: [...new Set(customSubjects)],
      sortBy: el.subjectChartSort?.value === "target" ? "target" : "actual"
    }
  };
  try {
    await saveState({ ...nextState, goals });
    setAnalyticsTargetsEditor(false);
    showToast("Study targets saved.");
  } catch (error) {
    showToast(error?.message || "Study targets could not be saved.");
  }
}

async function restoreSuggestedStudyTargets() {
  const profileId = state.profile?.studyProfile || "jee";
  const suggested = studyTargetSuggestions(profileId);
  if (!confirm("Restore the suggested daily, weekly, and subject targets for " + (STUDY_PROFILES.find((item) => item.id === profileId)?.name || "your profile") + "?")) return;
  await saveState({ ...state, goals: { ...state.goals, studyHours: suggested.dailyMinutes / 60, analyticsTargets: { profileId, weeklyMinutes: suggested.weeklyMinutes, subjectTargets: suggested.subjectTargets, customSubjects: [], sortBy: "actual" } } });
  renderAnalyticsTargetEditor();
  showToast("Profile suggestions restored.");
}

function addAnalyticsTargetSubject() {
  const name = String(el.analyticsNewSubjectInput?.value || "").trim().replace(/\s+/g, " ").slice(0, 48);
  if (!name) { el.analyticsNewSubjectInput?.focus(); return; }
  const exists = [...(el.analyticsTargetSubjectList?.querySelectorAll(".analytics-target-subject-row") || [])].some((row) => (row.querySelector(".analytics-target-subject-name")?.value || row.dataset.subjectName || "").trim().toLocaleLowerCase() === name.toLocaleLowerCase());
  if (exists) { showToast("That subject is already in your targets."); return; }
  el.analyticsTargetSubjectList?.append(makeAnalyticsTargetSubjectRow(name, 120, true));
  el.analyticsNewSubjectInput.value = "";
  el.analyticsAddSubjectRow?.classList.add("hidden");
  el.analyticsTargetSubjectList?.lastElementChild?.querySelector(".analytics-target-subject-name")?.focus();
}

function renderAnalytics() {
  const summary = recordedAnalytics();
  const targets = resolveStudyTargets(state);
  const currentPeriod = completedPeriodAnalytics(summary, "current-week", new Date(), state.goals?.studyHours, targets.weeklyMinutes);
  const weeklyMinutes = currentPeriod.minutes;
  const avgMinutes = Math.round(weeklyMinutes / 7);
  const sixWeekMinutes = dateSeries(42).reduce((sum, key) => sum + (summary.byDate.get(key) || 0), 0);
  const weeklyAverageMinutes = Math.round(sixWeekMinutes / 6);
  const streak = Math.max(0, Number(state.analytics.streak?.current) || 0);
  el.currentStreak.textContent = streak + " day" + (streak === 1 ? "" : "s");
  if (el.analyticsToday) el.analyticsToday.textContent = formatDuration(summary.todayMinutes);
  const visualPeriodName = selectedAnalyticsVisualPeriod();
  const visualPeriod = completedPeriodAnalytics(summary, visualPeriodName, new Date(), state.goals?.studyHours, targets.weeklyMinutes);
  const periodLabel = analyticsVisualPeriodLabel(visualPeriodName);
  const periodPhrase = visualPeriodName === "previous-week" ? "last week" : visualPeriodName === "previous-month" ? "last month" : "this week";
  const periodTitle = $("#analyticsPeriodTitle");
  const periodIntro = $("#analyticsPeriodIntro");
  if (periodTitle) periodTitle.textContent = "Your progress " + periodPhrase;
  if (periodIntro) periodIntro.textContent = visualPeriodName === "current-week"
    ? "A quick look at what you studied and how your week is going."
    : "A quick look at what you studied " + periodPhrase + ".";
  if (el.analyticsWeekLabel) el.analyticsWeekLabel.textContent = periodLabel;
  if (el.analyticsWeek) el.analyticsWeek.textContent = formatDuration(visualPeriod.minutes);
  if (el.analyticsWeekHint) el.analyticsWeekHint.textContent = "Study time " + periodPhrase;
  if (el.analyticsSessions) el.analyticsSessions.textContent = String(visualPeriod.completedSessions);
  if (el.analyticsSessionsHint) el.analyticsSessionsHint.textContent = "Completed sessions " + periodPhrase;
  if (el.weeklyHours) el.weeklyHours.textContent = hours(weeklyAverageMinutes);
  if (el.averageStudy) el.averageStudy.textContent = hours(avgMinutes);
  const dailyGoalPercent = studyTargetProgress(summary.todayMinutes, targets.dailyMinutes);
  el.goalProgress.textContent = dailyGoalPercent === null ? "—" : dailyGoalPercent + "%";
  if (el.analyticsGoalHint) el.analyticsGoalHint.textContent = dailyGoalPercent === null ? "Set a daily study target" : formatDuration(summary.todayMinutes) + " of " + formatDuration(targets.dailyMinutes) + " today";
  if (el.subjectChartSort && document.activeElement !== el.subjectChartSort) el.subjectChartSort.value = targets.sortBy;
  const todayMinutes = summary.todayMinutes;
  if (el.dailyComparison) el.dailyComparison.textContent = (todayMinutes >= avgMinutes ? "+" : "-") + formatDuration(Math.abs(todayMinutes - avgMinutes));
  renderGamification();
  renderStudyActivity(summary, visualPeriodName);
  renderCourseDistribution(visualPeriod, visualPeriodName, summary);
  renderGoalConsistency(visualPeriod, visualPeriodName);
  destroyChart("weekly");
  destroyChart("subject");
  renderCourseHistory(summary);
  renderAnalyticsHistory(summary);
}
function historicalPeriodLabel(period) { return period === "previous-month" ? "Previous month" : "Previous week"; }
function renderAnalyticsHistory(summary = recordedAnalytics()) {
  const drawer = el.analyticsHistoryDrawer;
  if (!drawer) return;
  const buttons = [[el.analyticsCurrentBtn, null], [el.analyticsPreviousWeekBtn, "previous-week"], [el.analyticsPreviousMonthBtn, "previous-month"]];
  buttons.forEach(([button, period]) => { if (!button) return; const active = analyticsHistoryPeriod === period; button.classList.toggle("active", active); button.setAttribute("aria-pressed", String(active)); });
  if (!analyticsHistoryPeriod) { drawer.classList.add("hidden"); return; }
  const now = new Date();
  const weeklyTarget = resolveStudyTargets(state).weeklyMinutes;
  const previous = completedPeriodAnalytics(summary, analyticsHistoryPeriod, now, state.goals?.studyHours, weeklyTarget);
  const current = completedPeriodAnalytics(summary, analyticsHistoryPeriod === "previous-month" ? "current-month" : "current-week", now, state.goals?.studyHours, weeklyTarget);
  drawer.classList.remove("hidden");
  el.analyticsHistoryTitle.textContent = historicalPeriodLabel(analyticsHistoryPeriod);
  el.analyticsHistoryTotal.textContent = formatDuration(previous.minutes);
  el.analyticsHistorySessions.textContent = String(previous.completedSessions);
  el.analyticsHistoryAverage.textContent = formatDuration(previous.dailyAverageMinutes);
  el.analyticsHistoryGoal.textContent = previous.goalProgress === null ? "No goal" : previous.goalProgress + "%";
  if (!previous.minutes) el.analyticsHistoryComparison.textContent = "Complete a few more sessions to unlock a " + historicalPeriodLabel(analyticsHistoryPeriod).toLowerCase() + " comparison.";
  else if (current.minutes > 0) { const change = Math.round(((current.minutes - previous.minutes) / previous.minutes) * 100); el.analyticsHistoryComparison.textContent = "Current period: " + formatDuration(current.minutes) + " • Change: " + (change >= 0 ? "+" : "") + change + "%"; }
  else el.analyticsHistoryComparison.textContent = "Your " + historicalPeriodLabel(analyticsHistoryPeriod).toLowerCase() + " recorded " + formatDuration(previous.minutes) + " across " + previous.completedSessions + " completed session" + (previous.completedSessions === 1 ? "" : "s") + ".";
  el.analyticsHistoryCourses.innerHTML = "";
  if (!previous.courseEntries.length) { el.analyticsHistoryCourses.innerHTML = "<span class='analytics-history-empty'>No course activity recorded in this period.</span>"; return; }
  const heading = document.createElement("strong"); heading.textContent = "Top courses"; el.analyticsHistoryCourses.append(heading);
  previous.courseEntries.slice(0, 3).forEach((course) => { const row = document.createElement("div"); row.innerHTML = "<span title=''></span><b></b><small></small>"; row.querySelector("span").textContent = course.title; row.querySelector("span").title = course.title; row.querySelector("b").textContent = formatDuration(course.minutes); row.querySelector("small").textContent = course.sessions + " session" + (course.sessions === 1 ? "" : "s"); el.analyticsHistoryCourses.append(row); });
}
function setCourseHistoryExpanded(expanded) {
  courseHistoryExpanded = Boolean(expanded);
  try { sessionStorage.setItem("courseFocusProCourseHistoryExpanded", String(courseHistoryExpanded)); } catch {}
  if (el.courseHistoryPanel) el.courseHistoryPanel.dataset.expanded = String(courseHistoryExpanded);
  if (el.courseHistoryToggle) el.courseHistoryToggle.setAttribute("aria-expanded", String(courseHistoryExpanded));
}
function renderCourseHistory(summary = recordedAnalytics()) {
  if (!el.courseHistoryList) return;
  const query = courseHistoryQuery.trim().toLowerCase();
  const courseMeta = new Map();
  summary.sessions.forEach((session) => {
    const key = String(session.courseId || session.courseTitle || "Focus session");
    const entry = courseMeta.get(key) || { lastStudied: 0, subjects: new Map() };
    entry.lastStudied = Math.max(entry.lastStudied, Number(session.endedAt) || 0);
    const subject = String(session.subject || "").trim();
    if (subject) entry.subjects.set(subject, (entry.subjects.get(subject) || 0) + sessionActualMinutes(session));
    courseMeta.set(key, entry);
  });
  const courses = summary.courseEntries.map((course) => {
    const meta = courseMeta.get(String(course.id || course.title)) || { lastStudied: 0, subjects: new Map() };
    const subject = [...meta.subjects.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0]?.[0] || "Subject not recorded";
    return { ...course, subject, lastStudied: meta.lastStudied };
  }).filter((course) => (course.title + " " + course.id + " " + course.subject).toLowerCase().includes(query));
  if (courseHistorySort === "recent") courses.sort((a, b) => b.lastStudied - a.lastStudied || b.minutes - a.minutes || a.title.localeCompare(b.title));
  else if (courseHistorySort === "name") courses.sort((a, b) => a.title.localeCompare(b.title, undefined, { sensitivity: "base" }));
  else courses.sort((a, b) => b.minutes - a.minutes || b.sessions - a.sessions || a.title.localeCompare(b.title));
  setCourseHistoryExpanded(courseHistoryExpanded);
  if (el.courseHistoryCount) el.courseHistoryCount.textContent = summary.courseEntries.length + " course" + (summary.courseEntries.length === 1 ? "" : "s");
  el.courseHistoryList.innerHTML = "";
  if (!courses.length) { el.courseHistoryList.innerHTML = "<div class='course-history-empty'><strong>" + (summary.recordedSessions ? "No matching courses" : "No course history yet") + "</strong><span>" + (summary.recordedSessions ? "Try a different course name." : "Complete a Focus session to see your study history here.") + "</span></div>"; return; }
  courses.forEach((course) => {
    const share = summary.totalMinutes ? Math.round((course.minutes / summary.totalMinutes) * 100) : 0;
    const row = document.createElement("details"); row.className = "course-history-row";
    const related = summary.sessions.filter((item) => String(item.courseId || item.courseTitle || "Focus session") === String(course.id || course.title));
    row.innerHTML = "<summary><span class='course-history-course-copy'><strong class='course-history-name' title=''></strong><small class='course-history-subject'></small></span><span class='course-history-time'></span><span class='course-history-sessions'></span><span class='course-history-share'><i></i><b></b></span><span class='course-history-expand'>Details</span></summary><div class='course-history-details'></div>";
    const name = row.querySelector(".course-history-name"); name.textContent = course.title; name.title = course.title;
    row.querySelector(".course-history-subject").textContent = course.subject;
    row.querySelector(".course-history-time").textContent = formatDuration(course.minutes);
    row.querySelector(".course-history-share i").style.setProperty("--progress", share + "%"); row.querySelector(".course-history-share b").textContent = share + "%";
    row.querySelector(".course-history-sessions").textContent = course.sessions + " session" + (course.sessions === 1 ? "" : "s");
    const details = row.querySelector(".course-history-details"); details.textContent = related.length ? related.slice(0, 4).map((item) => historyDateLabel(item.endedAt) + " · " + formatDuration(item.actualMinutes) + (item.status === "completed" ? " · completed" : " · " + item.status)).join("\n") : "No study sessions recorded.";
    el.courseHistoryList.append(row);
  });
}
function minutesForDate(key) {
  const daily = state.analytics?.daily?.[key] || {};
  return Number(daily.studyMinutes || 0);
}
function renderAdvancedAnalytics() {
  if (el.analyticsInsightGrid) {
    const summary = completedAnalytics();
    const history = summary.sessions;
    const byHour = new Map();
    history.forEach((session) => {
      const hour = new Date(session.startedAt || session.endedAt || 0).getHours();
      byHour.set(hour, (byHour.get(hour) || 0) + sessionActualMinutes(session));
    });
    const productiveHour = [...byHour.entries()].sort((a, b) => b[1] - a[1])[0];
    const topSubject = Object.entries(subjectTotalsFromHistory()).sort((a, b) => b[1].minutes - a[1].minutes)[0];
    const thisWeek = summary.weekMinutes;
    const distractionThisWeek = dateSeries(7).reduce((sum, key) => sum + Number(state.analytics?.daily?.[key]?.distractionsBlocked || 0), 0);
    const weeklyHours = thisWeek / 60;
    const averageSession = history.length ? Math.round(history.reduce((sum, session) => sum + sessionActualMinutes(session), 0) / history.length) : 0;
    const dailyTotals = dateSeries(7).map((key) => ({ key, minutes: summary.byDate.get(key) || 0 }));
    const strongestDay = [...dailyTotals].sort((a, b) => b.minutes - a.minutes)[0];
    const insights = [
      { label: "Best study window", value: productiveHour ? new Date(2000, 0, 1, productiveHour[0]).toLocaleTimeString([], { hour: "numeric" }) : "Not enough data", detail: productiveHour ? formatDuration(productiveHour[1]) + " focused at this hour" : "Focus time will reveal your pattern" },
      { label: "Most focused subject", value: topSubject?.[1]?.minutes ? topSubject[0] : "Not enough data", detail: topSubject?.[1]?.minutes ? formatDuration(topSubject[1].minutes) + " of actual focus" : "Your first session will appear here" },
      { label: "Average session", value: averageSession ? formatDuration(averageSession) : "Not enough data", detail: averageSession ? "your average focused block" : "Focus time will set a baseline" },
      { label: "Strongest day", value: strongestDay?.minutes ? new Date(strongestDay.key + "T00:00:00").toLocaleDateString([], { weekday: "long" }) : "Not enough data", detail: strongestDay?.minutes ? formatDuration(strongestDay.minutes) + " focused on that day" : "Your strongest day will appear here" },
      { label: "Distraction trend", value: distractionThisWeek + " blocked", detail: distractionThisWeek ? "this week across protected sites" : "a clean week so far" },
      { label: "Monthly estimate", value: hours(Math.round(weeklyHours * 4.35 * 60)), detail: "at your current 7-day pace" },
      { label: "Yearly estimate", value: hours(Math.round(weeklyHours * 52 * 60)), detail: "at your current 7-day pace" }
    ];
    el.analyticsInsightGrid.innerHTML = "";
    insights.forEach((insight) => {
      const item = document.createElement("article");
      item.className = "analytics-insight";
      item.innerHTML = "<span></span><strong></strong><p></p>";
      item.querySelector("span").textContent = insight.label;
      item.querySelector("strong").textContent = insight.value;
      item.querySelector("p").textContent = insight.detail;
      el.analyticsInsightGrid.append(item);
    });
  }
  if (el.studyHeatmap) {
    const keys = dateSeries(84);
    const values = keys.map(minutesForDate);
    const max = Math.max(1, ...values);
    el.studyHeatmap.innerHTML = "";
    keys.forEach((key, index) => {
      const minutes = values[index];
      const cell = document.createElement("span");
      const intensity = minutes ? Math.max(1, Math.ceil(minutes / max * 4)) : 0;
      cell.className = "heatmap-cell level-" + intensity;
      cell.title = new Date(key + "T00:00:00").toLocaleDateString([], { month: "short", day: "numeric" }) + ": " + formatDuration(minutes);
      cell.setAttribute("aria-label", cell.title);
      el.studyHeatmap.append(cell);
    });
  }
}
function historyDateLabel(timestamp, active = false) {
  if (active) return "Now • In progress";
  const date = new Date(Number(timestamp) || 0);
  if (!Number.isFinite(date.getTime())) return "Date unavailable";
  const day = todayKey(date) === todayKey() ? "Today" : date.toLocaleDateString([], { month: "short", day: "numeric", year: date.getFullYear() === new Date().getFullYear() ? undefined : "numeric" });
  return day + " • " + date.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}
function missionCompletionPercent() {
  const tasks = state.daily.tasks || [];
  if (!tasks.length) return 0;
  const total = tasks.reduce((sum, task) => sum + Math.max(10, Number(task.minutes) || 20), 0);
  const done = tasks.filter((task) => task.done).reduce((sum, task) => sum + Math.max(10, Number(task.minutes) || 20), 0);
  return Math.round((done / Math.max(1, total)) * 100);
}
function systemGoalsData() { return dailySystemGoals(state); }
function renderSystemGoals() {
  if (!el.systemGoalsList) return;
  el.systemGoalsList.innerHTML = "";
  systemGoalsData().forEach((goal) => {
    const card = document.createElement("article");
    card.className = "system-goal-card" + (goal.done ? " done" : "");
    card.innerHTML = "<div><span></span><h4></h4><p></p></div><strong></strong><div class='progress-bar'><span></span></div>";
    card.querySelector("span").textContent = goal.done ? "Complete" : "In progress";
    card.querySelector("h4").textContent = goal.title;
    card.querySelector("p").textContent = goal.display || Math.min(goal.value, goal.target) + " / " + goal.target;
    card.querySelector("strong").textContent = "+" + goal.xp + " XP";
    card.querySelector(".progress-bar span").style.width = goal.percent + "%";
    el.systemGoalsList.append(card);
  });
}
function missionCard(task, index) {
  const item = document.createElement("article");
  item.className = "mission-item personal-goal-card" + (task.done ? " done" : "");
  item.innerHTML = "<input class='done' type='checkbox'><div class='personal-goal-copy'><strong></strong><span></span><p></p><small>No XP - personal goal</small></div><div class='mission-actions'><button class='button secondary compact-button edit' type='button'>Edit</button><button class='icon-button danger del' type='button'>x</button></div>";
  item.querySelector(".done").checked = task.done;
  item.querySelector("strong").textContent = task.title || "Personal goal";
  item.querySelector("span").textContent = (task.area || "Personal") + (Number(task.minutes || 0) ? " - " + task.minutes + " min" : "");
  item.querySelector("p").textContent = task.note || "No note added.";
  item.querySelector(".done").addEventListener("change", (e) => updateTask(index, { done: e.target.checked }));
  item.querySelector(".edit").addEventListener("click", () => editTask(index));
  item.querySelector(".del").addEventListener("click", () => deleteTask(index));
  return item;
}
function renderMissions() {
  renderSystemGoals();
  if (el.personalTaskList) {
    el.personalTaskList.innerHTML = "";
    const percent = missionCompletionPercent();
    el.missionProgressText.textContent = percent + "%";
    el.missionProgressFill.style.width = percent + "%";
    const indexed = state.daily.tasks.map((task, index) => ({ task, index }));
    if (!indexed.length) el.personalTaskList.innerHTML = "<div class='empty-state'><h4>No personal goals yet</h4><p>Add homework, assignments, revision, or any custom goal here. These do not award XP.</p></div>";
    else indexed.forEach(({ task, index }) => el.personalTaskList.append(missionCard(task, index)));
  }
}
function renderPlanner() {
  if (!el.plannerTimeline) return;
  if (el.plannerDateInput && !el.plannerDateInput.value) el.plannerDateInput.value = todayKey();
  el.plannerTimeline.innerHTML = "";
  const items = [...(state.planner?.items || [])].sort((a, b) => a.date.localeCompare(b.date) || Number(a.done) - Number(b.done)).slice(0, 18);
  if (!items.length) {
    el.plannerTimeline.innerHTML = "<div class='empty-state compact-empty'><h4>Nothing scheduled yet</h4><p>Schedule the next revision, study block, or deadline. Planner items help you organize but do not award XP.</p></div>";
    return;
  }
  items.forEach((item) => {
    const row = document.createElement("article");
    row.className = "planner-item" + (item.done ? " done" : "");
    row.innerHTML = "<input type='checkbox'><div><span></span><strong></strong><p></p></div><button class='icon-button danger remove' type='button' aria-label='Delete plan'>x</button>";
    const check = row.querySelector("input");
    check.checked = item.done;
    check.addEventListener("change", () => updatePlannerItem(item.id, { done: check.checked }));
    row.querySelector("span").textContent = item.kind + " - " + new Date(item.date + "T00:00:00").toLocaleDateString([], { month: "short", day: "numeric" });
    row.querySelector("strong").textContent = item.title;
    row.querySelector("p").textContent = courseName(item.courseId) + (item.minutes ? " - " + item.minutes + " min" : "");
    row.querySelector(".remove").addEventListener("click", () => deletePlannerItem(item.id));
    el.plannerTimeline.append(row);
  });
}
async function addPlannerItem(event) {
  event.preventDefault();
  const title = el.plannerTitleInput.value.trim();
  if (!title) return showToast("Give the study plan a clear title.");
  const item = { id: uid("plan"), title, date: el.plannerDateInput.value || todayKey(), kind: el.plannerKindInput.value, courseId: el.plannerCourseInput.value || null, minutes: Math.max(0, Number(el.plannerMinutesInput.value) || 0), done: false, createdAt: Date.now() };
  await saveState({ ...state, planner: { items: [...(state.planner?.items || []), item] } });
  el.plannerForm.reset();
  el.plannerDateInput.value = todayKey();
  showToast("Study block scheduled.");
}
async function updatePlannerItem(id, patch) {
  await saveState({ ...state, planner: { items: (state.planner?.items || []).map((item) => item.id === id ? { ...item, ...patch } : item) } });
}
async function deletePlannerItem(id) {
  if (!confirm("Delete this study plan?")) return;
  const previous = state;
  await saveState({ ...state, planner: { items: (state.planner?.items || []).filter((item) => item.id !== id) } });
  showUndo("Study plan deleted.", previous);
}
function musicMetadata(track) { return { id: track.id, title: track.title, type: track.type, size: track.size || 0, name: track.name || track.title, lastModified: track.lastModified || 0, available: Boolean(track.url) }; }
function musicKey(source = music.source, id = music.currentImportedId || MUSIC_TRACKS[music.index]?.id) { return source === "imported" ? "imported:" + id : "built-in:" + id; }
function musicTrackFromKey(key) {
  const [source, id] = String(key || "").split(":");
  if (source === "imported") return { source, track: music.imported.find((item) => item.id === id) || null };
  return { source: "built-in", track: MUSIC_TRACKS.find((item) => item.id === id) || null };
}
function playMusicKey(key) {
  const item = musicTrackFromKey(key);
  if (!item.track) return false;
  if (item.source === "imported") playImported(item.track.id);
  else playMusic(MUSIC_TRACKS.findIndex((track) => track.id === item.track.id));
  return true;
}
function saveMusicLibrary() {
  try {
    localStorage.setItem(MUSIC_LIBRARY_KEY, JSON.stringify({
      imported: music.imported.map(musicMetadata),
      currentImportedId: music.currentImportedId
    }));
  } catch {}
}
function loadMusicLibrary() {
  try {
    const raw = JSON.parse(localStorage.getItem(MUSIC_LIBRARY_KEY) || "{}");
    music.imported = Array.isArray(raw.imported) ? raw.imported.map((track) => ({ ...track, available: false, url: "" })).slice(0, 80) : [];
    music.currentImportedId = raw.currentImportedId || null;
  } catch { music.imported = []; }
}
function stopImportedAudio() {
  if (music.audio) {
    try { music.audio.pause(); } catch {}
    music.audio.onended = null;
    music.audio = null;
  }
}
function activeImportedList() {
  return music.imported.filter((track) => track.available !== false);
}
function renderMyMusic() {
  if (!el.myMusicList) return;
  el.myMusicList.innerHTML = "";
  if (!music.imported.length) {
    el.myMusicList.innerHTML = "<div class='empty-state compact-empty'><h4>No imported songs</h4><p>Add MP3, WAV, or OGG files. They stay local and are never uploaded.</p></div>";
    return;
  }
  music.imported.forEach((track) => {
    const row = document.createElement("article");
    row.className = "music-track-row" + (music.source === "imported" && music.currentImportedId === track.id ? " active" : "") + (track.available === false ? " unavailable" : "");
    row.innerHTML = "<div><strong></strong><span></span></div><button class='button secondary compact-button play-track' type='button'>Play</button><button class='button danger compact-button' type='button'>Remove</button>";
    row.querySelector("strong").textContent = track.title;
    row.querySelector("span").textContent = track.available === false ? "Re-import needed after browser restart" : track.type.toUpperCase() + " ready";
    const play = row.querySelector(".play-track");
    play.textContent = track.available === false ? "Re-import" : "Play";
    play.addEventListener("click", () => track.available === false ? el.musicImportInput.click() : playImported(track.id));
    row.querySelector(".danger").addEventListener("click", () => removeImported(track.id));
    el.myMusicList.append(row);
  });
}
function renderMusic() {
  if (!el.musicCategories) return;
  el.musicCategories.innerHTML = "";
  MUSIC_TRACKS.forEach((track, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "music-category" + (music.source === "built-in" && index === music.index ? " active" : "");
    button.innerHTML = "<strong></strong><span></span>";
    button.querySelector("strong").textContent = track.title;
    button.querySelector("span").textContent = track.description;
    button.addEventListener("click", () => playMusic(index));
    el.musicCategories.append(button);
  });
  const imported = music.imported.find((track) => track.id === music.currentImportedId);
  const builtIn = MUSIC_TRACKS[music.index];
  const current = music.source === "imported" && imported ? imported : builtIn;
  el.musicTitle.textContent = current.title;
  el.musicDescription.textContent = music.source === "imported" && imported ? (imported.available === false ? "Re-import this local file to play it again." : "Imported local audio file.") : current.description;
  el.musicStatus.textContent = music.playing ? "Music Playing" : "Stopped";
  el.musicStatus.classList.toggle("active", music.playing);
  el.musicVolumeInput.value = Math.round(music.volume * 100);
  if (el.musicVolumeLabel) el.musicVolumeLabel.textContent = Math.round(music.volume * 100) + "%";
  el.musicLoopInput.checked = music.loop;
  el.musicShuffleBtn?.classList.toggle("active", music.shuffle);
  if (el.musicPlayBtn) {
    if (el.musicPlayIcon) el.musicPlayIcon.textContent = music.playing ? "Ⅱ" : "▶";
    if (el.musicPlayLabel) el.musicPlayLabel.textContent = music.playing ? "Pause" : "Play";
    el.musicPlayBtn.setAttribute("aria-label", music.playing ? "Pause music" : "Play music");
    el.musicPlayBtn.setAttribute("aria-pressed", String(music.playing));
    el.musicPlayBtn.classList.toggle("is-playing", music.playing);
  }
  const canSeek = music.source === "imported" && Boolean(music.audio);
  if (el.musicBackBtn) el.musicBackBtn.disabled = !canSeek;
  if (el.musicForwardBtn) el.musicForwardBtn.disabled = !canSeek;
  renderMyMusic();
}
function renderMusicLibraryControls() {
  if (!el.playlistSelect || !el.musicQueue) return;
  el.playlistSelect.innerHTML = "";
  if (!music.playlists.length) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "Create a playlist first";
    el.playlistSelect.append(option);
  } else {
    music.playlists.forEach((playlist) => {
      const option = document.createElement("option");
      option.value = playlist.id;
      option.textContent = playlist.name + " (" + playlist.trackIds.length + ")";
      option.selected = playlist.id === music.activePlaylistId;
      el.playlistSelect.append(option);
    });
  }
  el.playlistAddCurrentBtn.disabled = !music.activePlaylistId;
  const currentKey = musicKey();
  el.musicFavoriteBtn.textContent = music.favorites.includes(currentKey) ? "Favorited" : "Favorite";
  el.musicFavoriteBtn.classList.toggle("active", music.favorites.includes(currentKey));
  el.musicQueue.innerHTML = "";
  if (!music.queue.length) el.musicQueue.innerHTML = "<p class='form-status'>Queue is empty. Add a sound to line up the next study block.</p>";
  else music.queue.forEach((key, index) => {
    const item = musicTrackFromKey(key);
    if (!item.track) return;
    const row = document.createElement("div");
    row.className = "queue-row";
    row.innerHTML = "<span></span><strong></strong><button class='icon-button remove' type='button' aria-label='Remove queued track'>x</button>";
    row.querySelector("span").textContent = index + 1;
    row.querySelector("strong").textContent = item.track.title;
    row.querySelector(".remove").addEventListener("click", () => { music.queue.splice(index, 1); saveMusicLibrary(); renderMusic(); });
    el.musicQueue.append(row);
  });
}
function toggleMusicFavorite() {
  const key = musicKey();
  music.favorites = music.favorites.includes(key) ? music.favorites.filter((item) => item !== key) : [...music.favorites, key];
  saveMusicLibrary();
  renderMusic();
}
function enqueueCurrentMusic() {
  const key = musicKey();
  if (music.queue.length >= 80) return showToast("Music queue is full.");
  music.queue.push(key);
  saveMusicLibrary();
  renderMusic();
  showToast("Added to queue.");
}
function createPlaylist() {
  const name = el.playlistNameInput.value.trim().slice(0, 48);
  if (!name) return showToast("Name the playlist first.");
  const playlist = { id: uid("playlist"), name, trackIds: [] };
  music.playlists.push(playlist);
  music.activePlaylistId = playlist.id;
  el.playlistNameInput.value = "";
  saveMusicLibrary();
  renderMusic();
  showToast("Playlist created.");
}
function addCurrentToPlaylist() {
  const playlist = music.playlists.find((item) => item.id === music.activePlaylistId);
  if (!playlist) return showToast("Create or choose a playlist first.");
  const key = musicKey();
  if (!playlist.trackIds.includes(key)) playlist.trackIds.push(key);
  saveMusicLibrary();
  renderMusic();
  showToast("Added to " + playlist.name + ".");
}
function playActivePlaylist() {
  const playlist = music.playlists.find((item) => item.id === music.activePlaylistId);
  if (!playlist?.trackIds.length) return showToast("Add at least one track to this playlist.");
  music.queue = [...playlist.trackIds.slice(1), ...music.queue];
  saveMusicLibrary();
  playMusicKey(playlist.trackIds[0]);
  showToast("Playing " + playlist.name + ".");
}
function deleteActivePlaylist() {
  const playlist = music.playlists.find((item) => item.id === music.activePlaylistId);
  if (!playlist || !confirm("Delete playlist '" + playlist.name + "'?")) return;
  music.playlists = music.playlists.filter((item) => item.id !== playlist.id);
  music.activePlaylistId = music.playlists[0]?.id || null;
  saveMusicLibrary();
  renderMusic();
}
function setMusicSleepTimer(minutes) {
  clearTimeout(music.sleepTimer);
  music.sleepTimer = null;
  const duration = Math.max(0, Number(minutes) || 0);
  music.sleepEndsAt = duration ? Date.now() + duration * 60000 : null;
  if (duration) music.sleepTimer = setTimeout(() => { music.sleepEndsAt = null; pauseMusic(true); showToast("Music sleep timer finished."); }, duration * 60000);
  renderMusic();
}
function ensureMusicContext() {
  if (!music.ctx) {
    music.ctx = new (window.AudioContext || window.webkitAudioContext)();
    music.gain = music.ctx.createGain();
    music.gain.gain.value = music.volume;
    music.gain.connect(music.ctx.destination);
  }
  return music.ctx;
}
function stopMusicNodes() {
  clearTimeout(music.endTimer);
  music.endTimer = null;
  music.nodes.forEach((node) => { try { node.stop?.(); } catch {} try { node.disconnect?.(); } catch {} });
  music.nodes = [];
}
function crossfadeMusicNodes() {
  if (!music.nodes.length || !music.gain || !music.ctx) return stopMusicNodes();
  clearTimeout(music.endTimer);
  music.endTimer = null;
  const previousNodes = music.nodes;
  music.nodes = [];
  const now = music.ctx.currentTime;
  music.gain.gain.cancelScheduledValues(now);
  music.gain.gain.setValueAtTime(Math.max(0.0001, music.gain.gain.value), now);
  music.gain.gain.linearRampToValueAtTime(0.0001, now + 0.14);
  setTimeout(() => {
    previousNodes.forEach((node) => { try { node.stop?.(); } catch {} try { node.disconnect?.(); } catch {} });
    const resumeAt = music.ctx.currentTime;
    music.gain.gain.setValueAtTime(0.0001, resumeAt);
    music.gain.gain.linearRampToValueAtTime(music.volume, resumeAt + 0.16);
  }, 145);
}
function makeNoiseBuffer(ctx, brown = false) {
  const length = ctx.sampleRate * 2;
  const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  let last = 0;
  for (let i = 0; i < length; i++) {
    const white = Math.random() * 2 - 1;
    data[i] = brown ? (last = (last + 0.02 * white) / 1.02) * 3.5 : white * 0.42;
  }
  return buffer;
}
function makeRainBuffer(ctx) {
  const length = ctx.sampleRate * 8;
  const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  let smooth = 0;
  for (let i = 0; i < length; i++) {
    const t = i / ctx.sampleRate;
    const white = Math.random() * 2 - 1;
    smooth = smooth * 0.78 + white * 0.22;
    const shower = white * 0.28 + smooth * 0.42;
    const droplets = Math.random() > 0.993 ? (Math.random() * 2 - 1) * 0.7 : 0;
    const thunderA = t > 1.2 && t < 2.8 ? Math.sin((t - 1.2) * Math.PI / 1.6) : 0;
    const thunderB = t > 5.4 && t < 7.1 ? Math.sin((t - 5.4) * Math.PI / 1.7) : 0;
    const rumble = (thunderA + thunderB) * smooth * 1.8;
    data[i] = Math.max(-1, Math.min(1, shower + droplets + rumble));
  }
  return buffer;
}
function createFilteredNoise(ctx, { buffer = makeNoiseBuffer(ctx), filter = 1200, gain = 0.14, filterType = "lowpass" } = {}) {
  const source = ctx.createBufferSource();
  const biquad = ctx.createBiquadFilter();
  const level = ctx.createGain();
  source.buffer = buffer;
  source.loop = true;
  biquad.type = filterType;
  biquad.frequency.value = filter;
  level.gain.value = gain;
  source.connect(biquad).connect(level).connect(music.gain);
  source.start();
  music.nodes.push(source, biquad, level);
  return level;
}
function playRainMusic(ctx) {
  createFilteredNoise(ctx, { buffer: makeRainBuffer(ctx), filter: 3600, gain: 0.17 });
  createFilteredNoise(ctx, { buffer: makeNoiseBuffer(ctx, true), filter: 150, gain: 0.12 });
}
function playCoffeeAmbience(ctx) {
  createFilteredNoise(ctx, { buffer: makeNoiseBuffer(ctx, true), filter: 720, gain: 0.075 });
  [118, 164, 226].forEach((frequency, index) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = frequency;
    gain.gain.value = 0.018 - index * 0.003;
    osc.connect(gain).connect(music.gain);
    osc.start();
    music.nodes.push(osc, gain);
  });
}
function playOceanWave(ctx) {
  const waveGain = createFilteredNoise(ctx, { buffer: makeNoiseBuffer(ctx, true), filter: 760, gain: 0.12 });
  const lfo = ctx.createOscillator();
  const lfoGain = ctx.createGain();
  lfo.frequency.value = 0.09;
  lfoGain.gain.value = 0.08;
  lfo.connect(lfoGain).connect(waveGain.gain);
  lfo.start();
  music.nodes.push(lfo, lfoGain);
}
function playMusic(index = music.index) {
  music.index = (index + MUSIC_TRACKS.length) % MUSIC_TRACKS.length;
  music.source = "built-in";
  stopImportedAudio();
  const track = MUSIC_TRACKS[music.index];
  const ctx = ensureMusicContext();
  ctx.resume?.();
  stopMusicNodes();
  if (track.type === "tone") {
    const osc = ctx.createOscillator();
    const lfo = ctx.createOscillator();
    const lfoGain = ctx.createGain();
    osc.type = track.wave;
    osc.frequency.value = track.frequency;
    lfo.frequency.value = track.lfoFrequency || (track.id === "piano" ? 1.1 : 0.32);
    lfoGain.gain.value = track.lfoGain ?? (track.id === "piano" ? 0.18 : 0.07);
    const toneGain = ctx.createGain();
    toneGain.gain.value = track.gain ?? 0.18;
    lfo.connect(lfoGain);
    lfoGain.connect(toneGain.gain);
    osc.connect(toneGain).connect(music.gain);
    osc.start();
    lfo.start();
    music.nodes.push(osc, lfo, toneGain, lfoGain);
  } else if (track.type === "rain") {
    playRainMusic(ctx);
  } else if (track.type === "coffee") {
    playCoffeeAmbience(ctx);
  } else if (track.type === "oceanwave") {
    playOceanWave(ctx);
  } else {
    createFilteredNoise(ctx, { buffer: makeNoiseBuffer(ctx, track.id === "brown"), filter: track.filter || 1000, gain: track.id === "white" ? 0.09 : 0.16 });
  }
  music.playing = true;
  if (!music.loop) music.endTimer = setTimeout(() => nextMusic(), 10 * 60 * 1000);
  saveMusicLibrary();
  renderMusic();
}
function playImported(id) {
  const track = music.imported.find((item) => item.id === id);
  if (!track) return;
  if (track.available === false || !track.url) { showToast("Re-import this song to play it again."); el.musicImportInput.click(); return; }
  music.source = "imported";
  music.currentImportedId = id;
  stopMusicNodes();
  stopImportedAudio();
  const audio = new Audio(track.url);
  audio.volume = music.volume;
  audio.loop = music.loop;
  audio.onended = () => { if (!music.loop) nextMusic(); };
  music.audio = audio;
  music.playing = true;
  audio.play().catch(() => { music.playing = false; showToast("Click Play again if Chrome blocked audio start."); renderMusic(); });
  saveMusicLibrary();
  renderMusic();
}
function pauseMusic() {
  stopMusicNodes();
  stopImportedAudio();
  music.playing = false;
  renderMusic();
}
function randomOtherIndex(length, current) {
  if (length <= 1) return 0;
  let next = Math.floor(Math.random() * length);
  if (next === current) next = (next + 1) % length;
  return next;
}
function previousMusic() {
  if (music.source === "imported") {
    const list = activeImportedList();
    const index = list.findIndex((track) => track.id === music.currentImportedId);
    if (list.length) playImported(list[(index - 1 + list.length) % list.length].id);
    return;
  }
  playMusic(music.shuffle ? randomOtherIndex(MUSIC_TRACKS.length, music.index) : music.index - 1);
}
function nextMusic() {
  if (music.source === "imported") {
    const list = activeImportedList();
    const index = list.findIndex((track) => track.id === music.currentImportedId);
    if (list.length) playImported(list[music.shuffle ? randomOtherIndex(list.length, index) : (index + 1) % list.length].id);
    return;
  }
  playMusic(music.shuffle ? randomOtherIndex(MUSIC_TRACKS.length, music.index) : music.index + 1);
}
function handleMusicCommand(action) {
  if (action === "play") { music.source === "imported" && music.currentImportedId ? playImported(music.currentImportedId) : playMusic(); return true; }
  if (action === "pause") { pauseMusic(); return true; }
  if (action === "next") { nextMusic(); return true; }
  if (action === "previous") { previousMusic(); return true; }
  return false;
}
function seekImportedMusic(seconds) {
  if (!music.audio) return showToast("Seeking works with imported songs only.");
  const duration = Number.isFinite(music.audio.duration) ? music.audio.duration : 0;
  const next = Math.max(0, Math.min(duration || music.audio.currentTime + seconds, music.audio.currentTime + seconds));
  music.audio.currentTime = next;
}
function setMusicVolume(value) {
  music.volume = Math.max(0, Math.min(1, Number(value) / 100));
  if (music.gain) music.gain.gain.value = music.volume;
  if (music.audio) music.audio.volume = music.volume;
  if (el.musicVolumeLabel) el.musicVolumeLabel.textContent = Math.round(music.volume * 100) + "%";
}
function importMusicFiles(files) {
  const accepted = ["audio/mpeg", "audio/wav", "audio/ogg", "audio/x-wav"];
  let added = 0;
  Array.from(files || []).forEach((file) => {
    const ext = file.name.split(".").pop()?.toLowerCase();
    if (!accepted.includes(file.type) && !["mp3", "wav", "ogg"].includes(ext)) return;
    const existing = music.imported.find((track) => track.name === file.name && track.size === file.size && track.lastModified === file.lastModified);
    const next = { id: existing?.id || uid("song"), title: file.name.replace(/\.[^.]+$/, ""), name: file.name, type: ext || "audio", url: URL.createObjectURL(file), size: file.size, lastModified: file.lastModified, available: true };
    if (existing) {
      if (existing.url) URL.revokeObjectURL(existing.url);
      Object.assign(existing, next);
    } else {
      music.imported.push(next);
    }
    added += 1;
  });
  if (added) { saveMusicLibrary(); showToast(added + " song" + (added === 1 ? "" : "s") + " ready."); }
  renderMusic();
}
function removeImported(id) {
  const track = music.imported.find((item) => item.id === id);
  if (!track || !confirm("Remove this imported song from My Music?")) return;
  if (music.currentImportedId === id) pauseMusic();
  if (track.url) URL.revokeObjectURL(track.url);
  music.imported = music.imported.filter((item) => item.id !== id);
    saveMusicLibrary();
  renderMusic();
}
const HELP_INFO = Object.freeze({
  "xp-rank": { title: "XP & Rank", text: "XP comes from completed focus sessions, verified system goals, and study streaks. Your level and rank update automatically as XP grows." },
  "focus-mode": { title: "Focus Mode", text: "Starts a timed session for your selected course. During the session, your course, its saved links, and Supporting Sites stay available." },
  "approved-sites": { title: "Approved Study Sites", text: "Enables Focus Mode's strict allowlist. When it is on, pages outside your course, saved links, and Supporting Sites are redirected until you pause or stop." },
  "today-study-time": { title: "Today Study Time", text: "Shows focused time recorded today. Paused time never counts, and an early stop keeps only the time you actually focused." },
  "today-sessions": { title: "Today Sessions", text: "Counts focus sessions that reached their planned end today." },
  "productivity-score": { title: "Productivity Score", text: "A 0-100 daily score based on actual study time, completed sessions, and blocked distraction attempts." },
  "study-music": { title: "Study Music", text: "Plays built-in focus sounds or local audio while you study. It does not upload your music." },
  "my-music": { title: "My Music", text: "Imports MP3, WAV, or OGG files from your device. Files stay local; after a browser restart, re-import them to reconnect playback." },
  "add-course": { title: "Add Course", text: "Saves an educational web page or video as a course you can open and use in Focus Mode." },
  "study-analytics": { title: "Study Analytics", text: "Shows time from each recorded focus session, including tracked sessions you ended early. Completion-based streaks and rewards remain separate." },
  "daily-goal": { title: "Daily Goal", text: "Compares today's recorded study minutes with your daily time target. Sessions, XP, and streaks do not change this percentage." },
  "study-streak": { title: "Study Streak", text: "Counts consecutive local calendar days with at least one completed focus session. Completing a session today continues the streak." },
  "daily-study-time": { title: "Daily Study Time", text: "Shows tracked study minutes for each day in the selected period. The reference line marks your daily time target." },
  "subject-study-time": { title: "Subject Study Time", text: "Compares tracked minutes for each subject with its target for the selected period. Edit targets to match your plan." },
  "system-goals": { title: "System Goals", text: "Automatically tracked goals that complete only from verified study activity and can contribute to XP." },
  "personal-goals": { title: "Personal Goals", text: "Your private planning list for tasks and reminders. Marking these complete does not award XP." },
  "supporting-sites": { title: "Supporting Sites", text: "These domains remain available during Focus Mode. Outside a session, normal browsing applies." },
  "distraction-protection": { title: "Distraction Protection", text: "Redirects only the sites in your Distracting Sites list whenever this switch is on, including outside Focus Mode." },
  "camera-focus-check": { title: "Camera Focus Check", text: "An optional beta attention cue that runs only during active focus sessions. It processes temporary camera frames locally and never saves or uploads video." },
  "incognito-protection": { title: "Incognito Protection", text: "Extends your existing protection rules to Incognito windows after Chrome's Allow in incognito permission is enabled." },
  "general-settings": { title: "General Settings", text: "Sets the defaults for new focus sessions, including duration, study profile, theme, and sound." },
  default: { title: "Help", text: "Learn what this control does before changing it." }
});
function showHelp(button) {
  const info = HELP_INFO[button.dataset.helpKey] || HELP_INFO.default;
  el.helpPopover.innerHTML = "";
  const heading = document.createElement("strong");
  heading.textContent = info.title;
  const copy = document.createElement("p");
  copy.textContent = info.text;
  el.helpPopover.append(heading, copy);
  const rect = button.getBoundingClientRect();
  el.helpPopover.style.left = Math.min(window.innerWidth - 300, Math.max(12, rect.left)) + "px";
  el.helpPopover.style.top = Math.min(window.innerHeight - 120, rect.bottom + 8) + "px";
  el.helpPopover.classList.remove("hidden");
}
function renderSettings() {
  if (!el.settingsForm) return;
  el.settingsFocusMinutesInput.value = state.settings.focusMinutesDefault || 50;
  if (el.studyProfileSelect) el.studyProfileSelect.value = state.profile?.studyProfile || "jee";
  el.themeModeSelect.value = state.settings.themeMode || "dark";
  if (el.soundEnabledInput) el.soundEnabledInput.checked = Boolean(state.settings.soundEnabled);
  if (el.soundVolumeInput) el.soundVolumeInput.value = Number(state.settings.soundVolume || 35);
  if (el.soundVolumeLabel) el.soundVolumeLabel.textContent = Number(state.settings.soundVolume || 35) + "%";
  if (el.cameraAttentionEnabledInput) el.cameraAttentionEnabledInput.checked = Boolean(state.settings.cameraAttentionEnabled);
  if (el.cameraAttentionSensitivityInput) el.cameraAttentionSensitivityInput.value = state.settings.cameraAttentionSensitivity || "balanced";
  if (el.cameraAttentionGraceInput) el.cameraAttentionGraceInput.value = String(state.settings.cameraAttentionGraceSeconds || 10);
  if (el.cameraAttentionVoiceInput) el.cameraAttentionVoiceInput.checked = Boolean(state.settings.cameraAttentionVoice);
  renderCameraAttention();
}

function renderCourseSwitchModal() {
  if (!el.courseSwitchList) return;
  el.courseSwitchList.innerHTML = "";
  if (!state.courses.length) {
    el.courseSwitchList.innerHTML = "<div class='empty-state'><h4>No courses yet</h4><p>Add one educational link in the Courses tab first.</p></div>";
    return;
  }
  state.courses.forEach((course) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "course-switch-item" + (course.id === state.settings.defaultCourseId ? " active" : "");
    button.innerHTML = "<strong></strong><span></span>";
    button.querySelector("strong").textContent = course.title;
    button.querySelector("span").textContent = (course.subject || "Other") + " - " + (safeUrl(course.url)?.hostname.replace(/^www\./, "") || "study link");
    button.addEventListener("click", async () => {
      await updateSettings({ defaultCourseId: course.id });
      el.courseModal.classList.add("hidden");
      showToast("Course selected: " + course.title);
    });
    el.courseSwitchList.append(button);
  });
}

function openCourseSwitchModal() {
  renderCourseSwitchModal();
  el.courseModal.classList.remove("hidden");
}

function renderCompletion() {
  if (!el.completionModal) return;
  const summary = state.focusCompletion;
  el.completionModal.classList.toggle("hidden", !summary);
  if (!summary) return;
  el.completionSubject.textContent = summary.subject || "Study";
  el.completionDuration.textContent = formatDuration(summary.durationMinutes || 0);
  el.completionXp.textContent = "+" + (summary.xpEarned || sessionXp(summary.durationMinutes, true)) + " XP";
  el.completionToday.textContent = formatDuration(summary.todayTotalMinutes || completedMinutesToday());
  el.completionStreak.textContent = (summary.streak || state.analytics.streak?.current || 0) + " days";
}

function renderWelcomeBack() {
  if (!el.welcomeBackModal) return;
  const session = activeSession();
  const show = Boolean(session?.welcomeBack);
  el.welcomeBackModal.classList.toggle("hidden", !show);
  if (!show) return;
  const remaining = Math.max(1, Math.ceil(sessionRemainingMs(session) / 60000));
  el.welcomeBackTime.textContent = formatDuration(remaining);
}

async function clearWelcomeBack() {
  const session = activeSession();
  if (!session?.welcomeBack) return;
  await saveState({ ...state, focusSession: { ...session, welcomeBack: false } });
}

async function clearCompletion() {
  if (!state.focusCompletion) return;
  await saveState({ ...state, focusCompletion: null });
}

function renderOnboarding() {
  const profile = state.profile || {};
  const shouldShow = !profile.onboarded || Number(profile.onboardingVersion || 0) < ONBOARDING_VERSION;
  el.onboardingOverlay?.classList.toggle("hidden", !shouldShow);
  if (!shouldShow) return;
  el.onboardingOverlay?.classList.remove("fade-out");
  syncOnboardingControls();
  renderOnboardingProfileCards();
  renderOnboardingSummary();
  showOnboardingStep(onboardingStep);
}

function showOnboardingStep(step) {
  const previousStep = onboardingStep;
  onboardingStep = ONBOARDING_STEPS.includes(step) ? step : "welcome";
  $$(".onboarding-step").forEach((item) => item.classList.toggle("active", item.dataset.step === onboardingStep));
  const stepIndex = Math.max(0, ONBOARDING_STEPS.indexOf(onboardingStep));
  if (el.onboardingProgressText) el.onboardingProgressText.textContent = "Step " + (stepIndex + 1) + " of " + ONBOARDING_STEPS.length;
  if (el.onboardingProgressFill) el.onboardingProgressFill.style.width = ((stepIndex + 1) / ONBOARDING_STEPS.length * 100) + "%";
  el.onboardingCard?.setAttribute("data-step", onboardingStep);
  el.onboardingCard?.classList.remove("step-animate");
  void el.onboardingCard?.offsetWidth;
  el.onboardingCard?.classList.add("step-animate");
  if (onboardingStep === "profile") renderOnboardingTargetEditor();
  if (onboardingStep === "ready") renderOnboardingSummary();
  if (previousStep !== onboardingStep) {
    const nextStep = onboardingStep;
    requestAnimationFrame(() => {
      if (nextStep !== onboardingStep || el.onboardingOverlay?.classList.contains("hidden")) return;
      document.querySelector(".onboarding-step.active .button.primary")?.focus({ preventScroll: true });
    });
  }
}

function handleWelcomeOnboardingKeydown(event) {
  if (event.key !== "Enter" || event.isComposing || event.repeat) return;
  if (el.onboardingOverlay?.classList.contains("hidden")) return;
  if (onboardingStep === "profile" && event.target === el.onboardingNewSubjectInput && !el.onboardingAddSubjectRow?.classList.contains("hidden")) {
    event.preventDefault();
    addOnboardingTargetSubject();
    return;
  }
  const actions = {
    welcome: el.onboardingGetStartedBtn,
    profile: el.onboardingProfileNextBtn,
    protection: el.onboardingProtectionNextBtn,
    ready: el.finishTutorialBtn
  };
  const action = actions[onboardingStep];
  if (!action || action.disabled) return;
  const targetButton = event.target instanceof Element ? event.target.closest("button") : null;
  if (targetButton && targetButton !== action && targetButton.closest(".onboarding-step.active")) return;
  event.preventDefault();
  action.click();
}

function cleanOnboardingName() {
  return String(el.onboardingNameInput ? el.onboardingNameInput.value : (onboardingNameDraft ?? state.profile?.name ?? "")).trim().slice(0, 60);
}

function currentOnboardingProfileChoice() {
  if (onboardingProfileChoice && ONBOARDING_PROFILE_OPTIONS[onboardingProfileChoice]) return onboardingProfileChoice;
  const storedProfile = state.profile?.studyProfile || "jee";
  return Object.entries(ONBOARDING_PROFILE_OPTIONS).find(([, option]) => option.profileId === storedProfile)?.[0] || "jee";
}

function currentOnboardingProfileId() {
  return ONBOARDING_PROFILE_OPTIONS[currentOnboardingProfileChoice()]?.profileId || "jee";
}

function syncOnboardingControls() {
  if (onboardingNameDraft === null) onboardingNameDraft = state.profile?.name || "";
  if (el.onboardingNameInput) el.onboardingNameInput.value = onboardingNameDraft;
  if (onboardingThemeChoice === null) onboardingThemeChoice = state.settings?.themeMode || "dark";
  if (onboardingDurationDraft === null) onboardingDurationDraft = String(state.settings?.focusMinutesDefault || 50);
  if (el.onboardingFocusMinutesInput) el.onboardingFocusMinutesInput.value = String(onboardingDurationDraft);
  renderOnboardingThemeOptions();
}

function renderOnboardingThemeOptions() {
  el.onboardingThemeOptions?.querySelectorAll("[data-onboarding-theme]").forEach((button) => {
    const selected = button.dataset.onboardingTheme === onboardingThemeChoice;
    button.classList.toggle("selected", selected);
    button.setAttribute("aria-pressed", String(selected));
  });
}

async function selectOnboardingTheme(mode) {
  if (!Object.hasOwn(ONBOARDING_THEME_NAMES, mode)) return;
  onboardingThemeChoice = mode;
  renderOnboardingThemeOptions();
  document.documentElement.dataset.theme = resolvedTheme(mode);
  document.documentElement.dataset.themeMode = mode;
  try { localStorage.setItem(THEME_MODE_CACHE_KEY, mode); } catch {}
  try {
    await updateSettings({ themeMode: mode });
  } catch (error) {
    onboardingThemeChoice = state.settings?.themeMode || "dark";
    applyTheme();
    renderOnboardingThemeOptions();
    showToast(error?.message || "Theme could not be saved.");
  }
}

function renderOnboardingProfileCards() {
  const selected = currentOnboardingProfileChoice();
  $$(".onboarding-profile-option").forEach((card) => {
    const active = card.dataset.onboardingProfile === selected;
    card.classList.toggle("selected", active);
    card.setAttribute("aria-pressed", String(active));
  });
}

function selectOnboardingProfile(choice) {
  if (!ONBOARDING_PROFILE_OPTIONS[choice]) return;
  const previousProfileId = currentOnboardingProfileId();
  captureOnboardingTargetDraft();
  onboardingProfileChoice = choice;
  const nextProfileId = currentOnboardingProfileId();
  if (previousProfileId !== nextProfileId) {
    const suggestions = studyTargetSuggestions(nextProfileId);
    const canReplaceUntouchedSuggestions = !onboardingTargetsTouched && !state.profile?.startedAt && !state.goals?.analyticsTargets;
    if (canReplaceUntouchedSuggestions) {
      onboardingTargetsDraft = { ...suggestions, customSubjects: [], sortBy: "actual" };
    } else {
      onboardingTargetsDraft ||= { ...suggestions, customSubjects: [], sortBy: "actual" };
      onboardingTargetsDraft.subjectTargets = { ...suggestions.subjectTargets, ...onboardingTargetsDraft.subjectTargets };
    }
    onboardingTargetsProfileId = nextProfileId;
    renderOnboardingTargetEditor();
  }
  renderOnboardingProfileCards();
}

function normalizeOnboardingDuration(value) {
  const raw = String(value ?? "").trim();
  const numeric = raw ? Number(raw) : Number(state.settings?.focusMinutesDefault) || 50;
  const bounded = Math.max(5, Math.min(240, Number.isFinite(numeric) ? numeric : 50));
  return Math.max(5, Math.min(240, Math.round(bounded / 5) * 5));
}

function initialOnboardingTargets(profileId) {
  const suggestions = studyTargetSuggestions(profileId);
  const resolved = resolveStudyTargets({ ...state, profile: { ...(state.profile || {}), studyProfile: profileId } });
  const isNewSetup = !state.profile?.startedAt && !state.goals?.analyticsTargets;
  return {
    profileId,
    dailyMinutes: isNewSetup ? suggestions.dailyMinutes : resolved.dailyMinutes,
    weeklyMinutes: resolved.weeklyMinutes,
    subjectTargets: { ...suggestions.subjectTargets, ...resolved.subjectTargets },
    customSubjects: [...resolved.customSubjects],
    sortBy: resolved.sortBy
  };
}

function captureOnboardingTargetDraft() {
  if (!el.onboardingTargetSubjectList) return onboardingTargetsDraft;
  const profileId = currentOnboardingProfileId();
  const base = onboardingTargetsDraft || initialOnboardingTargets(profileId);
  const readHours = (input, fallback) => {
    const value = input?.valueAsNumber;
    return Number.isFinite(value) ? Math.round(Math.max(0, Math.min(168, value)) * 4) * 15 : fallback;
  };
  const subjectTargets = {};
  const customSubjects = [];
  el.onboardingTargetSubjectList.querySelectorAll(".analytics-target-subject-row").forEach((row) => {
    const original = String(row.dataset.subjectName || "").trim();
    const subject = String(row.querySelector(".analytics-target-subject-name")?.value || original).trim().replace(/\s+/g, " ").slice(0, 48);
    const hoursValue = row.querySelector(".analytics-target-subject-input")?.valueAsNumber;
    if (!subject) return;
    subjectTargets[subject] = Math.round(Math.max(0, Math.min(168, Number.isFinite(hoursValue) ? hoursValue : 0)) * 4) * 15;
    if (row.dataset.custom === "true") customSubjects.push(subject);
  });
  onboardingTargetsDraft = {
    profileId,
    dailyMinutes: readHours(el.onboardingDailyTargetInput, base.dailyMinutes),
    weeklyMinutes: readHours(el.onboardingWeeklyTargetInput, base.weeklyMinutes),
    subjectTargets,
    customSubjects: [...new Set(customSubjects)],
    sortBy: base.sortBy || "actual"
  };
  onboardingTargetsProfileId = profileId;
  return onboardingTargetsDraft;
}

function onboardingSubjectIsEditable(name, profileId) {
  const customizableProfile = ["school", "college", "custom"].includes(profileId);
  return customizableProfile || onboardingTargetsDraft.customSubjects.includes(name) || !Object.hasOwn(studyTargetSuggestions(profileId).subjectTargets, name);
}

function renderOnboardingTargetEditor() {
  if (!el.onboardingTargetSubjectList) return;
  const profileId = currentOnboardingProfileId();
  if (!onboardingTargetsDraft) {
    onboardingTargetsDraft = initialOnboardingTargets(profileId);
    onboardingTargetsTouched = Boolean(state.profile?.startedAt || state.goals?.analyticsTargets);
    onboardingTargetsProfileId = profileId;
  }
  const suggestions = studyTargetSuggestions(profileId);
  const names = [...new Set([...Object.keys(suggestions.subjectTargets), ...Object.keys(onboardingTargetsDraft.subjectTargets || {}), ...(onboardingTargetsDraft.customSubjects || [])])].slice(0, 80);
  if (el.onboardingDailyTargetInput) el.onboardingDailyTargetInput.value = String(Number((onboardingTargetsDraft.dailyMinutes / 60).toFixed(2)));
  if (el.onboardingWeeklyTargetInput) el.onboardingWeeklyTargetInput.value = String(Number((onboardingTargetsDraft.weeklyMinutes / 60).toFixed(2)));
  if (el.onboardingTargetSubjectList.children.length && el.onboardingTargetSubjectList.dataset.profileId === profileId) return;
  el.onboardingTargetSubjectList.innerHTML = "";
  names.forEach((name) => {
    const row = makeAnalyticsTargetSubjectRow(name, onboardingTargetsDraft.subjectTargets[name] || 0, onboardingSubjectIsEditable(name, profileId));
    row.classList.add("onboarding-target-subject-row");
    el.onboardingTargetSubjectList.append(row);
  });
  el.onboardingTargetSubjectList.dataset.profileId = profileId;
  onboardingTargetsProfileId = profileId;
}

function renderOnboardingSummary() {
  const choice = ONBOARDING_PROFILE_OPTIONS[currentOnboardingProfileChoice()] || ONBOARDING_PROFILE_OPTIONS.jee;
  const targets = onboardingTargetsDraft || initialOnboardingTargets(choice.profileId);
  const duration = normalizeOnboardingDuration(onboardingDurationDraft ?? state.settings?.focusMinutesDefault);
  if (el.onboardingReadyName) el.onboardingReadyName.textContent = cleanOnboardingName() || "Not provided";
  if (el.onboardingReadyProfile) el.onboardingReadyProfile.textContent = choice.name;
  if (el.onboardingReadyTheme) el.onboardingReadyTheme.textContent = ONBOARDING_THEME_NAMES[onboardingThemeChoice || state.settings?.themeMode] || "Dark";
  if (el.onboardingReadyDuration) el.onboardingReadyDuration.textContent = duration + " minutes";
  if (el.onboardingReadyDailyTarget) el.onboardingReadyDailyTarget.textContent = formatDuration(targets.dailyMinutes) + " / day";
  if (el.onboardingReadyWeeklyTarget) el.onboardingReadyWeeklyTarget.textContent = formatDuration(targets.weeklyMinutes) + " / week";
  if (el.onboardingReadySubjects) {
    el.onboardingReadySubjects.innerHTML = "";
    const entries = Object.entries(targets.subjectTargets || {}).sort(([a], [b]) => a.localeCompare(b));
    if (!entries.length) {
      const empty = document.createElement("small"); empty.textContent = "No subject targets set"; el.onboardingReadySubjects.append(empty);
    } else entries.forEach(([subject, minutes]) => {
      const item = document.createElement("small");
      item.textContent = subject + " · " + (minutes ? formatDuration(minutes) : "No target");
      el.onboardingReadySubjects.append(item);
    });
  }
  if (el.onboardingReadyMessage) el.onboardingReadyMessage.textContent = "Your preferences are saved. Add courses whenever you're ready.";
}

async function saveOnboardingWelcome() {
  const duration = normalizeOnboardingDuration(el.onboardingFocusMinutesInput?.value ?? onboardingDurationDraft);
  const name = cleanOnboardingName();
  onboardingNameDraft = name;
  onboardingDurationDraft = String(duration);
  if (el.onboardingFocusMinutesInput) el.onboardingFocusMinutesInput.value = onboardingDurationDraft;
  try {
    await saveState({
      ...state,
      settings: { ...state.settings, themeMode: onboardingThemeChoice || state.settings.themeMode || "dark", focusMinutesDefault: duration },
      profile: { ...(state.profile || {}), name }
    });
    showOnboardingStep("profile");
  } catch (error) {
    showToast(error?.message || "Your preferences could not be saved.");
  }
}

function addOnboardingTargetSubject() {
  const name = String(el.onboardingNewSubjectInput?.value || "").trim().replace(/\s+/g, " ").slice(0, 48);
  if (!name) { el.onboardingNewSubjectInput?.focus(); return; }
  const exists = [...(el.onboardingTargetSubjectList?.querySelectorAll(".analytics-target-subject-row") || [])]
    .some((row) => String(row.querySelector(".analytics-target-subject-name")?.value || row.dataset.subjectName || "").trim().toLocaleLowerCase() === name.toLocaleLowerCase());
  if (exists) { showToast("That subject is already in your targets."); return; }
  const row = makeAnalyticsTargetSubjectRow(name, 120, true);
  row.classList.add("onboarding-target-subject-row");
  el.onboardingTargetSubjectList?.append(row);
  if (el.onboardingNewSubjectInput) el.onboardingNewSubjectInput.value = "";
  el.onboardingAddSubjectRow?.classList.add("hidden");
  onboardingTargetsTouched = true;
  row.querySelector(".analytics-target-subject-name")?.focus();
}

async function saveOnboardingProfile() {
  const studyProfile = currentOnboardingProfileId();
  const name = cleanOnboardingName();
  onboardingNameDraft = name;
  const draft = captureOnboardingTargetDraft() || initialOnboardingTargets(studyProfile);
  const rows = [...(el.onboardingTargetSubjectList?.querySelectorAll(".analytics-target-subject-row") || [])];
  const seen = new Set();
  for (const row of rows) {
    const name = String(row.querySelector(".analytics-target-subject-name")?.value || row.dataset.subjectName || "").trim().replace(/\s+/g, " ");
    if (!name) { row.querySelector(".analytics-target-subject-name")?.focus(); showToast("Enter a name for each subject."); return; }
    const key = name.toLocaleLowerCase();
    if (seen.has(key)) { row.querySelector(".analytics-target-subject-name")?.focus(); showToast("Each subject name must be unique."); return; }
    seen.add(key);
  }
  const suggestions = studyTargetSuggestions(studyProfile);
  const subjectTargets = { ...Object.fromEntries(Object.keys(suggestions.subjectTargets).map((subject) => [subject, 0])), ...draft.subjectTargets };
  const nextProfile = {
    ...(state.profile || {}), name, profileType: "local", email: "", studyProfile,
    startedAt: state.profile?.startedAt || Date.now(), lastProfileAt: Date.now()
  };
  const nextGoals = {
    ...state.goals,
    studyHours: Math.max(0, Math.min(24, draft.dailyMinutes / 60)),
    analyticsTargets: {
      profileId: studyProfile,
      weeklyMinutes: Math.max(0, Math.min(10080, draft.weeklyMinutes)),
      subjectTargets,
      customSubjects: [...new Set(draft.customSubjects)],
      sortBy: draft.sortBy || "actual"
    }
  };
  let nextState = { ...state, profile: nextProfile, goals: nextGoals };
  const renames = rows.filter((row) => row.dataset.custom === "true").map((row) => [String(row.dataset.subjectName || "").trim(), String(row.querySelector(".analytics-target-subject-name")?.value || row.dataset.subjectName || "").trim().replace(/\s+/g, " ").slice(0, 48)]).filter(([from, to]) => from && to && from !== to);
  renames.forEach(([from, to]) => { nextState = renameTrackedSubject(nextState, from, to); });
  try {
    await saveState(nextState);
    onboardingTargetsDraft = { ...draft, profileId: studyProfile, subjectTargets, customSubjects: [...new Set(draft.customSubjects)] };
    onboardingTargetsTouched = true;
    showOnboardingStep("protection");
  } catch (error) {
    showToast(error?.message || "Your study targets could not be saved.");
  }
}

async function saveOnboardingPreferences() {
  renderOnboardingSummary();
  showOnboardingStep("ready");
}

async function completeOnboarding(destination = "focus") {
  const cleanName = cleanOnboardingName();
  el.onboardingOverlay?.classList.add("fade-out");
  await saveState({ ...state, profile: { ...(state.profile || {}), onboarded: true, onboardingVersion: ONBOARDING_VERSION, guidedTourStatus: "not_started", guidedTourVersion: GUIDED_TOUR_VERSION, guidedTourActive: false, guidedTourStep: 0, guidedTourTabId: null, guidedTourSessionId: null, guidedTourUpdatedAt: Date.now(), name: cleanName, profileType: "local", email: "", startedAt: state.profile?.startedAt || Date.now(), lastProfileAt: Date.now() } });
  setTimeout(() => {
    el.onboardingOverlay?.classList.add("hidden");
    void startGuidedTour();
  }, 220);
  setActiveTab(destination === "courses" ? "courses" : "focus");
  showToast(cleanName ? "Setup complete, " + cleanName + "." : "Setup complete.");
}

async function showWelcomeAgain() {
  onboardingStep = "welcome";
  onboardingProfileChoice = null;
  onboardingNameDraft = state.profile?.name || "";
  onboardingThemeChoice = null;
  onboardingDurationDraft = null;
  onboardingTargetsDraft = null;
  onboardingTargetsProfileId = null;
  onboardingTargetsTouched = false;
  guidedTourAutoStartHandled = false;
  if (el.onboardingNameInput) el.onboardingNameInput.value = onboardingNameDraft;
  if (el.onboardingTargetSubjectList) { el.onboardingTargetSubjectList.innerHTML = ""; delete el.onboardingTargetSubjectList.dataset.profileId; }
  el.onboardingOverlay?.classList.remove("fade-out");
  await saveState({ ...state, profile: { ...(state.profile || {}), onboarded: false, onboardingVersion: 0, guidedTourStatus: "completed", guidedTourVersion: 0, guidedTourActive: false, guidedTourStep: 0, guidedTourTabId: null, guidedTourSessionId: null, guidedTourUpdatedAt: Date.now() } });
}

function render() {
  renderClock();
  renderHeader();
  renderFocus();
  renderTodayInsight();
  renderCourses();
  renderShield();
  if ($("#tab-analytics")?.classList.contains("active")) renderAnalytics();
  renderMissions();
  renderMusic();
  renderSettings();
  renderCourseSwitchModal();
  renderCompletion();
  renderWelcomeBack();
  renderOnboarding();
}

function savedVideoCourse(rawUrl) { return state.courses.find((course) => courseHasVideo(course, rawUrl)) || null; }
function fillYouTubeAddSelects() {
  if (!pendingYouTubeVideo) return;
  const title = safeYouTubeTitle(pendingYouTubeVideo.title, "");
  el.youtubeAddVideoTitle.textContent = title || "We couldn't read the video title. Enter it below.";
  el.youtubeNewTitleInput.value = title;
  el.youtubeNewTitleInput.placeholder = title ? "" : "Enter video title";
  el.youtubeNewTitleInput.required = !title;
  el.youtubeNewSubjectSelect.innerHTML = "";
    currentSubjects().forEach((subject) => {
    const option = document.createElement("option");
    option.value = subject;
    option.textContent = subject;
    el.youtubeNewSubjectSelect.append(option);
  });
  el.youtubeNewLibrarySelect.innerHTML = "";
  state.courseLibraries.forEach((library) => {
    const option = document.createElement("option");
    option.value = library.id;
    option.textContent = library.name;
    el.youtubeNewLibrarySelect.append(option);
  });
}
function closeYouTubeAddModal() {
  pendingYouTubeVideo = null;
  el.youtubeAddModal?.classList.add("hidden");
  if (guidedTourActive) {
    setGuidedTourSuspended(false);
    void renderGuidedTourStep();
  }
}
function openYouTubeAddModal(rawUrl, rawTitle = "") {
  const url = canonicalYouTubeVideoUrl(rawUrl);
  if (!url) return showToast("That YouTube link is not a supported video URL.");
  const existing = savedVideoCourse(url);
  if (existing) return showToast("This video is already saved in " + existing.title + ".");
  pendingYouTubeVideo = { url, title: safeYouTubeTitle(rawTitle, "") };
  fillYouTubeAddSelects();
  el.youtubeAddModal.classList.remove("hidden");
  if (!pendingYouTubeVideo.title) el.youtubeNewTitleInput?.focus({ preventScroll: true });
  if (guidedTourActive) setGuidedTourSuspended(true);
}
async function prepareGuidedTourCourseAdd(rawUrl, rawTitle = "", handoffId = null) {
  const url = canonicalYouTubeVideoUrl(rawUrl);
  if (!url) {
    showToast("That YouTube link is not a supported video URL.");
    return false;
  }
  const handoff = guidedTourHandoff();
  if (handoffId && (!handoff || handoff.id !== handoffId || handoff.url !== url)) return false;
  const existing = savedVideoCourse(url);
  if (existing) {
    if (handoff) await clearGuidedTourHandoff(handoff.id);
    setGuidedTourSuspended(false);
    await renderGuidedTourStep();
    showToast("This video is already saved in " + existing.title + ". Continue when you're ready.");
    return true;
  }
  const title = safeYouTubeTitle(rawTitle, "");
  if (el.courseTitleInput) {
    el.courseTitleInput.value = title;
    el.courseTitleInput.placeholder = title ? "Physics lecture" : "Enter video title";
  }
  if (el.courseUrlInput) el.courseUrlInput.value = url;
  setGuidedTourSuspended(false);
  await renderGuidedTourStep();
  if (!title) el.courseTitleInput?.focus({ preventScroll: true });
  showToast(title ? "Video ready. Add it to Studizen to continue." : "We couldn't read the title. Enter it in Name; the video link is ready.");
  return true;
}
async function removeCourseVideo(courseId, videoId) {
  await saveState({ ...state, courses: state.courses.map((course) => course.id === courseId ? { ...course, videos: (course.videos || []).filter((video) => video.id !== videoId) } : course) });
  showToast("Video removed.");
}
async function addCourse(title, rawUrl, subject = "Other", libraryId = el.courseLibraryInput?.value || state.courseLibraries[0]?.id || "library-main") {
  const url = validUrl(rawUrl);
  if (!url) { showToast("Paste a valid course link."); return false; }
  const duplicate = canonicalYouTubeVideoUrl(url) ? savedVideoCourse(url) : null;
  if (duplicate) { showToast("This video is already saved in " + duplicate.title + "."); return false; }
  const youtubeVideoUrl = canonicalYouTubeVideoUrl(url);
  const courseTitle = youtubeVideoUrl ? safeYouTubeTitle(title, "") : String(title || "").trim();
  if (youtubeVideoUrl && !courseTitle) {
    showToast("Enter the video title before adding it.");
    const modalIsOpen = el.youtubeAddModal && !el.youtubeAddModal.classList.contains("hidden");
    (modalIsOpen ? el.youtubeNewTitleInput : el.courseTitleInput)?.focus({ preventScroll: true });
    return false;
  }
  const targetLibraryId = state.courseLibraries.some((library) => library.id === libraryId) ? libraryId : (state.courseLibraries[0]?.id || "library-main");
  const course = { id: uid("course"), title: courseTitle || inferTitle(url), subject: normalizeSubject(subject, state.profile?.studyProfile, currentSubjects()), libraryId: targetLibraryId, url: normalizeUrl(url), videos: [], createdAt: Date.now(), lastUsedAt: null };
  await saveState({ ...state, courses: [course, ...state.courses], settings: { ...state.settings, defaultCourseId: state.settings.defaultCourseId || course.id } });
  if (el.courseTitleInput) {
    el.courseTitleInput.value = "";
    el.courseTitleInput.placeholder = "Physics lecture";
  }
  if (el.courseUrlInput) el.courseUrlInput.value = "";
  const handoff = guidedTourHandoff();
  const addedHandoffVideo = Boolean(handoff && courseHasVideo(course, handoff.url));
  // A real manual course creation is also a valid completion of this guided
  // step. The handoff only waits for the selected video while it is pending.
  if (handoff) await clearGuidedTourHandoff(handoff.id);
  if (guidedTourActive && GUIDED_TOUR_STEPS[guidedTourStepIndex]?.action === "courses") {
    setGuidedTourSuspended(false);
    await renderGuidedTourStep();
  }
  showToast(addedHandoffVideo ? "Video added. Continue when you're ready." : "Course added. Continue when you're ready.");
  return true;
}
async function deleteCourse(id) { const course = state.courses.find((c) => c.id === id); if (!course) return; if (state.focusSession?.active && state.focusSession.courseId === id) return showToast("Stop the active focus session before deleting this course."); if (!confirm("Delete course '" + course.title + "'?")) return; const previous = state; const courses = state.courses.filter((c) => c.id !== id); await saveState({ ...state, courses, settings: { ...state.settings, defaultCourseId: state.settings.defaultCourseId === id ? courses[0]?.id || null : state.settings.defaultCourseId } }); showUndo("Course deleted.", previous); }
async function createLibrary(event) { event.preventDefault(); const name = el.libraryNameInput.value.trim().slice(0, 48); if (!name) return showToast("Library name is required."); const library = { id: uid("library"), name, collapsed: false, createdAt: Date.now() }; await saveState({ ...state, courseLibraries: [...state.courseLibraries, library] }); el.libraryNameInput.value = ""; showToast("Library created."); }
async function renameLibrary(id) { const library = state.courseLibraries.find((item) => item.id === id); if (!library) return; const name = prompt("Rename library", library.name)?.trim().slice(0, 48); if (!name) return; await saveState({ ...state, courseLibraries: state.courseLibraries.map((item) => item.id === id ? { ...item, name } : item) }); showToast("Library renamed."); }
async function deleteLibrary(id) { const library = state.courseLibraries.find((item) => item.id === id); if (!library) return; if (state.courseLibraries.length <= 1) return showToast("Keep at least one course library."); const remaining = state.courseLibraries.filter((item) => item.id !== id); const fallbackId = remaining[0]?.id || "library-main"; if (!confirm("Delete library '" + library.name + "'? Courses move to " + (remaining.find((item) => item.id === fallbackId)?.name || "another library") + ".")) return; const previous = state; await saveState({ ...state, courseLibraries: remaining, courses: state.courses.map((course) => course.libraryId === id ? { ...course, libraryId: fallbackId } : course) }); showUndo("Library deleted.", previous); }
async function setLibraryCollapsed(id, collapsed) { if (!state.courseLibraries.some((library) => library.id === id && library.collapsed !== collapsed)) return; await saveState({ ...state, courseLibraries: state.courseLibraries.map((library) => library.id === id ? { ...library, collapsed } : library) }); }
async function moveCourseToLibrary(courseId, libraryId) { await saveState({ ...state, courses: state.courses.map((course) => course.id === courseId ? { ...course, libraryId } : course) }); showToast("Course moved."); }
async function openCourse(url = getActiveCourse(state)?.url) { if (!url) return showToast("No course link available."); if (hasChrome) await sendMessage({ type: "openCourse", url }); else window.open(url, "_blank", "noopener"); }
async function startFocus(courseId = getActiveCourse(state)?.id) {
  if (!courseId) { setActiveTab("courses"); return showToast("Add or select a course first."); }
  const durationMinutes = Math.max(5, Number(el.durationInput.value) || state.settings.focusMinutesDefault);
  if (hasChrome) {
    const result = await sendMessage({ type: "startFocus", payload: { courseId, durationMinutes } });
    if (!result?.ok) return showToast(result?.error || "Could not start focus.");
    state = mergeState(result.response);
    applyTheme();
    render();
  } else {
    const course = state.courses.find((c) => c.id === courseId);
    const session = { id: uid("session"), active: true, courseId, courseTitle: course.title, courseUrl: course.url, subject: course.subject || "Other", startedAt: Date.now(), endsAt: Date.now() + durationMinutes * 60000, durationMinutes, paused: false, pausedAt: null, remainingMs: durationMinutes * 60000, accumulatedPausedMs: 0, distractionsBlocked: 0 };
    await saveState({ ...state, settings: { ...state.settings, defaultCourseId: courseId, focusMinutesDefault: durationMinutes }, courses: state.courses.map((item) => item.id === courseId ? { ...item, lastUsedAt: Date.now() } : item), focusSession: session, focusCompletion: null });
    openCourse(course.url);
  }
  showToast("Focus started. Opening your course.");
}
async function pauseFocus() {
  const session = activeSession();
  if (!session || session.paused || focusActionPending) return;
  focusActionPending = true;
  renderFocus();
  if (hasChrome) {
    const result = await sendMessage({ type: "pauseFocus" });
    if (result?.ok) state = mergeState(result.response);
    else await loadState();
  } else {
    const remainingMs = sessionRemainingMs(session);
    await saveState({ ...state, focusSession: { ...session, paused: true, pausedAt: Date.now(), remainingMs, endsAt: Date.now() + remainingMs } });
  }
  focusActionPending = false;
  applyTheme();
  render();
  showToast("Focus paused. Redirect protection is off.");
}
async function resumeFocus() {
  const session = activeSession();
  if (!session?.paused || focusActionPending) return;
  const remainingMs = Math.max(0, Number(session.remainingMs) || sessionRemainingMs(session));
  focusActionPending = true;
  renderFocus();
  if (hasChrome) {
    const result = await sendMessage({ type: "resumeFocus" });
    if (result?.ok) state = mergeState(result.response);
    else await loadState();
  } else {
    await saveState({ ...state, focusSession: { ...session, paused: false, pausedAt: null, remainingMs, accumulatedPausedMs: (session.accumulatedPausedMs || 0) + Math.max(0, Date.now() - (session.pausedAt || Date.now())), endsAt: Date.now() + remainingMs } });
  }
  focusActionPending = false;
  applyTheme();
  render();
  showToast("Focus resumed. Redirect protection is active.");
}
async function stopFocus() {
  if (hasChrome) {
    const result = await sendMessage({ type: "stopFocus" });
    if (result?.ok) state = mergeState(result.response);
    applyTheme();
    render();
  } else {
    const session = state.focusSession;
    const elapsed = session ? focusElapsedMinutes(session) : 0;
    const completed = session ? !session.paused && sessionRemainingMs(session) <= 0 : false;
    await saveState({ ...state, focusSession: null, focusCompletion: completed ? { id: session.id, courseTitle: session.courseTitle, subject: session.subject || "Other", durationMinutes: elapsed, xpEarned: sessionXp(elapsed, completed), todayTotalMinutes: state.stats.focusMinutes + elapsed, streak: state.analytics.streak?.current || 1, completedAt: Date.now() } : state.focusCompletion, analytics: session ? recordFocusAnalytics(state.analytics, session, elapsed, completed) : state.analytics, stats: { ...state.stats, focusMinutes: state.stats.focusMinutes + elapsed, sessionsCompleted: state.stats.sessionsCompleted + (completed ? 1 : 0) } });
  }
  showToast("Focus stopped.");
}
async function updateTask(index, patch) { const tasks = state.daily.tasks.map((task, i) => i === index ? { ...task, ...patch } : task); await saveState({ ...state, daily: { ...state.daily, tasks } }); }
async function deleteTask(index) { const task = state.daily.tasks[index]; if (!task || !confirm("Delete personal goal '" + task.title + "'?")) return; const previous = state; const tasks = state.daily.tasks.filter((_, i) => i !== index); await saveState({ ...state, daily: { ...state.daily, tasks } }); showUndo("Personal goal deleted.", previous); }
async function editTask(index) {
  const task = state.daily.tasks[index];
  if (!task) return;
  const title = prompt("Personal goal title", task.title || "")?.trim();
  if (!title) return;
  const area = prompt("Area or subject", task.area || "Personal")?.trim() || "Personal";
  const minutes = Math.max(0, Number(prompt("Estimated minutes", task.minutes || 0)) || 0);
  const note = prompt("Short note", task.note || "")?.trim() || "";
  await updateTask(index, { title: title.slice(0, 90), area: area.slice(0, 40), minutes, note: note.slice(0, 140) });
  showToast("Personal goal updated.");
}
async function addMission(event) { event.preventDefault(); const title = el.missionTitleInput.value.trim(); if (!title) return showToast("Personal goal title is required."); const task = { id: uid("task"), title, area: el.missionAreaInput.value.trim() || "Personal", minutes: Number(el.missionMinutesInput.value) || 0, note: el.missionNoteInput.value.trim(), priority: "personal", done: false }; await saveState({ ...state, daily: { ...state.daily, tasks: [...state.daily.tasks, task] } }); el.missionForm.reset(); showToast("Personal goal added."); }
async function resetMissions() { if (!confirm("Clear all personal goals?")) return; const previous = state; await saveState({ ...state, daily: { ...state.daily, tasks: [] } }); showUndo("Personal goals cleared.", previous); }
async function requestCameraPermission() {
  if (!navigator.mediaDevices?.getUserMedia) return showToast("This Chrome installation cannot request camera access.");
  const button = el.cameraPermissionBtn;
  if (button) button.disabled = true;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: false, video: { facingMode: "user" } });
    stream.getTracks().forEach((track) => track.stop());
    if (hasChrome) {
      const result = await sendMessage({ type: "syncAttentionMonitor" });
      if (!result?.ok) throw new Error(result?.error || "Camera access was granted, but monitoring could not start.");
      state = ensureToday(mergeState(result.response));
      applyTheme();
      render();
    }
    showToast("Camera access granted. Camera Focus Check beta is ready.");
  } catch (error) {
    const denied = error?.name === "NotAllowedError" || error?.name === "SecurityError";
    showToast(denied ? "Camera access was blocked. Allow it in Chrome, then try again." : "No camera could be started. Check that it is connected and not in use.");
  } finally {
    if (button) button.disabled = false;
  }
}
async function saveCameraAttentionSettings() {
  const settingsPatch = {
    cameraAttentionEnabled: el.cameraAttentionEnabledInput?.checked ?? false,
    cameraAttentionSensitivity: el.cameraAttentionSensitivityInput?.value || "balanced",
    cameraAttentionGraceSeconds: Math.max(5, Math.min(30, Number(el.cameraAttentionGraceInput?.value) || 10)),
    cameraAttentionVoice: el.cameraAttentionVoiceInput?.checked ?? true
  };

  try {
    await updateSettings(settingsPatch);
    if (hasChrome) {
      const result = await sendMessage({ type: "syncAttentionMonitor" });
      if (!result?.ok) throw new Error(result?.error || "Camera Focus Check could not be updated.");
      state = ensureToday(mergeState(result.response));
      applyTheme();
      render();
    }
    showToast(settingsPatch.cameraAttentionEnabled ? "Camera Focus Check beta is ready for your next focus session." : "Camera Focus Check is off. Enable it in Settings to use attention checks during Focus.");
  } catch (error) {
    showToast(error.message || "Camera Focus Check could not be updated.");
  }
}
async function saveSettings(event) {
  event.preventDefault();
  const focusMinutesDefault = Math.max(5, Math.min(240, Number(el.settingsFocusMinutesInput.value) || 50));
  const studyProfile = el.studyProfileSelect?.value || state.profile?.studyProfile || "jee";
  await saveState({
    ...state,
    settings: {
      ...state.settings,
      themeMode: el.themeModeSelect.value,
      focusMinutesDefault,
      soundEnabled: el.soundEnabledInput?.checked ?? true,
      soundVolume: Math.max(0, Math.min(100, Number(el.soundVolumeInput?.value) || 0)),
      cameraAttentionEnabled: el.cameraAttentionEnabledInput?.checked ?? false,
      cameraAttentionSensitivity: el.cameraAttentionSensitivityInput?.value || "balanced",
      cameraAttentionGraceSeconds: Math.max(5, Math.min(30, Number(el.cameraAttentionGraceInput?.value) || 10)),
      cameraAttentionVoice: el.cameraAttentionVoiceInput?.checked ?? true
    },
    profile: { ...(state.profile || {}), studyProfile }
  });
  if (hasChrome) {
    const result = await sendMessage({ type: "syncAttentionMonitor" });
    if (result?.ok) state = ensureToday(mergeState(result.response));
  }
  showToast("Settings saved.");
}
async function resetAnalyticsData() {
  if (!confirm("Reset analytics, streaks, XP history, and subject study hours?")) return;
  const previous = state;
  await saveState({ ...state, analytics: defaultState().analytics, stats: { ...state.stats, focusMinutes: 0, distractions: 0, sessionsCompleted: 0 } });
  showUndo("Analytics reset.", previous);
}
async function clearAllData() {
  if (!confirm("Clear all local Studizen data? This removes courses, saved links, goals, study history, settings, and music-library details.")) return;
  const previous = state;
  let localSnapshot = [];
  try { localSnapshot = Array.from({ length: localStorage.length }, (_, index) => { const key = localStorage.key(index); return [key, localStorage.getItem(key)]; }).filter(([key]) => key); } catch {}
  await saveState(defaultState());
  try { localStorage.clear(); } catch {}
  showUndo("All data cleared.", previous, localSnapshot);
}
function exportJson() { const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" }); const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "studizen-backup.json"; a.click(); URL.revokeObjectURL(a.href); el.backupStatus.textContent = "JSON backup exported."; }
async function restoreBackupFile(event) { const file = event.target.files?.[0]; if (!file) return; if (!confirm("Restore this backup and replace current local data?")) { event.target.value = ""; return; } const previous = state; try { const text = await file.text(); await saveState(mergeState(JSON.parse(text))); el.backupStatus.textContent = "Backup restored."; showUndo("Backup restored.", previous); showToast("Backup restored."); } catch { el.backupStatus.textContent = "Backup restore failed."; } finally { event.target.value = ""; } }

function bindEvents() {
  $$(".help-button").forEach((button) => {
    const info = HELP_INFO[button.dataset.helpKey] || HELP_INFO.default;
    button.setAttribute("aria-label", "Help: " + info.title);
    button.setAttribute("title", "Learn more");
  });
  $$(".tab-button").forEach((button) => button.addEventListener("click", () => {
    const tab = button.dataset.tab;
    setActiveTab(tab);
    syncGuidedTourToManualTab(tab);
  }));
  el.cameraStatusSettingsBtn?.addEventListener("click", () => {
    setActiveTab("settings");
    syncGuidedTourToManualTab("settings");
  });
  if (el.sidebarMoreNav) {
    try { el.sidebarMoreNav.open = sessionStorage.getItem("courseFocusProSidebarMoreOpen") === "true"; } catch {}
    el.sidebarMoreNav.addEventListener("toggle", () => {
      try { sessionStorage.setItem("courseFocusProSidebarMoreOpen", String(el.sidebarMoreNav.open)); } catch {}
    });
  }
  setSiteControlExpanded(siteControlExpanded);
  Object.entries(settingsDisclosureExpanded).forEach(([key, expanded]) => setSettingsDisclosureExpanded(key, expanded));
  el.analyticsCurrentBtn?.addEventListener("click", () => { analyticsHistoryPeriod = null; renderAnalytics(); });
  el.analyticsPreviousWeekBtn?.addEventListener("click", () => { analyticsHistoryPeriod = "previous-week"; renderAnalytics(); });
  el.analyticsPreviousMonthBtn?.addEventListener("click", () => { analyticsHistoryPeriod = "previous-month"; renderAnalytics(); });
  el.analyticsTargetsToggle?.addEventListener("click", () => setAnalyticsTargetsEditor(el.analyticsTargetsEditor?.classList.contains("hidden")));
  [el.analyticsTargetsClose, el.analyticsTargetsCancel].forEach((button) => button?.addEventListener("click", () => setAnalyticsTargetsEditor(false)));
  el.analyticsTargetsForm?.addEventListener("submit", saveAnalyticsTargets);
  el.analyticsTargetsRestore?.addEventListener("click", restoreSuggestedStudyTargets);
  el.analyticsAddSubjectBtn?.addEventListener("click", () => { el.analyticsAddSubjectRow?.classList.toggle("hidden"); if (!el.analyticsAddSubjectRow?.classList.contains("hidden")) el.analyticsNewSubjectInput?.focus(); });
  el.analyticsConfirmAddSubject?.addEventListener("click", addAnalyticsTargetSubject);
  el.analyticsNewSubjectInput?.addEventListener("keydown", (event) => { if (event.key === "Enter") { event.preventDefault(); addAnalyticsTargetSubject(); } });
  el.analyticsTargetSubjectList?.addEventListener("click", (event) => { const button = event.target.closest(".analytics-target-subject-remove"); if (button) button.closest(".analytics-target-subject-row")?.remove(); });
  el.subjectChartSort?.addEventListener("change", async (event) => {
    const targets = resolveStudyTargets(state);
    await saveState({ ...state, goals: { ...state.goals, analyticsTargets: { profileId: state.profile?.studyProfile || "jee", weeklyMinutes: targets.weeklyMinutes, subjectTargets: targets.subjectTargets, customSubjects: targets.customSubjects, sortBy: event.target.value === "target" ? "target" : "actual" } } });
  });
  el.analyticsHistoryCloseBtn?.addEventListener("click", () => { analyticsHistoryPeriod = null; renderAnalytics(); });
  el.analyticsXpBtn?.addEventListener("click", () => { renderGamification(); setAnalyticsXpOpen(el.analyticsXpPopover?.classList.contains("hidden")); });
  el.analyticsXpCloseBtn?.addEventListener("click", () => setAnalyticsXpOpen(false, true));
  el.activeFocusViewBtn?.addEventListener("click", () => setActiveTab("focus"));
  el.changeCourseBtn?.addEventListener("click", openCourseSwitchModal);
  el.focusOpenCourseBtn?.addEventListener("click", () => openCourse());
  el.courseModalClose?.addEventListener("click", () => el.courseModal.classList.add("hidden"));
  el.courseModal?.addEventListener("click", (event) => { if (event.target === el.courseModal) el.courseModal.classList.add("hidden"); });
  el.youtubeAddCloseBtn?.addEventListener("click", closeYouTubeAddModal);
  el.youtubeAddModal?.addEventListener("click", (event) => { if (event.target === el.youtubeAddModal) closeYouTubeAddModal(); });
  el.youtubeNewForm?.addEventListener("submit", async (event) => { event.preventDefault(); if (!pendingYouTubeVideo) return; const added = await addCourse(el.youtubeNewTitleInput.value, pendingYouTubeVideo.url, el.youtubeNewSubjectSelect.value, el.youtubeNewLibrarySelect.value); if (added) closeYouTubeAddModal(); });
  if (hasChrome) chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "guidedTourYouTubeHandoff") return;
    resumeGuidedTourYouTubeHandoff(message.handoffId, message.dashboardTabId, message.sessionId, message.videoUrl, message.videoTitle)
      .then((handled) => sendResponse({ handled }))
      .catch(() => sendResponse({ handled: false }));
    return true;
  });
  el.onboardingGetStartedBtn?.addEventListener("click", () => { void saveOnboardingWelcome(); });
  window.addEventListener("keydown", handleWelcomeOnboardingKeydown);
  el.onboardingNameInput?.addEventListener("input", () => { onboardingNameDraft = el.onboardingNameInput.value; el.onboardingNameInput.classList.remove("input-error"); });
  el.onboardingThemeOptions?.addEventListener("click", (event) => { const option = event.target.closest?.("[data-onboarding-theme]"); if (option) void selectOnboardingTheme(option.dataset.onboardingTheme); });
  el.onboardingFocusMinutesInput?.addEventListener("input", () => { onboardingDurationDraft = el.onboardingFocusMinutesInput.value; });
  el.onboardingProfileCards?.addEventListener("click", (event) => { const card = event.target.closest?.("[data-onboarding-profile]"); if (card) selectOnboardingProfile(card.dataset.onboardingProfile); });
  el.onboardingProfileNextBtn?.addEventListener("click", saveOnboardingProfile);
  el.onboardingTargetEditor?.addEventListener("input", () => { onboardingTargetsTouched = true; captureOnboardingTargetDraft(); });
  el.onboardingAddSubjectBtn?.addEventListener("click", () => { el.onboardingAddSubjectRow?.classList.toggle("hidden"); if (!el.onboardingAddSubjectRow?.classList.contains("hidden")) el.onboardingNewSubjectInput?.focus(); });
  el.onboardingConfirmAddSubject?.addEventListener("click", addOnboardingTargetSubject);
  el.onboardingTargetSubjectList?.addEventListener("click", (event) => { const button = event.target.closest(".analytics-target-subject-remove"); if (!button) return; button.closest(".analytics-target-subject-row")?.remove(); onboardingTargetsTouched = true; captureOnboardingTargetDraft(); });
  el.onboardingProtectionNextBtn?.addEventListener("click", saveOnboardingPreferences);
  $$(".onboarding-back").forEach((button) => button.addEventListener("click", () => showOnboardingStep(button.dataset.onboardingBack)));
  el.showOnboardingBtn?.addEventListener("click", showWelcomeAgain);
  el.startGuidedTourBtn?.addEventListener("click", () => { void startGuidedTour({ restart: true }); });
  el.finishTutorialBtn?.addEventListener("click", () => completeOnboarding("focus"));
  el.guidedTourNextBtn?.addEventListener("click", () => { void moveGuidedTour(1); });
  el.guidedTourBackBtn?.addEventListener("click", () => { void moveGuidedTour(-1); });
  el.guidedTourYouTubeBtn?.addEventListener("click", () => { void openGuidedTourYouTube(); });
  el.guidedTourPopupBtn?.addEventListener("click", () => { void openGuidedTourPopup(); });
  el.guidedTourSkipBtn?.addEventListener("click", () => { void finishGuidedTour("skipped"); });
  el.completionStartBtn?.addEventListener("click", async () => { await clearCompletion(); await startFocus(); });
  el.completionBreakBtn?.addEventListener("click", clearCompletion);
  el.completionCloseBtn?.addEventListener("click", clearCompletion);
  el.completionModal?.addEventListener("click", (event) => { if (event.target === el.completionModal) clearCompletion(); });
  el.welcomeResumeBtn?.addEventListener("click", async () => { if (activeSession()?.paused) await resumeFocus(); await clearWelcomeBack(); });
  el.welcomeEndBtn?.addEventListener("click", async () => { await clearWelcomeBack(); await stopFocus(); });
  el.welcomeDismissBtn?.addEventListener("click", clearWelcomeBack);
  el.welcomeBackModal?.addEventListener("click", (event) => { if (event.target === el.welcomeBackModal) clearWelcomeBack(); });
  el.musicPlayBtn.addEventListener("click", () => {
    if (music.playing) { pauseMusic(); return; }
    if (music.source === "imported" && music.currentImportedId) playImported(music.currentImportedId);
    else playMusic();
  });
  el.musicPrevBtn.addEventListener("click", previousMusic);
  el.musicBackBtn.addEventListener("click", () => seekImportedMusic(-10));
  el.musicNextBtn.addEventListener("click", nextMusic);
  el.musicForwardBtn.addEventListener("click", () => seekImportedMusic(10));
  el.musicShuffleBtn.addEventListener("click", () => { music.shuffle = !music.shuffle; if (music.playing && music.shuffle) nextMusic(); else renderMusic(); showToast("Shuffle " + (music.shuffle ? "on" : "off") + "."); });
  el.musicImportInput.addEventListener("change", (event) => { importMusicFiles(event.target.files); event.target.value = ""; });
  el.musicVolumeInput.addEventListener("input", (event) => setMusicVolume(event.target.value));
  el.musicLoopInput.addEventListener("change", (event) => { music.loop = event.target.checked; if (music.audio) music.audio.loop = music.loop; if (music.playing && music.source === "built-in") { clearTimeout(music.endTimer); music.endTimer = null; if (!music.loop) music.endTimer = setTimeout(() => nextMusic(), 10 * 60 * 1000); } });
  el.musicSleepInput?.addEventListener("change", (event) => setMusicSleepTimer(event.target.value));
  el.musicCrossfadeInput?.addEventListener("change", (event) => { music.crossfade = event.target.checked; saveMusicLibrary(); });
  el.playlistCreateBtn?.addEventListener("click", createPlaylist);
  el.playlistSelect?.addEventListener("change", (event) => { music.activePlaylistId = event.target.value || null; saveMusicLibrary(); renderMusic(); });
  el.playlistAddCurrentBtn?.addEventListener("click", addCurrentToPlaylist);
  el.playlistPlayBtn?.addEventListener("click", playActivePlaylist);
  el.playlistDeleteBtn?.addEventListener("click", deleteActivePlaylist);
  el.musicFavoriteBtn?.addEventListener("click", toggleMusicFavorite);
  el.musicQueueBtn?.addEventListener("click", enqueueCurrentMusic);
  document.addEventListener("click", (event) => { const help = event.target.closest?.(".help-button"); if (help) { closeStudyLinkMenu(); event.preventDefault(); event.stopPropagation(); showHelp(help); return; } if (!event.target.closest?.("#helpPopover")) el.helpPopover.classList.add("hidden"); if (!event.target.closest?.("#analyticsXpControl")) setAnalyticsXpOpen(false); if (!event.target.closest?.(".study-link-action-menu, .study-link-menu-items")) closeStudyLinkMenu(); });
  window.addEventListener("keydown", (event) => { if (event.key === "Escape") { closeStudyLinkMenu(); el.helpPopover.classList.add("hidden"); setAnalyticsXpOpen(false, true); el.courseModal?.classList.add("hidden"); closeYouTubeAddModal(); if (!el.completionModal?.classList.contains("hidden")) clearCompletion(); if (!el.welcomeBackModal?.classList.contains("hidden")) clearWelcomeBack(); } });
  el.startForm.addEventListener("submit", (e) => { e.preventDefault(); startFocus(); });
  el.pauseFocusBtn?.addEventListener("click", pauseFocus);
  el.resumeFocusBtn?.addEventListener("click", resumeFocus);
  el.stopFocusBtn.addEventListener("click", stopFocus);
  el.durationInput.addEventListener("change", () => updateSettings({ focusMinutesDefault: Math.max(5, Number(el.durationInput.value) || 50) }));
  el.redirectEnabledInput.addEventListener("change", () => updateSettings({ redirectEnabled: el.redirectEnabledInput.checked }));
  el.courseForm.addEventListener("submit", (e) => { e.preventDefault(); addCourse(el.courseTitleInput.value, el.courseUrlInput.value, el.courseSubjectInput.value, el.courseLibraryInput.value); });
  el.libraryForm?.addEventListener("submit", createLibrary);
  el.studyLinkLibraryToggle?.addEventListener("click", () => setCourseLibraryExpanded(!courseLibraryExpanded));
  el.courseLibrarySearch?.addEventListener("input", (event) => { courseLibraryQuery = event.target.value || ""; courseLibraryLimit = 60; renderCourseLibraries(); });
  el.courseLibrarySource?.addEventListener("change", (event) => { courseLibrarySource = event.target.value || "all"; courseLibraryLimit = 60; renderCourseLibraries(); });
  el.courseLibrarySort?.addEventListener("change", (event) => { courseLibrarySort = event.target.value || "priority"; courseLibraryLimit = 60; renderCourseLibraries(); });
  el.noteForm?.addEventListener("submit", saveNote);
  el.noteNewBtn?.addEventListener("click", () => { clearNoteDraft(); selectedNoteId = null; setNoteEditor(null); });
  [el.noteCourseInput, el.noteTitleInput, el.noteBodyInput, el.noteChecklistInput, el.notePinnedInput].filter(Boolean).forEach((input) => input.addEventListener(input.type === "checkbox" || input.tagName === "SELECT" ? "change" : "input", () => { renderNoteCharacterCount(); queueNoteDraft(); }));
  el.noteSearchInput?.addEventListener("input", renderNotes);
  el.noteClearSearchBtn?.addEventListener("click", () => { el.noteSearchInput.value = ""; renderNotes(); });
  el.notesExportBtn?.addEventListener("click", exportNotes);
  el.notesImportBtn?.addEventListener("click", () => el.notesImportInput?.click());
  el.notesImportInput?.addEventListener("change", importNotes);
  el.flashcardForm?.addEventListener("submit", addFlashcard);
  el.allowedForm?.addEventListener("submit", (e) => { e.preventDefault(); const value = el.allowedInput.value.trim().toLowerCase(); if (!value) return; updateSettings({ allowedSites: cleanPatterns([...state.settings.allowedSites, value]) }); el.allowedInput.value = ""; });
  el.blockedForm?.addEventListener("submit", (e) => { e.preventDefault(); const value = el.blockedInput.value.trim().toLowerCase(); if (!value) return; updateSettings({ blockedSites: cleanPatterns([...state.settings.blockedSites, value]) }); el.blockedInput.value = ""; });
  el.distractionProtectionInput?.addEventListener("change", async () => { const enabled = el.distractionProtectionInput.checked; await updateSettings({ guardBlockedOutsideFocus: enabled }); showToast(enabled ? "Distraction Protection is on." : "Distraction Protection is off."); });
  el.incognitoProtectionInput?.addEventListener("change", async () => { const enabled = el.incognitoProtectionInput.checked; if (!enabled) { await updateSettings({ incognitoProtection: false }); showToast("Incognito Protection is off."); return; } const allowed = await refreshIncognitoAccessStatus(); if (!allowed) { el.incognitoProtectionInput.checked = false; renderShield(); showToast("Allow Studizen in Incognito before turning this on."); return; } await updateSettings({ incognitoProtection: true }); showToast("Incognito Protection is on."); });
  el.openIncognitoSettingsBtn?.addEventListener("click", openIncognitoSettings);
  el.addSupportingSiteBtn?.addEventListener("click", () => { el.allowedForm?.classList.toggle("hidden"); if (!el.allowedForm?.classList.contains("hidden")) el.allowedInput?.focus(); });
  el.addBlockedSiteBtn?.addEventListener("click", () => { el.blockedForm?.classList.toggle("hidden"); if (!el.blockedForm?.classList.contains("hidden")) el.blockedInput?.focus(); });
  el.siteControlToggle?.addEventListener("click", () => setSiteControlExpanded(!siteControlExpanded));
  $$('[data-settings-disclosure-toggle]').forEach((button) => button.addEventListener("click", () => {
    const key = button.dataset.settingsDisclosureToggle;
    setSettingsDisclosureExpanded(key, !settingsDisclosureExpanded[key]);
  }));
  el.allowedSearch?.addEventListener("input", (event) => { allowedSiteQuery = event.target.value || ""; renderShield(); });
  el.blockedSearch?.addEventListener("input", (event) => { blockedSiteQuery = event.target.value || ""; renderShield(); });
  el.courseHistoryToggle?.addEventListener("click", () => setCourseHistoryExpanded(!courseHistoryExpanded));
  el.courseHistorySearch?.addEventListener("input", (event) => { courseHistoryQuery = event.target.value || ""; renderCourseHistory(); });
  el.courseHistorySort?.addEventListener("change", (event) => { courseHistorySort = event.target.value || "time"; renderCourseHistory(); });
  el.addCurrentSiteBtn?.addEventListener("click", addCurrentSupportingSite);
  el.missionForm.addEventListener("submit", addMission); el.resetTasksBtn.addEventListener("click", resetMissions);
  el.plannerForm?.addEventListener("submit", addPlannerItem);
  el.soundVolumeInput?.addEventListener("input", (event) => { el.soundVolumeLabel.textContent = event.target.value + "%"; }); [el.cameraAttentionEnabledInput, el.cameraAttentionSensitivityInput, el.cameraAttentionGraceInput, el.cameraAttentionVoiceInput].filter(Boolean).forEach((input) => input.addEventListener("change", saveCameraAttentionSettings)); el.cameraPermissionBtn?.addEventListener("click", requestCameraPermission); el.settingsForm.addEventListener("submit", saveSettings); el.resetAnalyticsBtn.addEventListener("click", resetAnalyticsData); el.clearAllDataBtn.addEventListener("click", clearAllData); el.exportJsonBtn.addEventListener("click", exportJson); el.restoreBackupBtn.addEventListener("click", () => el.restoreBackupInput.click()); el.restoreBackupInput.addEventListener("change", restoreBackupFile);
  el.undoBtn.addEventListener("click", async () => { if (!undoSnapshot) return; const snapshot = undoSnapshot; const localSnapshot = undoLocalStorageSnapshot; undoSnapshot = null; undoLocalStorageSnapshot = null; el.undoBar.classList.add("hidden"); await saveState(snapshot); if (localSnapshot) { try { localStorage.clear(); localSnapshot.forEach(([key, value]) => localStorage.setItem(key, value)); } catch {} } showToast("Undo complete."); });
  systemThemeQuery?.addEventListener?.("change", () => { applyTheme(); renderAnalytics(); });
  window.addEventListener("resize", queueGuidedTourPosition);
  window.addEventListener("resize", closeStudyLinkMenu);
  window.addEventListener("scroll", (event) => { if (activeStudyLinkMenu && !activeStudyLinkMenu.menu.contains(event.target)) closeStudyLinkMenu(); }, true);
  window.addEventListener("scroll", queueGuidedTourPosition, true);
  window.addEventListener("keydown", (event) => {
    if (!guidedTourActive) return;
    if (event.key === "Enter" && !event.isComposing && !event.repeat) {
      const target = event.target instanceof Element ? event.target : null;
      const tourAction = target?.closest("#guidedTour button, #guidedTour a");
      const formControl = target?.closest("input, textarea, select, [contenteditable='true'], form");
      const settingsDisclosure = target?.closest(".settings-disclosure-toggle, #siteControlToggle");
      const plainTourCard = target?.closest("#guidedTour") && !tourAction && !formControl;
      const plainPage = !target?.closest("button, a, input, textarea, select, [contenteditable='true'], form");
      if (!tourAction && !formControl && (plainTourCard || plainPage || settingsDisclosure)) {
        event.preventDefault();
        if (!el.guidedTourNextBtn?.disabled) void moveGuidedTour(1);
        return;
      }
    }
    if (event.key === "Escape") { event.preventDefault(); void finishGuidedTour("skipped"); }
    if (event.key === "ArrowRight") { event.preventDefault(); void moveGuidedTour(1); }
    if (event.key === "ArrowLeft" && guidedTourStepIndex > 0) { event.preventDefault(); void moveGuidedTour(-1); }
  });
  if (hasChrome) chrome.storage.onChanged.addListener((changes, area) => { if (area !== "local") return; if (changes[STATE_KEY]?.newValue) { const previousReminderAt = state.attention?.lastEventAt || 0; state = ensureToday(mergeState(changes[STATE_KEY].newValue)); applyTheme(); render(); if (guidedTourActive) void renderGuidedTourStep(); const reminderAt = state.attention?.lastEventAt || 0; if (reminderAt && reminderAt !== previousReminderAt && reminderAt !== lastSeenAttentionReminderAt) { lastSeenAttentionReminderAt = reminderAt; showToast(attentionReminderText(state.attention?.reason)); } } if (changes[MUSIC_COMMAND_KEY]?.newValue) handleMusicCommand(changes[MUSIC_COMMAND_KEY].newValue.action); });
  window.addEventListener("focus", () => { void refreshIncognitoAccessStatus(); });
}
async function handleParams() {
  const params = new URLSearchParams(location.search);
  const section = params.get("section");
  const welcome = params.get("welcome");
  const youtubeAdd = params.get("youtubeAdd");
  const guidedTourHandoffId = params.get("guidedTourHandoff");
  if (welcome) showToast("Extension ready. Add your first course link.");
  if (section) { const map = { shield: "settings", mission: "daily", focus: "focus", advice: "focus", about: "about" }; setActiveTab(map[section] || section); }
  if (guidedTourHandoffId) {
    await resumeGuidedTourYouTubeHandoff(guidedTourHandoffId);
    history.replaceState(null, "", location.pathname + "?section=courses");
  } else if (youtubeAdd === "1") {
    await prepareGuidedTourCourseAdd(params.get("youtubeUrl"), params.get("youtubeTitle"));
    history.replaceState(null, "", location.pathname + "?section=courses");
  } else if (youtubeAdd === "invalid") {
    showToast("Choose a YouTube video link or video page to add it.");
    history.replaceState(null, "", location.pathname + "?section=courses");
  }
}
async function refreshDailyStateIfNeeded() {
  const before = state.daily?.date + "|" + state.stats?.date;
  const next = ensureToday(state);
  const after = next.daily?.date + "|" + next.stats?.date;
  if (before !== after) await saveState(next);
}
fillSelects(); loadMusicLibrary(); bindEvents(); await loadState(); await handleParams(); await maybeStartGuidedTour(); if (!focusQuoteShown && $("#tab-focus")?.classList.contains("active")) rotateFocusQuote(); setInterval(() => { renderFocusTick(); renderWelcomeBack(); }, 1000); setInterval(renderClock, 60000); setInterval(refreshDailyStateIfNeeded, 60000);
