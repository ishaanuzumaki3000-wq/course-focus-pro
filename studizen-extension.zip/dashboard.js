import {
  STATE_KEY,
  actualStudyMinutesForDate,
  buildTodayInsight,
  completedFocusAnalytics,
  completedPeriodAnalytics,
  canonicalYouTubeVideoUrl,
  courseHasVideo,
  STUDY_PROFILES,
  createStatePatch,
  dailySystemGoals,
  cleanPatterns,
  dateSeries,
  defaultState,
  ensureToday,
  focusElapsedMinutes,
  focusGreeting,
  formatClock,
  formatDuration,
  getActiveCourse,
  goalProgressPercent,
  mergeState,
  normalizeSubject,
  normalizeUrl,
  productivityScore,
  levelForXp,
  rankForLevel,
  recordFocusAnalytics,
  safeUrl,
  rewardXpTotal,
  sessionRemainingMs,
  sessionXp,
  subjectsForProfile,
  todayKey,
  uid
} from "./shared.js";

const hasChrome = Boolean(globalThis.chrome?.storage?.local);
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));
const systemThemeQuery = globalThis.matchMedia?.("(prefers-color-scheme: dark)");
const THEME_MODE_CACHE_KEY = "courseFocusProThemeMode";
const ONBOARDING_VERSION = 4;
const ONBOARDING_STEPS = ["welcome", "profile", "protection", "ready"];
const ONBOARDING_PROFILE_OPTIONS = Object.freeze({
  jee: { profileId: "jee", name: "JEE" },
  neet: { profileId: "school", name: "NEET" },
  school: { profileId: "school", name: "School" },
  college: { profileId: "college", name: "College" },
  upsc: { profileId: "upsc", name: "UPSC" },
  "self-learner": { profileId: "custom", name: "Self Learner" }
});
let state = defaultState();
let toastTimer = null;
let undoTimer = null;
let undoSnapshot = null;
let lastSeenAttentionReminderAt = 0;
let onboardingStep = "welcome";
let onboardingProfileChoice = null;
let charts = {};
let focusActionPending = false;
let allowedSiteQuery = "";
let blockedSiteQuery = "";
let siteControlExpanded = false;
try { siteControlExpanded = sessionStorage.getItem("courseFocusProSiteControlExpanded") === "true"; } catch {}
let completedAnalyticsCache = { signature: "", summary: null };
let courseHistoryQuery = "";
let courseHistoryExpanded = sessionStorage.getItem("courseFocusProCourseHistoryExpanded") === "true";
let analyticsHistoryPeriod = null;
let pendingYouTubeVideo = null;
let lastLiveFocusMinutes = null;
let courseLibraryQuery = "";
let courseLibrarySource = "all";
let courseLibrarySort = "priority";
let courseLibraryLimit = 60;
let courseLibraryExpanded = false;
try { courseLibraryExpanded = sessionStorage.getItem("courseFocusProStudyLinkLibraryExpanded") === "true"; } catch {}
const FOCUS_QUOTES = Object.freeze([
  "A clear hour can change the shape of a difficult topic.",
  "Protect the next small step. It is enough to begin.",
  "Return to the page. The work becomes lighter once it has your attention.",
  "Understanding grows where distraction ends.",
  "Make the next twenty minutes honest.",
  "Progress is often quiet: one concept, one page, one problem at a time.",
  "Do the part that makes tomorrow easier.",
  "Give the difficult idea enough uninterrupted time to become familiar.",
  "Consistency is built from the sessions you choose not to skip."
]);
let focusQuoteIndex = -1;
let focusQuoteShown = false;
let lastShownLevel = Number(sessionStorage.getItem("courseFocusProLastLevel") || 1);
if (globalThis.Chart?.register && !globalThis.Chart.registry.plugins.get("goalLine")) {
  globalThis.Chart.register({
    id: "goalLine",
    afterDraw(chart, _args, options) {
      const value = Number(options?.value);
      if (!Number.isFinite(value) || value <= 0) return;
      const scale = chart.options.indexAxis === "y" ? chart.scales.x : chart.scales.y;
      if (!scale) return;
      const pixel = scale.getPixelForValue(value);
      const { ctx, chartArea } = chart;
      ctx.save();
      ctx.strokeStyle = options.color || "#e59b23";
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 5]);
      ctx.beginPath();
      if (chart.options.indexAxis === "y") { ctx.moveTo(pixel, chartArea.top); ctx.lineTo(pixel, chartArea.bottom); }
      else { ctx.moveTo(chartArea.left, pixel); ctx.lineTo(chartArea.right, pixel); }
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = ctx.strokeStyle;
      ctx.font = "700 10px Inter, system-ui, sans-serif";
      ctx.textAlign = chart.options.indexAxis === "y" ? "left" : "right";
      ctx.textBaseline = "bottom";
      if (chart.options.indexAxis === "y") ctx.fillText(options.label || "Goal", Math.min(chartArea.right - 4, pixel + 5), chartArea.top + 13);
      else ctx.fillText(options.label || "Goal", chartArea.right - 4, Math.max(chartArea.top + 12, pixel - 5));
      ctx.restore();
    }
  });
}
let music = { ctx: null, gain: null, nodes: [], index: 0, playing: false, loop: true, shuffle: false, volume: 0.35, endTimer: null, imported: [], audio: null, source: "built-in", currentImportedId: null };
let uiSoundCtx = null;
const MUSIC_LIBRARY_KEY = "courseFocusProMusicLibrary";
const MUSIC_COMMAND_KEY = "courseFocusProMusicCommand";
const MUSIC_TRACKS = [
  { id: "lofi", title: "Lo-fi", description: "Soft warm tones for quiet study.", type: "tone", frequency: 196, wave: "triangle" },
  { id: "piano", title: "Piano", description: "Gentle piano-like pulses.", type: "tone", frequency: 261.63, wave: "sine" },
  { id: "nature", title: "Nature Sounds", description: "Light filtered ambience for calm focus.", type: "noise", filter: 1200 },
  { id: "white", title: "White Noise", description: "Even noise for blocking distractions.", type: "noise", filter: 5000 },
  { id: "rain", title: "Rain + Thunder", description: "Layered rain with soft distant thunder.", type: "rain" },
  { id: "brown", title: "Brown Noise", description: "Low smooth noise for concentration.", type: "noise", filter: 420 },
  { id: "deep", title: "Deep Focus", description: "Lower steady tone for long sessions.", type: "tone", frequency: 174, wave: "sine" },
  { id: "ocean", title: "Ocean Air", description: "Soft filtered wash for reading.", type: "noise", filter: 900 },
  { id: "wind", title: "Soft Wind", description: "Light airy texture for calm study.", type: "noise", filter: 2600 },
  { id: "warm", title: "Warm Pad", description: "Gentle pad for quiet problem solving.", type: "tone", frequency: 220, wave: "triangle" },
  { id: "coffee", title: "Coffee Shop Ambience", description: "Soft cafe room tone with warm background hum.", type: "coffee" },
  { id: "oceanwave", title: "Ocean Wave", description: "Slow breathing waves for relaxed study.", type: "oceanwave" },
  { id: "beat852", title: "852 Hz Beat", description: "A very subtle 852 Hz focus tone.", type: "tone", frequency: 852, wave: "sine", gain: 0.035, lfoFrequency: 3.2, lfoGain: 0.012 }
];

const el = {
  connectionLabel: $("#connectionLabel"), stateEyebrow: $("#stateEyebrow"), mainTitle: $("#mainTitle"), liveClock: $("#liveClock"), focusOpenCourseBtn: $("#focusOpenCourseBtn"),
  sidebarMoreNav: $("#sidebarMoreNav"), focusHeadline: $("#focusHeadline"), focusPill: $("#focusPill"), timerProgress: $("#timerProgress"), timerText: $("#timerText"), timerCaption: $("#timerCaption"), selectedCourseTitle: $("#selectedCourseTitle"), selectedCourseMeta: $("#selectedCourseMeta"), changeCourseBtn: $("#changeCourseBtn"), startFocusBtn: $("#startFocusBtn"), focusQuote: $("#focusQuote"),
  startForm: $("#startForm"), courseSelect: $("#courseSelect"), durationInput: $("#durationInput"), pauseFocusBtn: $("#pauseFocusBtn"), resumeFocusBtn: $("#resumeFocusBtn"), stopFocusBtn: $("#stopFocusBtn"), redirectEnabledInput: $("#redirectEnabledInput"), focusRemainingText: $("#focusRemainingText"), cameraFocusStatus: $("#cameraFocusStatus"),
  todayFocus: $("#todayFocus"), todaySessions: $("#todaySessions"), todayBlocks: $("#todayBlocks"), todayScore: $("#todayScore"), todayInsightTitle: $("#todayInsightTitle"), todayInsightText: $("#todayInsightText"),
  courseForm: $("#courseForm"), courseTitleInput: $("#courseTitleInput"), courseSubjectInput: $("#courseSubjectInput"), courseLibraryInput: $("#courseLibraryInput"), courseUrlInput: $("#courseUrlInput"), courseOverview: $("#courseOverview"), studyLinkLibraryPanel: $("#studyLinkLibraryPanel"), studyLinkLibraryToggle: $("#studyLinkLibraryToggle"), courseLibrariesList: $("#courseLibrariesList"), courseCount: $("#courseCount"), courseLibrarySearch: $("#courseLibrarySearch"), courseLibrarySource: $("#courseLibrarySource"), courseLibrarySort: $("#courseLibrarySort"), libraryForm: $("#libraryForm"), libraryNameInput: $("#libraryNameInput"),
  siteControlSection: $("#siteControlSection"), siteControlToggle: $("#siteControlToggle"), siteControlBody: $("#siteControlBody"),
  allowedForm: $("#allowedForm"), allowedInput: $("#allowedInput"), allowedList: $("#allowedList"), allowedCount: $("#allowedCount"), allowedSearch: $("#allowedSearch"), addSupportingSiteBtn: $("#addSupportingSiteBtn"), addCurrentSiteBtn: $("#addCurrentSiteBtn"), blockedForm: $("#blockedForm"), blockedInput: $("#blockedInput"), blockedList: $("#blockedList"), blockedCount: $("#blockedCount"), blockedSearch: $("#blockedSearch"), addBlockedSiteBtn: $("#addBlockedSiteBtn"), distractionProtectionInput: $("#distractionProtectionInput"), distractionProtectionState: $("#distractionProtectionState"),
  currentStreak: $("#currentStreak"), analyticsToday: $("#analyticsToday"), analyticsWeek: $("#analyticsWeek"), analyticsSessions: $("#analyticsSessions"), weeklyHours: $("#weeklyHours"), averageStudy: $("#averageStudy"), goalProgress: $("#goalProgress"), dailyComparison: $("#dailyComparison"), xpPanel: $("#analyticsXpPopover"), analyticsXpBtn: $("#analyticsXpBtn"), analyticsXpPopover: $("#analyticsXpPopover"), analyticsXpCloseBtn: $("#analyticsXpCloseBtn"), rankTitle: $("#rankTitle"), rankMeta: $("#rankMeta"), xpProgressFill: $("#xpProgressFill"), badgeRow: $("#badgeRow"), dailyChart: $("#dailyChart"), dailyChartMeta: $("#dailyChartMeta"), dailyChartGoal: $("#dailyChartGoal"), dailyChartEmpty: $("#dailyChartEmpty"), courseDistributionList: $("#courseDistributionList"), courseDistributionMeta: $("#courseDistributionMeta"), courseDistributionEmpty: $("#courseDistributionEmpty"), consistencyMeta: $("#consistencyMeta"), consistencyGoalLabel: $("#consistencyGoalLabel"), consistencyGoalValue: $("#consistencyGoalValue"), consistencyGoalPercent: $("#consistencyGoalPercent"), consistencyGoalFill: $("#consistencyGoalFill"), consistencyDailyAverage: $("#consistencyDailyAverage"), consistencySessions: $("#consistencySessions"), consistencyAverageSession: $("#consistencyAverageSession"), consistencyLongestSession: $("#consistencyLongestSession"), courseHistoryPanel: $("#courseHistoryPanel"), courseHistoryToggle: $("#courseHistoryToggle"), courseHistoryCount: $("#courseHistoryCount"), courseHistorySearch: $("#courseHistorySearch"), courseHistoryList: $("#courseHistoryList"), analyticsCurrentBtn: $("#analyticsCurrentBtn"), analyticsPreviousWeekBtn: $("#analyticsPreviousWeekBtn"), analyticsPreviousMonthBtn: $("#analyticsPreviousMonthBtn"), analyticsHistoryDrawer: $("#analyticsHistoryDrawer"), analyticsHistoryTitle: $("#analyticsHistoryTitle"), analyticsHistoryComparison: $("#analyticsHistoryComparison"), analyticsHistoryTotal: $("#analyticsHistoryTotal"), analyticsHistorySessions: $("#analyticsHistorySessions"), analyticsHistoryAverage: $("#analyticsHistoryAverage"), analyticsHistoryGoal: $("#analyticsHistoryGoal"), analyticsHistoryCourses: $("#analyticsHistoryCourses"), analyticsHistoryCloseBtn: $("#analyticsHistoryCloseBtn"),
  missionForm: $("#missionForm"), missionTitleInput: $("#missionTitleInput"), missionAreaInput: $("#missionAreaInput"), missionMinutesInput: $("#missionMinutesInput"), missionNoteInput: $("#missionNoteInput"), systemGoalsList: $("#systemGoalsList"), personalTaskList: $("#personalTaskList"), missionProgressText: $("#missionProgressText"), missionProgressFill: $("#missionProgressFill"), resetTasksBtn: $("#resetTasksBtn"),
  musicCategories: $("#musicCategories"), musicStatus: $("#musicStatus"), musicTitle: $("#musicTitle"), musicDescription: $("#musicDescription"), musicVolumeLabel: $("#musicVolumeLabel"), musicPrevBtn: $("#musicPrevBtn"), musicBackBtn: $("#musicBackBtn"), musicForwardBtn: $("#musicForwardBtn"), musicPlayBtn: $("#musicPlayBtn"), musicPauseBtn: $("#musicPauseBtn"), musicNextBtn: $("#musicNextBtn"), musicShuffleBtn: $("#musicShuffleBtn"), musicVolumeInput: $("#musicVolumeInput"), musicLoopInput: $("#musicLoopInput"), musicImportInput: $("#musicImportInput"), myMusicList: $("#myMusicList"),
  studyProfileSelect: $("#studyProfileSelect"), themeModeSelect: $("#themeModeSelect"), soundEnabledInput: $("#soundEnabledInput"), soundVolumeInput: $("#soundVolumeInput"), soundVolumeLabel: $("#soundVolumeLabel"), cameraAttentionEnabledInput: $("#cameraAttentionEnabledInput"), cameraAttentionSensitivityInput: $("#cameraAttentionSensitivityInput"), cameraAttentionGraceInput: $("#cameraAttentionGraceInput"), cameraAttentionVoiceInput: $("#cameraAttentionVoiceInput"), cameraPermissionBtn: $("#cameraPermissionBtn"), cameraSettingsState: $("#cameraSettingsState"), settingsFocusMinutesInput: $("#settingsFocusMinutesInput"), settingsForm: $("#settingsForm"), resetAnalyticsBtn: $("#resetAnalyticsBtn"), clearAllDataBtn: $("#clearAllDataBtn"), exportJsonBtn: $("#exportJsonBtn"), restoreBackupBtn: $("#restoreBackupBtn"), restoreBackupInput: $("#restoreBackupInput"), backupStatus: $("#backupStatus"),
  helpPopover: $("#helpPopover"), toast: $("#toast"), undoBar: $("#undoBar"), undoText: $("#undoText"), undoBtn: $("#undoBtn"), completionModal: $("#completionModal"), completionSubject: $("#completionSubject"), completionDuration: $("#completionDuration"), completionXp: $("#completionXp"), completionToday: $("#completionToday"), completionStreak: $("#completionStreak"), completionStartBtn: $("#completionStartBtn"), completionBreakBtn: $("#completionBreakBtn"), completionCloseBtn: $("#completionCloseBtn"), welcomeBackModal: $("#welcomeBackModal"), welcomeBackTime: $("#welcomeBackTime"), welcomeResumeBtn: $("#welcomeResumeBtn"), welcomeEndBtn: $("#welcomeEndBtn"), welcomeDismissBtn: $("#welcomeDismissBtn"), courseModal: $("#courseModal"), courseModalClose: $("#courseModalClose"), courseSwitchList: $("#courseSwitchList"), youtubeAddModal: $("#youtubeAddModal"), youtubeAddCloseBtn: $("#youtubeAddCloseBtn"), youtubeAddVideoTitle: $("#youtubeAddVideoTitle"), youtubeExistingModeBtn: $("#youtubeExistingModeBtn"), youtubeNewModeBtn: $("#youtubeNewModeBtn"), youtubeExistingForm: $("#youtubeExistingForm"), youtubeExistingCourseSelect: $("#youtubeExistingCourseSelect"), youtubeExistingTitleInput: $("#youtubeExistingTitleInput"), youtubeNewForm: $("#youtubeNewForm"), youtubeNewTitleInput: $("#youtubeNewTitleInput"), youtubeNewSubjectSelect: $("#youtubeNewSubjectSelect"), youtubeNewLibrarySelect: $("#youtubeNewLibrarySelect"), onboardingOverlay: $("#onboardingOverlay"), onboardingCard: $("#onboardingCard"), onboardingProgressText: $("#onboardingProgressText"), onboardingProgressFill: $("#onboardingProgressFill"), onboardingGetStartedBtn: $("#onboardingGetStartedBtn"), onboardingNameInput: $("#onboardingNameInput"), onboardingProfileCards: $("#onboardingProfileCards"), onboardingProfileNextBtn: $("#onboardingProfileNextBtn"), onboardingProtectionNextBtn: $("#onboardingProtectionNextBtn"), onboardingReadyProfile: $("#onboardingReadyProfile"), onboardingReadyMessage: $("#onboardingReadyMessage"), finishTutorialBtn: $("#finishTutorialBtn"), onboardingAddCourseBtn: $("#onboardingAddCourseBtn"), showOnboardingBtn: $("#showOnboardingBtn"), developerEmail: $("#developerEmail")
};

function sendMessage(message) { return hasChrome ? chrome.runtime.sendMessage(message) : Promise.resolve({ ok: false }); }
function resolvedTheme(mode) { const allowed = ["light", "dark", "midnight", "amoled", "forest", "purple", "beige", "slate", "teal", "rose"]; if (allowed.includes(mode)) return mode; return systemThemeQuery?.matches ? "dark" : "light"; }
function applyTheme() { const mode = state.settings.themeMode || "system"; document.documentElement.dataset.theme = resolvedTheme(mode); document.documentElement.dataset.themeMode = mode; try { localStorage.setItem(THEME_MODE_CACHE_KEY, mode); } catch {} if (el.themeModeSelect) el.themeModeSelect.value = mode; }
function showToast(message) { el.toast.textContent = message; el.toast.classList.add("show"); clearTimeout(toastTimer); toastTimer = setTimeout(() => el.toast.classList.remove("show"), 2400); }
function showUndo(message, snapshot) { undoSnapshot = snapshot ? JSON.parse(JSON.stringify(snapshot)) : null; if (!undoSnapshot) return; el.undoText.textContent = message; el.undoBar.classList.remove("hidden"); clearTimeout(undoTimer); undoTimer = setTimeout(() => { el.undoBar.classList.add("hidden"); undoSnapshot = null; }, 7000); }
function hours(minutes) { return Math.round((Number(minutes || 0) / 60) * 10) / 10 + "h"; }
function activeSession() { const session = state.focusSession; return session?.active && (session.paused || sessionRemainingMs(session) > 0) ? session : null; }
function cameraAttentionLabel(session = activeSession()) {
  const attention = state.attention || {};
  if (!state.settings.cameraAttentionEnabled) return "Camera Focus Check beta is off";
  if (!session) return "Camera Focus Check beta is ready for your next focus session";
  if (session.paused) return "Camera is off while Focus Mode is paused";
  const labels = {
    starting: "Starting",
    calibrating: "Calibrating",
    watching: "Watching",
    "attention-lost": "Attention detected",
    "needs-position": "Needs positioning",
    "permission-denied": "Camera permission denied",
    unsupported: "Not available in this Chrome version",
    error: attention.error || "Camera check error"
  };
  return labels[attention.status] || "Camera check is preparing";
}
function cameraAttentionIcon(session = activeSession()) {
  const status = state.attention?.status || "off";
  if (!state.settings.cameraAttentionEnabled || !session) return "⚪";
  if (session.paused) return "⏸";
  return { starting: "◌", calibrating: "🟡", watching: "🟢", "attention-lost": "🔴", "needs-position": "⚠️", "permission-denied": "❌", unsupported: "❌", error: "❌" }[status] || "◌";
}
function attentionReminderText(reason) {
  if (reason === "eyes closed") return "Attention: your eyes have been closed for a while.";
  if (reason === "eyes away from screen") return "Attention: bring your gaze back to the lesson.";
  return "Attention: you have been away from the course for a while.";
}
function renderCameraAttention(session = activeSession()) {
  if (el.cameraFocusStatus) {
    const status = state.attention?.status || "off";
    el.cameraFocusStatus.firstElementChild.textContent = cameraAttentionIcon(session);
    el.cameraFocusStatus.lastElementChild.textContent = cameraAttentionLabel(session);
    el.cameraFocusStatus.dataset.status = status;
    el.cameraFocusStatus.classList.toggle("is-active", Boolean(session && state.settings.cameraAttentionEnabled && !session.paused && status === "watching"));
  }
  if (el.cameraSettingsState) el.cameraSettingsState.textContent = cameraAttentionLabel(session);
}
function validUrl(raw) { const url = safeUrl(raw); return url && /^https?:/.test(url.protocol) ? url.href : ""; }
function inferTitle(url) { const host = safeUrl(url)?.hostname.replace(/^www\./, "") || "Study"; return host.includes("youtube") || host.includes("youtu.be") ? "YouTube Course" : host; }
function completedAnalytics() { const history = state.analytics?.focusHistory || []; const signature = String(state.profile?.studyProfile || "") + "|" + history.map((item) => [item?.id, item?.status, item?.completed, item?.actualMinutes, item?.endedAt, item?.recordedDate].join(":" )).join("|"); if (completedAnalyticsCache.signature !== signature) completedAnalyticsCache = { signature, summary: completedFocusAnalytics(state) }; return completedAnalyticsCache.summary; }
function completedFocusSessions(days = null) { const summary = completedAnalytics(); if (!days) return summary.sessions; const keys = new Set(dateSeries(days)); return summary.sessions.filter((item) => keys.has(item.recordedDate)); }
function actualFocusSessions(days = null) { return completedFocusSessions(days); }
function sessionActualMinutes(item) { return Math.max(0, Number(item?.actualMinutes ?? item?.durationMinutes) || 0); }
function actualMinutesToday() { return actualStudyMinutesForDate(state, todayKey()); }
function completedMinutesToday() { return completedAnalytics().todayMinutes; }
function completedSessionsToday() { const today = completedAnalytics().today; return completedFocusSessions().filter((item) => item.recordedDate === today).length; }
function currentSubjects() { return subjectsForProfile(state.profile?.studyProfile); }
function subjectTotalsFromHistory(days = null) { const subjects = currentSubjects(); const totals = Object.fromEntries(subjects.map((subject) => [subject, { minutes: 0, sessions: 0 }])); const keys = days ? new Set(dateSeries(days)) : null; completedFocusSessions().forEach((item) => { if (keys && !keys.has(item.recordedDate)) return; const subject = normalizeSubject(item.subject, state.profile?.studyProfile); if (!totals[subject]) totals[subject] = { minutes: 0, sessions: 0 }; totals[subject].minutes += sessionActualMinutes(item); totals[subject].sessions += 1; }); return totals; }
function courseStudyMinutes(courseId) { const course = state.courses.find((item) => item.id === courseId); return completedFocusSessions().filter((item) => item.courseId === courseId || (!item.courseId && item.courseTitle === course?.title)).reduce((sum, item) => sum + sessionActualMinutes(item), 0); }
function playUiSound(kind = "soft") {
  if (!state.settings.soundEnabled || Number(state.settings.soundVolume || 0) <= 0) return;
  try {
    uiSoundCtx ||= new (window.AudioContext || window.webkitAudioContext)();
    const ctx = uiSoundCtx;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const volume = Math.max(0, Math.min(0.18, Number(state.settings.soundVolume || 35) / 600));
    osc.type = "sine";
    osc.frequency.value = kind === "complete" ? 740 : 440;
    gain.gain.setValueAtTime(0, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(volume, ctx.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.22);
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.24);
  } catch {}
}
function setActiveTab(tab) {
  const button = document.querySelector(".tab-button[data-tab='" + tab + "']");
  const panel = $("#tab-" + tab);
  if (!button || !panel) return;
  setAnalyticsXpOpen(false);
  if (button.closest(".secondary-nav") && el.sidebarMoreNav) el.sidebarMoreNav.open = true;
  $$(".tab-button").forEach((b) => b.classList.toggle("active", b === button));
  $$(".tab-panel").forEach((p) => p.classList.toggle("active", p === panel));
  renderHeader();
  if (tab === "focus") rotateFocusQuote();
  if (tab === "analytics") requestAnimationFrame(() => renderAnalytics());
  if (tab === "daily") requestAnimationFrame(() => renderMissions());
}

function rotateFocusQuote() {
  if (!el.focusQuote || !FOCUS_QUOTES.length) return;
  let index = Math.floor(Math.random() * FOCUS_QUOTES.length);
  if (FOCUS_QUOTES.length > 1 && index === focusQuoteIndex) index = (index + 1) % FOCUS_QUOTES.length;
  focusQuoteIndex = index;
  focusQuoteShown = true;
  el.focusQuote.textContent = FOCUS_QUOTES[index];
}

async function loadState() {
  document.body.classList.add("is-loading");
  if (hasChrome) {
    const result = await sendMessage({ type: "getState" });
    if (result?.ok) state = ensureToday(mergeState(result.response));
    else {
      const data = await chrome.storage.local.get(STATE_KEY);
      state = ensureToday(mergeState(data[STATE_KEY]));
    }
  } else {
    try { state = ensureToday(mergeState(JSON.parse(localStorage.getItem(STATE_KEY) || "null"))); } catch { state = defaultState(); }
  }
  applyTheme();
  render();
  document.body.classList.remove("is-loading");
}
async function saveState(next, options = {}) {
  const candidate = ensureToday(mergeState(next));
  if (hasChrome) {
    const result = await sendMessage({ type: "saveState", patch: createStatePatch(state, candidate) });
    if (!result?.ok) throw new Error(result?.error || "Could not save your changes.");
    state = ensureToday(mergeState(result.response));
  } else {
    state = candidate;
    localStorage.setItem(STATE_KEY, JSON.stringify(state));
  }
  applyTheme();
  render();
}
async function updateSettings(patch, options = {}) { await saveState({ ...state, settings: { ...state.settings, ...patch } }, options); }
async function addCurrentSupportingSite() {
  if (!hasChrome || !chrome.tabs?.query) return showToast("Open this in Chrome to add a supporting site.");
  const tabs = await chrome.tabs.query({});
  const candidate = tabs
    .filter((tab) => {
      const url = safeUrl(tab.url);
      return url && ["http:", "https:"].includes(url.protocol);
    })
    .sort((a, b) => Number(b.lastAccessed || 0) - Number(a.lastAccessed || 0))[0];
  const url = safeUrl(candidate?.url);
  if (!url) return showToast("Open a website first, then add it as a supporting site.");
  const domain = url.hostname.replace(/^www\./, "").toLowerCase();
  if (state.settings.allowedSites.includes(domain)) return showToast(domain + " is already allowed.");
  await updateSettings({ allowedSites: cleanPatterns([...state.settings.allowedSites, domain]) });
  showToast(domain + " is now allowed during Focus Mode.");
}

function fillSelects() {
  [el.studyProfileSelect].forEach((select) => {
    if (!select) return;
    const selected = state.profile?.studyProfile || "jee";
    select.innerHTML = "";
    STUDY_PROFILES.forEach((profile) => { const option = document.createElement("option"); option.value = profile.id; option.textContent = profile.name; option.selected = profile.id === selected; select.append(option); });
  });
  [el.courseSubjectInput].forEach((select) => {
    if (!select) return;
    const selected = normalizeSubject(select.value || "Other", state.profile?.studyProfile);
    select.innerHTML = "";
    currentSubjects().forEach((subject) => { const option = document.createElement("option"); option.value = subject; option.textContent = subject; option.selected = subject === selected; select.append(option); });
  });
  if (el.courseLibraryInput) {
    const selected = el.courseLibraryInput.value || state.courseLibraries?.[0]?.id || "library-main";
    el.courseLibraryInput.innerHTML = "";
    (state.courseLibraries || []).forEach((library) => {
      const option = document.createElement("option");
      option.value = library.id;
      option.textContent = library.name;
      option.selected = library.id === selected;
      el.courseLibraryInput.append(option);
    });
  }
}

function renderHeader() {
  const session = activeSession();
  const course = getActiveCourse(state);
  const focusTabActive = $("#tab-focus")?.classList.contains("active");
  const analyticsTabActive = $("#tab-analytics")?.classList.contains("active");
  el.connectionLabel.textContent = hasChrome ? "Chrome extension active" : "Preview mode";
  el.stateEyebrow.textContent = session ? (session.paused ? "Focus paused" : "Focus running") : "Ready";
  el.mainTitle.textContent = focusTabActive ? focusGreeting(state.profile?.name) : (analyticsTabActive ? "Track your study progress." : (session ? session.courseTitle : "Ready to focus?"));
  if (el.focusOpenCourseBtn) el.focusOpenCourseBtn.disabled = !course;
  el.stopFocusBtn.classList.toggle("hidden", !session);
}
function renderClock() {
  if (!el.liveClock) return;
  el.liveClock.textContent = "\uD83D\uDD52 " + new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  if ($("#tab-focus")?.classList.contains("active")) renderHeader();
}
function renderFocus() {
  const session = activeSession();
  const course = getActiveCourse(state);
  el.courseSelect.value = course?.id || "";
  el.durationInput.value = state.settings.focusMinutesDefault || 50;
  el.redirectEnabledInput.checked = Boolean(state.settings.redirectEnabled);
  el.todayFocus.textContent = formatDuration(actualMinutesToday());
  el.todaySessions.textContent = String(completedSessionsToday());
  if (el.todayBlocks) el.todayBlocks.textContent = String(state.stats.distractions || 0);
  el.todayScore.textContent = String(productivityScore(state));
  el.selectedCourseTitle.textContent = course?.title || "No course selected";
  el.selectedCourseMeta.textContent = course ? (course.subject || "Other") + " - " + safeUrl(course.url)?.hostname.replace(/^www\./, "") : "Choose a course in the Courses tab.";
  const circumference = 427;
  if (!session) {
    lastLiveFocusMinutes = null;
    el.focusHeadline.textContent = course ? "Ready to focus?" : "Choose a course";
    el.focusPill.textContent = course ? "Ready" : "Choose course";
    el.focusPill.classList.remove("active");
    el.startFocusBtn.disabled = !course || focusActionPending;
    el.startFocusBtn.textContent = "Start Focus";
    el.pauseFocusBtn?.classList.remove("hidden");
    if (el.pauseFocusBtn) el.pauseFocusBtn.disabled = true;
    el.resumeFocusBtn?.classList.add("hidden");
    el.stopFocusBtn.classList.add("hidden");
    el.focusRemainingText?.classList.add("hidden");
    el.timerProgress.style.strokeDashoffset = String(circumference);
    el.timerText.textContent = "00:00";
    el.timerCaption.textContent = course ? course.title : "Choose a course";
    renderCameraAttention(null);
    return;
  }
  const totalMs = session.durationMinutes * 60000;
  const remainingMs = sessionRemainingMs(session);
  const ratio = Math.min(1, Math.max(0, 1 - remainingMs / Math.max(1, totalMs)));
  const remainingText = formatClock(remainingMs) + " remaining";
  el.focusHeadline.textContent = session.paused ? "Focus Paused" : "Focus Session Active";
  el.focusPill.textContent = session.paused ? "Paused" : "Active";
  el.startFocusBtn.disabled = true;
  el.startFocusBtn.textContent = session.paused ? "Focus Paused" : "Focus Session Active";
  el.pauseFocusBtn?.classList.toggle("hidden", session.paused);
  if (el.pauseFocusBtn) el.pauseFocusBtn.disabled = session.paused || focusActionPending;
  el.resumeFocusBtn?.classList.toggle("hidden", !session.paused);
  if (el.resumeFocusBtn) el.resumeFocusBtn.disabled = !session.paused || focusActionPending;
  el.stopFocusBtn.classList.remove("hidden");
  el.focusPill.classList.add("active");
  el.timerProgress.style.strokeDashoffset = String(circumference - circumference * ratio);
  el.timerText.textContent = formatClock(remainingMs);
  const percentComplete = Math.round(ratio * 100);
  el.timerCaption.textContent = session.paused ? percentComplete + "% complete - paused" : percentComplete + "% complete";
  if (el.focusRemainingText) {
    el.focusRemainingText.textContent = remainingText;
    el.focusRemainingText.classList.remove("hidden");
  }
  renderCameraAttention(session);
}
function renderFocusTick() {
  const session = activeSession();
  if (!session) return;
  const circumference = 427;
  const totalMs = Math.max(1, Number(session.durationMinutes || 0) * 60000);
  const remainingMs = sessionRemainingMs(session);
  const ratio = Math.min(1, Math.max(0, 1 - remainingMs / totalMs));
  const percentComplete = Math.round(ratio * 100);
  el.timerProgress.style.strokeDashoffset = String(circumference - circumference * ratio);
  el.timerText.textContent = formatClock(remainingMs);
  el.timerCaption.textContent = session.paused ? percentComplete + "% complete - paused" : percentComplete + "% complete";
  if (el.focusRemainingText) {
    el.focusRemainingText.textContent = formatClock(remainingMs) + " remaining";
    el.focusRemainingText.classList.remove("hidden");
  }
  const liveMinutes = actualMinutesToday();
  if (liveMinutes !== lastLiveFocusMinutes) {
    lastLiveFocusMinutes = liveMinutes;
    el.todayFocus.textContent = formatDuration(liveMinutes);
    el.todayScore.textContent = String(productivityScore(state));
    renderTodayInsight();
    if ($("#tab-daily")?.classList.contains("active")) renderSystemGoals();
    if ($("#tab-analytics")?.classList.contains("active")) {
      el.goalProgress.textContent = goalProgressPercent(state) + "%";
      const weeklyMinutes = actualFocusSessions(7).reduce((sum, item) => sum + sessionActualMinutes(item), 0) + focusElapsedMinutes(session);
      const avgMinutes = Math.round(weeklyMinutes / 7);
      if (el.averageStudy) el.averageStudy.textContent = hours(avgMinutes);
      const todayMinutes = liveMinutes;
      if (el.dailyComparison) el.dailyComparison.textContent = (todayMinutes >= avgMinutes ? "+" : "-") + formatDuration(Math.abs(todayMinutes - avgMinutes));
    }
  }
}
function renderTodayInsight() {
  if (!el.todayInsightTitle || !el.todayInsightText) return;
  const insight = buildTodayInsight(state);
  el.todayInsightTitle.textContent = insight.title;
  el.todayInsightText.textContent = insight.text;
}
function renderCourses() {
  fillSelects();
  el.courseCount.textContent = state.courses.length + (state.courses.length === 1 ? " course" : " courses");
  renderCourseOverview();
  renderCourseLibraries();
}
function courseName(courseId) { return state.courses.find((course) => course.id === courseId)?.title || "General study"; }
function escapeHtml(value = "") { return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;"); }
function inlineMarkdown(value = "") {
  return escapeHtml(value)
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/\*([^*]+)\*/g, "<em>$1</em>")
    .replace(/\[([^\]]+)]\((https?:\/\/[^\s)]+)\)/g, "<a href=\"$2\" target=\"_blank\" rel=\"noopener\">$1</a>");
}
function renderMarkdownPreview(value = "") {
  return String(value).split(/\r?\n/).map((line) => {
    if (/^###\s+/.test(line)) return "<h5>" + inlineMarkdown(line.replace(/^###\s+/, "")) + "</h5>";
    if (/^##\s+/.test(line)) return "<h4>" + inlineMarkdown(line.replace(/^##\s+/, "")) + "</h4>";
    if (/^#\s+/.test(line)) return "<h3>" + inlineMarkdown(line.replace(/^#\s+/, "")) + "</h3>";
    if (/^-\s+/.test(line)) return "<p class=\"markdown-bullet\">• " + inlineMarkdown(line.replace(/^-\s+/, "")) + "</p>";
    return line ? "<p>" + inlineMarkdown(line) + "</p>" : "<br>";
  }).join("");
}
function readNoteDraft() { try { return JSON.parse(localStorage.getItem(NOTE_DRAFT_KEY) || "null"); } catch { return null; } }
function clearNoteDraft() { clearTimeout(noteDraftTimer); localStorage.removeItem(NOTE_DRAFT_KEY); }
function queueNoteDraft() {
  clearTimeout(noteDraftTimer);
  noteDraftTimer = setTimeout(() => {
    const draft = {
      courseId: el.noteCourseInput?.value || "",
      title: el.noteTitleInput?.value || "",
      body: el.noteBodyInput?.value || "",
      checklist: el.noteChecklistInput?.value || "",
      pinned: Boolean(el.notePinnedInput?.checked),
      selectedNoteId
    };
    if (draft.title || draft.body || draft.checklist) localStorage.setItem(NOTE_DRAFT_KEY, JSON.stringify(draft));
  }, 450);
}
function noteChecklistFromInput(value) { return String(value || "").split("|").map((item) => item.trim()).filter(Boolean).slice(0, 80).map((text) => ({ id: uid("check"), text, done: false })); }
function setNoteEditor(note = null) {
  const draft = note ? null : readNoteDraft();
  selectedNoteId = note?.id || draft?.selectedNoteId || null;
  if (!el.noteForm) return;
  el.noteCourseInput.value = note?.courseId || draft?.courseId || state.settings.defaultCourseId || "";
  el.noteTitleInput.value = note?.title || draft?.title || "";
  el.noteBodyInput.value = note?.body || draft?.body || "";
  el.noteChecklistInput.value = note ? (note.checklist || []).map((item) => item.text).join(" | ") : (draft?.checklist || "");
  el.notePinnedInput.checked = note ? Boolean(note.pinned) : Boolean(draft?.pinned);
  el.noteSaveBtn.textContent = note ? "Update Note" : "Save Note";
  renderNoteCharacterCount();
}
function renderNoteCharacterCount() {
  if (el.noteCharacterCount) el.noteCharacterCount.textContent = (el.noteBodyInput?.value?.length || 0).toLocaleString() + " / 50,000";
}
function renderNotes() {
  if (!el.noteList) return;
  renderNoteCharacterCount();
  const search = String(el.noteSearchInput?.value || "").trim().toLowerCase();
  const notes = [...state.notes].filter((note) => !search || [note.title, note.body, note.checklist.map((item) => item.text).join(" "), courseName(note.courseId)].join(" ").toLowerCase().includes(search)).sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt - a.updatedAt);
  el.noteList.innerHTML = "";
  if (!notes.length) {
    el.noteList.innerHTML = "<div class='empty-state compact-empty'><h4>No notes yet</h4><p>Save a short summary, formula, or checklist for the course you are studying.</p></div>";
    return;
  }
  notes.forEach((note) => {
    const card = document.createElement("article");
    card.className = "note-card" + (note.pinned ? " pinned" : "");
    card.innerHTML = "<div class='note-card-header'><div><span class='tag'></span><h4></h4><p></p></div><div class='note-actions'><button class='button secondary compact-button edit' type='button'>Edit</button><button class='icon-button danger remove' type='button' aria-label='Delete note'>x</button></div></div><div class='note-body'></div><div class='note-checklist'></div>";
    card.querySelector(".tag").textContent = note.pinned ? "Pinned" : courseName(note.courseId);
    card.querySelector("h4").textContent = note.title;
    card.querySelector(".note-card-header p").textContent = "Updated " + new Date(note.updatedAt).toLocaleDateString();
    card.querySelector(".note-body").innerHTML = note.body ? renderMarkdownPreview(note.body) : "<p>Checklist only</p>";
    const checklist = card.querySelector(".note-checklist");
    (note.checklist || []).forEach((item) => {
      const label = document.createElement("label");
      const check = document.createElement("input");
      check.type = "checkbox";
      check.checked = item.done;
      check.addEventListener("change", () => updateNote(note.id, { checklist: note.checklist.map((entry) => entry.id === item.id ? { ...entry, done: check.checked } : entry) }));
      const text = document.createElement("span");
      text.textContent = item.text;
      label.append(check, text);
      checklist.append(label);
    });
    card.querySelector(".edit").addEventListener("click", () => setNoteEditor(note));
    card.querySelector(".remove").addEventListener("click", () => deleteNote(note.id));
    el.noteList.append(card);
  });
}
async function updateNote(id, patch) {
  await saveState({ ...state, notes: state.notes.map((note) => note.id === id ? { ...note, ...patch, updatedAt: Date.now() } : note) });
}
async function saveNote(event) {
  event.preventDefault();
  const title = el.noteTitleInput.value.trim();
  const body = el.noteBodyInput.value.trim();
  const checklist = noteChecklistFromInput(el.noteChecklistInput.value);
  if (!title && !body && !checklist.length) return showToast("Add a title, note, or checklist first.");
  const previous = state.notes.find((note) => note.id === selectedNoteId);
  const next = {
    id: previous?.id || uid("note"),
    courseId: el.noteCourseInput.value || null,
    title: title || "Untitled note",
    body,
    checklist: previous?.checklist?.length && el.noteChecklistInput.value === previous.checklist.map((item) => item.text).join(" | ") ? previous.checklist : checklist,
    pinned: el.notePinnedInput.checked,
    createdAt: previous?.createdAt || Date.now(),
    updatedAt: Date.now()
  };
  await saveState({ ...state, notes: previous ? state.notes.map((note) => note.id === previous.id ? next : note) : [next, ...state.notes] });
  clearNoteDraft();
  setNoteEditor(null);
  showToast(previous ? "Note updated." : "Note saved.");
}
async function deleteNote(id) {
  const note = state.notes.find((item) => item.id === id);
  if (!note || !confirm("Delete note '" + note.title + "'?")) return;
  const previous = state;
  await saveState({ ...state, notes: state.notes.filter((item) => item.id !== id) });
  if (selectedNoteId === id) setNoteEditor(null);
  showUndo("Note deleted.", previous);
}
function exportNotes() {
  const blob = new Blob([JSON.stringify({ notes: state.notes }, null, 2)], { type: "application/json" });
  const anchor = document.createElement("a");
  anchor.href = URL.createObjectURL(blob);
  anchor.download = "course-focus-pro-notes.json";
  anchor.click();
  URL.revokeObjectURL(anchor.href);
}
async function importNotes(event) {
  const file = event.target.files?.[0];
  if (!file) return;
  try {
    const parsed = JSON.parse(await file.text());
    const incoming = Array.isArray(parsed) ? parsed : parsed.notes;
    if (!Array.isArray(incoming)) throw new Error("Invalid note backup.");
    const merged = [...state.notes];
    incoming.forEach((note) => {
      const index = merged.findIndex((item) => item.id === note.id);
      if (index >= 0) merged[index] = note; else merged.push(note);
    });
    await saveState({ ...state, notes: merged });
    showToast("Notes imported.");
  } catch { showToast("That note backup could not be imported."); }
  event.target.value = "";
}
function nextReviewCard() {
  const cards = state.flashcards || [];
  if (!cards.length) return null;
  const current = cards.find((card) => card.id === reviewFlashcardId);
  if (current) return current;
  return [...cards].sort((a, b) => (a.lastReviewedAt || 0) - (b.lastReviewedAt || 0))[0];
}
function renderFlashcards() {
  if (!el.flashcardReview || !el.flashcardList) return;
  const cards = state.flashcards || [];
  el.flashcardCount.textContent = cards.length + (cards.length === 1 ? " card" : " cards");
  const review = nextReviewCard();
  el.flashcardReview.innerHTML = "";
  if (!review) el.flashcardReview.innerHTML = "<div class='empty-state compact-empty'><h4>Ready when you are</h4><p>Add a question and answer pair to begin a quick revision.</p></div>";
  else {
    const card = document.createElement("article");
    card.className = "flashcard-review-card" + (flashcardAnswerVisible ? " revealed" : "");
    card.innerHTML = "<span></span><strong></strong><p></p><div class='flashcard-actions'></div>";
    card.querySelector("span").textContent = review.category + " - " + courseName(review.courseId);
    card.querySelector("strong").textContent = flashcardAnswerVisible ? "Answer" : "Question";
    card.querySelector("p").textContent = flashcardAnswerVisible ? review.back : review.front;
    const actions = card.querySelector(".flashcard-actions");
    if (!flashcardAnswerVisible) {
      const reveal = document.createElement("button");
      reveal.className = "button primary";
      reveal.type = "button";
      reveal.textContent = "Reveal Answer";
      reveal.addEventListener("click", () => { flashcardAnswerVisible = true; renderFlashcards(); });
      actions.append(reveal);
    } else {
      [["Again", "secondary"], ["I knew it", "primary"]].forEach(([label, tone]) => {
        const button = document.createElement("button");
        button.className = "button " + tone;
        button.type = "button";
        button.textContent = label;
        button.addEventListener("click", () => reviewFlashcard(review.id));
        actions.append(button);
      });
    }
    el.flashcardReview.append(card);
  }
  el.flashcardList.innerHTML = "";
  cards.slice().sort((a, b) => (b.lastReviewedAt || 0) - (a.lastReviewedAt || 0)).slice(0, 10).forEach((card) => {
    const row = document.createElement("article");
    row.className = "flashcard-row";
    row.innerHTML = "<div><span></span><strong></strong><p></p></div><button class='button secondary compact-button review' type='button'>Review</button><button class='icon-button danger remove' type='button' aria-label='Delete flashcard'>x</button>";
    row.querySelector("span").textContent = card.category;
    row.querySelector("strong").textContent = card.front;
    row.querySelector("p").textContent = card.reviews + " reviews";
    row.querySelector(".review").addEventListener("click", () => { reviewFlashcardId = card.id; flashcardAnswerVisible = false; renderFlashcards(); });
    row.querySelector(".remove").addEventListener("click", () => deleteFlashcard(card.id));
    el.flashcardList.append(row);
  });
}
async function addFlashcard(event) {
  event.preventDefault();
  const front = el.flashcardFrontInput.value.trim();
  const back = el.flashcardBackInput.value.trim();
  if (!front || !back) return showToast("Add both a question and an answer.");
  const card = { id: uid("card"), courseId: el.flashcardCourseInput.value || null, category: el.flashcardCategoryInput.value.trim() || "General", front, back, reviews: 0, lastReviewedAt: null, createdAt: Date.now() };
  await saveState({ ...state, flashcards: [card, ...state.flashcards] });
  el.flashcardForm.reset();
  flashcardAnswerVisible = false;
  reviewFlashcardId = card.id;
  showToast("Flashcard added.");
}
async function reviewFlashcard(id) {
  await saveState({ ...state, flashcards: state.flashcards.map((card) => card.id === id ? { ...card, reviews: (card.reviews || 0) + 1, lastReviewedAt: Date.now() } : card) });
  reviewFlashcardId = null;
  flashcardAnswerVisible = false;
}
async function deleteFlashcard(id) {
  if (!confirm("Delete this flashcard?")) return;
  await saveState({ ...state, flashcards: state.flashcards.filter((card) => card.id !== id) });
  if (reviewFlashcardId === id) reviewFlashcardId = null;
}
function resourceSource(url) {
  const host = safeUrl(url)?.hostname.replace(/^www\./, "").toLowerCase() || "resource";
  if (host === "youtu.be" || host.endsWith("youtube.com")) return { type: "youtube", label: "YouTube", host, mark: "YT" };
  return { type: "web", label: host, host, mark: host.slice(0, 2).toUpperCase() || "WEB" };
}
function studyLinkRecords() {
  return state.courses.flatMap((course) => {
    const primary = [{ id: "course:" + course.id, kind: "course", course, title: course.title, url: course.url, addedAt: Number(course.createdAt || 0), source: resourceSource(course.url) }];
    const videos = (Array.isArray(course.videos) ? course.videos : []).map((video) => ({ id: "video:" + course.id + ":" + video.id, kind: "video", course, video, title: video.title || "YouTube video", url: video.url, addedAt: Number(video.addedAt || course.createdAt || 0), source: resourceSource(video.url) }));
    return [...primary, ...videos];
  });
}
function resetStudyLinkFilters() {
  courseLibraryQuery = "";
  courseLibrarySource = "all";
  courseLibrarySort = "priority";
  courseLibraryLimit = 60;
  renderCourseLibraries();
}
function setCourseLibraryExpanded(expanded) {
  courseLibraryExpanded = Boolean(expanded);
  try { sessionStorage.setItem("courseFocusProStudyLinkLibraryExpanded", String(courseLibraryExpanded)); } catch {}
  if (el.studyLinkLibraryPanel) el.studyLinkLibraryPanel.dataset.expanded = String(courseLibraryExpanded);
  if (el.studyLinkLibraryToggle) el.studyLinkLibraryToggle.setAttribute("aria-expanded", String(courseLibraryExpanded));
}
function setSiteControlExpanded(expanded) {
  siteControlExpanded = Boolean(expanded);
  try { sessionStorage.setItem("courseFocusProSiteControlExpanded", String(siteControlExpanded)); } catch {}
  if (el.siteControlSection) el.siteControlSection.dataset.expanded = String(siteControlExpanded);
  if (el.siteControlToggle) el.siteControlToggle.setAttribute("aria-expanded", String(siteControlExpanded));
  if (el.siteControlBody) {
    el.siteControlBody.classList.toggle("is-expanded", siteControlExpanded);
    el.siteControlBody.setAttribute("aria-hidden", String(!siteControlExpanded));
    el.siteControlBody.toggleAttribute("inert", !siteControlExpanded);
  }
}
function sortStudyLinks(links) {
  const sorted = [...links];
  if (courseLibrarySort === "alpha") return sorted.sort((a, b) => a.title.localeCompare(b.title) || a.source.label.localeCompare(b.source.label));
  if (courseLibrarySort === "recent") return sorted.sort((a, b) => b.addedAt - a.addedAt || a.title.localeCompare(b.title));
  return sorted.sort((a, b) => {
    const aPriority = (a.course.id === state.settings.defaultCourseId ? 4 : 0) + (a.kind === "course" ? 2 : 0) + (a.course.lastUsedAt ? 1 : 0);
    const bPriority = (b.course.id === state.settings.defaultCourseId ? 4 : 0) + (b.kind === "course" ? 2 : 0) + (b.course.lastUsedAt ? 1 : 0);
    return bPriority - aPriority || b.addedAt - a.addedAt || a.title.localeCompare(b.title);
  });
}
function visibleStudyLinks() {
  const query = courseLibraryQuery.trim().toLowerCase();
  const filtered = studyLinkRecords().filter((link) => {
    if (courseLibrarySource !== "all" && link.source.type !== courseLibrarySource) return false;
    if (!query) return true;
    return [link.title, link.url, link.source.label, link.course.title, link.course.subject].some((value) => String(value || "").toLowerCase().includes(query));
  });
  return { all: filtered, visible: sortStudyLinks(filtered).slice(0, courseLibraryLimit) };
}
function actionButton(label, handler, danger = false) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "study-link-menu-button" + (danger ? " danger" : "");
  button.textContent = label;
  button.addEventListener("click", handler);
  return button;
}
async function editStudyLink(link) {
  if (link.kind === "course") {
    const title = prompt("Course title", link.course.title)?.trim();
    if (!title) return;
    const url = validUrl(prompt("Course link", link.course.url) || "");
    if (!url) return showToast("Paste a valid course link.");
    await saveState({ ...state, courses: state.courses.map((course) => course.id === link.course.id ? { ...course, title: title.slice(0, 180), url: normalizeUrl(url) } : course) });
    showToast("Course link updated.");
    return;
  }
  const title = prompt("Video title", link.video.title)?.trim();
  if (!title) return;
  const url = canonicalYouTubeVideoUrl(prompt("YouTube video link", link.video.url) || "");
  if (!url) return showToast("Paste a supported YouTube video link.");
  const duplicate = state.courses.some((course) => canonicalYouTubeVideoUrl(course.url) === url || (course.videos || []).some((video) => video.id !== link.video.id && canonicalYouTubeVideoUrl(video.url) === url));
  if (duplicate) return showToast("This video is already in Studizen.");
  await saveState({ ...state, courses: state.courses.map((course) => course.id === link.course.id ? { ...course, videos: (course.videos || []).map((video) => video.id === link.video.id ? { ...video, title: title.slice(0, 180), url } : video) } : course) });
  showToast("Video updated.");
}
function studyLinkMenu(link) {
  const menu = document.createElement("details");
  menu.className = "study-link-action-menu";
  const summary = document.createElement("summary");
  summary.setAttribute("aria-label", "Actions for " + link.title);
  summary.title = "More actions";
  summary.textContent = "...";
  const actions = document.createElement("div");
  actions.className = "study-link-menu-items";
  actions.append(actionButton("Edit", () => editStudyLink(link)));
  if (link.kind === "course") {
    actions.append(actionButton(link.course.id === state.settings.defaultCourseId ? "Current course" : "Set as current", () => updateSettings({ defaultCourseId: link.course.id }).then(() => showToast("Course selected."))));
    actions.append(actionButton("Start focus", () => startFocus(link.course.id)));
    const move = document.createElement("label");
    move.className = "study-link-menu-select";
    move.textContent = "Move to";
    const select = document.createElement("select");
    state.courseLibraries.forEach((library) => {
      const option = document.createElement("option");
      option.value = library.id;
      option.textContent = library.name;
      option.selected = library.id === link.course.libraryId;
      select.append(option);
    });
    select.addEventListener("change", () => moveCourseToLibrary(link.course.id, select.value));
    move.append(select);
    actions.append(move);
    actions.append(actionButton("Delete course", () => deleteCourse(link.course.id), true));
  } else actions.append(actionButton("Delete link", () => removeCourseVideo(link.course.id, link.video.id), true));
  menu.append(summary, actions);
  return menu;
}
function studyLinkRow(link) {
  const row = document.createElement("article");
  row.className = "study-link-row" + (link.course.id === state.settings.defaultCourseId && link.kind === "course" ? " is-current" : "");
  const icon = document.createElement("span");
  icon.className = "study-link-source" + (link.source.type === "youtube" ? " youtube" : "");
  icon.textContent = link.source.mark;
  icon.setAttribute("aria-hidden", "true");
  const copy = document.createElement("div");
  copy.className = "study-link-copy";
  const title = document.createElement("strong");
  title.textContent = link.title;
  title.title = link.title;
  const meta = document.createElement("span");
  const context = link.kind === "video" ? link.course.title : (link.course.subject || "Course link");
  meta.textContent = link.source.label + " · " + context + (link.course.id === state.settings.defaultCourseId && link.kind === "course" ? " · Current" : "");
  copy.append(title, meta);
  const open = document.createElement("button");
  open.type = "button";
  open.className = "button secondary compact-button study-link-open";
  open.textContent = "Open";
  open.addEventListener("click", () => openCourse(link.url));
  row.append(icon, copy, open, studyLinkMenu(link));
  return row;
}
function courseLinkGroup(course, links) {
  const group = document.createElement("section");
  group.className = "study-link-course-group";
  const header = document.createElement("div");
  header.className = "study-link-course-header";
  const title = document.createElement("strong");
  title.textContent = course.title;
  const count = document.createElement("span");
  count.textContent = links.length + (links.length === 1 ? " link" : " links") + " · " + (course.subject || "Other");
  header.append(title, count);
  const rows = document.createElement("div");
  rows.className = "study-link-list";
  links.forEach((link) => rows.append(studyLinkRow(link)));
  group.append(header, rows);
  return group;
}
function renderCourseOverview() {
  if (!el.courseOverview) return;
  el.courseOverview.innerHTML = "";
  const active = getActiveCourse(state);
  const recent = [...state.courses].filter((course) => course.lastUsedAt).sort((a, b) => (b.lastUsedAt || 0) - (a.lastUsedAt || 0)).slice(0, 4);
  const studied = [...state.courses].map((course) => ({ course, minutes: courseStudyMinutes(course.id) })).filter((item) => item.minutes > 0).sort((a, b) => b.minutes - a.minutes).slice(0, 4);
  const sections = [
    { title: "Continue Learning", items: active ? [{ course: active, label: "Current course" }] : [] },
    { title: "Recently Viewed", items: recent.map((course) => ({ course, label: course.lastUsedAt ? new Date(course.lastUsedAt).toLocaleDateString() : "" })) },
    { title: "Most Studied", items: studied.map(({ course, minutes }) => ({ course, label: formatDuration(minutes) })) },
    { title: "All Courses", items: state.courses.slice(0, 6).map((course) => ({ course, label: course.subject || "Other" })) }
  ];
  sections.forEach((overviewSection) => {
    const section = document.createElement("section");
    section.className = "course-overview-section";
    section.innerHTML = "<h4></h4><div></div>";
    section.querySelector("h4").textContent = overviewSection.title;
    const list = section.querySelector("div");
    if (!overviewSection.items.length) list.innerHTML = "<p class='form-status'>No courses yet.</p>";
    overviewSection.items.forEach(({ course, label }) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "course-mini-card";
      button.innerHTML = "<strong></strong><span></span>";
      button.querySelector("strong").textContent = course.title;
      button.querySelector("span").textContent = label || course.subject || "Course";
      button.addEventListener("click", () => updateSettings({ defaultCourseId: course.id }));
      list.append(button);
    });
    el.courseOverview.append(section);
  });
}
function renderCourseLibraries() {
  if (!el.courseLibrariesList) return;
  setCourseLibraryExpanded(courseLibraryExpanded);
  el.courseLibrariesList.innerHTML = "";
  const totalLinks = studyLinkRecords().length;
  if (el.courseCount) el.courseCount.textContent = state.courses.length + (state.courses.length === 1 ? " course" : " courses") + " · " + totalLinks + (totalLinks === 1 ? " link" : " links");
  if (el.courseLibrarySearch) el.courseLibrarySearch.value = courseLibraryQuery;
  if (el.courseLibrarySource) el.courseLibrarySource.value = courseLibrarySource;
  if (el.courseLibrarySort) el.courseLibrarySort.value = courseLibrarySort;
  if (!state.courses.length) { el.courseLibrariesList.innerHTML = "<div class='empty-state study-link-empty'><h4>No saved study links yet</h4><p>Add a course above, or right-click a YouTube video and choose Add to Studizen.</p></div>"; return; }
  const { all, visible } = visibleStudyLinks();
  if (!all.length) {
    const empty = document.createElement("div");
    empty.className = "empty-state study-link-empty";
    empty.innerHTML = "<h4>No matching study links</h4><p>Try another title, source, or sort option.</p>";
    const clear = document.createElement("button");
    clear.type = "button";
    clear.className = "button secondary compact-button";
    clear.textContent = "Clear filters";
    clear.addEventListener("click", resetStudyLinkFilters);
    empty.append(clear);
    el.courseLibrariesList.append(empty);
    return;
  }
  state.courseLibraries.forEach((library) => {
    const links = visible.filter((link) => link.course.libraryId === library.id);
    const totalInLibrary = all.filter((link) => link.course.libraryId === library.id).length;
    if (!links.length && !totalInLibrary) return;
    const section = document.createElement("details");
    section.className = "course-library study-link-library";
    section.open = courseLibraryQuery || courseLibrarySource !== "all" ? true : !library.collapsed;
    section.innerHTML = "<summary><span></span><strong></strong><div class='course-library-actions'><button class='icon-button rename' type='button' aria-label='Rename library'>Edit</button><button class='icon-button danger delete' type='button' aria-label='Delete library'>x</button></div></summary><div class='course-library-list'></div>";
    section.querySelector("span").textContent = library.name;
    section.querySelector("strong").textContent = totalInLibrary + (totalInLibrary === 1 ? " link" : " links");
    section.addEventListener("toggle", () => setLibraryCollapsed(library.id, !section.open));
    section.querySelector(".rename").addEventListener("click", (event) => { event.preventDefault(); event.stopPropagation(); renameLibrary(library.id); });
    section.querySelector(".delete").addEventListener("click", (event) => { event.preventDefault(); event.stopPropagation(); deleteLibrary(library.id); });
    const list = section.querySelector(".course-library-list");
    if (!links.length) list.innerHTML = "<div class='empty-state compact-empty'><p>Matching links are outside the current view. Load more to see them.</p></div>";
    const courseIds = [...new Set(links.map((link) => link.course.id))];
    courseIds.forEach((courseId) => {
      const course = state.courses.find((item) => item.id === courseId);
      const courseLinks = links.filter((link) => link.course.id === courseId);
      if (course && courseLinks.length) list.append(courseLinkGroup(course, courseLinks));
    });
    el.courseLibrariesList.append(section);
  });
  if (all.length > visible.length) {
    const more = document.createElement("button");
    more.type = "button";
    more.className = "button secondary study-link-load-more";
    more.textContent = "Show 60 more links (" + (all.length - visible.length) + " remaining)";
    more.addEventListener("click", () => { courseLibraryLimit += 60; renderCourseLibraries(); });
    el.courseLibrariesList.append(more);
  }
}
function siteRuleInfo(pattern) {
  const domain = String(pattern || "").replace(/^https?:\/\//, "").replace(/^www\./, "");
  const host = domain.split("/")[0];
  const named = { "docs.google.com": "Google Docs", "drive.google.com": "Google Drive", "classroom.google.com": "Google Classroom", "youtube.com": "YouTube", "wikipedia.org": "Wikipedia", "github.com": "GitHub", "instagram.com": "Instagram", "reddit.com": "Reddit", "facebook.com": "Facebook", "netflix.com": "Netflix", "discord.com": "Discord", "twitter.com": "X / Twitter", "x.com": "X / Twitter" };
  const key = Object.keys(named).find((item) => host === item || host.endsWith("." + item));
  const name = key ? named[key] : host.replace(/^www\./, "").split(".")[0].replace(/[-_]/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
  return { domain, name, mark: name.slice(0, 2).toUpperCase() };
}
function renderSiteRuleList(container, patterns, query, mode) {
  if (!container) return;
  const all = cleanPatterns(patterns);
  const visible = all.filter((pattern) => (siteRuleInfo(pattern).name + " " + pattern).toLowerCase().includes(query.toLowerCase()));
  container.innerHTML = "";
  if (!visible.length) { const empty = document.createElement("div"); empty.className = "site-rule-empty"; empty.innerHTML = "<strong>" + (all.length ? "No matching sites" : mode === "allowed" ? "No supporting sites yet" : "No distracting sites saved") + "</strong><span>" + (all.length ? "Try a different search." : mode === "allowed" ? "Add the study tools you need during Focus Mode." : "Add a site to keep it visible in your distraction watchlist.") + "</span>"; container.append(empty); return; }
  visible.slice(0, 80).forEach((pattern) => {
    const info = siteRuleInfo(pattern); const row = document.createElement("article"); row.className = "site-rule-row " + mode; row.title = info.domain;
    const badge = document.createElement("span"); badge.className = "site-rule-icon"; badge.textContent = info.mark;
    const copy = document.createElement("div"); copy.className = "site-rule-copy"; const title = document.createElement("strong"); title.textContent = info.name; const domain = document.createElement("span"); domain.textContent = info.domain; domain.title = info.domain; copy.append(title, domain);
    const status = document.createElement("span"); status.className = "site-rule-status"; status.textContent = mode === "allowed" ? "Focus Mode" : state.settings.guardBlockedOutsideFocus ? "Protected" : "Off";
    const actions = document.createElement("div"); actions.className = "site-rule-actions";
    const open = actionButton("Open", () => openCourse("https://" + info.domain)); const edit = actionButton("Edit", async () => { const next = prompt("Edit site domain", pattern)?.trim().toLowerCase(); if (!next || next === pattern) return; const key = mode === "allowed" ? "allowedSites" : "blockedSites"; await updateSettings({ [key]: cleanPatterns(state.settings[key].map((item) => item === pattern ? next : item)) }); }); const remove = actionButton("Remove", () => { const key = mode === "allowed" ? "allowedSites" : "blockedSites"; updateSettings({ [key]: state.settings[key].filter((item) => item !== pattern) }); });
    [open, edit, remove].forEach((button) => button.classList.add("site-rule-action")); remove.classList.add("danger"); actions.append(open, edit, remove); row.append(badge, copy, status, actions); container.append(row);
  });
  if (visible.length > 80) { const note = document.createElement("p"); note.className = "site-rule-limit"; note.textContent = "Showing the first 80 matching sites. Refine your search to narrow the list."; container.append(note); }
}
function renderShield() {
  if (el.allowedCount) el.allowedCount.textContent = String(state.settings.allowedSites.length);
  if (el.blockedCount) el.blockedCount.textContent = String(state.settings.blockedSites.length);
  if (el.distractionProtectionInput) el.distractionProtectionInput.checked = Boolean(state.settings.guardBlockedOutsideFocus);
  if (el.distractionProtectionState) el.distractionProtectionState.textContent = state.settings.guardBlockedOutsideFocus ? "On" : "Off";
  renderSiteRuleList(el.allowedList, state.settings.allowedSites, allowedSiteQuery, "allowed");
  renderSiteRuleList(el.blockedList, state.settings.blockedSites, blockedSiteQuery, "blocked");
}
function cssVar(name) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim(); }
function chartPalette() { return { blue: cssVar("--chart-blue") || cssVar("--blue") || "#2f7cf6", muted: cssVar("--muted") || "#687789", grid: cssVar("--chart-grid") || "rgba(100,116,139,.16)", text: cssVar("--ink") || "#142033", surface: cssVar("--surface-raised") || cssVar("--surface") || "#fff", font: cssVar("--font-display") || "Manrope, Arial, sans-serif" }; }
function chartAlpha(color, alpha) {
  if (!color) return "rgba(47,124,246," + alpha + ")";
  const hex = color.trim();
  if (/^#[0-9a-f]{6}$/i.test(hex)) {
    const n = parseInt(hex.slice(1), 16);
    return "rgba(" + ((n >> 16) & 255) + "," + ((n >> 8) & 255) + "," + (n & 255) + "," + alpha + ")";
  }
  return color;
}
function destroyChart(key) { if (!charts[key]) return; charts[key].destroy(); delete charts[key]; }
function chart(key, canvas, config) {
  if (!canvas || !globalThis.Chart) return;
  const existing = charts[key];
  if (existing?.canvas === canvas && existing.config.type === config.type) {
    existing.data = config.data;
    existing.options = config.options;
    existing.update();
    return;
  }
  destroyChart(key);
  charts[key] = new Chart(canvas, config);
}
function gamificationStats() {
  const history = completedFocusSessions();
  const focusXp = history.reduce((sum, item) => sum + (Number.isFinite(Number(item.xpEarned)) ? Number(item.xpEarned) : sessionXp(item.durationMinutes, item.completed)), 0);
  const xp = Math.round(focusXp + rewardXpTotal(state));
  const level = levelForXp(xp);
  const levelStart = (level - 1) * 300;
  const nextLevel = level * 300;
  const progress = Math.min(100, Math.round(((xp - levelStart) / Math.max(1, nextLevel - levelStart)) * 100));
  const rank = rankForLevel(level);
  const badges = [];
  if (history.length >= 1) badges.push("First Focus");
  if ((state.analytics.streak?.current || 0) >= 3) badges.push("3-Day Streak");
  if (completedMinutesToday() >= 120) badges.push("Deep Work Day");
  if ((state.stats.distractions || 0) === 0 && (state.stats.focusMinutes || 0) > 0) badges.push("Clean Session");
  return { xp, level, progress, rank, badges };
}
function renderGamification() {
  const stats = gamificationStats();
  if (stats.level > lastShownLevel) {
    lastShownLevel = stats.level;
    sessionStorage.setItem("courseFocusProLastLevel", String(stats.level));
    el.xpPanel?.classList.remove("level-up");
    void el.xpPanel?.offsetWidth;
    el.xpPanel?.classList.add("level-up");
    showToast("Level " + stats.level + " reached - " + stats.rank + ".");
  } else if (stats.level < lastShownLevel) {
    lastShownLevel = stats.level;
    sessionStorage.setItem("courseFocusProLastLevel", String(stats.level));
  }
  el.rankTitle.textContent = "Level " + stats.level + " - " + stats.rank;
  el.rankMeta.textContent = stats.xp + " XP earned from verified focus sessions, system goals, and streaks";
  el.xpProgressFill.style.width = stats.progress + "%";
  el.badgeRow.innerHTML = "";
  if (!stats.badges.length) {
    el.badgeRow.innerHTML = "<span class='badge muted'>Badges appear as you study</span>";
    return;
  }
  stats.badges.slice(0, 5).forEach((badge) => {
    const item = document.createElement("span");
    item.className = "badge";
    item.textContent = badge;
    el.badgeRow.append(item);
  });
}
function setAnalyticsXpOpen(open, restoreFocus = false) {
  if (!el.analyticsXpPopover || !el.analyticsXpBtn) return;
  const wasOpen = !el.analyticsXpPopover.classList.contains("hidden");
  const next = Boolean(open);
  el.analyticsXpPopover.classList.toggle("hidden", !next);
  el.analyticsXpBtn.setAttribute("aria-expanded", String(next));
  if (!next && restoreFocus && wasOpen) el.analyticsXpBtn.focus();
}

function selectedAnalyticsVisualPeriod() {
  return analyticsHistoryPeriod || "current-week";
}

function analyticsVisualPeriodLabel(period) {
  if (period === "previous-month") return "Previous month";
  if (period === "previous-week") return "Previous week";
  return "This week";
}

function localDateFromKey(key) {
  const [year, month, day] = String(key || "").split("-").map(Number);
  return new Date(year || 1970, Math.max(0, (month || 1) - 1), day || 1);
}

function fullWeekKeys(now = new Date(), weekOffset = 0) {
  const day = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  day.setDate(day.getDate() - ((day.getDay() + 6) % 7) + weekOffset * 7);
  return Array.from({ length: 7 }, (_, index) => {
    const next = new Date(day);
    next.setDate(day.getDate() + index);
    return todayKey(next);
  });
}

function sessionsForDateKeys(summary, keys = []) {
  const keySet = new Set(keys);
  const counts = new Map();
  (summary.sessions || []).forEach((session) => {
    if (!keySet.has(session?.recordedDate)) return;
    counts.set(session.recordedDate, (counts.get(session.recordedDate) || 0) + 1);
  });
  return counts;
}

function monthlyActivityBuckets(summary, period) {
  const groups = [];
  (period.keys || []).forEach((key, index) => {
    const groupIndex = Math.floor(index / 7);
    groups[groupIndex] ||= [];
    groups[groupIndex].push(key);
  });
  return groups.map((keys, index) => {
    const sessions = sessionsForDateKeys(summary, keys);
    const first = localDateFromKey(keys[0]);
    const last = localDateFromKey(keys[keys.length - 1]);
    const startLabel = first.toLocaleDateString(undefined, { month: "short", day: "numeric" });
    const endLabel = last.getDate();
    return {
      label: "Week " + (index + 1),
      range: startLabel + " - " + endLabel,
      minutes: keys.reduce((total, key) => total + (summary.byDate.get(key) || 0), 0),
      sessions: [...sessions.values()].reduce((total, count) => total + count, 0)
    };
  });
}

function activityBucketsForPeriod(summary, periodName, now = new Date()) {
  if (periodName === "previous-month") {
    const period = completedPeriodAnalytics(summary, periodName, now, state.goals?.studyHours);
    return { label: analyticsVisualPeriodLabel(periodName) + " - weekly activity", buckets: monthlyActivityBuckets(summary, period) };
  }
  const keys = fullWeekKeys(now, periodName === "previous-week" ? -1 : 0);
  const sessions = sessionsForDateKeys(summary, keys);
  const labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  return {
    label: analyticsVisualPeriodLabel(periodName),
    buckets: keys.map((key, index) => ({ label: labels[index], range: key, minutes: summary.byDate.get(key) || 0, sessions: sessions.get(key) || 0 }))
  };
}

function setAnalyticsChartEmpty(canvas, empty, isEmpty) {
  canvas?.classList.toggle("hidden", isEmpty);
  empty?.classList.toggle("hidden", !isEmpty);
}

function renderStudyActivity(summary, periodName, now = new Date()) {
  const activity = activityBucketsForPeriod(summary, periodName, now);
  const hasActivity = activity.buckets.some((bucket) => bucket.minutes > 0);
  const dailyGoalMinutes = Math.max(0, Number(state.goals?.studyHours || 0) * 60);
  if (el.dailyChartMeta) el.dailyChartMeta.textContent = analyticsVisualPeriodLabel(periodName) + " · Study time per day";
  if (el.dailyChartGoal) el.dailyChartGoal.textContent = dailyGoalMinutes ? "Daily goal: " + formatDuration(dailyGoalMinutes) : "No daily goal set";
  setAnalyticsChartEmpty(el.dailyChart, el.dailyChartEmpty, !hasActivity);
  if (!hasActivity) { destroyChart("daily"); return; }
  const colors = chartPalette();
  const dailyGoalDataset = dailyGoalMinutes ? [{
    type: "line",
    label: "Daily goal",
    data: activity.buckets.map(() => dailyGoalMinutes),
    borderColor: chartAlpha(colors.blue, .48),
    borderDash: [5, 4],
    borderWidth: 1,
    pointRadius: 0,
    pointHoverRadius: 0,
    tension: 0,
    order: 0
  }] : [];
  chart("daily", el.dailyChart, {
    type: "bar",
    data: {
      labels: activity.buckets.map((bucket) => bucket.label),
      datasets: [{
        label: "Study time",
        data: activity.buckets.map((bucket) => bucket.minutes),
        backgroundColor: activity.buckets.map((bucket) => bucket.minutes ? chartAlpha(colors.blue, .82) : chartAlpha(colors.blue, .14)),
        hoverBackgroundColor: chartAlpha(colors.blue, .98),
        borderColor: colors.blue,
        borderWidth: 0,
        borderRadius: 6,
        borderSkipped: false,
        maxBarThickness: 36,
        categoryPercentage: .72,
        barPercentage: .82,
        order: 1
      }, ...dailyGoalDataset]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 240, easing: "easeOutQuart" },
      interaction: { mode: "index", intersect: false },
      hover: { mode: "index", intersect: false },
      layout: { padding: { top: 4, right: 2, bottom: 0, left: 0 } },
      plugins: {
        legend: { display: false },
        tooltip: {
          displayColors: false,
          filter: (item) => item.datasetIndex === 0,
          backgroundColor: colors.surface,
          borderColor: chartAlpha(colors.blue, .26),
          borderWidth: 1,
          titleColor: colors.text,
          bodyColor: colors.muted,
          titleFont: { family: colors.font, size: 12, weight: "600" },
          bodyFont: { family: colors.font, size: 11, weight: "500" },
          padding: 10,
          cornerRadius: 7,
          callbacks: {
            title: (items) => activity.buckets[items[0]?.dataIndex]?.range || "Daily study time",
            label: (item) => "Study time: " + formatDuration(item.parsed.y || 0),
            afterLabel: (item) => {
              const count = activity.buckets[item.dataIndex]?.sessions || 0;
              return "Sessions: " + count;
            }
          }
        }
      },
      scales: {
        x: { grid: { display: false }, border: { display: false }, ticks: { color: colors.muted, font: { family: colors.font, size: 11, weight: "600" }, padding: 8 } },
        y: {
          beginAtZero: true,
          grace: "14%",
          border: { display: false },
          grid: { color: colors.grid, drawTicks: false, lineWidth: 1 },
          ticks: { color: colors.muted, font: { family: colors.font, size: 10, weight: "500" }, maxTicksLimit: 4, padding: 8, callback: (value) => formatDuration(Number(value) || 0) }
        }
      }
    }
  });
}

function subjectEntriesForPeriod(period) {
  const subjects = new Map();
  (Array.isArray(period.sessions) ? period.sessions : []).forEach((session) => {
    const title = String(session?.subject || "Other").trim() || "Other";
    const entry = subjects.get(title) || { title, minutes: 0, sessions: 0 };
    entry.minutes += sessionActualMinutes(session);
    entry.sessions += 1;
    subjects.set(title, entry);
  });
  return [...subjects.values()].sort((a, b) => b.minutes - a.minutes || b.sessions - a.sessions || a.title.localeCompare(b.title));
}

function renderCourseDistribution(period, periodName) {
  const allEntries = subjectEntriesForPeriod(period);
  const entries = allEntries.slice(0, 20);
  if (el.courseDistributionMeta) el.courseDistributionMeta.textContent = analyticsVisualPeriodLabel(periodName) + " · Subject hours";
  const hasEntries = entries.some((subject) => subject.minutes > 0);
  el.courseDistributionList?.classList.toggle("hidden", !hasEntries);
  el.courseDistributionEmpty?.classList.toggle("hidden", hasEntries);
  if (!el.courseDistributionList) return;
  el.courseDistributionList.innerHTML = "";
  if (!hasEntries) return;
  const subjectGoalMinutes = 60;
  const peak = Math.max(subjectGoalMinutes, ...entries.map((subject) => subject.minutes));
  entries.forEach((subject, index) => {
    const share = period.minutes ? Math.round((subject.minutes / period.minutes) * 100) : 0;
    const row = document.createElement("div");
    row.className = "course-distribution-row";
    row.style.setProperty("--distribution-index", Math.min(index, 8));
    row.setAttribute("aria-label", subject.title + ": " + formatDuration(subject.minutes) + ", " + share + "% of this period. Subject target: 1 hour.");
    row.innerHTML = "<div class='course-distribution-copy'><strong title=''></strong><span></span></div><div class='course-distribution-bar' aria-hidden='true'><i></i><b class='course-distribution-goal'></b></div><div class='course-distribution-value'><strong></strong><span></span></div>";
    const title = row.querySelector(".course-distribution-copy strong");
    title.textContent = subject.title;
    title.title = subject.title;
    row.querySelector(".course-distribution-copy span").textContent = subject.sessions + " session" + (subject.sessions === 1 ? "" : "s");
    const fill = row.querySelector(".course-distribution-bar i");
    const width = Math.max(3, Math.round((subject.minutes / peak) * 100)) + "%";
    fill.style.width = "0%";
    row.querySelector(".course-distribution-goal").style.left = Math.min(100, Math.round((subjectGoalMinutes / peak) * 100)) + "%";
    row.querySelector(".course-distribution-value strong").textContent = formatDuration(subject.minutes);
    row.querySelector(".course-distribution-value span").textContent = share + "%";
    el.courseDistributionList.append(row);
    requestAnimationFrame(() => { fill.style.width = width; });
  });
}

function renderGoalConsistency(period, periodName) {
  const dailyGoalMinutes = Math.max(0, Number(state.goals?.studyHours || 0) * 60);
  const goalMinutes = periodName === "previous-month" ? dailyGoalMinutes * period.keys.length : dailyGoalMinutes * 7;
  const progress = goalMinutes ? Math.min(100, Math.round((period.minutes / goalMinutes) * 100)) : 0;
  const averageSession = period.completedSessions ? Math.round(period.minutes / period.completedSessions) : 0;
  const longest = (period.sessions || []).reduce((maximum, session) => Math.max(maximum, sessionActualMinutes(session)), 0);
  if (el.consistencyMeta) el.consistencyMeta.textContent = analyticsVisualPeriodLabel(periodName);
  if (el.consistencyGoalLabel) el.consistencyGoalLabel.textContent = periodName === "previous-month" ? "Monthly goal" : "Weekly goal";
  if (el.consistencyGoalValue) el.consistencyGoalValue.textContent = formatDuration(period.minutes) + " / " + formatDuration(goalMinutes);
  if (el.consistencyGoalPercent) el.consistencyGoalPercent.textContent = progress + "%";
  if (el.consistencyGoalFill) el.consistencyGoalFill.style.width = progress + "%";
  if (el.consistencyDailyAverage) el.consistencyDailyAverage.textContent = formatDuration(period.dailyAverageMinutes);
  if (el.consistencySessions) el.consistencySessions.textContent = String(period.completedSessions);
  if (el.consistencyAverageSession) el.consistencyAverageSession.textContent = formatDuration(averageSession);
  if (el.consistencyLongestSession) el.consistencyLongestSession.textContent = formatDuration(longest);
}

function renderAnalytics() {
  const summary = completedAnalytics();
  const currentPeriod = completedPeriodAnalytics(summary, "current-week", new Date(), state.goals?.studyHours);
  const weeklyMinutes = currentPeriod.minutes;
  const avgMinutes = Math.round(weeklyMinutes / 7);
  const sixWeekMinutes = dateSeries(42).reduce((sum, key) => sum + (summary.byDate.get(key) || 0), 0);
  const weeklyAverageMinutes = Math.round(sixWeekMinutes / 6);
  el.currentStreak.textContent = (state.analytics.streak?.current || 0) + " days";
  if (el.analyticsToday) el.analyticsToday.textContent = formatDuration(summary.todayMinutes);
  if (el.analyticsWeek) el.analyticsWeek.textContent = formatDuration(weeklyMinutes);
  if (el.analyticsSessions) el.analyticsSessions.textContent = String(currentPeriod.completedSessions);
  if (el.weeklyHours) el.weeklyHours.textContent = hours(weeklyAverageMinutes);
  if (el.averageStudy) el.averageStudy.textContent = hours(avgMinutes);
  el.goalProgress.textContent = goalProgressPercent(state) + "%";
  const todayMinutes = summary.todayMinutes;
  if (el.dailyComparison) el.dailyComparison.textContent = (todayMinutes >= avgMinutes ? "+" : "-") + formatDuration(Math.abs(todayMinutes - avgMinutes));
  renderGamification();
  const visualPeriodName = selectedAnalyticsVisualPeriod();
  const visualPeriod = completedPeriodAnalytics(summary, visualPeriodName, new Date(), state.goals?.studyHours);
  renderStudyActivity(summary, visualPeriodName);
  renderCourseDistribution(visualPeriod, visualPeriodName);
  renderGoalConsistency(visualPeriod, visualPeriodName);
  destroyChart("weekly");
  destroyChart("subject");
  renderCourseHistory(summary);
  renderAnalyticsHistory(summary);
}
function historicalPeriodLabel(period) { return period === "previous-month" ? "Previous month" : "Previous week"; }
function renderAnalyticsHistory(summary = completedAnalytics()) {
  const drawer = el.analyticsHistoryDrawer;
  if (!drawer) return;
  const buttons = [[el.analyticsCurrentBtn, null], [el.analyticsPreviousWeekBtn, "previous-week"], [el.analyticsPreviousMonthBtn, "previous-month"]];
  buttons.forEach(([button, period]) => { if (!button) return; const active = analyticsHistoryPeriod === period; button.classList.toggle("active", active); button.setAttribute("aria-pressed", String(active)); });
  if (!analyticsHistoryPeriod) { drawer.classList.add("hidden"); return; }
  const now = new Date();
  const previous = completedPeriodAnalytics(summary, analyticsHistoryPeriod, now, state.goals?.studyHours);
  const current = completedPeriodAnalytics(summary, analyticsHistoryPeriod === "previous-month" ? "current-month" : "current-week", now, state.goals?.studyHours);
  drawer.classList.remove("hidden");
  el.analyticsHistoryTitle.textContent = historicalPeriodLabel(analyticsHistoryPeriod);
  el.analyticsHistoryTotal.textContent = formatDuration(previous.minutes);
  el.analyticsHistorySessions.textContent = String(previous.completedSessions);
  el.analyticsHistoryAverage.textContent = formatDuration(previous.dailyAverageMinutes);
  el.analyticsHistoryGoal.textContent = previous.goalProgress === null ? "No goal" : previous.goalProgress + "%";
  if (!previous.minutes) el.analyticsHistoryComparison.textContent = "Complete a few more sessions to unlock a " + historicalPeriodLabel(analyticsHistoryPeriod).toLowerCase() + " comparison.";
  else if (current.minutes > 0) { const change = Math.round(((current.minutes - previous.minutes) / previous.minutes) * 100); el.analyticsHistoryComparison.textContent = "Current period: " + formatDuration(current.minutes) + " • Change: " + (change >= 0 ? "+" : "") + change + "%"; }
  else el.analyticsHistoryComparison.textContent = "Your " + historicalPeriodLabel(analyticsHistoryPeriod).toLowerCase() + " recorded " + formatDuration(previous.minutes) + " across " + previous.completedSessions + " completed session" + (previous.completedSessions === 1 ? "" : "s") + ".";
  el.analyticsHistoryCourses.innerHTML = "";
  if (!previous.courseEntries.length) { el.analyticsHistoryCourses.innerHTML = "<span class='analytics-history-empty'>No completed course activity in this period.</span>"; return; }
  const heading = document.createElement("strong"); heading.textContent = "Top courses"; el.analyticsHistoryCourses.append(heading);
  previous.courseEntries.slice(0, 3).forEach((course) => { const row = document.createElement("div"); row.innerHTML = "<span title=''></span><b></b><small></small>"; row.querySelector("span").textContent = course.title; row.querySelector("span").title = course.title; row.querySelector("b").textContent = formatDuration(course.minutes); row.querySelector("small").textContent = course.sessions + " session" + (course.sessions === 1 ? "" : "s"); el.analyticsHistoryCourses.append(row); });
}
function setCourseHistoryExpanded(expanded) {
  courseHistoryExpanded = Boolean(expanded);
  try { sessionStorage.setItem("courseFocusProCourseHistoryExpanded", String(courseHistoryExpanded)); } catch {}
  if (el.courseHistoryPanel) el.courseHistoryPanel.dataset.expanded = String(courseHistoryExpanded);
  if (el.courseHistoryToggle) el.courseHistoryToggle.setAttribute("aria-expanded", String(courseHistoryExpanded));
}
function renderCourseHistory(summary = completedAnalytics()) {
  if (!el.courseHistoryList) return;
  const query = courseHistoryQuery.trim().toLowerCase();
  const courses = summary.courseEntries.filter((course) => (course.title + " " + course.id).toLowerCase().includes(query));
  setCourseHistoryExpanded(courseHistoryExpanded);
  if (el.courseHistoryCount) el.courseHistoryCount.textContent = summary.courseEntries.length + " course" + (summary.courseEntries.length === 1 ? "" : "s");
  el.courseHistoryList.innerHTML = "";
  if (!courses.length) { el.courseHistoryList.innerHTML = "<div class='course-history-empty'><strong>" + (summary.completedSessions ? "No matching courses" : "No course history yet") + "</strong><span>" + (summary.completedSessions ? "Try a different course name." : "Complete your first focus session to see your study history here.") + "</span></div>"; return; }
  courses.slice(0, 80).forEach((course) => {
    const share = summary.totalMinutes ? Math.round((course.minutes / summary.totalMinutes) * 100) : 0;
    const row = document.createElement("details"); row.className = "course-history-row";
    const related = summary.sessions.filter((item) => String(item.courseId || item.courseTitle) === String(course.id || course.title)).slice(0, 4);
    row.innerHTML = "<summary><span class='course-history-name' title=''></span><span class='course-history-time'></span><span class='course-history-sessions'></span><span class='course-history-share'><i></i><b></b></span><span class='course-history-expand'>Details</span></summary><div class='course-history-details'></div>";
    const name = row.querySelector(".course-history-name"); name.textContent = course.title; name.title = course.title;
    row.querySelector(".course-history-time").textContent = formatDuration(course.minutes);
    row.querySelector(".course-history-share i").style.setProperty("--progress", share + "%"); row.querySelector(".course-history-share b").textContent = share + "%";
    row.querySelector(".course-history-sessions").textContent = course.sessions + " session" + (course.sessions === 1 ? "" : "s");
    const details = row.querySelector(".course-history-details"); details.textContent = related.length ? related.map((item) => historyDateLabel(item.endedAt) + " • " + formatDuration(item.actualMinutes)).join("\n") : "No recent completed sessions.";
    el.courseHistoryList.append(row);
  });
}
function minutesForDate(key) {
  const daily = state.analytics?.daily?.[key] || {};
  return Number(daily.studyMinutes || 0);
}
function renderAdvancedAnalytics() {
  if (el.analyticsInsightGrid) {
    const summary = completedAnalytics();
    const history = summary.sessions;
    const byHour = new Map();
    history.forEach((session) => {
      const hour = new Date(session.startedAt || session.endedAt || 0).getHours();
      byHour.set(hour, (byHour.get(hour) || 0) + sessionActualMinutes(session));
    });
    const productiveHour = [...byHour.entries()].sort((a, b) => b[1] - a[1])[0];
    const topSubject = Object.entries(subjectTotalsFromHistory()).sort((a, b) => b[1].minutes - a[1].minutes)[0];
    const thisWeek = summary.weekMinutes;
    const distractionThisWeek = dateSeries(7).reduce((sum, key) => sum + Number(state.analytics?.daily?.[key]?.distractionsBlocked || 0), 0);
    const weeklyHours = thisWeek / 60;
    const averageSession = history.length ? Math.round(history.reduce((sum, session) => sum + sessionActualMinutes(session), 0) / history.length) : 0;
    const dailyTotals = dateSeries(7).map((key) => ({ key, minutes: summary.byDate.get(key) || 0 }));
    const strongestDay = [...dailyTotals].sort((a, b) => b.minutes - a.minutes)[0];
    const insights = [
      { label: "Best study window", value: productiveHour ? new Date(2000, 0, 1, productiveHour[0]).toLocaleTimeString([], { hour: "numeric" }) : "Not enough data", detail: productiveHour ? formatDuration(productiveHour[1]) + " focused at this hour" : "Focus time will reveal your pattern" },
      { label: "Most focused subject", value: topSubject?.[1]?.minutes ? topSubject[0] : "Not enough data", detail: topSubject?.[1]?.minutes ? formatDuration(topSubject[1].minutes) + " of actual focus" : "Your first session will appear here" },
      { label: "Average session", value: averageSession ? formatDuration(averageSession) : "Not enough data", detail: averageSession ? "your average focused block" : "Focus time will set a baseline" },
      { label: "Strongest day", value: strongestDay?.minutes ? new Date(strongestDay.key + "T00:00:00").toLocaleDateString([], { weekday: "long" }) : "Not enough data", detail: strongestDay?.minutes ? formatDuration(strongestDay.minutes) + " focused on that day" : "Your strongest day will appear here" },
      { label: "Distraction trend", value: distractionThisWeek + " blocked", detail: distractionThisWeek ? "this week across protected sites" : "a clean week so far" },
      { label: "Monthly estimate", value: hours(Math.round(weeklyHours * 4.35 * 60)), detail: "at your current 7-day pace" },
      { label: "Yearly estimate", value: hours(Math.round(weeklyHours * 52 * 60)), detail: "at your current 7-day pace" }
    ];
    el.analyticsInsightGrid.innerHTML = "";
    insights.forEach((insight) => {
      const item = document.createElement("article");
      item.className = "analytics-insight";
      item.innerHTML = "<span></span><strong></strong><p></p>";
      item.querySelector("span").textContent = insight.label;
      item.querySelector("strong").textContent = insight.value;
      item.querySelector("p").textContent = insight.detail;
      el.analyticsInsightGrid.append(item);
    });
  }
  if (el.studyHeatmap) {
    const keys = dateSeries(84);
    const values = keys.map(minutesForDate);
    const max = Math.max(1, ...values);
    el.studyHeatmap.innerHTML = "";
    keys.forEach((key, index) => {
      const minutes = values[index];
      const cell = document.createElement("span");
      const intensity = minutes ? Math.max(1, Math.ceil(minutes / max * 4)) : 0;
      cell.className = "heatmap-cell level-" + intensity;
      cell.title = new Date(key + "T00:00:00").toLocaleDateString([], { month: "short", day: "numeric" }) + ": " + formatDuration(minutes);
      cell.setAttribute("aria-label", cell.title);
      el.studyHeatmap.append(cell);
    });
  }
}
function historyDateLabel(timestamp, active = false) {
  if (active) return "Now • In progress";
  const date = new Date(Number(timestamp) || 0);
  if (!Number.isFinite(date.getTime())) return "Date unavailable";
  const day = todayKey(date) === todayKey() ? "Today" : date.toLocaleDateString([], { month: "short", day: "numeric", year: date.getFullYear() === new Date().getFullYear() ? undefined : "numeric" });
  return day + " • " + date.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}
function missionCompletionPercent() {
  const tasks = state.daily.tasks || [];
  if (!tasks.length) return 0;
  const total = tasks.reduce((sum, task) => sum + Math.max(10, Number(task.minutes) || 20), 0);
  const done = tasks.filter((task) => task.done).reduce((sum, task) => sum + Math.max(10, Number(task.minutes) || 20), 0);
  return Math.round((done / Math.max(1, total)) * 100);
}
function systemGoalsData() { return dailySystemGoals(state); }
function renderSystemGoals() {
  if (!el.systemGoalsList) return;
  el.systemGoalsList.innerHTML = "";
  systemGoalsData().forEach((goal) => {
    const card = document.createElement("article");
    card.className = "system-goal-card" + (goal.done ? " done" : "");
    card.innerHTML = "<div><span></span><h4></h4><p></p></div><strong></strong><div class='progress-bar'><span></span></div>";
    card.querySelector("span").textContent = goal.done ? "Complete" : "In progress";
    card.querySelector("h4").textContent = goal.title;
    card.querySelector("p").textContent = goal.display || Math.min(goal.value, goal.target) + " / " + goal.target;
    card.querySelector("strong").textContent = "+" + goal.xp + " XP";
    card.querySelector(".progress-bar span").style.width = goal.percent + "%";
    el.systemGoalsList.append(card);
  });
}
function missionCard(task, index) {
  const item = document.createElement("article");
  item.className = "mission-item personal-goal-card" + (task.done ? " done" : "");
  item.innerHTML = "<input class='done' type='checkbox'><div class='personal-goal-copy'><strong></strong><span></span><p></p><small>No XP - personal goal</small></div><div class='mission-actions'><button class='button secondary compact-button edit' type='button'>Edit</button><button class='icon-button danger del' type='button'>x</button></div>";
  item.querySelector(".done").checked = task.done;
  item.querySelector("strong").textContent = task.title || "Personal goal";
  item.querySelector("span").textContent = (task.area || "Personal") + (Number(task.minutes || 0) ? " - " + task.minutes + " min" : "");
  item.querySelector("p").textContent = task.note || "No note added.";
  item.querySelector(".done").addEventListener("change", (e) => updateTask(index, { done: e.target.checked }));
  item.querySelector(".edit").addEventListener("click", () => editTask(index));
  item.querySelector(".del").addEventListener("click", () => deleteTask(index));
  return item;
}
function renderMissions() {
  renderSystemGoals();
  if (el.personalTaskList) {
    el.personalTaskList.innerHTML = "";
    const percent = missionCompletionPercent();
    el.missionProgressText.textContent = percent + "%";
    el.missionProgressFill.style.width = percent + "%";
    const indexed = state.daily.tasks.map((task, index) => ({ task, index }));
    if (!indexed.length) el.personalTaskList.innerHTML = "<div class='empty-state'><h4>No personal goals yet</h4><p>Add homework, assignments, revision, or any custom goal here. These do not award XP.</p></div>";
    else indexed.forEach(({ task, index }) => el.personalTaskList.append(missionCard(task, index)));
  }
}
function renderPlanner() {
  if (!el.plannerTimeline) return;
  if (el.plannerDateInput && !el.plannerDateInput.value) el.plannerDateInput.value = todayKey();
  el.plannerTimeline.innerHTML = "";
  const items = [...(state.planner?.items || [])].sort((a, b) => a.date.localeCompare(b.date) || Number(a.done) - Number(b.done)).slice(0, 18);
  if (!items.length) {
    el.plannerTimeline.innerHTML = "<div class='empty-state compact-empty'><h4>Nothing scheduled yet</h4><p>Schedule the next revision, study block, or deadline. Planner items help you organize but do not award XP.</p></div>";
    return;
  }
  items.forEach((item) => {
    const row = document.createElement("article");
    row.className = "planner-item" + (item.done ? " done" : "");
    row.innerHTML = "<input type='checkbox'><div><span></span><strong></strong><p></p></div><button class='icon-button danger remove' type='button' aria-label='Delete plan'>x</button>";
    const check = row.querySelector("input");
    check.checked = item.done;
    check.addEventListener("change", () => updatePlannerItem(item.id, { done: check.checked }));
    row.querySelector("span").textContent = item.kind + " - " + new Date(item.date + "T00:00:00").toLocaleDateString([], { month: "short", day: "numeric" });
    row.querySelector("strong").textContent = item.title;
    row.querySelector("p").textContent = courseName(item.courseId) + (item.minutes ? " - " + item.minutes + " min" : "");
    row.querySelector(".remove").addEventListener("click", () => deletePlannerItem(item.id));
    el.plannerTimeline.append(row);
  });
}
async function addPlannerItem(event) {
  event.preventDefault();
  const title = el.plannerTitleInput.value.trim();
  if (!title) return showToast("Give the study plan a clear title.");
  const item = { id: uid("plan"), title, date: el.plannerDateInput.value || todayKey(), kind: el.plannerKindInput.value, courseId: el.plannerCourseInput.value || null, minutes: Math.max(0, Number(el.plannerMinutesInput.value) || 0), done: false, createdAt: Date.now() };
  await saveState({ ...state, planner: { items: [...(state.planner?.items || []), item] } });
  el.plannerForm.reset();
  el.plannerDateInput.value = todayKey();
  showToast("Study block scheduled.");
}
async function updatePlannerItem(id, patch) {
  await saveState({ ...state, planner: { items: (state.planner?.items || []).map((item) => item.id === id ? { ...item, ...patch } : item) } });
}
async function deletePlannerItem(id) {
  if (!confirm("Delete this study plan?")) return;
  const previous = state;
  await saveState({ ...state, planner: { items: (state.planner?.items || []).filter((item) => item.id !== id) } });
  showUndo("Study plan deleted.", previous);
}
function musicMetadata(track) { return { id: track.id, title: track.title, type: track.type, size: track.size || 0, name: track.name || track.title, lastModified: track.lastModified || 0, available: Boolean(track.url) }; }
function musicKey(source = music.source, id = music.currentImportedId || MUSIC_TRACKS[music.index]?.id) { return source === "imported" ? "imported:" + id : "built-in:" + id; }
function musicTrackFromKey(key) {
  const [source, id] = String(key || "").split(":");
  if (source === "imported") return { source, track: music.imported.find((item) => item.id === id) || null };
  return { source: "built-in", track: MUSIC_TRACKS.find((item) => item.id === id) || null };
}
function playMusicKey(key) {
  const item = musicTrackFromKey(key);
  if (!item.track) return false;
  if (item.source === "imported") playImported(item.track.id);
  else playMusic(MUSIC_TRACKS.findIndex((track) => track.id === item.track.id));
  return true;
}
function saveMusicLibrary() {
  try {
    localStorage.setItem(MUSIC_LIBRARY_KEY, JSON.stringify({
      imported: music.imported.map(musicMetadata),
      currentImportedId: music.currentImportedId
    }));
  } catch {}
}
function loadMusicLibrary() {
  try {
    const raw = JSON.parse(localStorage.getItem(MUSIC_LIBRARY_KEY) || "{}");
    music.imported = Array.isArray(raw.imported) ? raw.imported.map((track) => ({ ...track, available: false, url: "" })).slice(0, 80) : [];
    music.currentImportedId = raw.currentImportedId || null;
  } catch { music.imported = []; }
}
function stopImportedAudio() {
  if (music.audio) {
    try { music.audio.pause(); } catch {}
    music.audio.onended = null;
    music.audio = null;
  }
}
function activeImportedList() {
  return music.imported.filter((track) => track.available !== false);
}
function renderMyMusic() {
  if (!el.myMusicList) return;
  el.myMusicList.innerHTML = "";
  if (!music.imported.length) {
    el.myMusicList.innerHTML = "<div class='empty-state compact-empty'><h4>No imported songs</h4><p>Add MP3, WAV, or OGG files. They stay local and are never uploaded.</p></div>";
    return;
  }
  music.imported.forEach((track) => {
    const row = document.createElement("article");
    row.className = "music-track-row" + (music.source === "imported" && music.currentImportedId === track.id ? " active" : "") + (track.available === false ? " unavailable" : "");
    row.innerHTML = "<div><strong></strong><span></span></div><button class='button secondary compact-button play-track' type='button'>Play</button><button class='button danger compact-button' type='button'>Remove</button>";
    row.querySelector("strong").textContent = track.title;
    row.querySelector("span").textContent = track.available === false ? "Re-import needed after browser restart" : track.type.toUpperCase() + " ready";
    const play = row.querySelector(".play-track");
    play.textContent = track.available === false ? "Re-import" : "Play";
    play.addEventListener("click", () => track.available === false ? el.musicImportInput.click() : playImported(track.id));
    row.querySelector(".danger").addEventListener("click", () => removeImported(track.id));
    el.myMusicList.append(row);
  });
}
function renderMusic() {
  if (!el.musicCategories) return;
  el.musicCategories.innerHTML = "";
  MUSIC_TRACKS.forEach((track, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "music-category" + (music.source === "built-in" && index === music.index ? " active" : "");
    button.innerHTML = "<strong></strong><span></span>";
    button.querySelector("strong").textContent = track.title;
    button.querySelector("span").textContent = track.description;
    button.addEventListener("click", () => playMusic(index));
    el.musicCategories.append(button);
  });
  const imported = music.imported.find((track) => track.id === music.currentImportedId);
  const builtIn = MUSIC_TRACKS[music.index];
  const current = music.source === "imported" && imported ? imported : builtIn;
  el.musicTitle.textContent = current.title;
  el.musicDescription.textContent = music.source === "imported" && imported ? (imported.available === false ? "Re-import this local file to play it again." : "Imported local audio file.") : current.description;
  el.musicStatus.textContent = music.playing ? "Music Playing" : "Stopped";
  el.musicStatus.classList.toggle("active", music.playing);
  el.musicVolumeInput.value = Math.round(music.volume * 100);
  if (el.musicVolumeLabel) el.musicVolumeLabel.textContent = Math.round(music.volume * 100) + "%";
  el.musicLoopInput.checked = music.loop;
  el.musicShuffleBtn?.classList.toggle("active", music.shuffle);
  el.musicPlayBtn?.classList.toggle("active", music.playing);
  if (el.musicPlayBtn) el.musicPlayBtn.disabled = music.playing;
  if (el.musicPauseBtn) el.musicPauseBtn.disabled = !music.playing;
  el.musicPauseBtn?.classList.toggle("active", music.playing);
  const canSeek = music.source === "imported" && Boolean(music.audio);
  if (el.musicBackBtn) el.musicBackBtn.disabled = !canSeek;
  if (el.musicForwardBtn) el.musicForwardBtn.disabled = !canSeek;
  renderMyMusic();
}
function renderMusicLibraryControls() {
  if (!el.playlistSelect || !el.musicQueue) return;
  el.playlistSelect.innerHTML = "";
  if (!music.playlists.length) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "Create a playlist first";
    el.playlistSelect.append(option);
  } else {
    music.playlists.forEach((playlist) => {
      const option = document.createElement("option");
      option.value = playlist.id;
      option.textContent = playlist.name + " (" + playlist.trackIds.length + ")";
      option.selected = playlist.id === music.activePlaylistId;
      el.playlistSelect.append(option);
    });
  }
  el.playlistAddCurrentBtn.disabled = !music.activePlaylistId;
  const currentKey = musicKey();
  el.musicFavoriteBtn.textContent = music.favorites.includes(currentKey) ? "Favorited" : "Favorite";
  el.musicFavoriteBtn.classList.toggle("active", music.favorites.includes(currentKey));
  el.musicQueue.innerHTML = "";
  if (!music.queue.length) el.musicQueue.innerHTML = "<p class='form-status'>Queue is empty. Add a sound to line up the next study block.</p>";
  else music.queue.forEach((key, index) => {
    const item = musicTrackFromKey(key);
    if (!item.track) return;
    const row = document.createElement("div");
    row.className = "queue-row";
    row.innerHTML = "<span></span><strong></strong><button class='icon-button remove' type='button' aria-label='Remove queued track'>x</button>";
    row.querySelector("span").textContent = index + 1;
    row.querySelector("strong").textContent = item.track.title;
    row.querySelector(".remove").addEventListener("click", () => { music.queue.splice(index, 1); saveMusicLibrary(); renderMusic(); });
    el.musicQueue.append(row);
  });
}
function toggleMusicFavorite() {
  const key = musicKey();
  music.favorites = music.favorites.includes(key) ? music.favorites.filter((item) => item !== key) : [...music.favorites, key];
  saveMusicLibrary();
  renderMusic();
}
function enqueueCurrentMusic() {
  const key = musicKey();
  if (music.queue.length >= 80) return showToast("Music queue is full.");
  music.queue.push(key);
  saveMusicLibrary();
  renderMusic();
  showToast("Added to queue.");
}
function createPlaylist() {
  const name = el.playlistNameInput.value.trim().slice(0, 48);
  if (!name) return showToast("Name the playlist first.");
  const playlist = { id: uid("playlist"), name, trackIds: [] };
  music.playlists.push(playlist);
  music.activePlaylistId = playlist.id;
  el.playlistNameInput.value = "";
  saveMusicLibrary();
  renderMusic();
  showToast("Playlist created.");
}
function addCurrentToPlaylist() {
  const playlist = music.playlists.find((item) => item.id === music.activePlaylistId);
  if (!playlist) return showToast("Create or choose a playlist first.");
  const key = musicKey();
  if (!playlist.trackIds.includes(key)) playlist.trackIds.push(key);
  saveMusicLibrary();
  renderMusic();
  showToast("Added to " + playlist.name + ".");
}
function playActivePlaylist() {
  const playlist = music.playlists.find((item) => item.id === music.activePlaylistId);
  if (!playlist?.trackIds.length) return showToast("Add at least one track to this playlist.");
  music.queue = [...playlist.trackIds.slice(1), ...music.queue];
  saveMusicLibrary();
  playMusicKey(playlist.trackIds[0]);
  showToast("Playing " + playlist.name + ".");
}
function deleteActivePlaylist() {
  const playlist = music.playlists.find((item) => item.id === music.activePlaylistId);
  if (!playlist || !confirm("Delete playlist '" + playlist.name + "'?")) return;
  music.playlists = music.playlists.filter((item) => item.id !== playlist.id);
  music.activePlaylistId = music.playlists[0]?.id || null;
  saveMusicLibrary();
  renderMusic();
}
function setMusicSleepTimer(minutes) {
  clearTimeout(music.sleepTimer);
  music.sleepTimer = null;
  const duration = Math.max(0, Number(minutes) || 0);
  music.sleepEndsAt = duration ? Date.now() + duration * 60000 : null;
  if (duration) music.sleepTimer = setTimeout(() => { music.sleepEndsAt = null; pauseMusic(true); showToast("Music sleep timer finished."); }, duration * 60000);
  renderMusic();
}
function ensureMusicContext() {
  if (!music.ctx) {
    music.ctx = new (window.AudioContext || window.webkitAudioContext)();
    music.gain = music.ctx.createGain();
    music.gain.gain.value = music.volume;
    music.gain.connect(music.ctx.destination);
  }
  return music.ctx;
}
function stopMusicNodes() {
  clearTimeout(music.endTimer);
  music.endTimer = null;
  music.nodes.forEach((node) => { try { node.stop?.(); } catch {} try { node.disconnect?.(); } catch {} });
  music.nodes = [];
}
function crossfadeMusicNodes() {
  if (!music.nodes.length || !music.gain || !music.ctx) return stopMusicNodes();
  clearTimeout(music.endTimer);
  music.endTimer = null;
  const previousNodes = music.nodes;
  music.nodes = [];
  const now = music.ctx.currentTime;
  music.gain.gain.cancelScheduledValues(now);
  music.gain.gain.setValueAtTime(Math.max(0.0001, music.gain.gain.value), now);
  music.gain.gain.linearRampToValueAtTime(0.0001, now + 0.14);
  setTimeout(() => {
    previousNodes.forEach((node) => { try { node.stop?.(); } catch {} try { node.disconnect?.(); } catch {} });
    const resumeAt = music.ctx.currentTime;
    music.gain.gain.setValueAtTime(0.0001, resumeAt);
    music.gain.gain.linearRampToValueAtTime(music.volume, resumeAt + 0.16);
  }, 145);
}
function makeNoiseBuffer(ctx, brown = false) {
  const length = ctx.sampleRate * 2;
  const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  let last = 0;
  for (let i = 0; i < length; i++) {
    const white = Math.random() * 2 - 1;
    data[i] = brown ? (last = (last + 0.02 * white) / 1.02) * 3.5 : white * 0.42;
  }
  return buffer;
}
function makeRainBuffer(ctx) {
  const length = ctx.sampleRate * 8;
  const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  let smooth = 0;
  for (let i = 0; i < length; i++) {
    const t = i / ctx.sampleRate;
    const white = Math.random() * 2 - 1;
    smooth = smooth * 0.78 + white * 0.22;
    const shower = white * 0.28 + smooth * 0.42;
    const droplets = Math.random() > 0.993 ? (Math.random() * 2 - 1) * 0.7 : 0;
    const thunderA = t > 1.2 && t < 2.8 ? Math.sin((t - 1.2) * Math.PI / 1.6) : 0;
    const thunderB = t > 5.4 && t < 7.1 ? Math.sin((t - 5.4) * Math.PI / 1.7) : 0;
    const rumble = (thunderA + thunderB) * smooth * 1.8;
    data[i] = Math.max(-1, Math.min(1, shower + droplets + rumble));
  }
  return buffer;
}
function createFilteredNoise(ctx, { buffer = makeNoiseBuffer(ctx), filter = 1200, gain = 0.14, filterType = "lowpass" } = {}) {
  const source = ctx.createBufferSource();
  const biquad = ctx.createBiquadFilter();
  const level = ctx.createGain();
  source.buffer = buffer;
  source.loop = true;
  biquad.type = filterType;
  biquad.frequency.value = filter;
  level.gain.value = gain;
  source.connect(biquad).connect(level).connect(music.gain);
  source.start();
  music.nodes.push(source, biquad, level);
  return level;
}
function playRainMusic(ctx) {
  createFilteredNoise(ctx, { buffer: makeRainBuffer(ctx), filter: 3600, gain: 0.17 });
  createFilteredNoise(ctx, { buffer: makeNoiseBuffer(ctx, true), filter: 150, gain: 0.12 });
}
function playCoffeeAmbience(ctx) {
  createFilteredNoise(ctx, { buffer: makeNoiseBuffer(ctx, true), filter: 720, gain: 0.075 });
  [118, 164, 226].forEach((frequency, index) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = frequency;
    gain.gain.value = 0.018 - index * 0.003;
    osc.connect(gain).connect(music.gain);
    osc.start();
    music.nodes.push(osc, gain);
  });
}
function playOceanWave(ctx) {
  const waveGain = createFilteredNoise(ctx, { buffer: makeNoiseBuffer(ctx, true), filter: 760, gain: 0.12 });
  const lfo = ctx.createOscillator();
  const lfoGain = ctx.createGain();
  lfo.frequency.value = 0.09;
  lfoGain.gain.value = 0.08;
  lfo.connect(lfoGain).connect(waveGain.gain);
  lfo.start();
  music.nodes.push(lfo, lfoGain);
}
function playMusic(index = music.index) {
  music.index = (index + MUSIC_TRACKS.length) % MUSIC_TRACKS.length;
  music.source = "built-in";
  stopImportedAudio();
  const track = MUSIC_TRACKS[music.index];
  const ctx = ensureMusicContext();
  ctx.resume?.();
  stopMusicNodes();
  if (track.type === "tone") {
    const osc = ctx.createOscillator();
    const lfo = ctx.createOscillator();
    const lfoGain = ctx.createGain();
    osc.type = track.wave;
    osc.frequency.value = track.frequency;
    lfo.frequency.value = track.lfoFrequency || (track.id === "piano" ? 1.1 : 0.32);
    lfoGain.gain.value = track.lfoGain ?? (track.id === "piano" ? 0.18 : 0.07);
    const toneGain = ctx.createGain();
    toneGain.gain.value = track.gain ?? 0.18;
    lfo.connect(lfoGain);
    lfoGain.connect(toneGain.gain);
    osc.connect(toneGain).connect(music.gain);
    osc.start();
    lfo.start();
    music.nodes.push(osc, lfo, toneGain, lfoGain);
  } else if (track.type === "rain") {
    playRainMusic(ctx);
  } else if (track.type === "coffee") {
    playCoffeeAmbience(ctx);
  } else if (track.type === "oceanwave") {
    playOceanWave(ctx);
  } else {
    createFilteredNoise(ctx, { buffer: makeNoiseBuffer(ctx, track.id === "brown"), filter: track.filter || 1000, gain: track.id === "white" ? 0.09 : 0.16 });
  }
  music.playing = true;
  if (!music.loop) music.endTimer = setTimeout(() => nextMusic(), 10 * 60 * 1000);
  saveMusicLibrary();
  renderMusic();
}
function playImported(id) {
  const track = music.imported.find((item) => item.id === id);
  if (!track) return;
  if (track.available === false || !track.url) { showToast("Re-import this song to play it again."); el.musicImportInput.click(); return; }
  music.source = "imported";
  music.currentImportedId = id;
  stopMusicNodes();
  stopImportedAudio();
  const audio = new Audio(track.url);
  audio.volume = music.volume;
  audio.loop = music.loop;
  audio.onended = () => { if (!music.loop) nextMusic(); };
  music.audio = audio;
  music.playing = true;
  audio.play().catch(() => { music.playing = false; showToast("Click Play again if Chrome blocked audio start."); renderMusic(); });
  saveMusicLibrary();
  renderMusic();
}
function pauseMusic() {
  stopMusicNodes();
  stopImportedAudio();
  music.playing = false;
  renderMusic();
}
function randomOtherIndex(length, current) {
  if (length <= 1) return 0;
  let next = Math.floor(Math.random() * length);
  if (next === current) next = (next + 1) % length;
  return next;
}
function previousMusic() {
  if (music.source === "imported") {
    const list = activeImportedList();
    const index = list.findIndex((track) => track.id === music.currentImportedId);
    if (list.length) playImported(list[(index - 1 + list.length) % list.length].id);
    return;
  }
  playMusic(music.shuffle ? randomOtherIndex(MUSIC_TRACKS.length, music.index) : music.index - 1);
}
function nextMusic() {
  if (music.source === "imported") {
    const list = activeImportedList();
    const index = list.findIndex((track) => track.id === music.currentImportedId);
    if (list.length) playImported(list[music.shuffle ? randomOtherIndex(list.length, index) : (index + 1) % list.length].id);
    return;
  }
  playMusic(music.shuffle ? randomOtherIndex(MUSIC_TRACKS.length, music.index) : music.index + 1);
}
function handleMusicCommand(action) {
  if (action === "play") { music.source === "imported" && music.currentImportedId ? playImported(music.currentImportedId) : playMusic(); return true; }
  if (action === "pause") { pauseMusic(); return true; }
  if (action === "next") { nextMusic(); return true; }
  if (action === "previous") { previousMusic(); return true; }
  return false;
}
function seekImportedMusic(seconds) {
  if (!music.audio) return showToast("Seeking works with imported songs only.");
  const duration = Number.isFinite(music.audio.duration) ? music.audio.duration : 0;
  const next = Math.max(0, Math.min(duration || music.audio.currentTime + seconds, music.audio.currentTime + seconds));
  music.audio.currentTime = next;
}
function setMusicVolume(value) {
  music.volume = Math.max(0, Math.min(1, Number(value) / 100));
  if (music.gain) music.gain.gain.value = music.volume;
  if (music.audio) music.audio.volume = music.volume;
  if (el.musicVolumeLabel) el.musicVolumeLabel.textContent = Math.round(music.volume * 100) + "%";
}
function importMusicFiles(files) {
  const accepted = ["audio/mpeg", "audio/wav", "audio/ogg", "audio/x-wav"];
  let added = 0;
  Array.from(files || []).forEach((file) => {
    const ext = file.name.split(".").pop()?.toLowerCase();
    if (!accepted.includes(file.type) && !["mp3", "wav", "ogg"].includes(ext)) return;
    const existing = music.imported.find((track) => track.name === file.name && track.size === file.size && track.lastModified === file.lastModified);
    const next = { id: existing?.id || uid("song"), title: file.name.replace(/\.[^.]+$/, ""), name: file.name, type: ext || "audio", url: URL.createObjectURL(file), size: file.size, lastModified: file.lastModified, available: true };
    if (existing) {
      if (existing.url) URL.revokeObjectURL(existing.url);
      Object.assign(existing, next);
    } else {
      music.imported.push(next);
    }
    added += 1;
  });
  if (added) { saveMusicLibrary(); showToast(added + " song" + (added === 1 ? "" : "s") + " ready."); }
  renderMusic();
}
function removeImported(id) {
  const track = music.imported.find((item) => item.id === id);
  if (!track || !confirm("Remove this imported song from My Music?")) return;
  if (music.currentImportedId === id) pauseMusic();
  if (track.url) URL.revokeObjectURL(track.url);
  music.imported = music.imported.filter((item) => item.id !== id);
    saveMusicLibrary();
  renderMusic();
}
function helpInfo(title, text) {
  const lower = (title + " " + text).toLowerCase();
  if (lower.includes("xp & rank") || lower.includes("xp-rank")) {
    return {
      title: "XP & Rank",
      what: "XP is your verified study progress score.",
      why: "It rewards completed focus sessions, system goals, and streak consistency without giving XP for manual personal goals.",
      how: "Earn XP by finishing real focus sessions and daily system goals. Your level rises automatically, and your rank name changes when you reach the next range.",
      example: "Example: Completing a 50 minute focus session earns session XP and can move you closer to Learner, Scholar, or higher ranks.",
      details: ["Level 1-4: Beginner", "Level 5-9: Learner", "Level 10-19: Student", "Level 20-34: Scholar", "Level 35-49: Achiever", "Level 50-69: Focus Master", "Level 70-89: Elite Scholar", "Level 90-119: Discipline Master", "Level 120+: Legend"]
    };
  }
  const map = [
    ["focus defaults", ["Sets the default session length, study profile, theme, and sound level.", "These are the settings you usually do once, then leave alone.", "Adjust the values, then press Save Settings.", "Example: Set default focus to 50 minutes and choose a comfortable theme."]],
    ["timed session", ["Starts one study block for the selected course.", "The timer, redirect protection, and analytics all begin from this action.", "Choose the minutes, check the course, then press Start Focus once.", "Example: Start a 50 minute Physics session and let the extension open your course."]],
    ["redirect sends", ["During Focus Mode, only your selected course, its saved study links, and approved supporting sites stay open.", "This keeps an accidental detour from becoming a longer break without relying on a blacklist.", "Keep the redirect switch on and add notes, search, or class domains to the Supporting Site Allowlist in Settings.", "Example: Your Physics YouTube course and Google Docs stay open, while Instagram redirects back to your course."]],
    ["today sessions", ["Counts completed focus blocks today.", "It shows whether you are building consistency, not just time.", "Finish a focus session to increase this number.", "Example: Two 25-minute sessions count as 2 sessions."]],
    ["productivity score", ["Combines actual study time, completed sessions, and distraction penalties into one score.", "It gives a quick health check for today's study routine.", "Study consistently and avoid blocked sites to raise it.", "Example: A high score means today was focused and balanced."]],
    ["insight uses", ["Shows one useful observation from completed focus sessions.", "It avoids guessing and only uses real tracked study data.", "Complete a few sessions and the insight becomes more personal.", "Example: It may point out that Chemistry has less study time than Physics this week."]],
    ["add course accepts", ["Saves any educational link as a course.", "This keeps your study starting point one click away.", "Paste a YouTube playlist, documentation page, coding site, or online course link.", "Example: Add a LeetCode study plan as a Coding course."]],
    ["my music", ["Imports local MP3, WAV, or OGG files for study music.", "Chrome protects local files, so after restart you may need to re-import them.", "Use Import, choose files from your computer, then play them from My Music.", "Example: Re-import your rain audio after reopening Chrome."]],
    ["daily study hours", ["Each bar shows how many focused hours were completed on that day.", "It makes weak and strong study days easy to see.", "Compare the bars with the goal line and average label.", "Example: A bar above the goal line means you hit the daily study target."]],
    ["system goals", ["Shows today's rotating goals from verified activity only.", "These goals prevent fake XP because they complete from focus sessions or distraction-free time.", "Start focus sessions and the cards update automatically.", "Example: Tuesday may ask for 3 hours, 2 sessions, and 60 distraction-free minutes."]],
    ["personal goals", ["A private custom list for homework, assignments, revision, or reminders.", "It keeps planning separate from XP, so progress stays honest.", "Add your own goal, then tick it when done. Use Edit to change it.", "Example: Add 'Finish chemistry homework' with a 40 minute estimate."]],
    ["supporting sites", ["Stores study sites that are available during an active Focus Session.", "Focus Mode is a strict allowlist: pages are redirected unless they are your selected course, one of its saved study links, or listed here.", "Outside Focus Mode, normal browsing applies. Supporting sites are also excluded from Distraction Protection.", "Example: docs.google.com and github.com remain available while unrelated sites redirect to your course."]],
    ["distraction protection", ["Redirects the sites in your Distracting Sites list whenever the switch is on, including outside Focus Mode.", "Supporting Sites and saved course links are excluded, so protection does not interrupt approved study resources.", "Turn it on to protect everyday browsing too; turn it off to leave the watchlist open outside Focus Mode.", "Example: Instagram can redirect outside a session while your course and Google Docs stay available."]],
    ["analytics", ["Shows study time, streak, score, XP, and subject progress from completed sessions.", "It helps you see real patterns without manual tracking.", "Read the summary cards first, then use the bar charts for detail.", "Example: If Wednesday is low, plan one shorter recovery session."]],
    ["music", ["Plays quiet study sounds or local audio files in the dashboard.", "It removes the need to open a separate music app.", "Pick a category or import local MP3/WAV/OGG files. After browser restart, import again to reconnect the file.", "Example: Import a rain track and loop it during problem solving."]],
    ["theme", ["Changes the look of every extension page.", "A comfortable palette makes long study sessions easier.", "Choose Light, Dark, System, or a named theme and it applies instantly.", "Example: Use AMOLED Black at night to reduce glare."]],
    ["streak", ["Shows how many days in a row you completed at least one study session.", "It helps you protect consistency, not just total hours.", "Finish one focus session today to keep the streak alive.", "Example: Study Monday, Tuesday, and Wednesday to reach a 3-day streak."]],
    ["weekly average", ["Shows your average study time per week across the last six weeks.", "It smooths out one unusually busy or weak week.", "Use it to see your normal weekly pace, then compare the weekly bars below.", "Example: A 12h weekly average means you usually study about two hours a day."]],
    ["daily average", ["Shows your average focused study time per day over the last seven days.", "It makes today's progress easier to judge.", "Compare today's study time with this number to see if you are ahead or behind.", "Example: If the average is 1h and today is 30m, one more short session balances the day."]],
    ["goal progress", ["This is a three-part daily score, not a count of every goal on the Daily Goals page.", "Your study-time goal, two completed focus sessions, and an active study streak contribute equally.", "Finish any incomplete part to raise the score; each part stops once complete.", "Example: Reaching your study-time goal gives one third of the score before sessions and streak are counted."]],
    ["today vs average", ["This compares today's completed focus minutes with the average of the last seven calendar days.", "Only fully completed focus sessions count, and days with no completed session still count as 0 minutes in the average.", "A plus value means today is above that seven-day average; a minus value means it is below it.", "Example: +25m means today's completed focus time is 25 minutes above your seven-day daily average."]],
    ["today study", ["Shows how much focused study you completed today.", "It tells you whether today has enough progress to support your streak.", "Start or log study time and this number updates automatically.", "Example: One 25-minute focus block counts toward today."]],
    ["xp", ["XP is earned from verified focus sessions, system goals, and streak bonuses.", "Levels rise as XP grows, while Study Rank updates automatically.", "Study consistently and complete system goals; personal goals do not award XP.", "Example: A completed focus session plus a streak bonus moves you closer to the next level.", ["Level 1-4: Beginner", "Level 5-9: Learner", "Level 10-19: Student", "Level 20-34: Scholar", "Level 35-49: Achiever", "Level 50-69: Focus Master", "Level 70-89: Elite Scholar", "Level 90-119: Discipline Master", "Level 120+: Legend"]]]
  ];
  const item = map.find(([key]) => lower.includes(key));
  const detail = item ? item[1] : [text || "This feature helps you study with less friction.", "It keeps important actions easier to understand.", "Use the controls in this section and review the result.", "Example: Start small, then adjust after one session."];
  return { title, what: detail[0], why: detail[1], how: detail[2], example: detail[3], details: detail[4] || [] };
}
function showHelp(button) {
  const text = button.dataset.help || "This helps you stay focused.";
  const statTitle = button.closest(".stat-widget")?.querySelector("span")?.textContent?.replace("?", "").trim();
  const key = button.dataset.helpKey || "";
  const title = key === "xp-rank" ? "XP & Rank" : statTitle || button.closest(".panel, .chart-card, .assistant-panel")?.querySelector("h3, h4")?.textContent?.trim() || button.closest("label")?.textContent?.replace("?", "").trim() || "Help";
  const info = helpInfo(title + " " + key, text);
  el.helpPopover.innerHTML = "";
  const heading = document.createElement("strong");
  heading.textContent = info.title;
  const copy = document.createElement("p");
  copy.textContent = info.what + " " + info.why + " " + info.how;
  el.helpPopover.append(heading, copy);
  if (info.details?.length) {
    const list = document.createElement("ul");
    info.details.forEach((line) => {
      const item = document.createElement("li");
      item.textContent = line;
      list.append(item);
    });
    el.helpPopover.append(list);
  }
  if (info.example) {
    const example = document.createElement("p");
    example.className = "help-example";
    example.textContent = info.example;
    el.helpPopover.append(example);
  }
  const rect = button.getBoundingClientRect();
  el.helpPopover.style.left = Math.min(window.innerWidth - 300, Math.max(12, rect.left)) + "px";
  el.helpPopover.style.top = Math.min(window.innerHeight - 120, rect.bottom + 8) + "px";
  el.helpPopover.classList.remove("hidden");
}
function renderSettings() {
  if (!el.settingsForm) return;
  el.settingsFocusMinutesInput.value = state.settings.focusMinutesDefault || 50;
  if (el.studyProfileSelect) el.studyProfileSelect.value = state.profile?.studyProfile || "jee";
  el.themeModeSelect.value = state.settings.themeMode || "system";
  if (el.soundEnabledInput) el.soundEnabledInput.checked = Boolean(state.settings.soundEnabled);
  if (el.soundVolumeInput) el.soundVolumeInput.value = Number(state.settings.soundVolume || 35);
  if (el.soundVolumeLabel) el.soundVolumeLabel.textContent = Number(state.settings.soundVolume || 35) + "%";
  if (el.cameraAttentionEnabledInput) el.cameraAttentionEnabledInput.checked = Boolean(state.settings.cameraAttentionEnabled);
  if (el.cameraAttentionSensitivityInput) el.cameraAttentionSensitivityInput.value = state.settings.cameraAttentionSensitivity || "balanced";
  if (el.cameraAttentionGraceInput) el.cameraAttentionGraceInput.value = String(state.settings.cameraAttentionGraceSeconds || 10);
  if (el.cameraAttentionVoiceInput) el.cameraAttentionVoiceInput.checked = Boolean(state.settings.cameraAttentionVoice);
  renderCameraAttention();
}

function renderCourseSwitchModal() {
  if (!el.courseSwitchList) return;
  el.courseSwitchList.innerHTML = "";
  if (!state.courses.length) {
    el.courseSwitchList.innerHTML = "<div class='empty-state'><h4>No courses yet</h4><p>Add one educational link in the Courses tab first.</p></div>";
    return;
  }
  state.courses.forEach((course) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "course-switch-item" + (course.id === state.settings.defaultCourseId ? " active" : "");
    button.innerHTML = "<strong></strong><span></span>";
    button.querySelector("strong").textContent = course.title;
    button.querySelector("span").textContent = (course.subject || "Other") + " - " + (safeUrl(course.url)?.hostname.replace(/^www\./, "") || "study link");
    button.addEventListener("click", async () => {
      await updateSettings({ defaultCourseId: course.id });
      el.courseModal.classList.add("hidden");
      showToast("Course selected: " + course.title);
    });
    el.courseSwitchList.append(button);
  });
}

function openCourseSwitchModal() {
  renderCourseSwitchModal();
  el.courseModal.classList.remove("hidden");
}

function renderCompletion() {
  if (!el.completionModal) return;
  const summary = state.focusCompletion;
  el.completionModal.classList.toggle("hidden", !summary);
  if (!summary) return;
  el.completionSubject.textContent = summary.subject || "Study";
  el.completionDuration.textContent = formatDuration(summary.durationMinutes || 0);
  el.completionXp.textContent = "+" + (summary.xpEarned || sessionXp(summary.durationMinutes, true)) + " XP";
  el.completionToday.textContent = formatDuration(summary.todayTotalMinutes || completedMinutesToday());
  el.completionStreak.textContent = (summary.streak || state.analytics.streak?.current || 0) + " days";
}

function renderWelcomeBack() {
  if (!el.welcomeBackModal) return;
  const session = activeSession();
  const show = Boolean(session?.welcomeBack);
  el.welcomeBackModal.classList.toggle("hidden", !show);
  if (!show) return;
  const remaining = Math.max(1, Math.ceil(sessionRemainingMs(session) / 60000));
  el.welcomeBackTime.textContent = formatDuration(remaining);
}

async function clearWelcomeBack() {
  const session = activeSession();
  if (!session?.welcomeBack) return;
  await saveState({ ...state, focusSession: { ...session, welcomeBack: false } });
}

async function clearCompletion() {
  if (!state.focusCompletion) return;
  await saveState({ ...state, focusCompletion: null });
}

function renderOnboarding() {
  const profile = state.profile || {};
  const shouldShow = !profile.onboarded || Number(profile.onboardingVersion || 0) < ONBOARDING_VERSION;
  el.onboardingOverlay?.classList.toggle("hidden", !shouldShow);
  if (!shouldShow) return;
  el.onboardingOverlay?.classList.remove("fade-out");
  syncOnboardingControls();
  renderOnboardingProfileCards();
  renderOnboardingSummary();
  showOnboardingStep(onboardingStep);
}

function showOnboardingStep(step) {
  onboardingStep = ONBOARDING_STEPS.includes(step) ? step : "welcome";
  $$(".onboarding-step").forEach((item) => item.classList.toggle("active", item.dataset.step === onboardingStep));
  const stepIndex = Math.max(0, ONBOARDING_STEPS.indexOf(onboardingStep));
  if (el.onboardingProgressText) el.onboardingProgressText.textContent = "Step " + (stepIndex + 1) + " of " + ONBOARDING_STEPS.length;
  if (el.onboardingProgressFill) el.onboardingProgressFill.style.width = ((stepIndex + 1) / ONBOARDING_STEPS.length * 100) + "%";
  el.onboardingCard?.setAttribute("data-step", onboardingStep);
  el.onboardingCard?.classList.remove("step-animate");
  void el.onboardingCard?.offsetWidth;
  el.onboardingCard?.classList.add("step-animate");
}

function cleanOnboardingName() {
  return (el.onboardingNameInput?.value || state.profile?.name || "").trim().slice(0, 60);
}

function currentOnboardingProfileChoice() {
  if (onboardingProfileChoice && ONBOARDING_PROFILE_OPTIONS[onboardingProfileChoice]) return onboardingProfileChoice;
  const storedProfile = state.profile?.studyProfile || "jee";
  return Object.entries(ONBOARDING_PROFILE_OPTIONS).find(([, option]) => option.profileId === storedProfile)?.[0] || "jee";
}

function currentOnboardingProfileId() {
  return ONBOARDING_PROFILE_OPTIONS[currentOnboardingProfileChoice()]?.profileId || "jee";
}

function syncOnboardingControls() {
  if (el.onboardingNameInput && !el.onboardingNameInput.value) el.onboardingNameInput.value = state.profile?.name || "";
}

function renderOnboardingProfileCards() {
  const selected = currentOnboardingProfileChoice();
  $$(".onboarding-profile-option").forEach((card) => {
    const active = card.dataset.onboardingProfile === selected;
    card.classList.toggle("selected", active);
    card.setAttribute("aria-pressed", String(active));
  });
}

function selectOnboardingProfile(choice) {
  if (!ONBOARDING_PROFILE_OPTIONS[choice]) return;
  onboardingProfileChoice = choice;
  renderOnboardingProfileCards();
}

function renderOnboardingSummary() {
  const choice = ONBOARDING_PROFILE_OPTIONS[currentOnboardingProfileChoice()] || ONBOARDING_PROFILE_OPTIONS.jee;
  if (el.onboardingReadyProfile) el.onboardingReadyProfile.textContent = choice.name;
  if (el.onboardingReadyMessage) el.onboardingReadyMessage.textContent = "Your setup is saved locally. Add courses whenever you are ready.";
}

async function saveOnboardingProfile() {
  const studyProfile = currentOnboardingProfileId();
  await saveState({
    ...state,
    profile: {
      ...(state.profile || {}),
      name: cleanOnboardingName(),
      profileType: "local",
      email: "",
      studyProfile,
      startedAt: state.profile?.startedAt || Date.now(),
      lastProfileAt: Date.now()
    }
  });
  showOnboardingStep("protection");
}

async function saveOnboardingPreferences() {
  renderOnboardingSummary();
  showOnboardingStep("ready");
}

async function completeOnboarding(destination = "focus") {
  const cleanName = cleanOnboardingName();
  el.onboardingOverlay?.classList.add("fade-out");
  await saveState({ ...state, profile: { ...(state.profile || {}), onboarded: true, onboardingVersion: ONBOARDING_VERSION, name: cleanName, profileType: "local", email: "", startedAt: state.profile?.startedAt || Date.now(), lastProfileAt: Date.now() } });
  setTimeout(() => el.onboardingOverlay?.classList.add("hidden"), 220);
  setActiveTab(destination === "courses" ? "courses" : "focus");
  showToast(cleanName ? "Setup complete, " + cleanName + "." : "Setup complete.");
}

async function showWelcomeAgain() {
  onboardingStep = "welcome";
  onboardingProfileChoice = null;
  el.onboardingOverlay?.classList.remove("fade-out");
  await saveState({ ...state, profile: { ...(state.profile || {}), onboarded: false, onboardingVersion: 0 } });
}

function render() {
  renderClock();
  renderHeader();
  renderFocus();
  renderTodayInsight();
  renderCourses();
  renderShield();
  if ($("#tab-analytics")?.classList.contains("active")) renderAnalytics();
  renderMissions();
  renderMusic();
  renderSettings();
  renderCourseSwitchModal();
  renderCompletion();
  renderWelcomeBack();
  renderOnboarding();
}

function savedVideoCourse(rawUrl) { return state.courses.find((course) => courseHasVideo(course, rawUrl)) || null; }
function fillYouTubeAddSelects() {
  if (!pendingYouTubeVideo) return;
  const title = pendingYouTubeVideo.title || "YouTube video";
  el.youtubeAddVideoTitle.textContent = title;
  el.youtubeExistingTitleInput.value = title;
  el.youtubeNewTitleInput.value = title;
  el.youtubeExistingCourseSelect.innerHTML = "";
  state.courses.forEach((course) => {
    const option = document.createElement("option");
    option.value = course.id;
    option.textContent = course.title;
    el.youtubeExistingCourseSelect.append(option);
  });
  el.youtubeNewSubjectSelect.innerHTML = "";
  subjectsForProfile(state.profile?.studyProfile).forEach((subject) => {
    const option = document.createElement("option");
    option.value = subject;
    option.textContent = subject;
    el.youtubeNewSubjectSelect.append(option);
  });
  el.youtubeNewLibrarySelect.innerHTML = "";
  state.courseLibraries.forEach((library) => {
    const option = document.createElement("option");
    option.value = library.id;
    option.textContent = library.name;
    el.youtubeNewLibrarySelect.append(option);
  });
}
function setYouTubeAddMode(mode = "existing") {
  const useExisting = mode === "existing" && state.courses.length > 0;
  el.youtubeExistingModeBtn.classList.toggle("active", useExisting);
  el.youtubeNewModeBtn.classList.toggle("active", !useExisting);
  el.youtubeExistingForm.classList.toggle("hidden", !useExisting);
  el.youtubeNewForm.classList.toggle("hidden", useExisting);
}
function closeYouTubeAddModal() { pendingYouTubeVideo = null; el.youtubeAddModal?.classList.add("hidden"); }
function openYouTubeAddModal(rawUrl, rawTitle = "") {
  const url = canonicalYouTubeVideoUrl(rawUrl);
  if (!url) return showToast("That YouTube link is not a supported video URL.");
  const existing = savedVideoCourse(url);
  if (existing) return showToast("This video is already saved in " + existing.title + ".");
  pendingYouTubeVideo = { url, title: String(rawTitle || "").trim().slice(0, 180) || "YouTube video" };
  fillYouTubeAddSelects();
  setYouTubeAddMode(state.courses.length ? "existing" : "new");
  el.youtubeAddModal.classList.remove("hidden");
}
async function addVideoToExistingCourse(courseId, title) {
  const course = state.courses.find((item) => item.id === courseId);
  if (!course || !pendingYouTubeVideo) return;
  if (savedVideoCourse(pendingYouTubeVideo.url)) return showToast("This video is already in Studizen.");
  const video = { id: uid("video"), title: String(title || pendingYouTubeVideo.title).trim().slice(0, 180) || "YouTube video", url: pendingYouTubeVideo.url, addedAt: Date.now() };
  await saveState({ ...state, courses: state.courses.map((item) => item.id === course.id ? { ...item, videos: [...(item.videos || []), video] } : item) });
  closeYouTubeAddModal();
  showToast("Video added to " + course.title + ".");
}
async function removeCourseVideo(courseId, videoId) {
  await saveState({ ...state, courses: state.courses.map((course) => course.id === courseId ? { ...course, videos: (course.videos || []).filter((video) => video.id !== videoId) } : course) });
  showToast("Video removed.");
}
async function addCourse(title, rawUrl, subject = "Other", libraryId = el.courseLibraryInput?.value || state.courseLibraries[0]?.id || "library-main") {
  const url = validUrl(rawUrl);
  if (!url) { showToast("Paste a valid course link."); return false; }
  const duplicate = canonicalYouTubeVideoUrl(url) ? savedVideoCourse(url) : null;
  if (duplicate) { showToast("This video is already saved in " + duplicate.title + "."); return false; }
  const targetLibraryId = state.courseLibraries.some((library) => library.id === libraryId) ? libraryId : (state.courseLibraries[0]?.id || "library-main");
  const course = { id: uid("course"), title: String(title || "").trim() || inferTitle(url), subject: normalizeSubject(subject, state.profile?.studyProfile), libraryId: targetLibraryId, url: normalizeUrl(url), videos: [], createdAt: Date.now(), lastUsedAt: null };
  await saveState({ ...state, courses: [course, ...state.courses], settings: { ...state.settings, defaultCourseId: state.settings.defaultCourseId || course.id } });
  if (el.courseTitleInput) el.courseTitleInput.value = "";
  if (el.courseUrlInput) el.courseUrlInput.value = "";
  showToast("Course added.");
  return true;
}
async function deleteCourse(id) { const course = state.courses.find((c) => c.id === id); if (!course) return; if (state.focusSession?.active && state.focusSession.courseId === id) return showToast("Stop the active focus session before deleting this course."); if (!confirm("Delete course '" + course.title + "'?")) return; const previous = state; const courses = state.courses.filter((c) => c.id !== id); await saveState({ ...state, courses, settings: { ...state.settings, defaultCourseId: state.settings.defaultCourseId === id ? courses[0]?.id || null : state.settings.defaultCourseId } }); showUndo("Course deleted.", previous); }
async function createLibrary(event) { event.preventDefault(); const name = el.libraryNameInput.value.trim().slice(0, 48); if (!name) return showToast("Library name is required."); const library = { id: uid("library"), name, collapsed: false, createdAt: Date.now() }; await saveState({ ...state, courseLibraries: [...state.courseLibraries, library] }); el.libraryNameInput.value = ""; showToast("Library created."); }
async function renameLibrary(id) { const library = state.courseLibraries.find((item) => item.id === id); if (!library) return; const name = prompt("Rename library", library.name)?.trim().slice(0, 48); if (!name) return; await saveState({ ...state, courseLibraries: state.courseLibraries.map((item) => item.id === id ? { ...item, name } : item) }); showToast("Library renamed."); }
async function deleteLibrary(id) { const library = state.courseLibraries.find((item) => item.id === id); if (!library) return; if (state.courseLibraries.length <= 1) return showToast("Keep at least one course library."); const remaining = state.courseLibraries.filter((item) => item.id !== id); const fallbackId = remaining[0]?.id || "library-main"; if (!confirm("Delete library '" + library.name + "'? Courses move to " + (remaining.find((item) => item.id === fallbackId)?.name || "another library") + ".")) return; const previous = state; await saveState({ ...state, courseLibraries: remaining, courses: state.courses.map((course) => course.libraryId === id ? { ...course, libraryId: fallbackId } : course) }); showUndo("Library deleted.", previous); }
async function setLibraryCollapsed(id, collapsed) { if (!state.courseLibraries.some((library) => library.id === id && library.collapsed !== collapsed)) return; await saveState({ ...state, courseLibraries: state.courseLibraries.map((library) => library.id === id ? { ...library, collapsed } : library) }); }
async function moveCourseToLibrary(courseId, libraryId) { await saveState({ ...state, courses: state.courses.map((course) => course.id === courseId ? { ...course, libraryId } : course) }); showToast("Course moved."); }
async function openCourse(url = getActiveCourse(state)?.url) { if (!url) return showToast("No course link available."); if (hasChrome) await sendMessage({ type: "openCourse", url }); else window.open(url, "_blank", "noopener"); }
async function startFocus(courseId = getActiveCourse(state)?.id) {
  if (!courseId) { setActiveTab("courses"); return showToast("Add or select a course first."); }
  const durationMinutes = Math.max(5, Number(el.durationInput.value) || state.settings.focusMinutesDefault);
  if (hasChrome) {
    const result = await sendMessage({ type: "startFocus", payload: { courseId, durationMinutes } });
    if (!result?.ok) return showToast(result?.error || "Could not start focus.");
    state = mergeState(result.response);
    applyTheme();
    render();
  } else {
    const course = state.courses.find((c) => c.id === courseId);
    const session = { id: uid("session"), active: true, courseId, courseTitle: course.title, courseUrl: course.url, subject: course.subject || "Other", startedAt: Date.now(), endsAt: Date.now() + durationMinutes * 60000, durationMinutes, paused: false, pausedAt: null, remainingMs: durationMinutes * 60000, accumulatedPausedMs: 0, distractionsBlocked: 0 };
    await saveState({ ...state, settings: { ...state.settings, defaultCourseId: courseId, focusMinutesDefault: durationMinutes }, courses: state.courses.map((item) => item.id === courseId ? { ...item, lastUsedAt: Date.now() } : item), focusSession: session, focusCompletion: null });
    openCourse(course.url);
  }
  showToast("Focus started. Opening your course.");
}
async function pauseFocus() {
  const session = activeSession();
  if (!session || session.paused || focusActionPending) return;
  focusActionPending = true;
  renderFocus();
  if (hasChrome) {
    const result = await sendMessage({ type: "pauseFocus" });
    if (result?.ok) state = mergeState(result.response);
    else await loadState();
  } else {
    const remainingMs = sessionRemainingMs(session);
    await saveState({ ...state, focusSession: { ...session, paused: true, pausedAt: Date.now(), remainingMs, endsAt: Date.now() + remainingMs } });
  }
  focusActionPending = false;
  applyTheme();
  render();
  showToast("Focus paused. Redirect protection is off.");
}
async function resumeFocus() {
  const session = activeSession();
  if (!session?.paused || focusActionPending) return;
  const remainingMs = Math.max(0, Number(session.remainingMs) || sessionRemainingMs(session));
  focusActionPending = true;
  renderFocus();
  if (hasChrome) {
    const result = await sendMessage({ type: "resumeFocus" });
    if (result?.ok) state = mergeState(result.response);
    else await loadState();
  } else {
    await saveState({ ...state, focusSession: { ...session, paused: false, pausedAt: null, remainingMs, accumulatedPausedMs: (session.accumulatedPausedMs || 0) + Math.max(0, Date.now() - (session.pausedAt || Date.now())), endsAt: Date.now() + remainingMs } });
  }
  focusActionPending = false;
  applyTheme();
  render();
  showToast("Focus resumed. Redirect protection is active.");
}
async function stopFocus() {
  if (hasChrome) {
    const result = await sendMessage({ type: "stopFocus" });
    if (result?.ok) state = mergeState(result.response);
    applyTheme();
    render();
  } else {
    const session = state.focusSession;
    const elapsed = session ? focusElapsedMinutes(session) : 0;
    const completed = session ? !session.paused && sessionRemainingMs(session) <= 0 : false;
    await saveState({ ...state, focusSession: null, focusCompletion: completed ? { id: session.id, courseTitle: session.courseTitle, subject: session.subject || "Other", durationMinutes: elapsed, xpEarned: sessionXp(elapsed, completed), todayTotalMinutes: state.stats.focusMinutes + elapsed, streak: state.analytics.streak?.current || 1, completedAt: Date.now() } : state.focusCompletion, analytics: session ? recordFocusAnalytics(state.analytics, session, elapsed, completed) : state.analytics, stats: { ...state.stats, focusMinutes: state.stats.focusMinutes + elapsed, sessionsCompleted: state.stats.sessionsCompleted + (completed ? 1 : 0) } });
  }
  showToast("Focus stopped.");
}
async function updateTask(index, patch) { const tasks = state.daily.tasks.map((task, i) => i === index ? { ...task, ...patch } : task); await saveState({ ...state, daily: { ...state.daily, tasks } }); }
async function deleteTask(index) { const task = state.daily.tasks[index]; if (!task || !confirm("Delete personal goal '" + task.title + "'?")) return; const previous = state; const tasks = state.daily.tasks.filter((_, i) => i !== index); await saveState({ ...state, daily: { ...state.daily, tasks } }); showUndo("Personal goal deleted.", previous); }
async function editTask(index) {
  const task = state.daily.tasks[index];
  if (!task) return;
  const title = prompt("Personal goal title", task.title || "")?.trim();
  if (!title) return;
  const area = prompt("Area or subject", task.area || "Personal")?.trim() || "Personal";
  const minutes = Math.max(0, Number(prompt("Estimated minutes", task.minutes || 0)) || 0);
  const note = prompt("Short note", task.note || "")?.trim() || "";
  await updateTask(index, { title: title.slice(0, 90), area: area.slice(0, 40), minutes, note: note.slice(0, 140) });
  showToast("Personal goal updated.");
}
async function addMission(event) { event.preventDefault(); const title = el.missionTitleInput.value.trim(); if (!title) return showToast("Personal goal title is required."); const task = { id: uid("task"), title, area: el.missionAreaInput.value.trim() || "Personal", minutes: Number(el.missionMinutesInput.value) || 0, note: el.missionNoteInput.value.trim(), priority: "personal", done: false }; await saveState({ ...state, daily: { ...state.daily, tasks: [...state.daily.tasks, task] } }); el.missionForm.reset(); showToast("Personal goal added."); }
async function resetMissions() { if (!confirm("Clear all personal goals?")) return; const previous = state; await saveState({ ...state, daily: { ...state.daily, tasks: [] } }); showUndo("Personal goals cleared.", previous); }
async function requestCameraPermission() {
  if (!navigator.mediaDevices?.getUserMedia) return showToast("This Chrome installation cannot request camera access.");
  const button = el.cameraPermissionBtn;
  if (button) button.disabled = true;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: false, video: { facingMode: "user" } });
    stream.getTracks().forEach((track) => track.stop());
    if (hasChrome) {
      const result = await sendMessage({ type: "syncAttentionMonitor" });
      if (!result?.ok) throw new Error(result?.error || "Camera access was granted, but monitoring could not start.");
      state = ensureToday(mergeState(result.response));
      applyTheme();
      render();
    }
    showToast("Camera access granted. Camera Focus Check beta is ready.");
  } catch (error) {
    const denied = error?.name === "NotAllowedError" || error?.name === "SecurityError";
    showToast(denied ? "Camera access was blocked. Allow it in Chrome, then try again." : "No camera could be started. Check that it is connected and not in use.");
  } finally {
    if (button) button.disabled = false;
  }
}
async function saveCameraAttentionSettings() {
  const settingsPatch = {
    cameraAttentionEnabled: el.cameraAttentionEnabledInput?.checked ?? false,
    cameraAttentionSensitivity: el.cameraAttentionSensitivityInput?.value || "balanced",
    cameraAttentionGraceSeconds: Math.max(5, Math.min(30, Number(el.cameraAttentionGraceInput?.value) || 10)),
    cameraAttentionVoice: el.cameraAttentionVoiceInput?.checked ?? true
  };

  try {
    await updateSettings(settingsPatch);
    if (hasChrome) {
      const result = await sendMessage({ type: "syncAttentionMonitor" });
      if (!result?.ok) throw new Error(result?.error || "Camera Focus Check could not be updated.");
      state = ensureToday(mergeState(result.response));
      applyTheme();
      render();
    }
    showToast(settingsPatch.cameraAttentionEnabled ? "Camera Focus Check beta is ready for your next focus session." : "Camera Focus Check beta is off.");
  } catch (error) {
    showToast(error.message || "Camera Focus Check could not be updated.");
  }
}
async function saveSettings(event) {
  event.preventDefault();
  const focusMinutesDefault = Math.max(5, Math.min(240, Number(el.settingsFocusMinutesInput.value) || 50));
  const studyProfile = el.studyProfileSelect?.value || state.profile?.studyProfile || "jee";
  await saveState({
    ...state,
    settings: {
      ...state.settings,
      themeMode: el.themeModeSelect.value,
      focusMinutesDefault,
      soundEnabled: el.soundEnabledInput?.checked ?? true,
      soundVolume: Math.max(0, Math.min(100, Number(el.soundVolumeInput?.value) || 0)),
      cameraAttentionEnabled: el.cameraAttentionEnabledInput?.checked ?? false,
      cameraAttentionSensitivity: el.cameraAttentionSensitivityInput?.value || "balanced",
      cameraAttentionGraceSeconds: Math.max(5, Math.min(30, Number(el.cameraAttentionGraceInput?.value) || 10)),
      cameraAttentionVoice: el.cameraAttentionVoiceInput?.checked ?? true
    },
    profile: { ...(state.profile || {}), studyProfile }
  });
  if (hasChrome) {
    const result = await sendMessage({ type: "syncAttentionMonitor" });
    if (result?.ok) state = ensureToday(mergeState(result.response));
  }
  showToast("Settings saved.");
}
async function resetAnalyticsData() {
  if (!confirm("Reset analytics, streaks, XP history, and subject study hours?")) return;
  const previous = state;
  await saveState({ ...state, analytics: defaultState().analytics, stats: { ...state.stats, focusMinutes: 0, distractions: 0, sessionsCompleted: 0 } });
  showUndo("Analytics reset.", previous);
}
async function clearAllData() {
  if (!confirm("Clear all local Studizen data? This removes courses, goals, missions, analytics, and settings.")) return;
  const previous = state;
  await saveState(defaultState());
  showUndo("All data cleared.", previous);
}
function exportJson() { const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" }); const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "course-focus-pro-backup.json"; a.click(); URL.revokeObjectURL(a.href); el.backupStatus.textContent = "JSON backup exported."; }
async function restoreBackupFile(event) { const file = event.target.files?.[0]; if (!file) return; if (!confirm("Restore this backup and replace current local data?")) { event.target.value = ""; return; } const previous = state; try { const text = await file.text(); await saveState(mergeState(JSON.parse(text))); el.backupStatus.textContent = "Backup restored."; showUndo("Backup restored.", previous); showToast("Backup restored."); } catch { el.backupStatus.textContent = "Backup restore failed."; } finally { event.target.value = ""; } }

function bindEvents() {
  $$(".help-button").forEach((button) => {
    const label = button.dataset.helpKey === "xp-rank" ? "Help: XP and rank progression" : "Help: " + (button.dataset.help || "this feature");
    button.setAttribute("aria-label", label);
    button.setAttribute("title", "Learn more");
  });
  $$(".tab-button").forEach((button) => button.addEventListener("click", () => setActiveTab(button.dataset.tab)));
  if (el.sidebarMoreNav) {
    try { el.sidebarMoreNav.open = sessionStorage.getItem("courseFocusProSidebarMoreOpen") === "true"; } catch {}
    el.sidebarMoreNav.addEventListener("toggle", () => {
      try { sessionStorage.setItem("courseFocusProSidebarMoreOpen", String(el.sidebarMoreNav.open)); } catch {}
    });
  }
  setSiteControlExpanded(siteControlExpanded);
  el.analyticsCurrentBtn?.addEventListener("click", () => { analyticsHistoryPeriod = null; renderAnalytics(); });
  el.analyticsPreviousWeekBtn?.addEventListener("click", () => { analyticsHistoryPeriod = "previous-week"; renderAnalytics(); });
  el.analyticsPreviousMonthBtn?.addEventListener("click", () => { analyticsHistoryPeriod = "previous-month"; renderAnalytics(); });
  el.analyticsHistoryCloseBtn?.addEventListener("click", () => { analyticsHistoryPeriod = null; renderAnalytics(); });
  el.analyticsXpBtn?.addEventListener("click", () => { renderGamification(); setAnalyticsXpOpen(el.analyticsXpPopover?.classList.contains("hidden")); });
  el.analyticsXpCloseBtn?.addEventListener("click", () => setAnalyticsXpOpen(false, true));
  el.changeCourseBtn?.addEventListener("click", openCourseSwitchModal);
  el.focusOpenCourseBtn?.addEventListener("click", () => openCourse());
  el.courseModalClose?.addEventListener("click", () => el.courseModal.classList.add("hidden"));
  el.courseModal?.addEventListener("click", (event) => { if (event.target === el.courseModal) el.courseModal.classList.add("hidden"); });
  el.youtubeAddCloseBtn?.addEventListener("click", closeYouTubeAddModal);
  el.youtubeAddModal?.addEventListener("click", (event) => { if (event.target === el.youtubeAddModal) closeYouTubeAddModal(); });
  el.youtubeExistingModeBtn?.addEventListener("click", () => setYouTubeAddMode("existing"));
  el.youtubeNewModeBtn?.addEventListener("click", () => setYouTubeAddMode("new"));
  el.youtubeExistingForm?.addEventListener("submit", async (event) => { event.preventDefault(); await addVideoToExistingCourse(el.youtubeExistingCourseSelect.value, el.youtubeExistingTitleInput.value); });
  el.youtubeNewForm?.addEventListener("submit", async (event) => { event.preventDefault(); if (!pendingYouTubeVideo) return; const added = await addCourse(el.youtubeNewTitleInput.value, pendingYouTubeVideo.url, el.youtubeNewSubjectSelect.value, el.youtubeNewLibrarySelect.value); if (added) closeYouTubeAddModal(); });
  el.onboardingGetStartedBtn?.addEventListener("click", () => showOnboardingStep("profile"));
  el.onboardingNameInput?.addEventListener("input", () => el.onboardingNameInput.classList.remove("input-error"));
  el.onboardingProfileCards?.addEventListener("click", (event) => { const card = event.target.closest?.("[data-onboarding-profile]"); if (card) selectOnboardingProfile(card.dataset.onboardingProfile); });
  el.onboardingProfileNextBtn?.addEventListener("click", saveOnboardingProfile);
  el.onboardingProtectionNextBtn?.addEventListener("click", saveOnboardingPreferences);
  $$(".onboarding-back").forEach((button) => button.addEventListener("click", () => showOnboardingStep(button.dataset.onboardingBack)));
  el.showOnboardingBtn?.addEventListener("click", showWelcomeAgain);
  el.finishTutorialBtn?.addEventListener("click", () => completeOnboarding("focus"));
  el.onboardingAddCourseBtn?.addEventListener("click", () => completeOnboarding("courses"));
  el.completionStartBtn?.addEventListener("click", async () => { await clearCompletion(); await startFocus(); });
  el.completionBreakBtn?.addEventListener("click", clearCompletion);
  el.completionCloseBtn?.addEventListener("click", clearCompletion);
  el.completionModal?.addEventListener("click", (event) => { if (event.target === el.completionModal) clearCompletion(); });
  el.welcomeResumeBtn?.addEventListener("click", async () => { if (activeSession()?.paused) await resumeFocus(); await clearWelcomeBack(); });
  el.welcomeEndBtn?.addEventListener("click", async () => { await clearWelcomeBack(); await stopFocus(); });
  el.welcomeDismissBtn?.addEventListener("click", clearWelcomeBack);
  el.welcomeBackModal?.addEventListener("click", (event) => { if (event.target === el.welcomeBackModal) clearWelcomeBack(); });
  el.musicPlayBtn.addEventListener("click", () => music.source === "imported" && music.currentImportedId ? playImported(music.currentImportedId) : playMusic());
  el.musicPauseBtn.addEventListener("click", pauseMusic);
  el.musicPrevBtn.addEventListener("click", previousMusic);
  el.musicBackBtn.addEventListener("click", () => seekImportedMusic(-10));
  el.musicNextBtn.addEventListener("click", nextMusic);
  el.musicForwardBtn.addEventListener("click", () => seekImportedMusic(10));
  el.musicShuffleBtn.addEventListener("click", () => { music.shuffle = !music.shuffle; if (music.playing && music.shuffle) nextMusic(); else renderMusic(); showToast("Shuffle " + (music.shuffle ? "on" : "off") + "."); });
  el.musicImportInput.addEventListener("change", (event) => { importMusicFiles(event.target.files); event.target.value = ""; });
  el.musicVolumeInput.addEventListener("input", (event) => setMusicVolume(event.target.value));
  el.musicLoopInput.addEventListener("change", (event) => { music.loop = event.target.checked; if (music.audio) music.audio.loop = music.loop; if (music.playing && music.source === "built-in") { clearTimeout(music.endTimer); music.endTimer = null; if (!music.loop) music.endTimer = setTimeout(() => nextMusic(), 10 * 60 * 1000); } });
  el.musicSleepInput?.addEventListener("change", (event) => setMusicSleepTimer(event.target.value));
  el.musicCrossfadeInput?.addEventListener("change", (event) => { music.crossfade = event.target.checked; saveMusicLibrary(); });
  el.playlistCreateBtn?.addEventListener("click", createPlaylist);
  el.playlistSelect?.addEventListener("change", (event) => { music.activePlaylistId = event.target.value || null; saveMusicLibrary(); renderMusic(); });
  el.playlistAddCurrentBtn?.addEventListener("click", addCurrentToPlaylist);
  el.playlistPlayBtn?.addEventListener("click", playActivePlaylist);
  el.playlistDeleteBtn?.addEventListener("click", deleteActivePlaylist);
  el.musicFavoriteBtn?.addEventListener("click", toggleMusicFavorite);
  el.musicQueueBtn?.addEventListener("click", enqueueCurrentMusic);
  document.addEventListener("click", (event) => { const help = event.target.closest?.(".help-button"); if (help) { event.preventDefault(); event.stopPropagation(); showHelp(help); return; } if (!event.target.closest?.("#helpPopover")) el.helpPopover.classList.add("hidden"); if (!event.target.closest?.("#analyticsXpControl")) setAnalyticsXpOpen(false); });
  window.addEventListener("keydown", (event) => { if (event.key === "Escape") { el.helpPopover.classList.add("hidden"); setAnalyticsXpOpen(false, true); el.courseModal?.classList.add("hidden"); closeYouTubeAddModal(); if (!el.completionModal?.classList.contains("hidden")) clearCompletion(); if (!el.welcomeBackModal?.classList.contains("hidden")) clearWelcomeBack(); } });
  el.startForm.addEventListener("submit", (e) => { e.preventDefault(); startFocus(); });
  el.pauseFocusBtn?.addEventListener("click", pauseFocus);
  el.resumeFocusBtn?.addEventListener("click", resumeFocus);
  el.stopFocusBtn.addEventListener("click", stopFocus);
  el.durationInput.addEventListener("change", () => updateSettings({ focusMinutesDefault: Math.max(5, Number(el.durationInput.value) || 50) }));
  el.redirectEnabledInput.addEventListener("change", () => updateSettings({ redirectEnabled: el.redirectEnabledInput.checked }));
  el.courseForm.addEventListener("submit", (e) => { e.preventDefault(); addCourse(el.courseTitleInput.value, el.courseUrlInput.value, el.courseSubjectInput.value, el.courseLibraryInput.value); });
  el.libraryForm?.addEventListener("submit", createLibrary);
  el.studyLinkLibraryToggle?.addEventListener("click", () => setCourseLibraryExpanded(!courseLibraryExpanded));
  el.courseLibrarySearch?.addEventListener("input", (event) => { courseLibraryQuery = event.target.value || ""; courseLibraryLimit = 60; renderCourseLibraries(); });
  el.courseLibrarySource?.addEventListener("change", (event) => { courseLibrarySource = event.target.value || "all"; courseLibraryLimit = 60; renderCourseLibraries(); });
  el.courseLibrarySort?.addEventListener("change", (event) => { courseLibrarySort = event.target.value || "priority"; courseLibraryLimit = 60; renderCourseLibraries(); });
  el.noteForm?.addEventListener("submit", saveNote);
  el.noteNewBtn?.addEventListener("click", () => { clearNoteDraft(); selectedNoteId = null; setNoteEditor(null); });
  [el.noteCourseInput, el.noteTitleInput, el.noteBodyInput, el.noteChecklistInput, el.notePinnedInput].filter(Boolean).forEach((input) => input.addEventListener(input.type === "checkbox" || input.tagName === "SELECT" ? "change" : "input", () => { renderNoteCharacterCount(); queueNoteDraft(); }));
  el.noteSearchInput?.addEventListener("input", renderNotes);
  el.noteClearSearchBtn?.addEventListener("click", () => { el.noteSearchInput.value = ""; renderNotes(); });
  el.notesExportBtn?.addEventListener("click", exportNotes);
  el.notesImportBtn?.addEventListener("click", () => el.notesImportInput?.click());
  el.notesImportInput?.addEventListener("change", importNotes);
  el.flashcardForm?.addEventListener("submit", addFlashcard);
  el.allowedForm?.addEventListener("submit", (e) => { e.preventDefault(); const value = el.allowedInput.value.trim().toLowerCase(); if (!value) return; updateSettings({ allowedSites: cleanPatterns([...state.settings.allowedSites, value]) }); el.allowedInput.value = ""; });
  el.blockedForm?.addEventListener("submit", (e) => { e.preventDefault(); const value = el.blockedInput.value.trim().toLowerCase(); if (!value) return; updateSettings({ blockedSites: cleanPatterns([...state.settings.blockedSites, value]) }); el.blockedInput.value = ""; });
  el.distractionProtectionInput?.addEventListener("change", async () => { const enabled = el.distractionProtectionInput.checked; await updateSettings({ guardBlockedOutsideFocus: enabled }); showToast(enabled ? "Distraction Protection is on." : "Distraction Protection is off."); });
  el.addSupportingSiteBtn?.addEventListener("click", () => { el.allowedForm?.classList.toggle("hidden"); if (!el.allowedForm?.classList.contains("hidden")) el.allowedInput?.focus(); });
  el.addBlockedSiteBtn?.addEventListener("click", () => { el.blockedForm?.classList.toggle("hidden"); if (!el.blockedForm?.classList.contains("hidden")) el.blockedInput?.focus(); });
  el.siteControlToggle?.addEventListener("click", () => setSiteControlExpanded(!siteControlExpanded));
  el.allowedSearch?.addEventListener("input", (event) => { allowedSiteQuery = event.target.value || ""; renderShield(); });
  el.blockedSearch?.addEventListener("input", (event) => { blockedSiteQuery = event.target.value || ""; renderShield(); });
  el.courseHistoryToggle?.addEventListener("click", () => setCourseHistoryExpanded(!courseHistoryExpanded));
  el.courseHistorySearch?.addEventListener("input", (event) => { courseHistoryQuery = event.target.value || ""; renderCourseHistory(); });
  el.addCurrentSiteBtn?.addEventListener("click", addCurrentSupportingSite);
  el.missionForm.addEventListener("submit", addMission); el.resetTasksBtn.addEventListener("click", resetMissions);
  el.plannerForm?.addEventListener("submit", addPlannerItem);
  el.soundVolumeInput?.addEventListener("input", (event) => { el.soundVolumeLabel.textContent = event.target.value + "%"; }); [el.cameraAttentionEnabledInput, el.cameraAttentionSensitivityInput, el.cameraAttentionGraceInput, el.cameraAttentionVoiceInput].filter(Boolean).forEach((input) => input.addEventListener("change", saveCameraAttentionSettings)); el.cameraPermissionBtn?.addEventListener("click", requestCameraPermission); el.settingsForm.addEventListener("submit", saveSettings); el.resetAnalyticsBtn.addEventListener("click", resetAnalyticsData); el.clearAllDataBtn.addEventListener("click", clearAllData); el.exportJsonBtn.addEventListener("click", exportJson); el.restoreBackupBtn.addEventListener("click", () => el.restoreBackupInput.click()); el.restoreBackupInput.addEventListener("change", restoreBackupFile);
  el.undoBtn.addEventListener("click", async () => { if (!undoSnapshot) return; const snapshot = undoSnapshot; undoSnapshot = null; el.undoBar.classList.add("hidden"); await saveState(snapshot); showToast("Undo complete."); });
  systemThemeQuery?.addEventListener?.("change", () => { applyTheme(); renderAnalytics(); });
  if (hasChrome) chrome.storage.onChanged.addListener((changes, area) => { if (area !== "local") return; if (changes[STATE_KEY]?.newValue) { const previousReminderAt = state.attention?.lastEventAt || 0; state = ensureToday(mergeState(changes[STATE_KEY].newValue)); applyTheme(); render(); const reminderAt = state.attention?.lastEventAt || 0; if (reminderAt && reminderAt !== previousReminderAt && reminderAt !== lastSeenAttentionReminderAt) { lastSeenAttentionReminderAt = reminderAt; showToast(attentionReminderText(state.attention?.reason)); } } if (changes[MUSIC_COMMAND_KEY]?.newValue) handleMusicCommand(changes[MUSIC_COMMAND_KEY].newValue.action); });
}
function handleParams() {
  const params = new URLSearchParams(location.search);
  const section = params.get("section");
  const welcome = params.get("welcome");
  const youtubeAdd = params.get("youtubeAdd");
  if (welcome) showToast("Extension ready. Add your first course link.");
  if (section) { const map = { shield: "settings", mission: "daily", focus: "focus", advice: "focus", about: "about" }; setActiveTab(map[section] || section); }
  if (youtubeAdd === "1") {
    openYouTubeAddModal(params.get("youtubeUrl"), params.get("youtubeTitle"));
    history.replaceState(null, "", location.pathname + "?section=courses");
  } else if (youtubeAdd === "invalid") {
    showToast("Choose a YouTube video link or video page to add it.");
    history.replaceState(null, "", location.pathname + "?section=courses");
  }
}
async function refreshDailyStateIfNeeded() {
  const before = state.daily?.date + "|" + state.stats?.date;
  const next = ensureToday(state);
  const after = next.daily?.date + "|" + next.stats?.date;
  if (before !== after) await saveState(next);
}
fillSelects(); loadMusicLibrary(); bindEvents(); await loadState(); handleParams(); if (!focusQuoteShown && $("#tab-focus")?.classList.contains("active")) rotateFocusQuote(); setInterval(() => { renderFocusTick(); renderWelcomeBack(); }, 1000); setInterval(renderClock, 60000); setInterval(refreshDailyStateIfNeeded, 60000);
