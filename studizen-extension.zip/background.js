import {
  ALARMS,
  STATE_KEY,
  applyStatePatch,
  awardVerifiedRewards,
  attentionVoiceMessage,
  buildAssistantState,
  cleanPatterns,
  compactHost,
  canonicalYouTubeVideoUrl,
  courseMatchesUrl,
  defaultState,
  ensureToday,
  focusElapsedMinutes,
  getActiveCourse,
  isHttpUrl,
  isInternalUrl,
  mergeState,
  normalizeSubject,
  recordDistractionAnalytics,
  recordFocusAnalytics,
  recordProtectionEvent,
  sessionRemainingMs,
  sessionXp,
  shouldRedirectByDistractionProtection,
  shouldRedirectDuringFocus,
  uid
} from "./shared.js";
import { createAttentionNotificationController, isAttentionNotificationId } from "./attention-notifications.js";

const ICON_URL = chrome.runtime.getURL("icons/icon128.png");
const ATTENTION_DOCUMENT_PATH = "attention.html";
const LEGACY_WATER_ALARM = "water-reminder";
const ADD_TO_COURSE_CONTEXT_MENU_ID = "add-to-course-focus";
let courseContextMenuQueue = Promise.resolve();
const redirectCooldown = new Map();
const tabCheckCooldown = new Map();
let stateQueue = Promise.resolve();
let attentionDocumentPromise = null;
let attentionCommandToken = 0;

async function getState() {
  const data = await chrome.storage.local.get(STATE_KEY);
  const source = data[STATE_KEY] || defaultState();
  return ensureToday(mergeState(source));
}

function setState(updater) {
  const task = stateQueue.then(async () => {
    const current = await getState();
    const candidate = typeof updater === "function" ? updater(current) : updater;
    const next = awardVerifiedRewards(ensureToday(mergeState(candidate)));
    await chrome.storage.local.set({ [STATE_KEY]: next });
    await updateBadge(next);
    return next;
  });
  stateQueue = task.catch(() => {});
  return task;
}

async function updateBadge(state = null) {
  const current = state || await getState();
  if (current.focusSession?.active && sessionRemainingMs(current.focusSession) > 0) {
    await chrome.action.setBadgeText({ text: current.focusSession.paused ? "II" : "ON" });
    await chrome.action.setBadgeBackgroundColor({ color: current.focusSession.paused ? "#e59b23" : "#2478ff" });
    return;
  }
  await chrome.action.setBadgeText({ text: "" });
}

async function notify(idPrefix, title, message, buttons = []) {
  const id = idPrefix + ":" + Date.now();
  await chrome.notifications.create(id, {
    type: "basic",
    iconUrl: ICON_URL,
    title,
    message,
    priority: 2,
    requireInteraction: false,
    buttons: buttons.slice(0, 2).map((title) => ({ title }))
  });
  return id;
}

const attentionNotifications = createAttentionNotificationController({
  create: (id, options) => chrome.notifications.create(id, { ...options, iconUrl: ICON_URL }),
  getAll: () => chrome.notifications.getAll(),
  clear: (id) => chrome.notifications.clear(id),
  clearAlarm: () => chrome.alarms.clear(ALARMS.ATTENTION_DISMISS),
  createAlarm: (name, details) => chrome.alarms.create(name, details),
  alarmName: ALARMS.ATTENTION_DISMISS,
  uid
});
const clearAttentionNotification = () => attentionNotifications.clear();
const notifyAttention = (title, message, buttons = []) => attentionNotifications.show({ title, message, buttons });
const forgetClosedAttentionNotification = (id) => attentionNotifications.closed(id);

function attentionOptions(settings = {}) {
  return {
    sensitivity: settings.cameraAttentionSensitivity || "balanced",
    graceSeconds: Math.max(5, Math.min(30, Number(settings.cameraAttentionGraceSeconds) || 10))
  };
}

async function attentionDocumentExists() {
  if (!chrome.runtime.getContexts) return false;
  const documentUrl = chrome.runtime.getURL(ATTENTION_DOCUMENT_PATH);
  const contexts = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"], documentUrls: [documentUrl] });
  return contexts.length > 0;
}

async function ensureAttentionDocument() {
  if (!chrome.offscreen) throw new Error("Camera Focus Check requires a newer version of Chrome.");
  if (await attentionDocumentExists()) return;
  if (!attentionDocumentPromise) {
    attentionDocumentPromise = chrome.offscreen.createDocument({
      url: ATTENTION_DOCUMENT_PATH,
      reasons: ["USER_MEDIA"],
      justification: "Run the optional local-only camera attention check during an active focus session."
    }).finally(() => { attentionDocumentPromise = null; });
  }
  await attentionDocumentPromise;
}

async function closeAttentionDocument() {
  if (!chrome.offscreen || !(await attentionDocumentExists())) return;
  await chrome.offscreen.closeDocument();
}

async function sendAttentionCommand(command, payload = {}, status = "off", commandToken = ++attentionCommandToken) {
  try {
    await chrome.runtime.sendMessage({ type: "attentionMonitorCommand", command, payload, status, commandToken });
  } catch {}
}

async function startAttentionMonitor(session, state) {
  const current = state || await getState();
  if (!current.settings.cameraAttentionEnabled || !session?.active || session.paused) {
    await clearAttentionNotification();
    return setState((saved) => ({ ...saved, attention: { ...saved.attention, active: false, status: "off", reason: null, error: null } }));
  }
  try {
    const commandToken = ++attentionCommandToken;
    await ensureAttentionDocument();
    let accepted = false;
    const next = await setState((saved) => {
      const liveSession = saved.focusSession;
      if (!liveSession?.active || liveSession.id !== session.id || liveSession.paused || !saved.settings.cameraAttentionEnabled) return saved;
      accepted = true;
      return { ...saved, attention: { ...saved.attention, active: true, status: "starting", reason: null, error: null } };
    });
    if (!accepted) return next;
    await sendAttentionCommand("start", { sessionId: session.id, options: attentionOptions(next.settings) }, "off", commandToken);
    return next;
  } catch (error) {
    return setState((saved) => {
      if (!saved.focusSession?.active || saved.focusSession.id !== session.id) return saved;
      return { ...saved, attention: { ...saved.attention, active: false, status: "error", reason: null, error: error?.message || "Camera Focus Check could not start." } };
    });
  }
}

async function stopAttentionMonitor(status = "off") {
  const commandToken = ++attentionCommandToken;
  await clearAttentionNotification();
  await sendAttentionCommand("stop", {}, status, commandToken);
  await new Promise((resolve) => setTimeout(resolve, 40));
  const current = await getState();
  if (current.focusSession?.active && !current.focusSession.paused && sessionRemainingMs(current.focusSession) > 0) return current;
  await closeAttentionDocument().catch(() => {});
  return setState((saved) => {
    if (saved.focusSession?.active && !saved.focusSession.paused && sessionRemainingMs(saved.focusSession) > 0) return saved;
    return { ...saved, attention: { ...saved.attention, active: false, status, reason: null, error: null } };
  });
}

function attentionMessage(reason) {
  if (reason === "eyes closed") return "Your eyes have been closed for a while. Return to the lesson when ready.";
  if (reason === "eyes away from screen") return "Your gaze has been away from the lesson for a while. Bring your attention back.";
  return "You have been away from the course for a while. Take one breath and return to it.";
}

async function speakAttention(settings = {}, reason = "") {
  if (!settings.soundEnabled || !settings.cameraAttentionVoice || !chrome.tts) return;
  try {
    await Promise.resolve(chrome.tts.stop());
    await chrome.tts.speak(attentionVoiceMessage(reason), { enqueue: false, lang: "en-US", rate: 0.92, pitch: 1, volume: 0.9 });
  } catch {}
}

async function showAttentionOverlay(state, message) {
  const session = state.focusSession;
  const course = state.courses.find((item) => item.id === session?.courseId) || getActiveCourse(state);
  if (!course?.url || !chrome.scripting) return;
  const tabs = await chrome.tabs.query({});
  const tab = tabs.find((item) => item.active && courseMatchesUrl(course, item.url)) || tabs.find((item) => courseMatchesUrl(course, item.url));
  if (!tab?.id || !isHttpUrl(tab.url)) return;
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    args: [message, state.settings?.themeMode || "system"],
    func: (copy, themeMode) => {
      const id = "course-focus-pro-attention-reminder";
      document.getElementById(id)?.remove();
      const reminder = document.createElement("aside");
      reminder.id = id;
      reminder.setAttribute("role", "alert");
      reminder.setAttribute("aria-live", "assertive");
      reminder.setAttribute("aria-atomic", "true");
      reminder.dataset.theme = themeMode === "light" || themeMode === "beige" ? "light" : themeMode === "system" ? "system" : "dark";
      Object.assign(reminder.style, {
        position: "fixed", top: "clamp(14px, 4vw, 28px)", right: "clamp(14px, 4vw, 28px)", zIndex: "2147483647", width: "min(360px, calc(100vw - 28px))", boxSizing: "border-box", fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif"
      });
      const shadow = reminder.attachShadow({ mode: "open" });
      const style = document.createElement("style");
      style.textContent = `
        :host { color-scheme: light dark; }
        .card { --card: #111d30; --card-border: rgba(245, 185, 75, .5); --ink: #f7fbff; --muted: #b8c5d5; --accent: #f2b84b; display: flex; gap: 12px; align-items: flex-start; padding: 14px 16px; border: 1px solid var(--card-border); border-radius: 16px; background: linear-gradient(135deg, rgba(245, 185, 75, .14), transparent 52%), var(--card); color: var(--ink); box-shadow: 0 18px 45px rgba(0, 0, 0, .28), 0 4px 12px rgba(0, 0, 0, .16); opacity: 0; transform: translateY(-10px) scale(.98); animation: reminder-in .24s cubic-bezier(.2, .8, .2, 1) forwards; }
        .icon { flex: 0 0 32px; width: 32px; height: 32px; display: grid; place-items: center; border-radius: 10px; background: var(--accent); color: #182235; font: 900 19px/1 system-ui, sans-serif; box-shadow: 0 5px 14px rgba(245, 185, 75, .25); }
        .copy { min-width: 0; padding-top: 1px; }
        h2 { margin: 0; color: var(--ink); font: 800 14px/1.2 system-ui, sans-serif; letter-spacing: .01em; }
        p { margin: 5px 0 0; color: var(--muted); font: 600 13px/1.45 system-ui, sans-serif; overflow-wrap: anywhere; }
        .card.is-exiting { animation: reminder-out .22s ease-in forwards; }
        :host([data-theme="light"]) .card, :host([data-theme="system"]) .card { --card: #ffffff; --card-border: rgba(174, 119, 22, .42); --ink: #172238; --muted: #536176; --accent: #f3bd50; box-shadow: 0 16px 36px rgba(31, 46, 68, .18), 0 3px 10px rgba(31, 46, 68, .1); }
        @media (prefers-color-scheme: dark) { :host([data-theme="system"]) .card { --card: #111d30; --card-border: rgba(245, 185, 75, .5); --ink: #f7fbff; --muted: #b8c5d5; --accent: #f2b84b; box-shadow: 0 18px 45px rgba(0, 0, 0, .28), 0 4px 12px rgba(0, 0, 0, .16); } }
        @keyframes reminder-in { to { opacity: 1; transform: translateY(0) scale(1); } }
        @keyframes reminder-out { to { opacity: 0; transform: translateY(-8px) scale(.98); } }
        @media (prefers-reduced-motion: reduce) { .card { animation: none; opacity: 1; transform: none; } .card.is-exiting { animation: none; opacity: 0; } }
      `;
      const icon = document.createElement("span");
      icon.className = "icon";
      icon.setAttribute("aria-hidden", "true");
      icon.textContent = "!";
      const copyWrap = document.createElement("div");
      copyWrap.className = "copy";
      const heading = document.createElement("h2");
      heading.textContent = "Attention Needed";
      const text = document.createElement("p");
      text.textContent = copy;
      copyWrap.append(heading, text);
      const card = document.createElement("div");
      card.className = "card";
      card.append(icon, copyWrap);
      shadow.append(style, card);
      document.documentElement.append(reminder);
      window.setTimeout(() => {
        card.classList.add("is-exiting");
        window.setTimeout(() => reminder.remove(), 240);
      }, 3600);
    }
  }).catch(() => {});
}

async function receiveAttentionStatus(payload = {}) {
  const current = await getState();
  const session = current.focusSession;
  if (!session?.active || session.paused || (payload.sessionId && payload.sessionId !== session.id)) return current;
  const status = ["starting", "calibrating", "watching", "attention-lost", "needs-position", "permission-denied", "unsupported", "error"].includes(payload.status) ? payload.status : "error";
  const remind = Boolean(payload.shouldRemind && status === "attention-lost");
  let accepted = false;
  const next = await setState((saved) => {
    const liveSession = saved.focusSession;
    if (!liveSession?.active || liveSession.paused || (payload.sessionId && payload.sessionId !== liveSession.id)) return saved;
    accepted = true;
    const previous = saved.attention || {};
    const attention = {
      ...previous,
      active: !["permission-denied", "unsupported", "error"].includes(status),
      status,
      reason: payload.reason || null,
      error: payload.error || null,
      diagnostics: payload.diagnostics || previous.diagnostics || null,
      calibratedAt: payload.calibrated ? Date.now() : previous.calibratedAt,
      lastEventAt: remind ? Date.now() : previous.lastEventAt,
      distractionCount: previous.distractionCount + (remind ? 1 : 0)
    };
    return { ...saved, attention };
  });
  if (!accepted) return next;
  if (payload.attentionState === "ATTENTIVE") await clearAttentionNotification();
  if (remind) {
    await speakAttention(next.settings, payload.reason);
    const message = attentionMessage(payload.reason);
      await showAttentionOverlay(next, message);
    await notifyAttention("Attention", message, ["Dashboard"]);
  }
  return next;
}
async function clearNotifications(prefix) {
  const all = await chrome.notifications.getAll();
  await Promise.all(Object.keys(all).filter((id) => id.startsWith(prefix)).map((id) => chrome.notifications.clear(id)));
}

async function clearLegacyHydrationArtifacts() {
  await chrome.alarms.clear(LEGACY_WATER_ALARM);
  await clearNotifications("water");
}

function contextVideoUrl(info = {}) {
  if (info.linkUrl) return canonicalYouTubeVideoUrl(info.linkUrl);
  return canonicalYouTubeVideoUrl(info.pageUrl);
}

function contextVideoTitle(tab = null) {
  return String(tab?.title || "").replace(/\s*[-|]\s*YouTube\s*$/i, "").trim().slice(0, 180);
}

function registerCourseContextMenu() {
  const task = courseContextMenuQueue.then(async () => {
    await new Promise((resolve) => chrome.contextMenus.remove(ADD_TO_COURSE_CONTEXT_MENU_ID, () => {
      void chrome.runtime.lastError;
      resolve();
    }));
    await new Promise((resolve) => chrome.contextMenus.create({
      id: ADD_TO_COURSE_CONTEXT_MENU_ID,
      title: "Add to Studizen",
      contexts: ["page", "link", "video"],
      documentUrlPatterns: ["*://youtube.com/*", "*://*.youtube.com/*", "*://youtu.be/*"]
    }, () => {
      void chrome.runtime.lastError;
      resolve();
    }));
  });
  courseContextMenuQueue = task.catch(() => {});
  return task;
}

async function scheduleFocusEnd(session) {
  await chrome.alarms.clear(ALARMS.FOCUS_END);
  if (session?.active && !session.paused && sessionRemainingMs(session) > 0) await chrome.alarms.create(ALARMS.FOCUS_END, { when: session.endsAt });
}

async function startFocus(payload = {}) {
  let current = await getState();
  if (current.focusSession?.active) {
    if (sessionRemainingMs(current.focusSession) <= 0) {
      await stopFocus("complete");
      current = await getState();
    } else {
      return current;
    }
  }
  const course = current.courses.find((item) => item.id === payload.courseId) || getActiveCourse(current);
  if (!course) throw new Error("Add a course link before starting focus.");
  const duration = Math.max(5, Math.min(240, Number(payload.durationMinutes) || current.settings.focusMinutesDefault));
  const subject = normalizeSubject(course.subject || "Other");
  const session = {
    id: uid("session"),
    active: true,
    courseId: course.id,
    courseTitle: course.title,
    courseUrl: course.url,
    subject,
    startedAt: Date.now(),
    endsAt: Date.now() + duration * 60000,
    durationMinutes: duration,
    paused: false,
    pausedAt: null,
    remainingMs: duration * 60000,
    accumulatedPausedMs: 0,
    distractionsBlocked: 0,
    lastReminderAt: 0
  };
  let started = false;
  const next = await setState((state) => {
    if (state.focusSession?.active) return state;
    started = true;
    return {
      ...state,
      settings: { ...state.settings, defaultCourseId: course.id, focusMinutesDefault: duration },
      courses: state.courses.map((item) => item.id === course.id ? { ...item, subject, lastUsedAt: Date.now() } : item),
      focusSession: session,
      focusCompletion: null,
      attention: { ...state.attention, active: false, status: state.settings.cameraAttentionEnabled ? "starting" : "off", reason: null, error: null, distractionCount: 0, calibratedAt: null },
      assistant: buildAssistantState({ ...state, focusSession: session }, "steady")
    };
  });
  if (!started) return next;
  await scheduleFocusEnd(session);
  await startAttentionMonitor(session, next);
  await openCourse(course.url);
  await enforceRedirectRules();
  await notify("focus-start", "Focus started", "Studying " + course.title + ". Distracting tabs will redirect while the switch is on.", ["Open course", "Dashboard"]);
  return getState();
}

async function stopFocus(reason = "manual") {
  const current = await getState();
  const session = current.focusSession;
  if (!session?.active) return current;
  let committed = false;
  let completedResult = false;
  const next = await setState((state) => {
    const liveSession = state.focusSession;
    if (!liveSession?.active || liveSession.id !== session.id) return state;
    const remaining = sessionRemainingMs(liveSession);
    const completed = reason === "complete" || (!liveSession.paused && remaining <= 0);
    const elapsed = completed ? Math.max(1, Number(liveSession.durationMinutes) || focusElapsedMinutes(liveSession)) : focusElapsedMinutes(liveSession);
    const historyStatus = reason === "interrupted" ? "interrupted" : completed ? "completed" : "incomplete";
    const analytics = recordFocusAnalytics(state.analytics, liveSession, elapsed, completed, historyStatus);
    committed = true;
    completedResult = completed;
    return {
      ...state,
      focusSession: null,
      focusCompletion: completed ? {
        id: liveSession.id,
        courseTitle: liveSession.courseTitle,
        subject: liveSession.subject || "Other",
        durationMinutes: elapsed,
        xpEarned: sessionXp(elapsed, true),
        todayTotalMinutes: (state.stats.focusMinutes || 0) + elapsed,
        streak: analytics.streak?.current || 1,
        completedAt: Date.now()
      } : state.focusCompletion,
      analytics,
      stats: {
        ...state.stats,
        focusMinutes: state.stats.focusMinutes + elapsed,
        sessionsCompleted: state.stats.sessionsCompleted + (completed ? 1 : 0)
      },
      assistant: buildAssistantState({ ...state, focusSession: null }, "steady")
    };
  });
  if (!committed) return next;
  await chrome.alarms.clear(ALARMS.FOCUS_END);
  await stopAttentionMonitor("off");
  await clearNotifications("focus-start");
  if (completedResult) await notify("focus-complete", "Focus complete", "Session finished. Start the next block when you are ready.", ["Dashboard"]);
  return getState();
}

async function pauseFocus() {
  const current = await getState();
  const session = current.focusSession;
  if (!session?.active || session.paused) return current;
  let committed = false;
  const next = await setState((state) => {
    const liveSession = state.focusSession;
    if (!liveSession?.active || liveSession.id !== session.id || liveSession.paused) return state;
    const remainingMs = sessionRemainingMs(liveSession);
    committed = true;
    return { ...state, focusSession: { ...liveSession, paused: true, pausedAt: Date.now(), remainingMs, endsAt: Date.now() + remainingMs } };
  });
  if (!committed) return next;
  await chrome.alarms.clear(ALARMS.FOCUS_END);
  await stopAttentionMonitor("paused");
  return getState();
}

async function resumeFocus() {
  const current = await getState();
  const session = current.focusSession;
  if (!session?.active || !session.paused) return current;
  let committed = false;
  let resumed = null;
  const next = await setState((state) => {
    const liveSession = state.focusSession;
    if (!liveSession?.active || liveSession.id !== session.id || !liveSession.paused) return state;
    const remainingMs = Math.max(0, Number(liveSession.remainingMs) || 0);
    resumed = {
      ...liveSession,
      paused: false,
      pausedAt: null,
      remainingMs,
      accumulatedPausedMs: (liveSession.accumulatedPausedMs || 0) + Math.max(0, Date.now() - (liveSession.pausedAt || Date.now())),
      endsAt: Date.now() + remainingMs
    };
    committed = true;
    return { ...state, focusSession: resumed };
  });
  if (!committed) return next;
  await scheduleFocusEnd(resumed);
  await startAttentionMonitor(resumed, next);
  return getState();
}

async function openCourse(url) {
  if (isHttpUrl(url)) await chrome.tabs.create({ url, active: true });
}

async function openDashboard(params = {}) {
  const query = new URLSearchParams(params).toString();
  await chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html" + (query ? "?" + query : "")) });
}

function shouldRedirect(state, url) {
  if (!url || isInternalUrl(url) || !isHttpUrl(url)) return false;
  if (url.includes(chrome.runtime.getURL("redirect.html")) || url.includes(chrome.runtime.getURL("dashboard.html"))) return false;
  return shouldRedirectDuringFocus(state, url) || shouldRedirectByDistractionProtection(state, url);
}

async function recordDistraction(url, reason) {
  const now = Date.now();
  return setState((state) => {
    const session = state.focusSession?.active && !state.focusSession.paused ? { ...state.focusSession, distractionsBlocked: (state.focusSession.distractionsBlocked || 0) + 1, lastReminderAt: now } : state.focusSession;
    const protection = recordProtectionEvent(state.protection, "blockedAttempts", { at: now, type: "blocked", host: compactHost(url), reason });
    return {
      ...state,
      focusSession: session,
      stats: { ...state.stats, distractions: state.stats.distractions + 1 },
      analytics: recordDistractionAnalytics(state.analytics),
      protection,
      assistant: buildAssistantState({ ...state, protection, stats: { ...state.stats, distractions: state.stats.distractions + 1 } }, "repeatedDistractions")
    };
  });
}

async function redirectTab(tab, reason) {
  if (!tab?.id || !tab.url) return;
  const last = redirectCooldown.get(tab.id) || 0;
  if (Date.now() - last < 900) return;
  redirectCooldown.set(tab.id, Date.now());
  const state = await getState();
  if (!shouldRedirect(state, tab.url)) return;
  const session = state.focusSession;
  const course = session ? state.courses.find((item) => item.id === session.courseId) : getActiveCourse(state);
  await recordDistraction(tab.url, reason);
  const fallback = !course?.url;
  const params = new URLSearchParams({
    courseUrl: fallback ? chrome.runtime.getURL("dashboard.html?section=courses") : course.url,
    courseTitle: fallback ? "your Studizen dashboard" : course.title,
    source: compactHost(tab.url),
    reason,
    remainingSeconds: String(session?.paused ? 0 : Math.max(0, Math.ceil(sessionRemainingMs(session) / 1000))),
    fallback: fallback ? "1" : "0"
  });
  await chrome.tabs.update(tab.id, { url: chrome.runtime.getURL("redirect.html?" + params.toString()) });
}

async function checkTab(tab, reason = "tab-change") {
  if (!tab?.url) return;
  const previous = tabCheckCooldown.get(tab.id);
  if (previous?.url === tab.url && Date.now() - previous.at < 600) return;
  tabCheckCooldown.set(tab.id, { url: tab.url, at: Date.now() });
  let state = await getState();
  if (state.focusSession?.active && !state.focusSession.paused && sessionRemainingMs(state.focusSession) <= 0) {
    await stopFocus("complete");
    state = await getState();
  }
  if (shouldRedirect(state, tab.url)) await redirectTab(tab, reason);
}

async function enforceRedirectRules() {
  const tabs = await chrome.tabs.query({});
  await Promise.all(tabs.map((tab) => checkTab(tab, "redirect-rules").catch(() => {})));
}

chrome.runtime.onInstalled.addListener(async (details) => {
  await registerCourseContextMenu();
  await clearLegacyHydrationArtifacts();
  const state = await getState();
  await enforceRedirectRules();
  await updateBadge(state);
  if (details.reason === "install") await openDashboard({ welcome: "1" });
});
async function restoreSchedules(markWelcome = false) {
  await registerCourseContextMenu();
  await clearAttentionNotification();
  await clearLegacyHydrationArtifacts();
  let state = await getState();
  if (state.focusSession?.active && !state.focusSession.paused && sessionRemainingMs(state.focusSession) <= 0) state = await stopFocus("complete");
  if (markWelcome && state.focusSession?.active && sessionRemainingMs(state.focusSession) > 0) {
    state = await setState((current) => ({
      ...current,
      focusSession: { ...current.focusSession, welcomeBack: true, restoredAt: Date.now() }
    }));
  }
  await scheduleFocusEnd(state.focusSession);
  if (state.focusSession?.active && !state.focusSession.paused && sessionRemainingMs(state.focusSession) > 0) await startAttentionMonitor(state.focusSession, state);
  else if (state.attention?.active) await stopAttentionMonitor(state.focusSession?.paused ? "paused" : "off");
  await enforceRedirectRules();
  await updateBadge(state);
}
chrome.runtime.onStartup.addListener(() => restoreSchedules(true));
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === ALARMS.FOCUS_END) await stopFocus("complete");
  if (alarm.name === ALARMS.ATTENTION_DISMISS) await clearAttentionNotification();
});
chrome.notifications.onButtonClicked.addListener(async (id, index) => {
  if (id.startsWith("focus-start") && index === 0) {
    const course = getActiveCourse(await getState());
    if (course?.url) await openCourse(course.url);
  } else await openDashboard();
  await chrome.notifications.clear(id);
});
chrome.notifications.onClicked.addListener(async (id) => { await openDashboard(); await chrome.notifications.clear(id); });
chrome.notifications.onClosed.addListener((id) => {
  if (isAttentionNotificationId(id)) forgetClosedAttentionNotification(id).catch(() => {});
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" || changeInfo.url) {
    const url = changeInfo.url || tab?.url;
    checkTab({ ...tab, id: tabId, url }, "tab-updated").catch(() => {});
  }
});
chrome.tabs.onActivated.addListener(async ({ tabId }) => { try { await checkTab(await chrome.tabs.get(tabId), "tab-activated"); } catch {} });
chrome.tabs.onCreated.addListener((tab) => { if (tab?.url) checkTab(tab, "tab-created").catch(() => {}); });
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== ADD_TO_COURSE_CONTEXT_MENU_ID) return;
  const url = contextVideoUrl(info);
  openDashboard({ section: "courses", youtubeAdd: url ? "1" : "invalid", youtubeUrl: url, youtubeTitle: contextVideoTitle(tab) }).catch(() => {});
});

if (chrome.contextMenus.onShown) {
  chrome.contextMenus.onShown.addListener((info) => {
    chrome.contextMenus.update(ADD_TO_COURSE_CONTEXT_MENU_ID, { visible: Boolean(contextVideoUrl(info)) }, () => {
      void chrome.runtime.lastError;
      chrome.contextMenus.refresh();
    });
  });
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    const type = message?.type;
    if (type === "getState") return getState();
    if (type === "saveState") {
      const changedSettings = message.patch?.settings || {};
      const response = await setState((state) => applyStatePatch(state, message.patch || {}));
      if (["guardBlockedOutsideFocus", "blockedSites", "allowedSites"].some((key) => Object.hasOwn(changedSettings, key))) await enforceRedirectRules();
      return response;
    }
    if (type === "attentionMonitorStatus") return receiveAttentionStatus(message.payload || {});
    if (type === "syncAttentionMonitor") {
      const state = await getState();
      if (state.focusSession?.active && !state.focusSession.paused && sessionRemainingMs(state.focusSession) > 0) return startAttentionMonitor(state.focusSession, state);
      return stopAttentionMonitor(state.focusSession?.paused ? "paused" : "off");
    }
    if (type === "startFocus") return startFocus(message.payload || {});
    if (type === "pauseFocus") return pauseFocus();
    if (type === "resumeFocus") return resumeFocus();
    if (type === "stopFocus") return stopFocus("manual");
    if (type === "openCourse") { await openCourse(message.url); return getState(); }
    if (type === "openDashboard") { await openDashboard(message.params || {}); return getState(); }
    return getState();
  })().then((response) => sendResponse({ ok: true, response })).catch((error) => sendResponse({ ok: false, error: error.message }));
  return true;
});
restoreSchedules(false);
