(() => {
  const cacheKey = "courseFocusProThemeMode";
  const stateKey = "courseFocusProState";
  const themes = new Set(["light", "dark", "midnight", "amoled", "forest", "purple", "beige", "slate", "teal", "rose"]);
  const systemDark = () => globalThis.matchMedia?.("(prefers-color-scheme: dark)")?.matches;
  const resolve = (mode) => themes.has(mode) ? mode : (systemDark() ? "dark" : "light");
  const apply = (mode) => {
    const savedMode = themes.has(mode) || mode === "system" ? mode : "system";
    document.documentElement.dataset.theme = resolve(savedMode);
    document.documentElement.dataset.themeMode = savedMode;
  };

  let cachedMode = "";
  try { cachedMode = localStorage.getItem(cacheKey) || ""; } catch {}
  apply(cachedMode || "system");

  if (!cachedMode && globalThis.chrome?.storage?.local) {
    chrome.storage.local.get(stateKey).then((data) => {
      const mode = data?.[stateKey]?.settings?.themeMode;
      if (!themes.has(mode) && mode !== "system") return;
      try { localStorage.setItem(cacheKey, mode); } catch {}
      apply(mode);
    }).catch(() => {});
  }
})();
