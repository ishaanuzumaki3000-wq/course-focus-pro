import { FaceLandmarker, FilesetResolver } from "./vendor/mediapipe/tasks-vision/vision_bundle.mjs";
import { createAttentionEngine } from "./attention-core.js";

const video = document.querySelector("#attentionVideo");
const WASM_ROOT = chrome.runtime.getURL("vendor/mediapipe/tasks-vision/wasm");
const MODEL_PATH = chrome.runtime.getURL("vendor/mediapipe/models/face_landmarker.task");
const SAMPLE_INTERVAL_MS = 100;
const EYE_INDICES = {
  left: { outer: 33, inner: 133, upper: [159, 158], lower: [145, 153], iris: [468, 469, 470, 471, 472] },
  right: { outer: 263, inner: 362, upper: [386, 385], lower: [374, 380], iris: [473, 474, 475, 476, 477] }
};

let stream = null;
let landmarker = null;
let visionRuntimePromise = null;
let engine = null;
let running = false;
let monitorTimer = null;
let monitorStartedAt = 0;
let lastVideoTime = -1;
let lastPublished = "";
let activeSessionId = null;
let options = { sensitivity: "balanced", graceSeconds: 10 };
let inferenceBusy = false;
let inferenceWindowStartedAt = 0;
let inferenceCount = 0;
let inferenceFps = 0;
let lastInferenceLatencyMs = 0;
let lastCommandToken = 0;

function clamp(value, min = 0, max = 1) { return Math.max(min, Math.min(max, Number(value) || 0)); }
function point(landmarks, index) { const value = landmarks?.[index]; return value && Number.isFinite(value.x) && Number.isFinite(value.y) ? value : null; }
function distance(a, b) { return a && b ? Math.hypot(a.x - b.x, a.y - b.y) : 0; }
function averagePoint(points) {
  const valid = points.filter(Boolean);
  if (!valid.length) return null;
  return { x: valid.reduce((sum, item) => sum + item.x, 0) / valid.length, y: valid.reduce((sum, item) => sum + item.y, 0) / valid.length };
}

function publish(payload) {
  const key = [payload.status, payload.attentionState || "", payload.reason || "", Boolean(payload.shouldRemind), payload.progress || "", payload.error || ""].join("|");
  if (key === lastPublished && !payload.shouldRemind) return;
  lastPublished = key;
  chrome.runtime.sendMessage({ type: "attentionMonitorStatus", payload: { ...payload, sessionId: activeSessionId } }).catch(() => {});
}

function clearMonitorTimer() {
  if (monitorTimer) clearInterval(monitorTimer);
  monitorTimer = null;
}

function stopTracks() {
  stream?.getTracks().forEach((track) => track.stop());
  stream = null;
  video.srcObject = null;
}

function closeLandmarker() {
  try { landmarker?.close?.(); } catch {}
  landmarker = null;
}

async function getVisionRuntime() {
  if (!visionRuntimePromise) visionRuntimePromise = FilesetResolver.forVisionTasks(WASM_ROOT).catch((error) => {
    visionRuntimePromise = null;
    throw error;
  });
  return visionRuntimePromise;
}

async function createLandmarker() {
  const vision = await getVisionRuntime();
  const create = (delegate) => FaceLandmarker.createFromOptions(vision, {
    baseOptions: { modelAssetPath: MODEL_PATH, delegate },
    runningMode: "VIDEO",
    numFaces: 2,
    minFaceDetectionConfidence: 0.65,
    minFacePresenceConfidence: 0.65,
    minTrackingConfidence: 0.6,
    outputFaceBlendshapes: false,
    outputFacialTransformationMatrixes: false
  });
  try {
    return await create("GPU");
  } catch {
    return create("CPU");
  }
}

function faceQuality(landmarks) {
  const valid = (landmarks || []).filter((item) => Number.isFinite(item?.x) && Number.isFinite(item?.y));
  if (valid.length < 468) return 0;
  const xs = valid.map((item) => item.x);
  const ys = valid.map((item) => item.y);
  const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys);
  const width = maxX - minX, height = maxY - minY;
  const centerX = (minX + maxX) / 2, centerY = (minY + maxY) / 2;
  const size = clamp((Math.min(width, height) - 0.12) / 0.16);
  const centered = clamp(1 - Math.hypot(centerX - 0.5, centerY - 0.5) / 0.65);
  const completeness = clamp(valid.length / 478);
  return clamp(size * 0.55 + centered * 0.25 + completeness * 0.2);
}

function eyeMetrics(landmarks, indices) {
  const outer = point(landmarks, indices.outer);
  const inner = point(landmarks, indices.inner);
  const upper = averagePoint(indices.upper.map((index) => point(landmarks, index)));
  const lower = averagePoint(indices.lower.map((index) => point(landmarks, index)));
  const iris = averagePoint(indices.iris.map((index) => point(landmarks, index)));
  const width = distance(outer, inner);
  const eyeCenter = averagePoint([outer, inner]);
  if (!outer || !inner || !upper || !lower || !eyeCenter || width < 0.015) return { openness: 0, gaze: null, gazeQuality: 0 };
  const openness = distance(upper, lower) / width;
  if (!iris) return { openness, gaze: null, gazeQuality: 0 };
  return {
    openness,
    gaze: { x: (iris.x - eyeCenter.x) / width, y: (iris.y - eyeCenter.y) / width },
    gazeQuality: clamp((width - 0.025) / 0.06)
  };
}

function landmarkObservation(results) {
  const faces = Array.isArray(results?.faceLandmarks) ? results.faceLandmarks : [];
  if (faces.length !== 1) return { faceCount: faces.length, faceQuality: 0, landmarkQuality: 0 };
  const landmarks = faces[0];
  const quality = faceQuality(landmarks);
  const leftEye = eyeMetrics(landmarks, EYE_INDICES.left);
  const rightEye = eyeMetrics(landmarks, EYE_INDICES.right);
  const leftOuter = point(landmarks, EYE_INDICES.left.outer);
  const leftInner = point(landmarks, EYE_INDICES.left.inner);
  const rightOuter = point(landmarks, EYE_INDICES.right.outer);
  const rightInner = point(landmarks, EYE_INDICES.right.inner);
  const leftCenter = averagePoint([leftOuter, leftInner]);
  const rightCenter = averagePoint([rightOuter, rightInner]);
  const eyeCenter = averagePoint([leftCenter, rightCenter]);
  const nose = point(landmarks, 1);
  const leftCheek = point(landmarks, 234);
  const rightCheek = point(landmarks, 454);
  const interEye = distance(leftCenter, rightCenter);
  const headReady = Boolean(eyeCenter && nose && leftCenter && rightCenter && leftCheek && rightCheek && interEye >= 0.04);
  const cheekAsymmetry = headReady ? (distance(nose, rightCheek) - distance(nose, leftCheek)) / Math.max(0.001, distance(nose, rightCheek) + distance(nose, leftCheek)) : 0;
  const gazeReady = leftEye.gaze && rightEye.gaze && leftEye.gazeQuality >= 0.55 && rightEye.gazeQuality >= 0.55;
  return {
    faceCount: 1,
    faceQuality: quality,
    landmarkQuality: headReady ? quality : 0,
    headPose: headReady ? {
      yaw: (nose.x - eyeCenter.x) / interEye + cheekAsymmetry * 0.55,
      pitch: (nose.y - eyeCenter.y) / interEye,
      roll: Math.atan2(rightCenter.y - leftCenter.y, rightCenter.x - leftCenter.x) * 180 / Math.PI
    } : {},
    eyeOpen: {
      left: leftEye.openness,
      right: rightEye.openness,
      quality: quality
    },
    gaze: gazeReady ? {
      x: (leftEye.gaze.x + rightEye.gaze.x) / 2,
      y: (leftEye.gaze.y + rightEye.gaze.y) / 2,
      quality: Math.min(quality, leftEye.gazeQuality, rightEye.gazeQuality)
    } : { quality: 0 }
  };
}

async function failMonitor(error, fallback) {
  running = false;
  inferenceBusy = false;
  clearMonitorTimer();
  engine?.reset();
  engine = null;
  closeLandmarker();
  stopTracks();
  const denied = error?.name === "NotAllowedError" || error?.name === "SecurityError";
  publish({ status: denied ? "permission-denied" : "error", error: denied ? "Camera permission was not granted." : fallback });
}

function cameraDiagnostics(result, latencyMs, now) {
  inferenceCount += 1;
  const windowMs = Math.max(1, now - inferenceWindowStartedAt);
  if (windowMs >= 1000) {
    inferenceFps = Number((inferenceCount * 1000 / windowMs).toFixed(1));
    inferenceCount = 0;
    inferenceWindowStartedAt = now;
  }
  const diagnostics = {
    inferenceFps,
    inferenceLatencyMs: Number(latencyMs.toFixed(1)),
    detectionLatencyMs: Number(latencyMs.toFixed(1)),
    confidence: result.confidence,
    state: result.attentionState,
    evidenceScore: Number(result.metrics?.evidenceScore || 0),
    sampledAt: now
  };
  return diagnostics;
}

function sampleCamera() {
  if (!running || !landmarker || !engine || inferenceBusy) return;
  if (video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA || video.videoWidth <= 0 || video.videoHeight <= 0) {
    if (Date.now() - monitorStartedAt >= 7000) failMonitor(null, "Camera video did not become ready. Reconnect the camera and try again.");
    return;
  }
  if (video.currentTime === lastVideoTime) return;
  inferenceBusy = true;
  lastVideoTime = video.currentTime;
  const startedAt = performance.now();
  try {
    const results = landmarker.detectForVideo(video, startedAt);
    const result = engine.analyze(landmarkObservation(results), Date.now());
    lastInferenceLatencyMs = performance.now() - startedAt;
    const now = Date.now();
    publish({ ...result, diagnostics: cameraDiagnostics(result, lastInferenceLatencyMs, now), health: { ...result.health, inferenceFps, inferenceLatencyMs: lastInferenceLatencyMs, cameraActive: true } });
  } catch {
    failMonitor(null, "Camera Focus Check could not process the camera feed.");
  } finally {
    inferenceBusy = false;
  }
}

async function startMonitor(payload = {}) {
  await stopMonitor(false);
  activeSessionId = payload.sessionId || null;
  options = { ...options, ...(payload.options || {}) };
  if (!navigator.mediaDevices?.getUserMedia) {
    publish({ status: "unsupported", error: "This browser cannot access a camera from the extension." });
    return;
  }
  lastPublished = "";
  publish({ status: "starting" });
  try {
    landmarker = await createLandmarker();
    stream = await navigator.mediaDevices.getUserMedia({ audio: false, video: { facingMode: "user", width: { ideal: 640 }, height: { ideal: 480 }, frameRate: { ideal: 12, max: 15 } } });
    video.srcObject = stream;
    await video.play();
    engine = createAttentionEngine(options);
    running = true;
    monitorStartedAt = Date.now();
    lastVideoTime = -1;
    inferenceBusy = false;
    inferenceWindowStartedAt = Date.now();
    inferenceCount = 0;
    inferenceFps = 0;
    lastInferenceLatencyMs = 0;
    publish({ status: "calibrating", progress: 0 });
    sampleCamera();
    monitorTimer = setInterval(sampleCamera, SAMPLE_INTERVAL_MS);
  } catch (error) {
    await failMonitor(error, "The local face-landmark model could not start.");
  }
}

async function stopMonitor(publishStatus = true, status = "off") {
  running = false;
  inferenceBusy = false;
  clearMonitorTimer();
  engine?.reset();
  engine = null;
  closeLandmarker();
  stopTracks();
  lastVideoTime = -1;
  if (publishStatus) publish({ status });
}

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type !== "attentionMonitorCommand") return;
  const commandToken = Number(message.commandToken) || 0;
  if (commandToken && commandToken < lastCommandToken) return;
  if (commandToken) lastCommandToken = commandToken;
  if (message.command === "start") startMonitor(message.payload).catch(() => publish({ status: "error", error: "The camera monitor could not start." }));
  if (message.command === "stop") stopMonitor(true, message.status || "off").catch(() => {});
});

window.addEventListener("unload", () => { stopMonitor(false).catch(() => {}); });
