# Studizen

## Chrome Web Store Polish Build 1.8.68

Studizen is a Chrome extension for students who want a clean focus dashboard, saved course links, automatic study analytics, distraction redirects, daily goals, local study music, and subtle XP/rank progress.

## Current Interface

- Focus: timer, selected course, start/pause/resume/stop controls, daily stats, redirect toggle, and Today's Insight.
- Courses: continue learning, recently viewed, most studied, user-created course libraries, and a compact searchable Study Link Library for course links and saved YouTube videos.
- Analytics: readable bar charts, streaks, goal progress, focus history, XP, level, and rank.
- Daily Goals: automatic system goals for XP plus custom personal goals for organization.
- Music: built-in study sounds and local imported audio.
- Settings: Focus Mode Supporting Sites, always-on Distraction Protection, study profile, theme, focus defaults, sound controls, backups, reset tools, and About information.

## Notes

- Subject analytics are calculated from actual focused time, excluding pauses.
- Personal tasks do not give XP, so XP stays tied to verified study actions.
- Imported audio files stay local. Browser security may require re-importing files after a restart.
- During an active Focus Mode session, only the selected course, its saved study links, and the supporting sites in Settings are allowed. Other HTTP(S) pages redirect back to the course; pausing or stopping immediately restores normal browsing.
- On YouTube, right-click a video page, video, or video link and choose **Add to Studizen**. Add it to an existing course or create a course with the video as its starting link.
- Today's Insight uses your recorded focus history, study goal, course subjects, streak, and focus-protection activity. It remains stable during a refresh and changes when meaningful study data changes.

## Tests

Run `npm test` to execute the dependency-free Node test suite in `tests/core.test.mjs`.

## Optional Camera Focus Check (Beta)

Camera Focus Check is an opt-in beta feature. During an active focus session it calibrates from a few seconds of local webcam frames, then watches for sustained face, head, or eye-direction changes. Frames stay in memory, are never saved or uploaded, and the camera is released immediately when the session pauses, stops, or completes. It is an experimental attention cue, not face recognition or a claim about a student's thoughts.

## Install

1. Open Chrome.
2. Go to `chrome://extensions`.
3. Turn on Developer mode.
4. Click Load unpacked.
5. Select this folder.
6. Pin Studizen from the extensions menu.
