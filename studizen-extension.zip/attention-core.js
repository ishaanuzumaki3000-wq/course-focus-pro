const CALIBRATION_SAMPLES = 12;
const MIN_CALIBRATION_QUALITY = 0.72;
const RECOVERY_MS = 1500;
const MAX_EVIDENCE_DELTA_MS = 1000;

const PROFILES = {
  gentle: { alertConfidence: 0.9, minimumHoldMs: 12000, uncertainGraceMs: 1400, recoveryMs: 1800 },
  balanced: { alertConfidence: 0.84, minimumHoldMs: 8000, uncertainGraceMs: 1100, recoveryMs: 1400 },
  strict: { alertConfidence: 0.8, fixedHoldMs: 3500, faceHoldMs: 2500, eyeHoldMs: 3500, uncertainGraceMs: 900, recoveryMs: 1100 }
};

const STATES = Object.freeze({
  CALIBRATING: "CALIBRATING",
  ATTENTIVE: "ATTENTIVE",
  UNCERTAIN: "UNCERTAIN",
  LOOKING_AWAY: "LOOKING_AWAY",
  HEAD_AWAY: "HEAD_AWAY",
  EYES_CLOSED: "EYES_CLOSED",
  FACE_NOT_VISIBLE: "FACE_NOT_VISIBLE"
});

function clamp(value, min = 0, max = 1) { return Math.max(min, Math.min(max, Number(value) || 0)); }
function mean(values) { return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0; }
function median(values) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}
function mad(values, center = median(values)) { return median(values.map((value) => Math.abs(value - center))); }
function distance(a, b) { return Math.hypot((Number(a?.x) || 0) - (Number(b?.x) || 0), (Number(a?.y) || 0) - (Number(b?.y) || 0)); }
function angleDistance(a, b) { return Math.abs((Number(a) || 0) - (Number(b) || 0)); }

function normalizedObservation(input = {}) {
  const headPose = input.headPose || {};
  const eyeOpen = input.eyeOpen || {};
  const gaze = input.gaze || {};
  return {
    faceCount: Math.max(0, Math.floor(Number(input.faceCount) || 0)),
    faceQuality: clamp(input.faceQuality),
    landmarkQuality: clamp(input.landmarkQuality ?? input.faceQuality),
    headPose: {
      yaw: Number.isFinite(Number(headPose.yaw)) ? Number(headPose.yaw) : null,
      pitch: Number.isFinite(Number(headPose.pitch)) ? Number(headPose.pitch) : null,
      roll: Number.isFinite(Number(headPose.roll)) ? Number(headPose.roll) : null
    },
    eyeOpen: {
      left: Math.max(0, Number(eyeOpen.left) || 0),
      right: Math.max(0, Number(eyeOpen.right) || 0),
      quality: clamp(eyeOpen.quality ?? input.landmarkQuality ?? input.faceQuality)
    },
    gaze: {
      x: Number.isFinite(Number(gaze.x)) ? Number(gaze.x) : null,
      y: Number.isFinite(Number(gaze.y)) ? Number(gaze.y) : null,
      quality: clamp(gaze.quality)
    }
  };
}

function isUsableFace(observation) {
  return observation.faceCount === 1 && observation.faceQuality >= MIN_CALIBRATION_QUALITY && observation.landmarkQuality >= MIN_CALIBRATION_QUALITY;
}

function hasHeadPose(observation) {
  return observation.headPose.yaw !== null && observation.headPose.pitch !== null && observation.headPose.roll !== null;
}

function isCalibrationSample(observation) {
  return isUsableFace(observation)
    && hasHeadPose(observation)
    && observation.eyeOpen.left > 0.04
    && observation.eyeOpen.right > 0.04
    && observation.eyeOpen.quality >= MIN_CALIBRATION_QUALITY;
}

function buildBaseline(samples) {
  const values = (selector) => samples.map(selector);
  const yaw = values((sample) => sample.headPose.yaw);
  const pitch = values((sample) => sample.headPose.pitch);
  const roll = values((sample) => sample.headPose.roll);
  const leftEye = values((sample) => sample.eyeOpen.left);
  const rightEye = values((sample) => sample.eyeOpen.right);
  const gazeSamples = samples.filter((sample) => sample.gaze.x !== null && sample.gaze.y !== null && sample.gaze.quality >= MIN_CALIBRATION_QUALITY);
  const gazeX = gazeSamples.map((sample) => sample.gaze.x);
  const gazeY = gazeSamples.map((sample) => sample.gaze.y);
  return {
    headPose: { yaw: median(yaw), pitch: median(pitch), roll: median(roll) },
    headVariation: {
      yaw: Math.max(0.035, mad(yaw) * 4),
      pitch: Math.max(0.035, mad(pitch) * 4),
      roll: Math.max(5, mad(roll) * 4)
    },
    eyeOpen: { left: median(leftEye), right: median(rightEye) },
    gaze: { x: gazeX.length ? median(gazeX) : null, y: gazeY.length ? median(gazeY) : null },
    gazeVariation: gazeX.length ? Math.max(0.08, Math.hypot(mad(gazeX) * 4, mad(gazeY) * 4)) : null,
    quality: median(values((sample) => Math.min(sample.faceQuality, sample.landmarkQuality, sample.eyeOpen.quality, sample.gaze.quality)))
  };
}

function adaptBaseline(baseline, observation) {
  const alpha = 0.018;
  const adapt = (current, next) => current + (next - current) * alpha;
  baseline.headPose.yaw = adapt(baseline.headPose.yaw, observation.headPose.yaw);
  baseline.headPose.pitch = adapt(baseline.headPose.pitch, observation.headPose.pitch);
  baseline.headPose.roll = adapt(baseline.headPose.roll, observation.headPose.roll);
  baseline.eyeOpen.left = adapt(baseline.eyeOpen.left, observation.eyeOpen.left);
  baseline.eyeOpen.right = adapt(baseline.eyeOpen.right, observation.eyeOpen.right);
  if (observation.gaze.quality >= 0.8 && observation.gaze.x !== null && observation.gaze.y !== null) {
    baseline.gaze.x = baseline.gaze.x === null ? observation.gaze.x : adapt(baseline.gaze.x, observation.gaze.x);
    baseline.gaze.y = baseline.gaze.y === null ? observation.gaze.y : adapt(baseline.gaze.y, observation.gaze.y);
    baseline.gazeVariation ||= 0.08;
  }
}

function candidateFor(observation, baseline) {
  if (observation.faceCount > 1) return { state: STATES.UNCERTAIN, confidence: 0, reason: null, metrics: { multipleFaces: true } };
  if (observation.faceCount === 0) return { state: STATES.FACE_NOT_VISIBLE, confidence: 0.9, reason: "face not visible", metrics: { faceQuality: 0 } };
  if (!isUsableFace(observation) || !hasHeadPose(observation)) return { state: STATES.UNCERTAIN, confidence: 0, reason: null, metrics: { faceQuality: observation.faceQuality, landmarkQuality: observation.landmarkQuality } };

  const yawDelta = angleDistance(observation.headPose.yaw, baseline.headPose.yaw);
  const pitchDelta = angleDistance(observation.headPose.pitch, baseline.headPose.pitch);
  const rollDelta = angleDistance(observation.headPose.roll, baseline.headPose.roll);
  const headScore = Math.max(
    yawDelta / Math.max(0.16, baseline.headVariation.yaw * 3),
    pitchDelta / Math.max(0.14, baseline.headVariation.pitch * 3)
  );
  const headConfidence = clamp((headScore - 1) / 0.65) * Math.min(observation.faceQuality, observation.landmarkQuality);

  const leftRatio = observation.eyeOpen.left / Math.max(0.04, baseline.eyeOpen.left);
  const rightRatio = observation.eyeOpen.right / Math.max(0.04, baseline.eyeOpen.right);
  const blinkEvidence = clamp(Math.min(leftRatio, rightRatio) < 0.42 ? (0.42 - Math.min(leftRatio, rightRatio)) / 0.32 : 0);
  const eyeConfidence = blinkEvidence * Math.min(observation.eyeOpen.quality, observation.faceQuality);

  const frontalEnough = headScore < 0.75 && rollDelta < 20;
  const gazeAvailable = baseline.gaze.x !== null && baseline.gaze.y !== null && baseline.gazeVariation !== null && observation.gaze.x !== null && observation.gaze.y !== null;
  const gazeQuality = frontalEnough && gazeAvailable ? Math.min(observation.gaze.quality, observation.eyeOpen.quality, observation.faceQuality) : 0;
  const gazeDelta = gazeAvailable ? distance(observation.gaze, baseline.gaze) : 0;
  const gazeScore = gazeAvailable ? gazeDelta / Math.max(0.18, baseline.gazeVariation * 2.5) : 0;
  const gazeConfidence = gazeQuality >= 0.74 ? clamp((gazeScore - 1) / 0.7) * gazeQuality : 0;

  const metrics = {
    faceQuality: Number(observation.faceQuality.toFixed(2)),
    landmarkQuality: Number(observation.landmarkQuality.toFixed(2)),
    yaw: Number(observation.headPose.yaw.toFixed(3)),
    pitch: Number(observation.headPose.pitch.toFixed(3)),
    roll: Number(observation.headPose.roll.toFixed(1)),
    eyeOpenLeft: Number(observation.eyeOpen.left.toFixed(3)),
    eyeOpenRight: Number(observation.eyeOpen.right.toFixed(3)),
    gazeQuality: Number(gazeQuality.toFixed(2))
  };

  if (headConfidence >= 0.72) return { state: STATES.HEAD_AWAY, confidence: headConfidence, reason: "head turned away", metrics };
  if (eyeConfidence >= 0.72) return { state: STATES.EYES_CLOSED, confidence: eyeConfidence, reason: "eyes closed", metrics };
  if (gazeConfidence >= 0.78) return { state: STATES.LOOKING_AWAY, confidence: gazeConfidence, reason: "eyes away from screen", metrics };
  if (headConfidence > 0.2 || eyeConfidence > 0.2 || (gazeQuality > 0 && gazeConfidence > 0.2)) return { state: STATES.UNCERTAIN, confidence: 0, reason: null, metrics };
  return { state: STATES.ATTENTIVE, confidence: Math.min(observation.faceQuality, observation.landmarkQuality), reason: null, metrics };
}

function statusFor(state, alerted) {
  if (state === STATES.CALIBRATING) return "calibrating";
  if (state === STATES.UNCERTAIN) return "needs-position";
  return alerted ? "attention-lost" : "watching";
}

export function createAttentionEngine(options = {}) {
  const profile = PROFILES[options.sensitivity] || PROFILES.balanced;
  const graceMs = clamp(Number(options.graceSeconds) / 30, 5 / 30, 1) * 30000;
  let calibration = [];
  let baseline = null;
  let state = STATES.CALIBRATING;
  let candidate = null;
  let candidateStartedAt = 0;
  let candidateLastSeenAt = 0;
  let evidenceMs = 0;
  let attentiveStartedAt = 0;
  let alertedThisEpisode = false;
  let lastAnalyzeAt = 0;

  function reset() {
    calibration = [];
    baseline = null;
    state = STATES.CALIBRATING;
    candidate = null;
    candidateStartedAt = 0;
    candidateLastSeenAt = 0;
    evidenceMs = 0;
    attentiveStartedAt = 0;
    alertedThisEpisode = false;
    lastAnalyzeAt = 0;
  }

  function holdFor(signalState) {
    if (profile.fixedHoldMs) {
      if (signalState === STATES.FACE_NOT_VISIBLE) return Math.max(graceMs, profile.faceHoldMs || profile.fixedHoldMs);
      if (signalState === STATES.EYES_CLOSED) return Math.max(graceMs, profile.eyeHoldMs || profile.fixedHoldMs);
      return Math.max(graceMs, profile.fixedHoldMs);
    }
    return Math.max(graceMs, profile.minimumHoldMs);
  }

  function resetEvidence() {
    candidate = null;
    candidateStartedAt = 0;
    candidateLastSeenAt = 0;
    evidenceMs = 0;
  }

  function output({ observation, signal, now, calibrated = false, progress = null, alerted = false, shouldRemind = false }) {
    const evidenceHoldMs = holdFor(candidate || signal?.state);
    const metrics = {
      ...(signal?.metrics || { faceQuality: observation?.faceQuality || 0 }),
      evidenceScore: Number(clamp(evidenceMs / Math.max(1, evidenceHoldMs)).toFixed(2)),
      evidenceMs: Math.round(evidenceMs),
      evidenceState: candidate || null,
      candidateAgeMs: candidateStartedAt ? Math.max(0, now - candidateStartedAt) : 0
    };
    return {
      status: statusFor(state, alerted),
      attentionState: state,
      reason: signal?.reason || null,
      confidence: Number((signal?.confidence || 0).toFixed(2)),
      progress,
      calibrated,
      shouldRemind,
      metrics,
      health: { modelReady: true, cameraActive: true, timestamp: now }
    };
  }

  function analyze(input, now = Date.now()) {
    const observation = normalizedObservation(input);
    const deltaMs = lastAnalyzeAt ? Math.min(MAX_EVIDENCE_DELTA_MS, Math.max(0, now - lastAnalyzeAt)) : 0;
    lastAnalyzeAt = now;
    if (!baseline) {
      if (isCalibrationSample(observation)) calibration.push(observation);
      else calibration = calibration.slice(-2);
      const progress = Math.round((calibration.length / CALIBRATION_SAMPLES) * 100);
      if (calibration.length < CALIBRATION_SAMPLES) {
        state = STATES.CALIBRATING;
        return output({ observation, now, progress, signal: { confidence: 0, metrics: { faceQuality: observation.faceQuality, landmarkQuality: observation.landmarkQuality } } });
      }
      baseline = buildBaseline(calibration);
      calibration = [];
      state = STATES.ATTENTIVE;
      attentiveStartedAt = now;
      return output({ observation, now, progress: 100, calibrated: true, signal: { confidence: baseline.quality, metrics: { faceQuality: observation.faceQuality, landmarkQuality: observation.landmarkQuality } } });
    }

    const signal = candidateFor(observation, baseline);
    if (signal.state === STATES.ATTENTIVE) {
      if (!attentiveStartedAt) attentiveStartedAt = now;
      evidenceMs = Math.max(0, evidenceMs - deltaMs * (1000 / Math.max(1, profile.recoveryMs || RECOVERY_MS)));
      if (evidenceMs <= 0) resetEvidence();
      if (now - attentiveStartedAt >= (profile.recoveryMs || RECOVERY_MS)) {
        state = STATES.ATTENTIVE;
        resetEvidence();
        alertedThisEpisode = false;
        adaptBaseline(baseline, observation);
      }
      return output({ observation, signal, now });
    }

    attentiveStartedAt = 0;
    if (signal.state === STATES.UNCERTAIN) {
      if (candidate && now - candidateLastSeenAt > profile.uncertainGraceMs) evidenceMs = Math.max(0, evidenceMs - deltaMs * 0.75);
      else if (candidate) evidenceMs = Math.max(0, evidenceMs - deltaMs * 0.12);
      if (evidenceMs <= 0) resetEvidence();
      state = STATES.UNCERTAIN;
      return output({ observation, signal, now });
    }

    if (candidate !== signal.state) {
      candidate = signal.state;
      candidateStartedAt = now;
      candidateLastSeenAt = now;
      evidenceMs = 0;
    } else {
      candidateLastSeenAt = now;
      evidenceMs = Math.min(holdFor(signal.state), evidenceMs + deltaMs);
    }
    state = signal.state;
    const minimumHold = holdFor(signal.state);
    const alerted = evidenceMs >= minimumHold && signal.confidence >= profile.alertConfidence;
    const shouldRemind = alerted && !alertedThisEpisode;
    if (shouldRemind) alertedThisEpisode = true;
    return output({ observation, signal, now, alerted, shouldRemind });
  }

  return { analyze, reset, get calibrated() { return Boolean(baseline); }, get attentionState() { return state; } };
}
