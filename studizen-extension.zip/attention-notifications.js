export const ATTENTION_NOTIFICATION_TTL_MS = 5000;

export function isAttentionNotificationId(id = "") {
  const value = String(id || "");
  return value.startsWith("attention:") || value.startsWith("attention-");
}

export function createAttentionNotificationController({
  create,
  getAll,
  clear,
  clearAlarm,
  createAlarm,
  alarmName,
  uid,
  now = Date.now,
  setTimer = setTimeout,
  clearTimer = clearTimeout
}) {
  let activeId = null;
  let dismissTimer = null;
  let queue = Promise.resolve();

  function run(task) {
    const next = queue.then(task, task);
    queue = next.catch(() => {});
    return next;
  }

  async function clearNow() {
    if (dismissTimer !== null) clearTimer(dismissTimer);
    dismissTimer = null;
    activeId = null;
    await Promise.resolve(clearAlarm()).catch(() => {});
    const all = await Promise.resolve(getAll()).catch(() => ({}));
    await Promise.all(Object.keys(all || {}).filter(isAttentionNotificationId).map((id) => Promise.resolve(clear(id)).catch(() => false)));
  }

  function clearAttention() {
    return run(() => clearNow());
  }

  function showAttention({ title, message, buttons = [] }) {
    return run(async () => {
      await clearNow();
      const id = "attention:" + uid("reminder");
      await create(id, {
        type: "basic",
        title,
        message,
        priority: 2,
        requireInteraction: false,
        buttons: buttons.slice(0, 2).map((buttonTitle) => ({ title: buttonTitle }))
      });
      activeId = id;
      await Promise.resolve(createAlarm(alarmName, { when: now() + ATTENTION_NOTIFICATION_TTL_MS })).catch(() => {});
      dismissTimer = setTimer(() => { clearAttention().catch(() => {}); }, ATTENTION_NOTIFICATION_TTL_MS);
      return id;
    });
  }

  function notificationClosed(id) {
    return run(async () => {
      if (activeId !== id) return;
      if (dismissTimer !== null) clearTimer(dismissTimer);
      dismissTimer = null;
      activeId = null;
      await Promise.resolve(clearAlarm()).catch(() => {});
    });
  }

  return {
    clear: clearAttention,
    show: showAttention,
    closed: notificationClosed,
    isActive: () => Boolean(activeId),
    activeId: () => activeId,
    pendingTimer: () => dismissTimer
  };
}
