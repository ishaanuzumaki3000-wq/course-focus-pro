export const STATE_KEY = "courseFocusProState";
export const ALARMS = { FOCUS_END: "focus-end", ATTENTION_DISMISS: "attention-dismiss" };
export const STUDY_PROFILES = [
  { id: "jee", name: "JEE", subjects: ["Physics", "Chemistry", "Mathematics", "Other"] },
  { id: "neet", name: "NEET", subjects: ["Physics", "Chemistry", "Biology", "Other"] },
  { id: "upsc", name: "UPSC", subjects: ["General Studies", "CSAT", "Current Affairs", "Optional Subject", "History", "Geography", "Politics", "Economy", "Environment", "Science & Tech", "Ethics", "Essay", "Other"] },
  { id: "nda", name: "NDA", subjects: ["Mathematics", "English", "General Ability", "Physics", "Chemistry", "History", "Geography", "Current Affairs", "Other"] },
  { id: "coding-ai", name: "Coding & AI", subjects: ["Programming", "DSA", "Web Development", "Databases", "AI", "Machine Learning", "Projects", "Other"] },
  { id: "school", name: "School", subjects: ["Physics", "Chemistry", "Biology", "Mathematics", "English", "Social Science", "Computer Science", "Other"] },
  { id: "college", name: "College", subjects: ["Core Subject", "Mathematics", "Programming", "Lab Work", "Assignments", "Projects", "Research", "Other"] },
  { id: "accounting", name: "Accounting", subjects: ["Financial Accounting", "Cost Accounting", "Taxation", "Auditing", "Business Studies", "Economics", "Other"] },
  { id: "custom", name: "Self Learner", subjects: ["General", "Revision", "Practice", "Other"] }
];
export const DEFAULT_STUDY_PROFILE = "jee";
export const SUBJECTS = STUDY_PROFILES.find((profile) => profile.id === DEFAULT_STUDY_PROFILE).subjects;
const PROFILE_TARGET_SUGGESTIONS = {
  jee: { dailyMinutes: 120, weeklyMinutes: 600, subjectTargets: { Physics: 120, Chemistry: 120, Mathematics: 180 } },
  neet: { dailyMinutes: 120, weeklyMinutes: 720, subjectTargets: { Physics: 120, Chemistry: 120, Biology: 240 } },
  upsc: { dailyMinutes: 90, weeklyMinutes: 600, subjectTargets: { "General Studies": 240, CSAT: 120, "Current Affairs": 120, "Optional Subject": 120 } },
  school: { dailyMinutes: 60, weeklyMinutes: 300, subjectTargets: { Physics: 45, Chemistry: 45, Biology: 45, Mathematics: 60, English: 45, "Social Science": 45, "Computer Science": 45 } },
  college: { dailyMinutes: 90, weeklyMinutes: 420, subjectTargets: { "Core Subject": 120, Mathematics: 60, Programming: 90, "Lab Work": 60, Assignments: 60, Projects: 60, Research: 60 } },
  custom: { dailyMinutes: 60, weeklyMinutes: 300, subjectTargets: { General: 120, Revision: 90, Practice: 90 } },
  nda: { dailyMinutes: 90, weeklyMinutes: 420, subjectTargets: { Mathematics: 120, English: 60, "General Ability": 120, Physics: 60, Chemistry: 60 } },
  "coding-ai": { dailyMinutes: 60, weeklyMinutes: 360, subjectTargets: { Programming: 120, DSA: 90, "Web Development": 90, AI: 60 } },
  accounting: { dailyMinutes: 90, weeklyMinutes: 420, subjectTargets: { "Financial Accounting": 120, "Cost Accounting": 90, Taxation: 90, Auditing: 60 } }
};
const cleanStudySubject = (value) => String(value || "").trim().replace(/\s+/g, " ").slice(0, 48);
export function studyTargetSuggestions(profileId = DEFAULT_STUDY_PROFILE) {
  const id = normalizeStudyProfile(profileId);
  const suggestion = PROFILE_TARGET_SUGGESTIONS[id] || PROFILE_TARGET_SUGGESTIONS[DEFAULT_STUDY_PROFILE];
  return { profileId: id, dailyMinutes: suggestion.dailyMinutes, weeklyMinutes: suggestion.weeklyMinutes, subjectTargets: { ...suggestion.subjectTargets } };
}
export function normalizeStudyTargets(input = null, profileId = DEFAULT_STUDY_PROFILE) {
  if (!input || typeof input !== "object" || Array.isArray(input)) return null;
  const suggested = studyTargetSuggestions(input.profileId || profileId);
  const subjectTargets = {};
  Object.entries(input.subjectTargets || {}).slice(0, 80).forEach(([name, minutes]) => {
    const subject = cleanStudySubject(name);
    if (subject) subjectTargets[subject] = Math.max(0, Math.min(10080, num(minutes)));
  });
  const customSubjects = [...new Set((Array.isArray(input.customSubjects) ? input.customSubjects : [])
    .map(cleanStudySubject).filter(Boolean))].slice(0, 40);
  return {
    profileId: normalizeStudyProfile(input.profileId || profileId),
    weeklyMinutes: Math.max(0, Math.min(10080, num(input.weeklyMinutes, suggested.weeklyMinutes))),
    subjectTargets,
    customSubjects,
    sortBy: input.sortBy === "target" ? "target" : "actual"
  };
}
export function resolveStudyTargets(input = {}) {
  const profileId = normalizeStudyProfile(input.profile?.studyProfile || DEFAULT_STUDY_PROFILE);
  const suggested = studyTargetSuggestions(profileId);
  const stored = normalizeStudyTargets(input.goals?.analyticsTargets, profileId);
  const dailyHours = Math.max(0, num(input.goals?.studyHours, DEFAULT_STUDY_GOALS.studyHours));
  return {
    profileId,
    dailyMinutes: Math.round(dailyHours * 60),
    weeklyMinutes: stored ? stored.weeklyMinutes : suggested.weeklyMinutes,
    subjectTargets: { ...suggested.subjectTargets, ...(stored?.subjectTargets || {}) },
    customSubjects: stored?.customSubjects || [],
    sortBy: stored?.sortBy || "actual",
    isCustomized: Boolean(stored)
  };
}
export function studyTargetProgress(actualMinutes = 0, targetMinutes = 0) {
  const target = Math.max(0, num(targetMinutes));
  return target ? Math.round((Math.max(0, num(actualMinutes)) / target) * 100) : null;
}
export const DEFAULT_COURSE_LIBRARIES = [
  { id: "library-main", name: "My Library", collapsed: false }
];
const LEGACY_PROFILE_LIBRARY_IDS = new Set(["group-jee", "group-coding", "group-ai", "group-upsc", "group-school", "group-college", "group-custom"]);
export const DEFAULT_BLOCKED_SITES = ["instagram.com", "twitter.com", "x.com", "facebook.com", "youtube.com/shorts", "reddit.com", "netflix.com", "primevideo.com", "hotstar.com", "twitch.tv", "discord.com/app", "snapchat.com", "roblox.com", "poki.com", "crazygames.com", "miniclip.com", "steamcommunity.com", "store.steampowered.com"];
export const DEFAULT_ALLOWED_SITES = ["google.com/search", "classroom.google.com", "docs.google.com", "drive.google.com", "sheets.google.com", "slides.google.com", "wikipedia.org", "khanacademy.org", "stackoverflow.com", "github.com", "developer.mozilla.org", "leetcode.com", "geeksforgeeks.org"];
export const DEFAULT_SETTINGS = { themeMode: "dark", focusMinutesDefault: 50, defaultCourseId: null, redirectEnabled: true, redirectDuringFocus: true, guardBlockedOutsideFocus: true, incognitoProtection: false, reminderCooldownMinutes: 2, soundEnabled: true, soundVolume: 35, cameraAttentionEnabled: false, cameraAttentionSensitivity: "balanced", cameraAttentionGraceSeconds: 10, cameraAttentionVoice: true, blockedSites: DEFAULT_BLOCKED_SITES, allowedSites: DEFAULT_ALLOWED_SITES };
export const DEFAULT_STUDY_GOALS = { studyHours: 4, chapters: 2, questions: 60 };
export const DEFAULT_DAILY_TASKS = [];
export function attentionVoiceMessage(reason = "") {
  const normalized = String(reason || "").trim().toLowerCase();
  if (["head turned away", "head turned", "head away", "gaze away", "gaze away from screen"].includes(normalized)) return "Stay focused on the course.";
  if (["eyes away", "eyes away from screen"].includes(normalized)) return "Please pay attention to the course.";
  if (normalized === "face not visible") return "Please stay on the course.";
  if (normalized === "eyes closed") return "Please pay attention to the course.";
  return "Stay focused on the course.";
}
export const RANKS = [
  { minLevel: 120, name: "Legend" },
  { minLevel: 90, name: "Discipline Master" },
  { minLevel: 70, name: "Elite Scholar" },
  { minLevel: 50, name: "Focus Master" },
  { minLevel: 35, name: "Achiever" },
  { minLevel: 20, name: "Scholar" },
  { minLevel: 10, name: "Student" },
  { minLevel: 5, name: "Learner" },
  { minLevel: 1, name: "Beginner" }
];
const LEGACY_DEFAULT_TASK_TITLES = new Set(["revise yesterday's notes", "one jee concept block", "solve practice questions"]);
export const ASSISTANT_MESSAGES = { steady: "You only need one clean study block. Choose the course and begin before the mind starts bargaining.", repeatedDistractions: "Your attention is leaking. Choose one course, close the extra tabs, and protect the next ten minutes.", tabSwitching: "Too many tab switches. Keep one course tab, one notes tab, and let the rest wait.", blockedAttempts: "Blocked sites are repeating. Make the task smaller and return to the course now.", browsing: "Browsing is replacing studying. Pick a saved course and start one short focus block." };
export function todayKey(date = new Date()) { const tzOffset = date.getTimezoneOffset() * 60000; return new Date(date.getTime() - tzOffset).toISOString().slice(0, 10); }
export function uid(prefix = "id") { return prefix + "-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8); }
function num(value, fallback = 0) { const n = Number(value); return Number.isFinite(n) ? n : fallback; }
export function cleanPatterns(patterns = []) { return [...new Set((Array.isArray(patterns) ? patterns : []).map((p) => String(p || "").trim().toLowerCase()).filter(Boolean))]; }
export function normalizeUrl(raw = "") { const text = String(raw || "").trim(); if (!text) return ""; if (/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) return text; return "https://" + text; }
export function safeUrl(raw = "") { try { return new URL(normalizeUrl(raw)); } catch { return null; } }
export function isHttpUrl(raw = "") { const url = safeUrl(raw); return Boolean(url && ["http:", "https:"].includes(url.protocol)); }
export function isInternalUrl(raw = "") { return /^(chrome|chrome-extension|edge|about|devtools):/i.test(String(raw || "")); }
export function compactHost(raw = "") { const url = safeUrl(raw); return url ? url.hostname.replace(/^www\./, "") : String(raw || "").replace(/^https?:\/\//, "").split("/")[0]; }
export function patternMatchesUrl(pattern, rawUrl) { const clean = String(pattern || "").trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, ""); const url = safeUrl(rawUrl); if (!clean || !url) return false; const host = url.hostname.toLowerCase().replace(/^www\./, ""); const path = url.pathname.toLowerCase(); const hostAndPath = host + path; if (clean.includes("/")) return hostAndPath.includes(clean); return host === clean || host.endsWith("." + clean); }
export function isBlockedUrl(rawUrl, settings = DEFAULT_SETTINGS) { return cleanPatterns(settings.blockedSites || DEFAULT_BLOCKED_SITES).some((p) => patternMatchesUrl(p, rawUrl)); }
export function isAllowedSupportUrl(rawUrl, settings = DEFAULT_SETTINGS) { return cleanPatterns(settings.allowedSites || DEFAULT_ALLOWED_SITES).some((p) => patternMatchesUrl(p, rawUrl)); }
export function extractYouTube(raw = "") { const url = safeUrl(raw); if (!url) return { videoId: null, playlistId: null }; return { videoId: youtubeVideoId(raw), playlistId: url.searchParams.get("list") || null }; }
export function youtubeVideoId(raw = "") {
  const url = safeUrl(raw);
  if (!url) return null;
  const host = url.hostname.toLowerCase().replace(/^www\./, "");
  if (host === "youtu.be") return url.pathname.split("/").filter(Boolean)[0] || null;
  const youtubeHost = host === "youtube.com" || host.endsWith(".youtube.com")
    || host === "youtube-nocookie.com" || host.endsWith(".youtube-nocookie.com");
  if (!youtubeHost) return null;
  if (url.pathname === "/watch") return url.searchParams.get("v") || null;
  const match = url.pathname.match(/^\/(?:shorts|embed|live)\/([^/?#]+)/i);
  return match?.[1] || null;
}
export function canonicalYouTubeVideoUrl(raw = "") { const id = youtubeVideoId(raw); return id ? "https://www.youtube.com/watch?v=" + encodeURIComponent(id) : ""; }
export function safeYouTubeTitle(raw = "", fallback = "") {
  const title = String(raw || "").replace(/\s+/g, " ").trim().slice(0, 180);
  if (!title || /^youtube video$/i.test(title) || /^(?:\d{1,2}:)?\d{1,2}:\d{2}$/.test(title) || /^\d+\s*(?:s|sec|secs|second|seconds|min|mins|minute|minutes)$/i.test(title)) return fallback;
  return title;
}
export function isYouTubeVideoUrl(raw = "") { return Boolean(canonicalYouTubeVideoUrl(raw)); }
export function normalizeGuidedTourHandoff(input = null) {
  if (!input || typeof input !== "object") return null;
  const id = String(input.id || "").trim().slice(0, 96);
  const url = canonicalYouTubeVideoUrl(input.url || "");
  const sessionId = String(input.sessionId || "").trim().slice(0, 96);
  const createdAt = Math.floor(num(input.createdAt));
  if (!id || !url || createdAt <= 0) return null;
  return {
    id,
    url,
    title: safeYouTubeTitle(input.title, ""),
    step: Math.max(0, Math.min(50, Math.floor(num(input.step)))),
    tabId: Number.isInteger(Number(input.tabId)) && Number(input.tabId) > 0 ? Number(input.tabId) : null,
    createdAt,
    ...(sessionId ? { sessionId } : {})
  };
}
// Prefer the clicked link, then the clicked page, then its callback tab URL.
// A media source is considered only when it is itself a YouTube video URL.
export function contextMenuYouTubeUrl(info = {}, tabUrl = "") {
  const linkUrl = String(info?.linkUrl || "").trim();
  const linkedVideo = canonicalYouTubeVideoUrl(linkUrl);
  if (linkedVideo) return linkedVideo;
  const pageVideo = canonicalYouTubeVideoUrl(info?.pageUrl || "");
  if (pageVideo) return pageVideo;
  const callbackTabVideo = canonicalYouTubeVideoUrl(tabUrl);
  if (callbackTabVideo) return callbackTabVideo;
  return canonicalYouTubeVideoUrl(info?.srcUrl || "");
}
export function courseHasVideo(course, rawUrl = "") {
  const id = youtubeVideoId(rawUrl);
  if (!id || !course) return false;
  if (youtubeVideoId(course.url) === id) return true;
  return (Array.isArray(course.videos) ? course.videos : []).some((video) => youtubeVideoId(video?.url) === id);
}
export function courseMatchesUrl(course, rawUrl) { if (!course?.url || !rawUrl) return false; const courseUrl = safeUrl(course.url); const targetUrl = safeUrl(rawUrl); if (!courseUrl || !targetUrl) return false; const cYt = extractYouTube(course.url); const tYt = extractYouTube(rawUrl); if (cYt.playlistId && tYt.playlistId === cYt.playlistId) return true; if (cYt.videoId && tYt.videoId === cYt.videoId) return true; const cHost = courseUrl.hostname.replace(/^www\./, "").toLowerCase(); const tHost = targetUrl.hostname.replace(/^www\./, "").toLowerCase(); const cPath = courseUrl.pathname.replace(/\/$/, ""); const tPath = targetUrl.pathname.replace(/\/$/, ""); if (cHost !== tHost && !tHost.endsWith("." + cHost)) return false; return !cPath || cPath === "/" || tPath.startsWith(cPath); }
export function courseResourceMatchesUrl(course, rawUrl = "") {
  if (courseMatchesUrl(course, rawUrl)) return true;
  return (Array.isArray(course?.videos) ? course.videos : []).some((video) => courseMatchesUrl({ url: video?.url || video }, rawUrl));
}
export function isFocusAllowedUrl(input = {}, rawUrl = "") {
  const state = mergeState(input);
  const course = state.courses.find((item) => item.id === state.focusSession?.courseId)
    || state.courses.find((item) => item.id === state.settings.defaultCourseId)
    || state.courses[0];
  return courseResourceMatchesUrl(course, rawUrl) || isAllowedSupportUrl(rawUrl, state.settings);
}
export function isDistractionProtectionAllowedUrl(input = {}, rawUrl = "") {
  const state = mergeState(input);
  if (isAllowedSupportUrl(rawUrl, state.settings)) return true;
  return state.courses.some((course) => courseResourceMatchesUrl(course, rawUrl));
}
export function shouldRedirectByDistractionProtection(input = {}, rawUrl = "") {
  const state = mergeState(input);
  if (!isHttpUrl(rawUrl) || isInternalUrl(rawUrl) || !state.settings.guardBlockedOutsideFocus) return false;
  if (isDistractionProtectionAllowedUrl(state, rawUrl)) return false;
  return isBlockedUrl(rawUrl, state.settings);
}
export function shouldRedirectDuringFocus(input = {}, rawUrl = "", now = Date.now()) {
  const state = mergeState(input);
  const session = state.focusSession;
  if (!isHttpUrl(rawUrl) || isInternalUrl(rawUrl) || !session?.active || session.paused || sessionRemainingMs(session, now) <= 0) return false;
  if (!state.settings.redirectEnabled || !state.settings.redirectDuringFocus) return false;
  return !isFocusAllowedUrl(state, rawUrl);
}
export function shouldApplyProtectionToTab(settings = {}, isIncognito = false) {
  return !isIncognito || Boolean(settings?.incognitoProtection);
}
export function shouldPersistProtectionEvent(isIncognito = false) { return !Boolean(isIncognito); }
export function normalizeStudyProfile(profileId) { return STUDY_PROFILES.some((profile) => profile.id === profileId) ? profileId : DEFAULT_STUDY_PROFILE; }
export function subjectsForProfile(profileId = DEFAULT_STUDY_PROFILE) { return STUDY_PROFILES.find((profile) => profile.id === normalizeStudyProfile(profileId))?.subjects || SUBJECTS; }
export function normalizeSubject(subject, profileId = null, customSubjects = []) {
  const rawText = String(subject || "").trim();
  const text = rawText === "Polity" ? "Politics" : rawText;
  const profileSubjects = profileId ? subjectsForProfile(profileId) : [];
  const allSubjects = [...new Set(STUDY_PROFILES.flatMap((profile) => profile.subjects))];
  if (profileSubjects.includes(text) || allSubjects.includes(text) || (Array.isArray(customSubjects) && customSubjects.includes(text))) return text;
  if (!profileId && cleanStudySubject(text)) return cleanStudySubject(text);
  return profileSubjects.includes("Other") || !profileSubjects.length ? "Other" : profileSubjects[0];
}
export function emptySubjectTracking(profileId = null) { const subjects = profileId ? subjectsForProfile(profileId) : [...new Set(STUDY_PROFILES.flatMap((profile) => profile.subjects))]; return Object.fromEntries(subjects.map((s) => [s, { subject: s, studyMinutes: 0, sessions: 0, completion: 0 }])); }
export function defaultAnalytics() { return { daily: {}, focusHistory: [], streak: { current: 0, longest: 0, lastStudyDate: null } }; }
export function defaultAssistant() { return { mode: "steady", suggestion: ASSISTANT_MESSAGES.steady, nextTask: "Start your default course.", lastUpdatedAt: null }; }
export function defaultState() { return { version: 12, profile: { onboarded: false, onboardingVersion: 0, guidedTourStatus: "completed", guidedTourVersion: 0, guidedTourActive: false, guidedTourStep: 0, guidedTourTabId: null, guidedTourSessionId: null, guidedTourUpdatedAt: null, guidedTourHandoff: null, name: "", profileType: "local", email: "", studyProfile: DEFAULT_STUDY_PROFILE, startedAt: null, lastProfileAt: null }, settings: { ...DEFAULT_SETTINGS, blockedSites: [...DEFAULT_BLOCKED_SITES], allowedSites: [...DEFAULT_ALLOWED_SITES] }, courseLibraries: DEFAULT_COURSE_LIBRARIES.map((library) => ({ ...library })), courses: [], focusSession: null, focusCompletion: null, attention: { active: false, status: "off", reason: null, lastEventAt: null, distractionCount: 0, calibratedAt: null, error: null }, goals: { ...DEFAULT_STUDY_GOALS, analyticsTargets: null }, daily: { date: todayKey(), tasks: DEFAULT_DAILY_TASKS.map((t) => ({ ...t, done: false })) }, stats: { date: todayKey(), focusMinutes: 0, distractions: 0, sessionsCompleted: 0 }, analytics: defaultAnalytics(), rewards: { awardedGoalKeys: {}, entries: [] }, assistant: defaultAssistant(), protection: { tabSwitches: [], blockedAttempts: [], browsingEvents: [], lastAssistantNoticeAt: null }, backups: { lastExportedAt: null, lastRestoredAt: null, lastFormat: null } }; }
function normalizeSubjects(src = {}) {
  const base = emptySubjectTracking();
  Object.keys(src || {}).forEach((name) => {
    const subject = cleanStudySubject(name);
    if (subject && !base[subject]) base[subject] = { subject, studyMinutes: 0, sessions: 0, completion: 0 };
  });
  for (const s of Object.keys(base)) {
    const stored = s === "Politics" ? { ...(src.Polity || {}), ...(src.Politics || {}), studyMinutes: num(src.Polity?.studyMinutes) + num(src.Politics?.studyMinutes), sessions: num(src.Polity?.sessions) + num(src.Politics?.sessions), completion: Math.max(num(src.Polity?.completion), num(src.Politics?.completion)) } : (src[s] || {});
    base[s] = { ...base[s], ...stored, subject: s, studyMinutes: num(stored.studyMinutes), sessions: num(stored.sessions), completion: Math.max(0, Math.min(100, num(stored.completion))) };
  }
  return base;
}
function normalizeCourseLibraries(items = null) { const source = Array.isArray(items) && items.length ? items : DEFAULT_COURSE_LIBRARIES; const seen = new Set(); const libraries = source.map((library) => ({ id: String(library.id || uid("library")), name: String(library.name || "My Library").trim().slice(0, 48) || "My Library", collapsed: Boolean(library.collapsed), createdAt: num(library.createdAt, Date.now()) })).filter((library) => { if (seen.has(library.id)) return false; if (LEGACY_PROFILE_LIBRARY_IDS.has(library.id)) return false; seen.add(library.id); return true; }); return (libraries.length ? libraries : DEFAULT_COURSE_LIBRARIES.map((library) => ({ ...library, createdAt: Date.now() }))).slice(0, 60); }
function normalizeCourseVideos(items = []) {
  const seen = new Set();
  return (Array.isArray(items) ? items : []).map((video) => {
    const url = canonicalYouTubeVideoUrl(video?.url || video);
    const id = youtubeVideoId(url);
    if (!id || seen.has(id)) return null;
    seen.add(id);
    return { id: String(video?.id || uid("video")), title: String(video?.title || "YouTube video").trim().slice(0, 180) || "YouTube video", url, addedAt: num(video?.addedAt, Date.now()) };
  }).filter(Boolean).slice(0, 200);
}
function normalizeCourses(items = [], libraries = DEFAULT_COURSE_LIBRARIES, profileId = DEFAULT_STUDY_PROFILE, customSubjects = []) {
  const normalizedLibraries = normalizeCourseLibraries(libraries);
  const libraryIds = new Set(normalizedLibraries.map((library) => library.id));
  const fallbackLibraryId = normalizedLibraries[0]?.id || "library-main";
  const source = Array.isArray(items) ? items : [];
  const existingSubjects = source.map((course) => cleanStudySubject(course?.subject)).filter(Boolean);
  const acceptedSubjects = [...new Set([...(customSubjects || []), ...existingSubjects])];
  return source.map((c) => {
    const subject = normalizeSubject(c.subject, profileId, acceptedSubjects);
    const legacyGroupId = c.groupId && !LEGACY_PROFILE_LIBRARY_IDS.has(c.groupId) ? c.groupId : null;
    const libraryId = libraryIds.has(c.libraryId) ? c.libraryId : (libraryIds.has(legacyGroupId) ? legacyGroupId : fallbackLibraryId);
    const url = normalizeUrl(c.url || "");
    const primaryVideoId = youtubeVideoId(url);
    return { id: c.id || uid("course"), title: String(c.title || "Study course").trim(), subject, libraryId, url, videos: normalizeCourseVideos(c.videos).filter((video) => youtubeVideoId(video.url) !== primaryVideoId), createdAt: num(c.createdAt, Date.now()), lastUsedAt: c.lastUsedAt ? num(c.lastUsedAt) : null };
  }).filter((c) => isHttpUrl(c.url));
}
function normalizeTasks(items = DEFAULT_DAILY_TASKS) { return (Array.isArray(items) ? items : DEFAULT_DAILY_TASKS).filter((t) => !LEGACY_DEFAULT_TASK_TITLES.has(String(t?.title || "").trim().toLowerCase())).map((t) => ({ id: t.id || uid("task"), title: String(t.title || "Study task").trim(), area: String(t.area || "Personal"), minutes: Math.max(0, num(t.minutes)), note: String(t.note || ""), priority: "personal", done: Boolean(t.done) })); }
function normalizeEvents(events = []) { return (Array.isArray(events) ? events : []).map((e) => ({ at: num(e.at, Date.now()), type: String(e.type || "event"), host: String(e.host || ""), reason: String(e.reason || "") })).filter((e) => Date.now() - e.at < 24 * 60 * 60000).slice(-120); }
function normalizeFocusHistory(items = []) {
  const seen = new Set();
  return (Array.isArray(items) ? items : []).map((item) => {
    const id = String(item?.id || uid("session"));
    const plannedMinutes = Math.max(0, num(item?.plannedMinutes, num(item?.durationMinutes)));
    const actualMinutes = Math.max(0, num(item?.actualMinutes, num(item?.durationMinutes)));
    const status = ["completed", "incomplete", "interrupted"].includes(String(item?.status || "").toLowerCase())
      ? String(item.status).toLowerCase()
      : item?.interrupted ? "interrupted" : item?.completed ? "completed" : "incomplete";
    const completionPercent = Math.max(0, Math.min(100, num(item?.completionPercent, plannedMinutes ? (actualMinutes / plannedMinutes) * 100 : status === "completed" ? 100 : 0)));
    return {
      id,
      courseId: item?.courseId ? String(item.courseId) : null,
      courseTitle: String(item?.courseTitle || "Focus session"),
      subject: normalizeSubject(item?.subject),
      startedAt: num(item?.startedAt, Date.now()),
      endedAt: item?.endedAt ? num(item.endedAt) : null,
      recordedDate: /^\d{4}-\d{2}-\d{2}$/.test(String(item?.recordedDate || "")) ? item.recordedDate : todayKey(new Date(num(item?.endedAt || item?.startedAt, Date.now()))),
      actualTracked: item?.actualTracked !== undefined ? Boolean(item.actualTracked) : status === "completed",
      plannedMinutes,
      actualMinutes,
      durationMinutes: actualMinutes,
      completionPercent: Math.round(completionPercent),
      completed: status === "completed",
      status,
      xpEarned: Math.max(0, num(item?.xpEarned)),
      distractionsBlocked: Math.max(0, num(item?.distractionsBlocked))
    };
  }).filter((item) => {
    if (seen.has(item.id)) return false;
    seen.add(item.id);
    return Number.isFinite(item.startedAt) && item.startedAt > 0 && item.actualMinutes >= 0;
  }).slice(0, 2000);
}
function emptyAnalyticsDay() { return { studyMinutes: 0, verifiedStudyMinutes: 0, sessions: 0, completedSessions: 0, distractionsBlocked: 0, subjects: emptySubjectTracking() }; }
function analyticsDay(daily, date) {
  const item = { ...emptyAnalyticsDay(), ...(daily[date] || {}) };
  item.subjects = normalizeSubjects(item.subjects);
  daily[date] = item;
  return item;
}
function adjustSubjectStudy(subjects, subject, minuteChange = 0, sessionChange = 0) {
  const next = normalizeSubjects(subjects);
  const key = normalizeSubject(subject);
  const current = next[key] || { subject: key, studyMinutes: 0, sessions: 0, completion: 0 };
  next[key] = {
    ...current,
    studyMinutes: Math.max(0, num(current.studyMinutes) + num(minuteChange)),
    sessions: Math.max(0, num(current.sessions) + num(sessionChange))
  };
  return next;
}
function backfillActualFocusTime(analytics = {}) {
  const next = { ...defaultAnalytics(), ...(analytics || {}) };
  const daily = { ...(next.daily || {}) };
  const focusHistory = (next.focusHistory || []).map((entry) => ({ ...entry }));
  focusHistory.forEach((entry) => {
    if (entry.actualTracked) return;
    const date = entry.recordedDate || todayKey(new Date(num(entry.endedAt || entry.startedAt, Date.now())));
    const item = analyticsDay(daily, date);
    const minutes = Math.max(0, num(entry.actualMinutes, num(entry.durationMinutes)));
    item.studyMinutes += minutes;
    item.subjects = adjustSubjectStudy(item.subjects, entry.subject, minutes, entry.completed ? 1 : 0);
    entry.actualTracked = true;
  });
  return { ...next, daily, focusHistory };
}
function normalizeRewards(rewards = {}) {
  const cutoff = Date.now() - 365 * 24 * 60 * 60000;
  const entries = (Array.isArray(rewards.entries) ? rewards.entries : []).map((entry) => ({
    id: String(entry.id || uid("reward")),
    key: String(entry.key || entry.id || ""),
    type: String(entry.type || "goal"),
    label: String(entry.label || "Verified study progress"),
    xp: Math.max(0, num(entry.xp)),
    awardedAt: num(entry.awardedAt, Date.now())
  })).filter((entry) => entry.awardedAt >= cutoff).slice(-700);
  const awardedGoalKeys = Object.fromEntries(Object.entries(rewards.awardedGoalKeys || {}).filter(([key, value]) => key && num(value) >= cutoff));
  entries.forEach((entry) => { if (entry.key) awardedGoalKeys[entry.key] = entry.awardedAt; });
  return { awardedGoalKeys, entries };
}
function normalizeNotes(notes = []) {
  return (Array.isArray(notes) ? notes : []).map((note) => ({
    id: String(note.id || uid("note")),
    courseId: note.courseId ? String(note.courseId) : null,
    title: String(note.title || "Untitled note").trim().slice(0, 120) || "Untitled note",
    body: String(note.body || "").slice(0, 50000),
    checklist: (Array.isArray(note.checklist) ? note.checklist : []).map((item) => ({ id: String(item.id || uid("check")), text: String(item.text || "").trim().slice(0, 180), done: Boolean(item.done) })).filter((item) => item.text).slice(0, 80),
    pinned: Boolean(note.pinned),
    createdAt: num(note.createdAt, Date.now()),
    updatedAt: num(note.updatedAt, Date.now())
  })).slice(0, 300);
}
function normalizeFlashcards(cards = []) {
  return (Array.isArray(cards) ? cards : []).map((card) => ({
    id: String(card.id || uid("card")),
    courseId: card.courseId ? String(card.courseId) : null,
    category: String(card.category || "General").trim().slice(0, 50) || "General",
    front: String(card.front || "").trim().slice(0, 600),
    back: String(card.back || "").trim().slice(0, 1200),
    reviews: Math.max(0, num(card.reviews)),
    lastReviewedAt: card.lastReviewedAt ? num(card.lastReviewedAt) : null,
    createdAt: num(card.createdAt, Date.now())
  })).filter((card) => card.front && card.back).slice(0, 800);
}
function normalizePlanner(items = []) {
  return (Array.isArray(items) ? items : []).map((item) => ({
    id: String(item.id || uid("plan")),
    title: String(item.title || "Study plan").trim().slice(0, 120) || "Study plan",
    date: /^\d{4}-\d{2}-\d{2}$/.test(String(item.date || "")) ? String(item.date) : todayKey(),
    kind: ["daily", "weekly", "monthly", "revision"].includes(item.kind) ? item.kind : "daily",
    courseId: item.courseId ? String(item.courseId) : null,
    minutes: Math.max(0, Math.min(720, num(item.minutes))),
    done: Boolean(item.done),
    createdAt: num(item.createdAt, Date.now())
  })).slice(0, 500);
}
const STATE_PATCH_DELETE = "__courseFocusDelete";
function isStateRecord(value) { return Boolean(value) && typeof value === "object" && !Array.isArray(value); }
function cloneStateValue(value) { if (Array.isArray(value)) return value.map(cloneStateValue); if (isStateRecord(value)) return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, cloneStateValue(item)])); return value; }
function isDeletePatch(value) { return isStateRecord(value) && value[STATE_PATCH_DELETE] === true && Object.keys(value).length === 1; }
function diffStateValue(before, after) {
  if (Object.is(before, after)) return undefined;
  if (Array.isArray(before) && Array.isArray(after)) {
    if (before.length === after.length && before.every((item, index) => diffStateValue(item, after[index]) === undefined)) return undefined;
    return cloneStateValue(after);
  }
  if (isStateRecord(before) && isStateRecord(after)) {
    const patch = {};
    new Set([...Object.keys(before), ...Object.keys(after)]).forEach((key) => {
      if (!Object.prototype.hasOwnProperty.call(after, key)) patch[key] = { [STATE_PATCH_DELETE]: true };
      else {
        const change = diffStateValue(before[key], after[key]);
        if (change !== undefined) patch[key] = change;
      }
    });
    return Object.keys(patch).length ? patch : undefined;
  }
  return cloneStateValue(after);
}
function applyStatePatchValue(current, patch) {
  if (isDeletePatch(patch)) return undefined;
  if (Array.isArray(patch)) return cloneStateValue(patch);
  if (!isStateRecord(patch)) return patch;
  const next = isStateRecord(current) ? cloneStateValue(current) : {};
  Object.entries(patch).forEach(([key, change]) => {
    if (isDeletePatch(change)) delete next[key];
    else next[key] = isStateRecord(change) && isStateRecord(current?.[key]) ? applyStatePatchValue(current[key], change) : cloneStateValue(change);
  });
  return next;
}
export function createStatePatch(previous = {}, next = {}) { return diffStateValue(previous, next) || {}; }
export function applyStatePatch(current = {}, patch = {}) { return isStateRecord(patch) ? applyStatePatchValue(current, patch) : cloneStateValue(current); }
export function mergeState(input = {}) {
  const base = defaultState();
  const src = input && typeof input === "object" ? input : {};
  const settings = { ...base.settings, ...(src.settings || {}) };
  if (!["system", "light", "dark", "midnight", "amoled", "beige"].includes(settings.themeMode)) settings.themeMode = "dark";
  // Defaults seed a new profile once. A user can subsequently remove every item.
  settings.blockedSites = Array.isArray(src.settings?.blockedSites) ? cleanPatterns(src.settings.blockedSites) : [...DEFAULT_BLOCKED_SITES];
  settings.allowedSites = Array.isArray(src.settings?.allowedSites) ? cleanPatterns(src.settings.allowedSites) : [...DEFAULT_ALLOWED_SITES];
  settings.redirectEnabled = src.settings?.redirectEnabled !== undefined ? Boolean(src.settings.redirectEnabled) : (src.settings?.guardAllTabsDuringFocus !== undefined ? Boolean(src.settings.guardAllTabsDuringFocus) : Boolean(settings.redirectEnabled));
  settings.redirectDuringFocus = src.settings?.redirectDuringFocus !== undefined ? Boolean(src.settings.redirectDuringFocus) : true;
  settings.guardBlockedOutsideFocus = src.settings?.guardBlockedOutsideFocus !== undefined ? Boolean(src.settings.guardBlockedOutsideFocus) : (src.settings?.alwaysGuardBlockedSites !== undefined ? Boolean(src.settings.alwaysGuardBlockedSites) : true);
  settings.incognitoProtection = src.settings?.incognitoProtection !== undefined ? Boolean(src.settings.incognitoProtection) : false;
  settings.soundEnabled = src.settings?.soundEnabled !== undefined ? Boolean(src.settings.soundEnabled) : Boolean(settings.soundEnabled);
  settings.soundVolume = Math.max(0, Math.min(100, num(settings.soundVolume, 35)));
  settings.cameraAttentionEnabled = src.settings?.cameraAttentionEnabled !== undefined ? Boolean(src.settings.cameraAttentionEnabled) : Boolean(settings.cameraAttentionEnabled);
  settings.cameraAttentionSensitivity = ["gentle", "balanced", "strict"].includes(settings.cameraAttentionSensitivity) ? settings.cameraAttentionSensitivity : "balanced";
  settings.cameraAttentionGraceSeconds = Math.max(5, Math.min(30, num(settings.cameraAttentionGraceSeconds, 10)));
  settings.cameraAttentionVoice = src.settings?.cameraAttentionVoice !== undefined ? Boolean(src.settings.cameraAttentionVoice) : Boolean(settings.cameraAttentionVoice);
  delete settings.autoOpenCourseOnFocus;

  const profile = { ...base.profile, ...(src.profile || {}) };
  const oldProfileKindKey = "log" + "inType";
  const oldProfileDateKey = "last" + "Log" + "inAt";
  profile.profileType = profile.profileType || profile[oldProfileKindKey] || "local";
  profile.lastProfileAt = profile.lastProfileAt || profile[oldProfileDateKey] || null;
  profile.studyProfile = normalizeStudyProfile(profile.studyProfile || src.settings?.studyProfile);
  profile.guidedTourStatus = ["not_started", "skipped", "completed"].includes(profile.guidedTourStatus) ? profile.guidedTourStatus : "completed";
  profile.guidedTourVersion = Math.max(0, Math.floor(num(profile.guidedTourVersion)));
  profile.guidedTourActive = Boolean(profile.guidedTourActive && profile.guidedTourStatus === "not_started");
  profile.guidedTourStep = Math.max(0, Math.min(50, Math.floor(num(profile.guidedTourStep))));
  profile.guidedTourTabId = Number.isInteger(Number(profile.guidedTourTabId)) && Number(profile.guidedTourTabId) > 0 ? Number(profile.guidedTourTabId) : null;
  profile.guidedTourSessionId = String(profile.guidedTourSessionId || "").trim().slice(0, 96) || null;
  profile.guidedTourUpdatedAt = profile.guidedTourUpdatedAt ? num(profile.guidedTourUpdatedAt) : null;
  profile.guidedTourHandoff = profile.guidedTourActive ? normalizeGuidedTourHandoff(profile.guidedTourHandoff) : null;
  delete profile[oldProfileKindKey];
  delete profile[oldProfileDateKey];

  const courseLibraries = normalizeCourseLibraries(src.courseLibraries || src.courseGroups);
  const goals = { ...base.goals, ...(src.goals || {}) };
  goals.analyticsTargets = normalizeStudyTargets(src.goals?.analyticsTargets, profile.studyProfile);
  const daily = { ...base.daily, ...(src.daily || {}), tasks: normalizeTasks(src.daily?.tasks) };
  delete daily.rescueCount;

  const state = {
    ...base,
    ...src,
    version: 12,
    profile,
    settings,
    courseLibraries,
    courses: normalizeCourses(src.courses, courseLibraries, profile.studyProfile, goals.analyticsTargets?.customSubjects),
    attention: {
      ...base.attention,
      ...(src.attention || {}),
      active: Boolean(src.attention?.active),
      status: ["off", "starting", "calibrating", "watching", "attention-lost", "paused", "needs-position", "permission-denied", "unsupported", "error"].includes(src.attention?.status) ? src.attention.status : "off",
      reason: src.attention?.reason ? String(src.attention.reason).slice(0, 80) : null,
      lastEventAt: src.attention?.lastEventAt ? num(src.attention.lastEventAt) : null,
      distractionCount: Math.max(0, num(src.attention?.distractionCount)),
      calibratedAt: src.attention?.calibratedAt ? num(src.attention.calibratedAt) : null,
      error: src.attention?.error ? String(src.attention.error).slice(0, 180) : null
    },
    goals,
    daily,
    stats: { ...base.stats, ...(src.stats || {}) },
    analytics: {
      ...base.analytics,
      ...(src.analytics || {}),
      daily: { ...(src.analytics?.daily || {}) },
      focusHistory: normalizeFocusHistory(src.analytics?.focusHistory)
    },
    rewards: normalizeRewards(src.rewards),
    assistant: { ...base.assistant, ...(src.assistant || {}) },
    protection: {
      tabSwitches: normalizeEvents(src.protection?.tabSwitches),
      blockedAttempts: normalizeEvents(src.protection?.blockedAttempts),
      browsingEvents: normalizeEvents(src.protection?.browsingEvents),
      lastAssistantNoticeAt: num(src.protection?.lastAssistantNoticeAt) || null
    },
    backups: { ...base.backups, ...(src.backups || {}) }
  };

  delete state.jeeMode;
  delete state.recommendations;
  delete state.subjects;
  delete state.courseGroups;
  delete state.notes;
  delete state.flashcards;
  delete state.planner;
  delete state.hydration;
  delete state.settings.waterEnabled;
  delete state.settings.waterGoal;
  delete state.settings.waterIntervalMinutes;
  delete state.goals.water;
  delete state.stats.water;
  delete state.todayGoal;
  state.settings.defaultCourseId = state.courses.some((c) => c.id === state.settings.defaultCourseId) ? state.settings.defaultCourseId : state.courses[0]?.id || null;
  state.goals.studyHours = Math.max(0, num(state.goals.studyHours, 4));
  state.goals.chapters = Math.max(0, num(state.goals.chapters, 2));
  state.goals.questions = Math.max(0, num(state.goals.questions, 60));
  if (num(src.version) < 11) state.analytics = backfillActualFocusTime(state.analytics);
  return state;
}
export function ensureToday(input = {}) { const state = mergeState(input); const today = todayKey(); if (state.daily.date !== today) state.daily.date = today; if (state.stats.date !== today) { state.stats = { date: today, focusMinutes: 0, distractions: 0, sessionsCompleted: 0 }; } return state; }
export function getActiveCourse(state) { const s = mergeState(state); return s.courses.find((c) => c.id === s.settings.defaultCourseId) || s.courses[0] || null; }
export function sessionRemainingMs(session, now = Date.now()) { if (!session?.active) return 0; if (session.paused) return Math.max(0, num(session.remainingMs)); return Math.max(0, num(session.endsAt) - now); }
export function minutesRemaining(session) { return Math.max(0, Math.ceil(sessionRemainingMs(session) / 60000)); }
export function formatClock(ms = 0) { const total = Math.max(0, Math.ceil(num(ms) / 1000)); const minutes = Math.floor(total / 60); const seconds = total % 60; return String(minutes).padStart(2, "0") + ":" + String(seconds).padStart(2, "0"); }
export function formatDuration(minutes = 0) { const total = Math.max(0, Math.round(num(minutes))); const h = Math.floor(total / 60); const m = total % 60; if (!h) return m + "m"; if (!m) return h + "h"; return h + "h " + m + "m"; }
export function focusElapsedMinutes(session, now = Date.now()) { const durationMs = Math.max(0, num(session?.durationMinutes) * 60000); if (!durationMs) return 0; return Math.max(0, Math.round((durationMs - sessionRemainingMs(session, now)) / 60000)); }
export function actualStudyMinutesForDate(input = {}, date = todayKey(), now = Date.now()) {
  const state = mergeState(input);
  const stored = Math.max(0, num(state.analytics?.daily?.[date]?.studyMinutes));
  const session = state.focusSession;
  const currentDate = todayKey(new Date(now));
  if (!session?.active || date !== currentDate || todayKey(new Date(num(session.startedAt, now))) !== date) return stored;
  return stored + focusElapsedMinutes(session, now);
}
export function sessionXp(minutes = 0, completed = true) { const base = Math.max(0, Math.round(num(minutes))); return completed ? Math.max(25, base) : 0; }
export function levelForXp(xp = 0) { return Math.max(1, Math.floor(Math.max(0, num(xp)) / 300) + 1); }
export function rankForLevel(level = 1) { return RANKS.find((rank) => level >= rank.minLevel)?.name || "Beginner"; }
export function rewardXpTotal(state = {}) { return (state.rewards?.entries || []).reduce((total, entry) => total + Math.max(0, num(entry.xp)), 0); }
export function dailySystemGoals(state, date = new Date()) {
  const key = todayKey(date);
  const dateValue = new Date(date);
  const templates = [
    [{ id: "study", type: "study", minutes: 150, xp: 80 }, { id: "sessions", type: "sessions", count: 1, xp: 60 }, { id: "clean", type: "clean", minutes: 45, xp: 50 }],
    [{ id: "study", type: "study", minutes: 180, xp: 80 }, { id: "sessions", type: "sessions", count: 2, xp: 60 }],
    [{ id: "study", type: "study", minutes: 240, xp: 80 }, { id: "clean", type: "clean", minutes: 60, xp: 50 }],
    [{ id: "study", type: "study", minutes: 120, xp: 80 }, { id: "sessions", type: "sessions", count: 1, xp: 60 }],
    [{ id: "study", type: "study", minutes: 180, xp: 80 }, { id: "clean", type: "clean", minutes: 45, xp: 50 }],
    [{ id: "study", type: "study", minutes: 210, xp: 80 }, { id: "sessions", type: "sessions", count: 2, xp: 60 }],
    [{ id: "study", type: "study", minutes: 150, xp: 80 }, { id: "sessions", type: "sessions", count: 1, xp: 60 }, { id: "clean", type: "clean", minutes: 30, xp: 50 }]
  ];
  const daily = state.analytics?.daily?.[key] || {};
  const todayStats = state.stats?.date === key ? state.stats : {};
  const studyMinutes = actualStudyMinutesForDate(state, key);
  const verifiedStudyMinutes = num(daily.verifiedStudyMinutes);
  const completedSessions = Math.max(num(daily.completedSessions), num(todayStats.sessionsCompleted));
  const distractions = num(todayStats.distractions, num(daily.distractionsBlocked));
  return (templates[dateValue.getDay()] || templates[1]).map((goal) => {
    const value = goal.type === "sessions" ? completedSessions : goal.type === "clean" ? (distractions > 0 ? 0 : Math.min(studyMinutes, goal.minutes)) : studyMinutes;
    const verifiedValue = goal.type === "sessions" ? completedSessions : goal.type === "clean" ? (distractions > 0 ? 0 : Math.min(verifiedStudyMinutes, goal.minutes)) : verifiedStudyMinutes;
    const target = goal.count || goal.minutes;
    const title = goal.type === "sessions" ? "Complete " + goal.count + " Focus " + (goal.count === 1 ? "Session" : "Sessions") : goal.type === "clean" ? "Stay distraction-free for " + formatDuration(goal.minutes) : "Study " + formatDuration(goal.minutes);
    const display = goal.type === "sessions" ? Math.min(value, target) + " / " + target + " sessions" : goal.type === "clean" && distractions > 0 ? "Distraction recorded today" : formatDuration(Math.min(value, target)) + " / " + formatDuration(target);
    return { ...goal, date: key, title, value, target, display, done: value >= target, awardEligible: verifiedValue >= target, percent: Math.min(100, Math.round((value / Math.max(1, target)) * 100)) };
  });
}
export function awardVerifiedRewards(input = {}) {
  const state = input;
  const rewards = normalizeRewards(state.rewards);
  const entries = [...rewards.entries];
  const awardedGoalKeys = { ...rewards.awardedGoalKeys };
  const award = (key, type, label, xp) => {
    if (awardedGoalKeys[key]) return;
    const awardedAt = Date.now();
    awardedGoalKeys[key] = awardedAt;
    entries.push({ id: uid("reward"), key, type, label, xp, awardedAt });
  };
  const dailyGoals = dailySystemGoals(state);
  dailyGoals.filter((goal) => goal.awardEligible).forEach((goal) => award(goal.date + ":" + goal.id, "system-goal", goal.title, goal.xp));
  if (dailyGoals.length && dailyGoals.every((goal) => goal.awardEligible)) award(todayKey() + ":daily-reward", "daily-reward", "Daily goals complete", 30);
  const streak = num(state.analytics?.streak?.current);
  const today = todayKey();
  const completedToday = num(state.analytics?.daily?.[today]?.completedSessions);
  if (streak >= 2 && completedToday > 0) award(today + ":streak", "streak", streak + "-day consistency bonus", Math.min(50, 10 + streak * 2));
  return { ...state, rewards: normalizeRewards({ awardedGoalKeys, entries }) };
}
export function addSubjectStudy(subjects, subject, minutes, sessionDone = true, completion = null) { const next = normalizeSubjects(subjects); const key = normalizeSubject(subject); const current = next[key]; const newCompletion = completion === null ? current.completion : Math.max(0, Math.min(100, num(completion))); next[key] = { ...current, studyMinutes: current.studyMinutes + Math.max(0, num(minutes)), sessions: current.sessions + (sessionDone ? 1 : 0), completion: Math.max(current.completion, newCompletion) }; return next; }
function streakAfterStudy(streak = {}, date = todayKey()) { const yesterday = new Date(date); yesterday.setDate(yesterday.getDate() - 1); const yKey = todayKey(yesterday); if (streak.lastStudyDate === date) return streak; const current = streak.lastStudyDate === yKey ? num(streak.current) + 1 : 1; return { current, longest: Math.max(num(streak.longest), current), lastStudyDate: date }; }
export function recordFocusAnalytics(analytics, session, elapsedMinutes, completed = false, status = null) {
  const date = todayKey();
  const base = { ...defaultAnalytics(), ...(analytics || {}) };
  const daily = { ...(base.daily || {}) };
  const id = session?.id || uid("session");
  const existing = (base.focusHistory || []).find((entry) => String(entry?.id || "") === String(id));
  if (existing) {
    const previousDate = existing.recordedDate || todayKey(new Date(num(existing.endedAt || existing.startedAt, Date.now())));
    const previous = analyticsDay(daily, previousDate);
    const previousMinutes = Math.max(0, num(existing.actualMinutes, num(existing.durationMinutes)));
    previous.sessions = Math.max(0, num(previous.sessions) - 1);
    previous.distractionsBlocked = Math.max(0, num(previous.distractionsBlocked) - num(existing.distractionsBlocked));
    if (existing.actualTracked) {
      previous.studyMinutes = Math.max(0, num(previous.studyMinutes) - previousMinutes);
      previous.subjects = adjustSubjectStudy(previous.subjects, existing.subject, -previousMinutes, existing.completed ? -1 : 0);
    }
    if (existing.completed) {
      previous.verifiedStudyMinutes = Math.max(0, num(previous.verifiedStudyMinutes) - previousMinutes);
      previous.completedSessions = Math.max(0, num(previous.completedSessions) - 1);
    }
  }
  const item = analyticsDay(daily, date);
  const minutes = Math.max(0, num(elapsedMinutes));
  const plannedMinutes = Math.max(0, num(session?.durationMinutes));
  const subject = normalizeSubject(session?.subject);
  const normalizedStatus = ["completed", "incomplete", "interrupted"].includes(String(status || "").toLowerCase()) ? String(status).toLowerCase() : completed ? "completed" : "incomplete";
  item.studyMinutes += minutes;
  item.subjects = adjustSubjectStudy(item.subjects, subject, minutes, completed ? 1 : 0);
  if (completed) {
    item.verifiedStudyMinutes = num(item.verifiedStudyMinutes) + minutes;
    item.completedSessions = num(item.completedSessions) + 1;
  }
  item.sessions = num(item.sessions) + 1;
  item.distractionsBlocked = num(item.distractionsBlocked) + num(session?.distractionsBlocked);
  daily[date] = item;
  const historyItem = { id, courseId: session?.courseId || null, courseTitle: session?.courseTitle || "Focus session", subject, startedAt: session?.startedAt || Date.now(), endedAt: Date.now(), recordedDate: date, actualTracked: true, plannedMinutes, actualMinutes: minutes, durationMinutes: minutes, completionPercent: Math.round(Math.max(0, Math.min(100, plannedMinutes ? (minutes / plannedMinutes) * 100 : normalizedStatus === "completed" ? 100 : 0))), completed: normalizedStatus === "completed", status: normalizedStatus, xpEarned: sessionXp(minutes, normalizedStatus === "completed"), distractionsBlocked: num(session?.distractionsBlocked) };
  const focusHistory = [historyItem, ...(base.focusHistory || []).filter((entry) => String(entry?.id || "") !== String(id))].slice(0, 300);
  return { daily, focusHistory, streak: completed && minutes > 0 ? streakAfterStudy(base.streak, date) : base.streak || defaultAnalytics().streak };
}
export function recordDistractionAnalytics(analytics) { const date = todayKey(); const base = { ...defaultAnalytics(), ...(analytics || {}) }; const daily = { ...(base.daily || {}) }; const item = daily[date] || { studyMinutes: 0, sessions: 0, completedSessions: 0, distractionsBlocked: 0, subjects: emptySubjectTracking() }; item.distractionsBlocked += 1; daily[date] = item; return { ...base, daily }; }
export function dateSeries(days = 14, end = new Date()) { return Array.from({ length: days }, (_, index) => { const d = new Date(end); d.setDate(d.getDate() - (days - index - 1)); return todayKey(d); }); }
export function focusGreeting(name = "", now = new Date()) {
  const hour = (now instanceof Date ? now : new Date(now)).getHours();
  const prefix = hour >= 5 && hour < 12 ? "Good morning" : hour >= 12 && hour < 17 ? "Good afternoon" : hour >= 17 && hour < 21 ? "Good evening" : "Good night";
  const cleanName = String(name || "").trim().slice(0, 60);
  return prefix + (cleanName ? ", " + cleanName : "") + (prefix === "Good night" ? " 🌙" : " 👋");
}
export function dashboardHeaderPresentation({ tab = "focus", session = null, course = null, profileName = "", now = new Date() } = {}) {
  const activeTab = String(tab || "focus");
  const focusTabActive = activeTab === "focus";
  const pageHeadings = { courses: "Your study library", analytics: "Track your study progress.", daily: "Daily goals", music: "Study music", settings: "Settings", about: "About Studizen" };
  const pageLabels = { courses: "Courses", analytics: "Analytics", daily: "Daily Goals", music: "Music", settings: "Settings", about: "About" };
  const sessionStatus = session?.paused ? "Focus paused" : "Focus running";
  return {
    eyebrow: focusTabActive ? (session ? sessionStatus : "Ready") : (pageLabels[activeTab] || "Studizen"),
    title: focusTabActive ? focusGreeting(profileName, now) : (pageHeadings[activeTab] || "Studizen"),
    showSessionIndicator: Boolean(session) && !focusTabActive,
    sessionStatus,
    sessionTitle: session?.courseTitle || course?.title || "Current course"
  };
}
export function completedPeriodAnalytics(summary = {}, period = "current-week", now = new Date(), dailyGoalHours = 0, weeklyGoalMinutes = null) {
  const date = now instanceof Date ? new Date(now) : new Date(now);
  const currentDay = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const mondayOffset = (currentDay.getDay() + 6) % 7;
  const weekStart = new Date(currentDay); weekStart.setDate(currentDay.getDate() - mondayOffset);
  let keys = [];
  if (period === "previous-week") {
    const previousWeekEnd = new Date(weekStart); previousWeekEnd.setDate(weekStart.getDate() - 1);
    keys = dateSeries(7, previousWeekEnd);
  } else if (period === "current-month") {
    keys = dateSeries(currentDay.getDate(), currentDay);
  } else if (period === "previous-month") {
    const previousMonthEnd = new Date(currentDay.getFullYear(), currentDay.getMonth(), 0);
    keys = dateSeries(previousMonthEnd.getDate(), previousMonthEnd);
  } else {
    keys = dateSeries(mondayOffset + 1, currentDay);
  }
  const keySet = new Set(keys);
  const sessions = Array.isArray(summary.sessions) ? summary.sessions.filter((session) => keySet.has(session?.recordedDate)) : [];
  const minutes = sessions.reduce((total, session) => total + Math.max(0, num(session?.actualMinutes, num(session?.durationMinutes))), 0);
  const courses = new Map();
  sessions.forEach((session) => {
    const id = String(session?.courseId || session?.courseTitle || "Focus session");
    const entry = courses.get(id) || { id: session?.courseId || null, title: String(session?.courseTitle || "Focus session"), minutes: 0, sessions: 0 };
    entry.minutes += Math.max(0, num(session?.actualMinutes, num(session?.durationMinutes)));
    entry.sessions += 1;
    courses.set(id, entry);
  });
  const usesWeeklyTarget = weeklyGoalMinutes !== null && weeklyGoalMinutes !== undefined;
  const goalMinutes = Math.max(0, usesWeeklyTarget
    ? num(weeklyGoalMinutes) * (period === "previous-month" || period === "current-month" ? keys.length / 7 : 1)
    : num(dailyGoalHours) * 60 * keys.length);
  const completedSessions = sessions.filter((session) => session?.completed === true && session?.status === "completed").length;
  return {
    period,
    keys,
    sessions,
    minutes,
    completedSessions,
    recordedSessions: sessions.length,
    dailyAverageMinutes: keys.length ? Math.round(minutes / keys.length) : 0,
    goalMinutes,
    goalProgress: goalMinutes ? Math.round((minutes / goalMinutes) * 100) : null,
    courseEntries: [...courses.values()].sort((a, b) => b.minutes - a.minutes || b.sessions - a.sessions || a.title.localeCompare(b.title))
  };
}
export function completedFocusAnalytics(input = {}, now = Date.now()) {
  const state = mergeState(input);
  const byDate = new Map(); const bySubject = new Map(); const byCourse = new Map(); const seen = new Set(); const sessions = [];
  let totalMinutes = 0; let longest = null;
  for (const item of Array.isArray(state.analytics?.focusHistory) ? state.analytics.focusHistory : []) {
    if (!item || typeof item !== "object" || item.completed !== true || item.status !== "completed") continue;
    const id = String(item.id || ""); const endedAt = num(item.endedAt, 0); const startedAt = num(item.startedAt, 0); const minutes = Math.max(0, num(item.actualMinutes, num(item.durationMinutes)));
    if (!id || seen.has(id) || !Number.isFinite(startedAt) || startedAt <= 0 || !Number.isFinite(endedAt) || endedAt <= 0 || !Number.isFinite(minutes) || minutes <= 0) continue;
    seen.add(id);
    const date = /^\d{4}-\d{2}-\d{2}$/.test(String(item.recordedDate || "")) ? item.recordedDate : todayKey(new Date(endedAt));
    const subject = normalizeSubject(item.subject, state.profile?.studyProfile);
    const courseKey = String(item.courseId || item.courseTitle || "Focus session");
    const course = byCourse.get(courseKey) || { id: item.courseId || null, title: String(item.courseTitle || "Focus session"), minutes: 0, sessions: 0 };
    const subjectEntry = bySubject.get(subject) || { minutes: 0, sessions: 0 };
    byDate.set(date, (byDate.get(date) || 0) + minutes);
    subjectEntry.minutes += minutes; subjectEntry.sessions += 1; bySubject.set(subject, subjectEntry);
    course.minutes += minutes; course.sessions += 1; byCourse.set(courseKey, course);
    const entry = { ...item, actualMinutes: minutes, durationMinutes: minutes, recordedDate: date, subject, endedAt, startedAt };
    sessions.push(entry); totalMinutes += minutes;
    if (!longest || minutes > longest.actualMinutes) longest = entry;
  }
  sessions.sort((a, b) => b.endedAt - a.endedAt);
  const today = todayKey(new Date(now)); const weekKeys = dateSeries(7, new Date(now)); const monthPrefix = today.slice(0, 7);
  const sumDates = (keys) => keys.reduce((sum, key) => sum + (byDate.get(key) || 0), 0);
  const courseEntries = [...byCourse.values()].sort((a, b) => b.minutes - a.minutes || b.sessions - a.sessions || a.title.localeCompare(b.title));
  return { sessions, totalMinutes, completedSessions: sessions.length, averageSessionMinutes: sessions.length ? Math.round(totalMinutes / sessions.length) : 0, longestSession: longest, byDate, bySubject, byCourse, courseEntries, todayMinutes: byDate.get(today) || 0, weekMinutes: sumDates(weekKeys), monthMinutes: [...byDate.entries()].filter(([key]) => key.startsWith(monthPrefix)).reduce((sum, [, minutes]) => sum + minutes, 0), today, weekKeys };
}
export function recordedStudyAnalytics(input = {}, now = Date.now()) {
  const state = mergeState(input);
  const byDate = new Map(); const bySubject = new Map(); const byCourse = new Map(); const seen = new Set(); const sessions = [];
  const profileId = state.profile?.studyProfile;
  const targets = normalizeStudyTargets(state.goals?.analyticsTargets, profileId);
  const customSubjects = [...new Set([...(targets?.customSubjects || []), ...(state.courses || []).map((course) => course.subject), ...(state.analytics?.focusHistory || []).map((item) => item?.subject)].filter(Boolean))];
  let totalMinutes = 0; let longestSession = null;
  for (const item of Array.isArray(state.analytics?.focusHistory) ? state.analytics.focusHistory : []) {
    if (!item || typeof item !== "object" || item.actualTracked !== true) continue;
    const id = String(item.id || "");
    const endedAt = num(item.endedAt, 0); const startedAt = num(item.startedAt, 0);
    const minutes = Math.max(0, num(item.actualMinutes, num(item.durationMinutes)));
    if (!id || seen.has(id) || !Number.isFinite(startedAt) || startedAt <= 0 || !Number.isFinite(endedAt) || endedAt <= 0 || !Number.isFinite(minutes) || minutes <= 0) continue;
    seen.add(id);
    const date = /^\d{4}-\d{2}-\d{2}$/.test(String(item.recordedDate || "")) ? item.recordedDate : todayKey(new Date(endedAt));
    const subject = normalizeSubject(item.subject, profileId, customSubjects);
    const courseKey = String(item.courseId || item.courseTitle || "Focus session");
    const course = byCourse.get(courseKey) || { id: item.courseId || null, title: String(item.courseTitle || "Focus session"), minutes: 0, sessions: 0 };
    const subjectEntry = bySubject.get(subject) || { minutes: 0, sessions: 0 };
    byDate.set(date, (byDate.get(date) || 0) + minutes);
    subjectEntry.minutes += minutes; subjectEntry.sessions += 1; bySubject.set(subject, subjectEntry);
    course.minutes += minutes; course.sessions += 1; byCourse.set(courseKey, course);
    const session = { ...item, actualMinutes: minutes, durationMinutes: minutes, recordedDate: date, subject, endedAt, startedAt };
    sessions.push(session); totalMinutes += minutes;
    if (!longestSession || minutes > longestSession.actualMinutes) longestSession = session;
  }
  sessions.sort((a, b) => b.endedAt - a.endedAt);
  const today = todayKey(new Date(now)); const weekKeys = dateSeries(7, new Date(now)); const monthPrefix = today.slice(0, 7);
  const sumDates = (keys) => keys.reduce((sum, key) => sum + (byDate.get(key) || 0), 0);
  const courseEntries = [...byCourse.values()].sort((a, b) => b.minutes - a.minutes || b.sessions - a.sessions || a.title.localeCompare(b.title));
  const completedSessions = sessions.filter((session) => session.completed === true && session.status === "completed").length;
  return { sessions, totalMinutes, completedSessions, recordedSessions: sessions.length, averageSessionMinutes: sessions.length ? Math.round(totalMinutes / sessions.length) : 0, longestSession, byDate, bySubject, byCourse, courseEntries, todayMinutes: byDate.get(today) || 0, weekMinutes: sumDates(weekKeys), monthMinutes: [...byDate.entries()].filter(([key]) => key.startsWith(monthPrefix)).reduce((sum, [, minutes]) => sum + minutes, 0), today, weekKeys };
}
export function productivityScore(state) { const s = mergeState(state); const today = todayKey(); const studyMinutes = actualStudyMinutesForDate(s, today); const daily = s.analytics.daily?.[today] || {}; const completedSessions = Math.max(num(daily.completedSessions), num(s.stats.sessionsCompleted)); const study = Math.min(65, (studyMinutes / Math.max(1, s.goals.studyHours * 60)) * 65); const sessions = Math.min(25, (completedSessions / 2) * 25); const penalty = Math.min(25, s.stats.distractions * 3); return Math.max(0, Math.min(100, Math.round(study + sessions + 10 - penalty))); }
function insightDateKey(value, fallback) {
  const at = num(value, 0);
  return at > 0 ? todayKey(new Date(at)) : fallback;
}
function insightMinutes(item) { return Math.max(0, num(item?.actualMinutes, num(item?.durationMinutes))); }
function insightHash(value = "") {
  let hash = 0;
  for (const char of String(value)) hash = ((hash << 5) - hash + char.charCodeAt(0)) | 0;
  return Math.abs(hash);
}
function insightDateOffset(date, offset) {
  const next = new Date(date);
  next.setDate(next.getDate() + offset);
  return todayKey(next);
}
function insightRangeSummary(daily, keys) {
  const values = keys.map((key) => Math.max(0, num(daily?.[key]?.studyMinutes)));
  return { minutes: values.reduce((sum, value) => sum + value, 0), days: values.filter((value) => value > 0).length };
}

// Uses existing recorded focus history and daily analytics only; it stores no derived insight state.
export function buildTodayInsight(input = {}, now = Date.now()) {
  const state = mergeState(input);
  const today = todayKey(new Date(now));
  const daily = state.analytics?.daily && typeof state.analytics.daily === "object" ? state.analytics.daily : {};
  const history = (Array.isArray(state.analytics?.focusHistory) ? state.analytics.focusHistory : []).filter((item) => item && typeof item === "object");
  const finished = history.filter((item) => ["completed", "incomplete", "interrupted"].includes(String(item.status || "").toLowerCase()) || typeof item.completed === "boolean");
  const todayEntries = finished.filter((item) => String(item.recordedDate || insightDateKey(item.endedAt || item.startedAt, "")) === today);
  const todayCompleted = todayEntries.filter((item) => item.completed === true || String(item.status).toLowerCase() === "completed");
  const todayActual = actualStudyMinutesForDate(state, today, now);
  const todayVerified = Math.max(0, num(daily[today]?.verifiedStudyMinutes));
  const completedCount = Math.max(todayCompleted.length, num(daily[today]?.completedSessions), state.stats?.date === today ? num(state.stats?.sessionsCompleted) : 0);
  const goalMinutes = Math.max(0, num(state.goals?.studyHours, DEFAULT_STUDY_GOALS.studyHours) * 60);
  const candidates = [];
  const add = (priority, key, title, text) => candidates.push({ priority, key, title, text });
  const sessionSubject = (item) => {
    const subject = String(item?.subject || "").trim();
    return subject || "your selected subject";
  };

  const blockedEvents = (Array.isArray(state.protection?.blockedAttempts) ? state.protection.blockedAttempts : []).filter((event) => insightDateKey(event?.at, "") === today).length;
  const recordedBlocks = Math.max(0, num(daily[today]?.distractionsBlocked));
  const statBlocks = state.stats?.date === today ? Math.max(0, num(state.stats?.distractions)) : 0;
  const blockedAttempts = Math.max(recordedBlocks, statBlocks, blockedEvents);
  const hasStoredStudy = Object.values(daily).some((item) => Math.max(0, num(item?.studyMinutes), num(item?.verifiedStudyMinutes)) > 0);

  if (!finished.length && !state.focusSession?.active && !hasStoredStudy && !blockedAttempts) {
    return { title: "Start your first session", text: "Add a course, then complete one focus session to begin building personal study insights.", key: "no-study-data" };
  }
  if (!todayEntries.length && !state.focusSession?.active && todayActual <= 0 && !blockedAttempts) {
    const latest = finished.slice().sort((a, b) => num(b.endedAt || b.startedAt) - num(a.endedAt || a.startedAt))[0];
    const latestMinutes = insightMinutes(latest);
    return {
      title: "No focus time recorded today",
      text: latest?.completed && latestMinutes > 0 ? "Your last completed session was " + formatDuration(latestMinutes) + " in " + sessionSubject(latest) + "." : "Start a focus session today to keep your study record current.",
      key: "no-study-today"
    };
  }
  if (state.focusSession?.active && !todayEntries.length) add(12, "focus-in-progress", "Focus in progress", "Your current " + (state.focusSession.courseTitle || "focus") + " session is now contributing to today's study progress.");
  if (goalMinutes > 0 && todayActual >= goalMinutes) add(14, "goal-complete", "Today's study goal reached", "You've reached your " + formatDuration(goalMinutes) + " study goal with " + formatDuration(todayActual) + " focused today.");
  if (goalMinutes > 0 && todayActual < goalMinutes) {
    const remaining = Math.max(0, goalMinutes - todayActual);
    const percent = Math.min(100, Math.round((todayActual / goalMinutes) * 100));
    if (remaining <= 45 && todayActual > 0) add(16, "goal-near", "Close to today's goal", "You're " + formatDuration(remaining) + " away from today's " + formatDuration(goalMinutes) + " study goal.");
    else if (percent >= 50) add(24, "goal-progress", "Today's goal progress", "You've completed " + percent + "% of today's study goal: " + formatDuration(todayActual) + " of " + formatDuration(goalMinutes) + ".");
  }
  if (blockedAttempts > 0) add(18, "blocked-attempts", "Focus protection is active", "You had " + blockedAttempts + " blocked distraction " + (blockedAttempts === 1 ? "attempt" : "attempts") + " today. Your focus protection is doing its job.");

  const completedBySubject = new Map();
  todayCompleted.forEach((item) => {
    const subject = sessionSubject(item);
    const entry = completedBySubject.get(subject) || { count: 0, minutes: 0 };
    entry.count += 1;
    entry.minutes += insightMinutes(item);
    completedBySubject.set(subject, entry);
  });
  const todaySubjectLeader = [...completedBySubject.entries()].sort((a, b) => b[1].count - a[1].count || b[1].minutes - a[1].minutes)[0];
  if (todaySubjectLeader?.[1].count >= 2) add(20, "subject-sessions", "Focused work today", "You completed " + todaySubjectLeader[1].count + " " + todaySubjectLeader[0] + " sessions today.");
  if (completedCount >= 3) add(22, "sessions-today", "Strong session count", "You completed " + completedCount + " focus sessions today.");
  if (todayCompleted.length === 1) {
    const item = todayCompleted[0];
    add(25, "one-completed", "Completed session", "You completed " + formatDuration(insightMinutes(item)) + " of " + sessionSubject(item) + " today.");
  }
  const longest = todayCompleted.reduce((best, item) => insightMinutes(item) > insightMinutes(best) ? item : best, null);
  if (longest && insightMinutes(longest) > 0) add(28, "longest-session", "Longest completed session", "Your longest completed session today was " + formatDuration(insightMinutes(longest)) + " in " + sessionSubject(longest) + ".");
  const interrupted = todayEntries.filter((item) => String(item.status).toLowerCase() === "interrupted");
  if (interrupted.length) {
    const minutes = interrupted.reduce((sum, item) => sum + insightMinutes(item), 0);
    add(30, "interrupted", "Focus time preserved", "You had " + interrupted.length + " interrupted " + (interrupted.length === 1 ? "session" : "sessions") + " today; " + formatDuration(minutes) + " of focused time is still reflected in your progress.");
  }
  const streak = Math.max(0, num(state.analytics?.streak?.current));
  if (streak >= 2) add(32, "streak", "Study consistency", "You've completed focus sessions on " + streak + " days in a row.");

  const weekKeys = Array.from({ length: 7 }, (_, index) => insightDateOffset(new Date(now), -index));
  const previousWeekKeys = Array.from({ length: 7 }, (_, index) => insightDateOffset(new Date(now), -7 - index));
  const weeklySubjectTotals = new Map();
  const previousSubjectTotals = new Map();
  const courseTotals = new Map();
  finished.forEach((item) => {
    const key = String(item.recordedDate || insightDateKey(item.endedAt || item.startedAt, ""));
    const minutes = insightMinutes(item);
    if (!minutes) return;
    const subject = sessionSubject(item);
    if (weekKeys.includes(key)) weeklySubjectTotals.set(subject, (weeklySubjectTotals.get(subject) || 0) + minutes);
    if (previousWeekKeys.includes(key)) previousSubjectTotals.set(subject, (previousSubjectTotals.get(subject) || 0) + minutes);
    if (weekKeys.includes(key)) {
      const course = String(item.courseTitle || state.courses.find((candidate) => candidate.id === item.courseId)?.title || "").trim();
      if (course) courseTotals.set(course, (courseTotals.get(course) || 0) + minutes);
    }
  });
  const weeklySubjects = [...weeklySubjectTotals.entries()].filter(([, minutes]) => minutes > 0).sort((a, b) => b[1] - a[1]);
  if (weeklySubjects.length) add(38, "most-studied-subject", "Most studied this week", weeklySubjects[0][0] + " was your most studied subject this week with " + formatDuration(weeklySubjects[0][1]) + ".");
  if (weeklySubjects.length >= 2) {
    const least = weeklySubjects[weeklySubjects.length - 1];
    add(40, "least-studied-subject", "Balance your subjects", least[0] + " received the least study time among the subjects you worked on this week: " + formatDuration(least[1]) + ".");
  }
  const topCourse = [...courseTotals.entries()].sort((a, b) => b[1] - a[1])[0];
  if (topCourse && topCourse[1] > 0) add(42, "most-studied-course", "Most studied course", topCourse[0] + " received " + formatDuration(topCourse[1]) + " of focused study time this week.");

  const yesterday = insightDateOffset(new Date(now), -1);
  const yesterdayMinutes = Math.max(0, num(daily[yesterday]?.studyMinutes));
  if (todayActual > 0 && yesterdayMinutes > 0) {
    const difference = Math.abs(todayActual - yesterdayMinutes);
    if (difference > 0) add(44, "today-vs-yesterday", "Compared with yesterday", "You've studied " + formatDuration(difference) + " " + (todayActual > yesterdayMinutes ? "more" : "less") + " than yesterday so far.");
  }
  const currentWeek = insightRangeSummary(daily, weekKeys);
  const previousWeek = insightRangeSummary(daily, previousWeekKeys);
  if (currentWeek.days >= 2 && previousWeek.days >= 2 && currentWeek.minutes > 0 && previousWeek.minutes > 0 && currentWeek.minutes !== previousWeek.minutes) {
    const difference = Math.abs(currentWeek.minutes - previousWeek.minutes);
    add(46, "week-comparison", "Weekly study trend", "This week's study time is " + formatDuration(difference) + " " + (currentWeek.minutes > previousWeek.minutes ? "ahead of" : "behind") + " the previous 7 days.");
  }
  const previousLeader = [...previousSubjectTotals.entries()].filter(([, minutes]) => minutes > 0).sort((a, b) => b[1] - a[1])[0];
  if (weeklySubjects[0] && previousLeader && weeklySubjects[0][0] !== previousLeader[0]) add(48, "subject-shift", "Subject focus shift", weeklySubjects[0][0] + " leads this week, while " + previousLeader[0] + " led the previous week.");

  if (!candidates.length) {
    if (todayVerified > 0) return { title: "Study record updated", text: "Your completed focus time is recorded and ready for deeper comparisons as you add more sessions.", key: "completed-fallback" };
    return { title: "Focus time recorded", text: "Your focused time is saved. Complete a session to unlock completion and consistency insights.", key: "actual-fallback" };
  }
  const bestPriority = Math.min(...candidates.map((candidate) => candidate.priority));
  const relevant = candidates.filter((candidate) => candidate.priority <= bestPriority + 24);
  const signature = [today, todayActual, todayVerified, completedCount, goalMinutes, blockedAttempts, streak, history.map((item) => [item.id, item.status, insightMinutes(item), item.endedAt]).join("|")].join(";");
  return relevant[insightHash(signature) % relevant.length];
}
export function goalProgressPercent(state) { const s = mergeState(state); const today = todayKey(); const daily = s.analytics.daily?.[today] || {}; const studyMinutes = actualStudyMinutesForDate(s, today); const completedSessions = Math.max(num(daily.completedSessions), num(s.stats.sessionsCompleted)); const study = s.goals.studyHours ? Math.min(1, studyMinutes / (s.goals.studyHours * 60)) : 0; const sessions = Math.min(1, completedSessions / 2); const streak = (s.analytics.streak?.current || 0) > 0 ? 1 : 0; return Math.round(((study + sessions + streak) / 3) * 100); }
export function recordProtectionEvent(protection, bucket, event = {}) { const p = { tabSwitches: normalizeEvents(protection?.tabSwitches), blockedAttempts: normalizeEvents(protection?.blockedAttempts), browsingEvents: normalizeEvents(protection?.browsingEvents), lastAssistantNoticeAt: protection?.lastAssistantNoticeAt || null }; const key = ["tabSwitches", "blockedAttempts", "browsingEvents"].includes(bucket) ? bucket : "browsingEvents"; p[key] = [...p[key], { at: num(event.at, Date.now()), type: String(event.type || bucket), host: String(event.host || ""), reason: String(event.reason || "") }].slice(-120); return p; }
export function countRecent(events, windowMs = 5 * 60 * 1000, now = Date.now()) { return (Array.isArray(events) ? events : []).filter((event) => now - num(event.at) <= windowMs).length; }
export function nextStudyTask(state) { const s = mergeState(state); const task = s.daily.tasks.find((t) => !t.done); const course = getActiveCourse(s); if (task) return task.title; if (course) return "Continue " + course.title; return "Add one course link and start a 25-minute focus block."; }
export function buildAssistantState(state, reason = "steady") { const s = mergeState(state); const blocked = countRecent(s.protection.blockedAttempts, 10 * 60 * 1000); const switches = countRecent(s.protection.tabSwitches, 5 * 60 * 1000); let mode = ASSISTANT_MESSAGES[reason] ? reason : "steady"; if (blocked >= 3) mode = "blockedAttempts"; else if (switches >= 5) mode = "tabSwitching"; else if ((s.stats.distractions || 0) >= 4) mode = "repeatedDistractions"; const course = getActiveCourse(s); return { mode, suggestion: ASSISTANT_MESSAGES[mode] || ASSISTANT_MESSAGES.steady, nextTask: course ? "Open " + course.title : nextStudyTask(s), lastUpdatedAt: Date.now() }; }
