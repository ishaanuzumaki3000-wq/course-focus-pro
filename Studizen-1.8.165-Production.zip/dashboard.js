import {
  STATE_KEY,
  actualStudyMinutesForDate,
  buildTodayInsight,
  completedFocusAnalytics,
  completedPeriodAnalytics,
  canonicalYouTubeVideoUrl,
  courseHasVideo,
  STUDY_PROFILES,
  createStatePatch,
  dailySystemGoals,
  deleteCourseLibrary,
  cleanPatterns,
  allocateStudyPercentages,
  closeFocusStudyInterval,
  createBreakStudyBlocks,
  dateSeries,
  defaultState,
  dashboardHeaderPresentation,
  focusElapsedMs,
  focusModeLabel,
  ensureToday,
  focusElapsedMinutes,
  formatClock,
  formatDuration,
  getActiveCourse,
  goalProgressPercent,
  isDistractionProtectionEnabled,
  isFocusSessionProtectionActive,
  isFocusSessionProtectionEnabled,
  isOutsideFocusProtectionEnabled,
  mergeState,
  normalizeSubject,
  normalizeUrl,
  productivityScore,
  renameCourseLibrary,
  levelForXp,
  rankForLevel,
  recordFocusAnalytics,
  recordedStudyAnalytics,
  recordedStudyPeriod,
  resolveStudyTargets,
  historicalStudyTargets,
  studyTargetSuggestions,
  normalizeGuidedTourHandoff,
  safeUrl,
  rewardXpTotal,
  safeYouTubeTitle,
  sessionRemainingMs,
  sessionXp,
  studySubjectPeriodTarget,
  studySessionsForLocalDay,
  studyDurationScale,
  studyWeekForLocalWeek,
  studyTimingForLocalDay,
  subjectStudyDistribution,
  studyTargetProgress,
  validateBreakSchedule,
  suggestedBreakSettings,
  subjectsForProfile,
  todayKey,
  uid
} from "./shared.js";

const hasChrome = Boolean(globalThis.chrome?.storage?.local);
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));
const systemThemeQuery = globalThis.matchMedia?.("(prefers-color-scheme: dark)");
const THEME_MODE_CACHE_KEY = "courseFocusProThemeMode";
const ONBOARDING_VERSION = 4;
const ONBOARDING_STEPS = ["welcome", "profile", "protection", "ready"];
const GUIDED_TOUR_VERSION = 1;
function guidedTourName() { return String(state?.profile?.name || "").trim().slice(0, 60); }
function guidedTourWelcomeText() {
  const name = guidedTourName();
  return name
    ? "Let's take a quick tour of the features you'll use most, " + name + "."
    : "Let's take a quick tour of the features you'll use most.";
}
const GUIDED_TOUR_STEPS = Object.freeze([
  { tab: "focus", selector: "#mainTitle", title: "Welcome to Studizen 👋", text: guidedTourWelcomeText, action: "start" },
  { tab: "focus", selector: "#focusWorkspaceTourTarget", spotlight: "focus", title: "Focus Mode", text: "Focus Mode is where you study. Choose a course, set your session time, and start focusing." },
  {
    tab: "courses",
    selector: "#addCourseTourTarget",
    title: "Add a study video",
    text: "Find an educational video on YouTube, right-click it, and choose Add to Studizen.",
    action: "courses",
    waitForCourse: true
  },
  { tab: "music", selector: "#studyMusicTourTarget", title: "Music", text: "Choose a sound to play while you study." },
  { tab: "analytics", selector: null, title: "Analytics", text: "Analytics shows how much you study and how you're progressing.", action: "analytics" },
  { tab: "settings", selector: "#distractionProtectionTourTarget", title: "Settings", text: "Settings is where you change how Studizen works for you.", action: "settings" },
  { tab: "focus", selector: null, title: "Quick access", text: "Use the Studizen popup for quick actions without opening the dashboard.", action: "popup" },
  {
    tab: () => state.courses.length ? "focus" : "courses",
    selector: () => state.courses.length ? "#startFocusBtn" : "#courseForm button[type='submit']",
    title: () => guidedTourName() ? "You're ready to focus, " + guidedTourName() + "." : "You're ready to focus.",
    text: () => state.courses.length
      ? "You know the basics. Start your first session whenever you're ready."
      : "Add a course first, then you can start your first session whenever you're ready.",
    action: "completion"
  }
]);
const GUIDED_TOUR_TAB_STEPS = Object.freeze({ focus: 1, courses: 2, music: 3, analytics: 4, settings: 5 });
const ONBOARDING_PROFILE_OPTIONS = Object.freeze({
  jee: { profileId: "jee", name: "JEE" },
  neet: { profileId: "neet", name: "NEET" },
  school: { profileId: "school", name: "School" },
  college: { profileId: "college", name: "College" },
  upsc: { profileId: "upsc", name: "UPSC" },
  "self-learner": { profileId: "custom", name: "Self Learner" }
});
const ONBOARDING_THEME_NAMES = Object.freeze({ system: "System", light: "Light", dark: "Dark", midnight: "Midnight Blue", amoled: "AMOLED Black", beige: "Warm Beige" });
let state = defaultState();
let toastTimer = null;
let undoTimer = null;
let undoSnapshot = null;
let undoLocalStorageSnapshot = null;
let settingsSaveQueue = Promise.resolve();
let settingsSaveFeedbackTimer = null;
let settingsSaveRevision = 0;
let lastSeenAttentionReminderAt = 0;
let onboardingStep = "welcome";
let onboardingProfileChoice = null;
let onboardingNameDraft = null;
let onboardingThemeChoice = null;
let onboardingDurationDraft = null;
let onboardingTargetsDraft = null;
let onboardingTargetsProfileId = null;
let onboardingTargetsTouched = false;
let pendingProfileTargetsChange = null;
let guidedTourStepIndex = 0;
let guidedTourActive = false;
let guidedTourSuspended = false;
let guidedTourTabId = null;
let guidedTourAutoStartHandled = false;
let guidedTourPositionFrame = 0;
let guidedTourTransition = false;
let charts = {};
let focusActionPending = false;
let focusModeDraft = null;
let lastFocusBreakSuggestionDuration = null;
let focusDurationCustom = false;
let pendingFocusStart = null;
let allowedSiteQuery = "";
let blockedSiteQuery = "";
let siteControlExpanded = false;
let distractionProtectionConsentPromptVisible = false;
let focusSessionProtectionConsentPromptVisible = false;
let distractionProtectionConsentSaving = false;
let websiteProtectionPermissionGranted = null;
let focusEnhancementsExpanded = false;
let incognitoAccessAllowed = null;
let cameraPermissionState = "checking";
let cameraPermissionQuery = null;
let cameraConsentSaving = false;
try { siteControlExpanded = sessionStorage.getItem("courseFocusProSiteControlExpanded") === "true"; } catch {}
try { focusEnhancementsExpanded = sessionStorage.getItem("studizenFocusEnhancementsExpanded") === "true"; } catch {}
let settingsDisclosureExpanded = { backup: false };
try {
  const savedSettingsDisclosures = JSON.parse(sessionStorage.getItem("studizenSettingsDisclosureExpanded") || "{}");
  settingsDisclosureExpanded.backup = savedSettingsDisclosures.backup === true;
} catch {}
let completedAnalyticsCache = { signature: "", summary: null };
let recordedAnalyticsCache = { signature: "", summary: null };
let courseHistoryQuery = "";
let courseHistorySort = "time";
let courseHistoryExpanded = sessionStorage.getItem("courseFocusProCourseHistoryExpanded") === "true";
let analyticsHistoryPeriod = null;
let pendingYouTubeVideo = null;
let lastLiveFocusMinutes = null;
let courseLibraryQuery = "";
let courseLibrarySource = "all";
let courseLibrarySort = "priority";
let courseLibraryLimit = 60;
let courseLibraryExpanded = false;
let openLibraryMenuId = null;
let editingLibraryId = null;
let deletingLibraryId = null;
let activeStudyLinkMenu = null;
try { courseLibraryExpanded = sessionStorage.getItem("courseFocusProStudyLinkLibraryExpanded") === "true"; } catch {}
const FOCUS_QUOTES = Object.freeze([
  "A clear hour can change the shape of a difficult topic.",
  "Protect the next small step. It is enough to begin.",
  "Return to the page. The work becomes lighter once it has your attention.",
  "Understanding grows where distraction ends.",
  "Make the next twenty minutes honest.",
  "Progress is often quiet: one concept, one page, one problem at a time.",
  "Do the part that makes tomorrow easier.",
  "Give the difficult idea enough uninterrupted time to become familiar.",
  "Consistency is built from the sessions you choose not to skip."
]);
let focusQuoteIndex = -1;
let focusQuoteShown = false;
let lastShownLevel = Number(sessionStorage.getItem("courseFocusProLastLevel") || 1);
let music = { ctx: null, gain: null, nodes: [], index: 0, playing: false, loop: true, shuffle: false, volume: 0.35, endTimer: null, imported: [], audio: null, source: "built-in", currentImportedId: null };
let uiSoundCtx = null;
const MUSIC_LIBRARY_KEY = "courseFocusProMusicLibrary";
const MUSIC_COMMAND_KEY = "courseFocusProMusicCommand";
const MUSIC_TRACKS = [
  { id: "lofi", title: "Lo-fi", description: "Soft warm tones for quiet study.", type: "tone", frequency: 196, wave: "triangle" },
  { id: "piano", title: "Piano", description: "Gentle piano-like pulses.", type: "tone", frequency: 261.63, wave: "sine" },
  { id: "nature", title: "Nature Sounds", description: "Light filtered ambience for calm focus.", type: "noise", filter: 1200 },
  { id: "white", title: "White Noise", description: "Even noise for blocking distractions.", type: "noise", filter: 5000 },
  { id: "rain", title: "Rain + Thunder", description: "Layered rain with soft distant thunder.", type: "rain" },
  { id: "brown", title: "Brown Noise", description: "Low smooth noise for concentration.", type: "noise", filter: 420 },
  { id: "deep", title: "Deep Focus", description: "Lower steady tone for long sessions.", type: "tone", frequency: 174, wave: "sine" },
  { id: "ocean", title: "Ocean Air", description: "Soft filtered wash for reading.", type: "noise", filter: 900 },
  { id: "wind", title: "Soft Wind", description: "Light airy texture for calm study.", type: "noise", filter: 2600 },
  { id: "warm", title: "Warm Pad", description: "Gentle pad for quiet problem solving.", type: "tone", frequency: 220, wave: "triangle" },
  { id: "coffee", title: "Coffee Shop Ambience", description: "Soft cafe room tone with warm background hum.", type: "coffee" },
  { id: "oceanwave", title: "Ocean Wave", description: "Slow breathing waves for relaxed study.", type: "oceanwave" },
  { id: "beat852", title: "852 Hz Beat", description: "A very subtle 852 Hz focus tone.", type: "tone", frequency: 852, wave: "sine", gain: 0.035, lfoFrequency: 3.2, lfoGain: 0.012 }
];

const el = {
  connectionLabel: $("#connectionLabel"), stateEyebrow: $("#stateEyebrow"), mainTitle: $("#mainTitle"), activeFocusIndicator: $("#activeFocusIndicator"), activeFocusStatus: $("#activeFocusStatus"), activeFocusCourse: $("#activeFocusCourse"), activeFocusViewBtn: $("#activeFocusViewBtn"), liveClock: $("#liveClock"), focusOpenCourseBtn: $("#focusOpenCourseBtn"),
  startForm: $("#startForm"), courseSelect: $("#courseSelect"), durationInput: $("#durationInput"), breakDurationInput: $("#breakDurationInput"), focusCyclesInput: $("#focusCyclesInput"), focusBreakValidation: $("#focusBreakValidation"), focusModePicker: $("#focusModePicker"), focusModeDescription: $("#focusModeDescription"), focusModeKicker: $("#focusModeKicker"), focusSessionSetup: $(".focus-session-setup"), focusConfigFields: $(".focus-config-fields"), focusBreakOptions: $("#focusBreakOptions"), focusDurationPresets: $("#focusDurationPresets"), focusCustomDurationField: $("#focusCustomDurationField"), focusHeadline: $("#focusHeadline"), focusPill: $("#focusPill"), focusWorkspace: $("#focusWorkspaceTourTarget"), selectedCourseTitle: $("#selectedCourseTitle"), selectedCourseMeta: $("#selectedCourseMeta"), changeCourseBtn: $("#changeCourseBtn"), startFocusBtn: $("#startFocusBtn"), timerProgress: $("#timerProgress"), timerText: $("#timerText"), timerCaption: $("#timerCaption"), focusRemainingText: $("#focusRemainingText"), focusQuote: $("#focusQuote"), pauseFocusBtn: $("#pauseFocusBtn"), resumeFocusBtn: $("#resumeFocusBtn"), stopFocusBtn: $("#stopFocusBtn"), focusExitConfirmation: $("#focusExitConfirmation"), focusExitCountdown: $("#focusExitCountdown"), cancelFocusEndBtn: $("#cancelFocusEndBtn"), endFocusNowBtn: $("#endFocusNowBtn"), focusSessionProgressWrap: $("#focusSessionProgressWrap"), focusSessionProgressLabel: $("#focusSessionProgressLabel"), focusSessionProgressValue: $("#focusSessionProgressValue"), focusSessionProgressFill: $("#focusSessionProgressFill"), focusEnhancements: $("#focusEnhancements"), focusEnhancementsToggle: $("#focusEnhancementsToggle"), focusEnhancementsBody: $("#focusEnhancementsBody"), incognitoEnhancementStatus: $("#incognitoEnhancementStatus"), youtubeEnhancementStatus: $("#youtubeEnhancementStatus"), cameraStatusMessage: $("#cameraStatusMessage"), cameraStatusState: $("#cameraStatusState"), guidedTourFeatureIntro: $("#guidedTourFeatureIntro"), guidedTourFeatureIntroSkip: $("#guidedTourFeatureIntroSkip"),
  todayFocus: $("#todayFocus"), todaySessions: $("#todaySessions"), todayBlocks: $("#todayBlocks"), todayScore: $("#todayScore"), todayInsightTitle: $("#todayInsightTitle"), todayInsightText: $("#todayInsightText"),
  courseForm: $("#courseForm"), courseTitleInput: $("#courseTitleInput"), courseSubjectInput: $("#courseSubjectInput"), courseLibraryInput: $("#courseLibraryInput"), courseUrlInput: $("#courseUrlInput"), courseOverview: $("#courseOverview"), studyLinkLibraryPanel: $("#studyLinkLibraryPanel"), studyLinkLibraryToggle: $("#studyLinkLibraryToggle"), courseLibrariesList: $("#courseLibrariesList"), courseCount: $("#courseCount"), courseLibrarySearch: $("#courseLibrarySearch"), courseLibrarySource: $("#courseLibrarySource"), courseLibrarySort: $("#courseLibrarySort"), libraryForm: $("#libraryForm"), libraryNameInput: $("#libraryNameInput"), libraryManagementList: $("#libraryManagementList"),
  siteControlSection: $("#siteControlSection"), siteControlToggle: $("#siteControlToggle"), siteControlBody: $("#siteControlBody"),
  allowedForm: $("#allowedForm"), allowedInput: $("#allowedInput"), allowedList: $("#allowedList"), allowedCount: $("#allowedCount"), allowedSearch: $("#allowedSearch"), addSupportingSiteBtn: $("#addSupportingSiteBtn"), addCurrentSiteBtn: $("#addCurrentSiteBtn"), blockedForm: $("#blockedForm"), blockedInput: $("#blockedInput"), blockedList: $("#blockedList"), blockedCount: $("#blockedCount"), blockedSearch: $("#blockedSearch"), addBlockedSiteBtn: $("#addBlockedSiteBtn"), distractionProtectionInput: $("#distractionProtectionInput"), distractionProtectionState: $("#distractionProtectionState"), distractionProtectionConsent: $("#distractionProtectionConsent"), distractionProtectionConsentAccept: $("#distractionProtectionConsentAccept"), distractionProtectionConsentDecline: $("#distractionProtectionConsentDecline"), incognitoProtectionInput: $("#incognitoProtectionInput"), incognitoProtectionState: $("#incognitoProtectionState"), openIncognitoSettingsBtn: $("#openIncognitoSettingsBtn"), youtubeStudyModeEnabledInput: $("#youtubeStudyModeEnabledInput"),
  currentStreak: $("#currentStreak"), analyticsToday: $("#analyticsToday"), analyticsWeek: $("#analyticsWeek"), analyticsWeekLabel: $("#analyticsWeekLabel"), analyticsWeekHint: $("#analyticsWeekHint"), analyticsSessions: $("#analyticsSessions"), analyticsSessionsHint: $("#analyticsSessionsHint"), analyticsGoalHint: $("#analyticsGoalHint"), weeklyHours: $("#weeklyHours"), averageStudy: $("#averageStudy"), goalProgress: $("#goalProgress"), dailyComparison: $("#dailyComparison"), xpPanel: $("#analyticsXpPopover"), analyticsXpBtn: $("#analyticsXpBtn"), analyticsXpPopover: $("#analyticsXpPopover"), analyticsXpCloseBtn: $("#analyticsXpCloseBtn"), rankTitle: $("#rankTitle"), rankMeta: $("#rankMeta"), xpProgressFill: $("#xpProgressFill"), badgeRow: $("#badgeRow"), dailyChart: $("#dailyChart"), dailyChartWrap: $("#dailyChartWrap"), dailyChartMeta: $("#dailyChartMeta"), dailyChartDescription: $("#dailyChartDescription"), dailyChartEmpty: $("#dailyChartEmpty"), subjectDistributionChart: $("#subjectDistributionChart"), subjectDistributionTotal: $("#subjectDistributionTotal"), subjectDistributionLegend: $("#subjectDistributionLegend"), subjectDistributionEmpty: $("#subjectDistributionEmpty"), todayStudySessionList: $("#todayStudySessionList"), todayStudySessionsEmpty: $("#todayStudySessionsEmpty"), subjectTargetSummary: $("#subjectTargetSummary"), consistencyMeta: $("#consistencyMeta"), consistencyGoalLabel: $("#consistencyGoalLabel"), consistencyGoalValue: $("#consistencyGoalValue"), consistencyGoalPercent: $("#consistencyGoalPercent"), consistencyGoalFill: $("#consistencyGoalFill"), consistencyDailyAverage: $("#consistencyDailyAverage"), consistencySessions: $("#consistencySessions"), consistencyAverageSession: $("#consistencyAverageSession"), consistencyLongestSession: $("#consistencyLongestSession"), courseHistoryPanel: $("#courseHistoryPanel"), courseHistoryToggle: $("#courseHistoryToggle"), courseHistoryCount: $("#courseHistoryCount"), courseHistorySearch: $("#courseHistorySearch"), courseHistorySort: $("#courseHistorySort"), courseHistoryList: $("#courseHistoryList"), analyticsCurrentBtn: $("#analyticsCurrentBtn"), analyticsPreviousWeekBtn: $("#analyticsPreviousWeekBtn"), analyticsPreviousMonthBtn: $("#analyticsPreviousMonthBtn"), analyticsHistoryDrawer: $("#analyticsHistoryDrawer"), analyticsHistoryTitle: $("#analyticsHistoryTitle"), analyticsHistoryComparison: $("#analyticsHistoryComparison"), analyticsHistoryTotal: $("#analyticsHistoryTotal"), analyticsHistorySessions: $("#analyticsHistorySessions"), analyticsHistoryAverage: $("#analyticsHistoryAverage"), analyticsHistoryGoal: $("#analyticsHistoryGoal"), analyticsHistoryCourses: $("#analyticsHistoryCourses"), analyticsHistoryCloseBtn: $("#analyticsHistoryCloseBtn"),
  currentStreak: $("#currentStreak"), analyticsToday: $("#analyticsToday"), analyticsWeek: $("#analyticsWeek"), analyticsWeekLabel: $("#analyticsWeekLabel"), analyticsWeekHint: $("#analyticsWeekHint"), analyticsSessions: $("#analyticsSessions"), analyticsSessionsHint: $("#analyticsSessionsHint"), analyticsGoalHint: $("#analyticsGoalHint"), weeklyHours: $("#weeklyHours"), averageStudy: $("#averageStudy"), goalProgress: $("#goalProgress"), dailyComparison: $("#dailyComparison"), xpPanel: $("#analyticsXpPopover"), analyticsXpBtn: $("#analyticsXpBtn"), analyticsXpPopover: $("#analyticsXpPopover"), analyticsXpCloseBtn: $("#analyticsXpCloseBtn"), rankTitle: $("#rankTitle"), rankMeta: $("#rankMeta"), xpProgressFill: $("#xpProgressFill"), badgeRow: $("#badgeRow"), dailyChart: $("#dailyChart"), dailyChartMeta: $("#dailyChartMeta"), dailyChartGoal: $("#dailyChartGoal"), dailyChartEmpty: $("#dailyChartEmpty"), courseDistributionList: $("#courseDistributionList"), courseDistributionMeta: $("#courseDistributionMeta"), courseDistributionEmpty: $("#courseDistributionEmpty"), subjectTargetSummary: $("#subjectTargetSummary"), subjectChartSort: $("#subjectChartSort"), analyticsTargetsToggle: $("#analyticsTargetsToggle"), analyticsTargetsEditor: $("#analyticsTargetsEditor"), analyticsTargetsForm: $("#analyticsTargetsForm"), analyticsTargetsProfileNote: $("#analyticsTargetsProfileNote"), analyticsDailyTargetInput: $("#analyticsDailyTargetInput"), analyticsWeeklyTargetInput: $("#analyticsWeeklyTargetInput"), analyticsTargetSubjectList: $("#analyticsTargetSubjectList"), analyticsTargetsClose: $("#analyticsTargetsClose"), analyticsTargetsCancel: $("#analyticsTargetsCancel"), analyticsTargetsRestore: $("#analyticsRestoreTargets"), analyticsAddSubjectBtn: $("#analyticsAddSubjectBtn"), analyticsAddSubjectRow: $("#analyticsAddSubjectRow"), analyticsNewSubjectInput: $("#analyticsNewSubjectInput"), analyticsConfirmAddSubject: $("#analyticsConfirmAddSubject"), consistencyMeta: $("#consistencyMeta"), consistencyGoalLabel: $("#consistencyGoalLabel"), consistencyGoalValue: $("#consistencyGoalValue"), consistencyGoalPercent: $("#consistencyGoalPercent"), consistencyGoalFill: $("#consistencyGoalFill"), consistencyDailyAverage: $("#consistencyDailyAverage"), consistencySessions: $("#consistencySessions"), consistencyAverageSession: $("#consistencyAverageSession"), consistencyLongestSession: $("#consistencyLongestSession"), courseHistoryPanel: $("#courseHistoryPanel"), courseHistoryToggle: $("#courseHistoryToggle"), courseHistoryCount: $("#courseHistoryCount"), courseHistorySearch: $("#courseHistorySearch"), courseHistorySort: $("#courseHistorySort"), courseHistoryList: $("#courseHistoryList"), analyticsCurrentBtn: $("#analyticsCurrentBtn"), analyticsPreviousWeekBtn: $("#analyticsPreviousWeekBtn"), analyticsPreviousMonthBtn: $("#analyticsPreviousMonthBtn"), analyticsHistoryDrawer: $("#analyticsHistoryDrawer"), analyticsHistoryTitle: $("#analyticsHistoryTitle"), analyticsHistoryComparison: $("#analyticsHistoryComparison"), analyticsHistoryTotal: $("#analyticsHistoryTotal"), analyticsHistorySessions: $("#analyticsHistorySessions"), analyticsHistoryAverage: $("#analyticsHistoryAverage"), analyticsHistoryGoal: $("#analyticsHistoryGoal"), analyticsHistoryCourses: $("#analyticsHistoryCourses"), analyticsHistoryCloseBtn: $("#analyticsHistoryCloseBtn"),
  missionForm: $("#missionForm"), missionTitleInput: $("#missionTitleInput"), missionAreaInput: $("#missionAreaInput"), missionMinutesInput: $("#missionMinutesInput"), missionNoteInput: $("#missionNoteInput"), systemGoalsList: $("#systemGoalsList"), personalTaskList: $("#personalTaskList"), missionProgressText: $("#missionProgressText"), missionProgressFill: $("#missionProgressFill"), resetTasksBtn: $("#resetTasksBtn"),
  musicCategories: $("#musicCategories"), musicStatus: $("#musicStatus"), musicTitle: $("#musicTitle"), musicDescription: $("#musicDescription"), musicVolumeLabel: $("#musicVolumeLabel"), musicPrevBtn: $("#musicPrevBtn"), musicBackBtn: $("#musicBackBtn"), musicForwardBtn: $("#musicForwardBtn"), musicPlayBtn: $("#musicPlayBtn"), musicPlayIcon: $("#musicPlayIcon"), musicPlayLabel: $("#musicPlayLabel"), musicNextBtn: $("#musicNextBtn"), musicShuffleBtn: $("#musicShuffleBtn"), musicVolumeInput: $("#musicVolumeInput"), musicLoopInput: $("#musicLoopInput"), musicImportInput: $("#musicImportInput"), myMusicList: $("#myMusicList"),
  studyProfileSelect: $("#studyProfileSelect"), themeModeSelect: $("#themeModeSelect"), soundEnabledInput: $("#soundEnabledInput"), soundVolumeInput: $("#soundVolumeInput"), soundVolumeLabel: $("#soundVolumeLabel"), soundVolumeSetting: $("#soundVolumeSetting"), cameraAttentionEnabledInput: $("#cameraAttentionEnabledInput"), cameraAttentionSensitivityInput: $("#cameraAttentionSensitivityInput"), cameraAttentionGraceInput: $("#cameraAttentionGraceInput"), cameraAttentionVoiceInput: $("#cameraAttentionVoiceInput"), cameraPermissionBtn: $("#cameraPermissionBtn"), cameraAdvancedSettings: $("#cameraAdvancedSettings"), cameraSettingsState: $("#cameraSettingsState"), settingsFocusMinutesInput: $("#settingsFocusMinutesInput"), settingsFocusModeSelect: $("#settingsFocusModeSelect"), settingsFocusBreakDefaults: $("#settingsFocusBreakDefaults"), settingsBreakMinutesInput: $("#settingsBreakMinutesInput"), settingsFocusCyclesInput: $("#settingsFocusCyclesInput"), focusCommitmentModal: $("#focusCommitmentModal"), commitmentMode: $("#commitmentMode"), commitmentStudyTime: $("#commitmentStudyTime"), commitmentBreakSummary: $("#commitmentBreakSummary"), commitmentBreakTime: $("#commitmentBreakTime"), focusCommitmentNote: $("#focusCommitmentNote"), cancelFocusCommitmentBtn: $("#cancelFocusCommitmentBtn"), confirmFocusCommitmentBtn: $("#confirmFocusCommitmentBtn"), settingsForm: $("#settingsForm"), resetAnalyticsBtn: $("#resetAnalyticsBtn"), clearAllDataBtn: $("#clearAllDataBtn"), exportJsonBtn: $("#exportJsonBtn"), restoreBackupBtn: $("#restoreBackupBtn"), restoreBackupInput: $("#restoreBackupInput"), backupStatus: $("#backupStatus"), sidebarMoreNav: $("#sidebarMoreNav"),
  helpPopover: $("#helpPopover"), toast: $("#toast"), undoBar: $("#undoBar"), undoText: $("#undoText"), undoBtn: $("#undoBtn"), completionModal: $("#completionModal"), completionSubject: $("#completionSubject"), completionDuration: $("#completionDuration"), completionXp: $("#completionXp"), completionToday: $("#completionToday"), completionStreak: $("#completionStreak"), completionStartBtn: $("#completionStartBtn"), completionBreakBtn: $("#completionBreakBtn"), completionCloseBtn: $("#completionCloseBtn"), welcomeBackModal: $("#welcomeBackModal"), welcomeBackTime: $("#welcomeBackTime"), welcomeResumeBtn: $("#welcomeResumeBtn"), welcomeEndBtn: $("#welcomeEndBtn"), welcomeDismissBtn: $("#welcomeDismissBtn"), courseModal: $("#courseModal"), courseModalClose: $("#courseModalClose"), courseSwitchList: $("#courseSwitchList"), libraryDeleteModal: $("#libraryDeleteModal"), libraryDeleteTitle: $("#libraryDeleteTitle"), libraryDeleteMessage: $("#libraryDeleteMessage"), libraryDeleteCourseSummary: $("#libraryDeleteCourseSummary"), libraryDeleteSafety: $("#libraryDeleteSafety"), libraryDeleteClose: $("#libraryDeleteClose"), libraryDeleteCancel: $("#libraryDeleteCancel"), libraryDeleteConfirm: $("#libraryDeleteConfirm"), youtubeAddModal: $("#youtubeAddModal"), youtubeAddCloseBtn: $("#youtubeAddCloseBtn"), youtubeAddVideoTitle: $("#youtubeAddVideoTitle"), youtubeTitleConsent: $("#youtubeTitleConsent"), youtubeTitleLookupBtn: $("#youtubeTitleLookupBtn"), youtubeTitleManualBtn: $("#youtubeTitleManualBtn"), youtubeTitleLookupStatus: $("#youtubeTitleLookupStatus"), youtubeNewForm: $("#youtubeNewForm"), youtubeNewTitleInput: $("#youtubeNewTitleInput"), youtubeNewSubjectSelect: $("#youtubeNewSubjectSelect"), youtubeNewLibrarySelect: $("#youtubeNewLibrarySelect"), onboardingOverlay: $("#onboardingOverlay"), onboardingCard: $("#onboardingCard"), onboardingProgressText: $("#onboardingProgressText"), onboardingProgressFill: $("#onboardingProgressFill"), onboardingGetStartedBtn: $("#onboardingGetStartedBtn"), onboardingNameInput: $("#onboardingNameInput"), onboardingThemeOptions: $("#onboardingThemeOptions"), onboardingFocusMinutesInput: $("#onboardingFocusMinutesInput"), onboardingProfileCards: $("#onboardingProfileCards"), onboardingProfileNextBtn: $("#onboardingProfileNextBtn"), onboardingTargetEditor: $("#onboardingTargetEditor"), onboardingDailyTargetInput: $("#onboardingDailyTargetInput"), onboardingWeeklyTargetInput: $("#onboardingWeeklyTargetInput"), onboardingTargetSubjectList: $("#onboardingTargetSubjectList"), onboardingAddSubjectBtn: $("#onboardingAddSubjectBtn"), onboardingAddSubjectRow: $("#onboardingAddSubjectRow"), onboardingNewSubjectInput: $("#onboardingNewSubjectInput"), onboardingConfirmAddSubject: $("#onboardingConfirmAddSubject"), onboardingProtectionNextBtn: $("#onboardingProtectionNextBtn"), onboardingReadyName: $("#onboardingReadyName"), onboardingReadyProfile: $("#onboardingReadyProfile"), onboardingReadyTheme: $("#onboardingReadyTheme"), onboardingReadyDuration: $("#onboardingReadyDuration"), onboardingReadyDailyTarget: $("#onboardingReadyDailyTarget"), onboardingReadyWeeklyTarget: $("#onboardingReadyWeeklyTarget"), onboardingReadySubjects: $("#onboardingReadySubjects"), onboardingReadyMessage: $("#onboardingReadyMessage"), finishTutorialBtn: $("#finishTutorialBtn"), showOnboardingBtn: $("#showOnboardingBtn"), startGuidedTourBtn: $("#startGuidedTourBtn"), guidedTour: $("#guidedTour"), guidedTourBackdrop: $("#guidedTourBackdrop"), guidedTourSpotlight: $("#guidedTourSpotlight"), guidedTourCard: $("#guidedTourCard"), guidedTourTitle: $("#guidedTourTitle"), guidedTourDescription: $("#guidedTourDescription"), guidedTourCoursesFlow: $("#guidedTourCoursesFlow"), guidedTourAnalyticsPreview: $("#guidedTourAnalyticsPreview"), guidedTourPopupGuide: $("#guidedTourPopupGuide"), guidedTourDistractionGuide: $("#guidedTourDistractionGuide"), guidedTourProgressText: $("#guidedTourProgressText"), guidedTourProgressFill: $("#guidedTourProgressFill"), guidedTourBackBtn: $("#guidedTourBackBtn"), guidedTourNextBtn: $("#guidedTourNextBtn"), guidedTourYouTubeBtn: $("#guidedTourYouTubeBtn"), guidedTourPopupBtn: $("#guidedTourPopupBtn"), guidedTourSkipBtn: $("#guidedTourSkipBtn"), developerEmail: $("#developerEmail")
};
el.youtubeStudyModeState = $("#youtubeStudyModeState");
el.cameraAttentionState = $("#cameraAttentionState");
el.focusIncognitoProtectionInput = $("#focusIncognitoProtectionInput");
el.focusCameraAttentionInput = $("#focusCameraAttentionInput");
el.focusYouTubeStudyModeInput = $("#focusYouTubeStudyModeInput");
el.focusSessionProtectionInput = $("#focusSessionProtectionInput");
el.focusSessionProtectionState = $("#focusSessionProtectionState");
el.focusSessionProtectionConsent = $("#focusSessionProtectionConsent");
el.focusSessionProtectionConsentAccept = $("#focusSessionProtectionConsentAccept");
el.focusSessionProtectionConsentDecline = $("#focusSessionProtectionConsentDecline");
el.studyTimingRows = $("#studyTimingRows");
el.studyTimingInsight = $("#studyTimingInsight");
el.studyTimingEmpty = $("#studyTimingEmpty");
el.studyTimingNote = $("#studyTimingNote");
el.cameraStatusPermissionBtn = $("#cameraStatusPermissionBtn");
el.cameraConsentModal = $("#cameraConsentModal");
el.cameraConsentAcceptBtn = $("#cameraConsentAcceptBtn");
el.cameraConsentDeclineBtn = $("#cameraConsentDeclineBtn");
el.settingsSaveStatus = $("#settingsSaveStatus");
el.settingsBreakValidation = $("#settingsBreakValidation");
el.profileTargetsConfirmModal = $("#profileTargetsConfirmModal");
el.profileTargetsConfirmMessage = $("#profileTargetsConfirmMessage");
el.applyProfileTargetsBtn = $("#applyProfileTargets");
el.keepProfileTargetsBtn = $("#keepProfileTargets");
el.cancelProfileTargetsChangeBtn = $("#cancelProfileTargetsChange");
el.breakHelpBtn = $("#breakHelpBtn");
el.breakHelpPopover = $("#breakHelpPopover");
el.breakHelpExample = $("#breakHelpExample");
el.focusBreakPreview = $("#focusBreakPreview");
el.focusBreakPreviewSequence = $("#focusBreakPreviewSequence");
el.focusBreakPreviewStudy = $("#focusBreakPreviewStudy");
el.focusBreakPreviewElapsed = $("#focusBreakPreviewElapsed");
el.breakSessionDetails = $("#breakSessionDetails");
el.breakHelpAnchor = $("#breakHelpAnchor");
el.focusModeSelectionRow = $("#focusModeSelectionRow");
el.breakSessionPhaseHeading = $(".break-session-phase-heading");
el.breakSessionPhase = $("#breakSessionPhase");
el.breakSessionBlock = $("#breakSessionBlock");
el.breakSessionMessage = $("#breakSessionMessage");
el.breakSessionTimeline = $("#breakSessionTimeline");

function sendMessage(message) { return hasChrome ? chrome.runtime.sendMessage(message) : Promise.resolve({ ok: false }); }
function resolvedTheme(mode) { const allowed = ["light", "dark", "midnight", "amoled", "beige"]; if (allowed.includes(mode)) return mode; if (mode === "system") return systemThemeQuery?.matches ? "dark" : "light"; return "dark"; }
function applyTheme(modeOverride = null) { const mode = modeOverride || state.settings.themeMode || "dark"; document.documentElement.dataset.theme = resolvedTheme(mode); document.documentElement.dataset.themeMode = mode; try { localStorage.setItem(THEME_MODE_CACHE_KEY, mode); } catch {} if (el.themeModeSelect && modeOverride === null) el.themeModeSelect.value = mode; }
function showToast(message) { el.toast.textContent = message; el.toast.classList.add("show"); clearTimeout(toastTimer); toastTimer = setTimeout(() => el.toast.classList.remove("show"), 2400); }
function showUndo(message, snapshot, localSnapshot = null) { undoSnapshot = snapshot ? JSON.parse(JSON.stringify(snapshot)) : null; undoLocalStorageSnapshot = localSnapshot; if (!undoSnapshot) return; el.undoText.textContent = message; el.undoBar.classList.remove("hidden"); clearTimeout(undoTimer); undoTimer = setTimeout(() => { el.undoBar.classList.add("hidden"); undoSnapshot = null; undoLocalStorageSnapshot = null; }, 7000); }
function hours(minutes) { return Math.round((Number(minutes || 0) / 60) * 10) / 10 + "h"; }
function activeSession() { const session = state.focusSession; return session?.active ? session : null; }
function cameraAttentionLabel(session = activeSession()) {
  const attention = state.attention || {};
  if (!state.settings.cameraAttentionEnabled) return "Camera Focus Check is off. Enable it in Settings to use attention checks during Focus.";
  if (!session) return "Camera Focus Check beta is ready for your next focus session";
  if (session.phase === "break") return "Camera Focus Check is paused during your scheduled break";
  if (session.paused) return "Camera is off while Focus Mode is paused";
  const labels = {
    starting: "Starting",
    calibrating: "Calibrating",
    watching: "Watching",
    "attention-lost": "Attention detected",
    "needs-position": "Needs positioning",
    "permission-denied": "Camera permission denied",
    unsupported: "Not available in this Chrome version",
    error: attention.error || "Camera check error"
  };
  return labels[attention.status] || "Camera check is preparing";
}
function cameraAttentionIcon(session = activeSession()) {
  const status = state.attention?.status || "off";
  if (!state.settings.cameraAttentionEnabled || !session) return "⚪";
  if (session.paused) return "⏸";
  return { starting: "◌", calibrating: "🟡", watching: "🟢", "attention-lost": "🔴", "needs-position": "⚠️", "permission-denied": "❌", unsupported: "❌", error: "❌" }[status] || "◌";
}
function attentionReminderText(reason) {
  if (reason === "eyes closed") return "Attention: your eyes have been closed for a while.";
  if (reason === "eyes away from screen") return "Attention: bring your gaze back to the lesson.";
  return "Attention: you have been away from the course for a while.";
}
function renderCameraAttention(session = activeSession()) {
  const permissionGranted = cameraPermissionState === "granted";
  const permissionChecking = cameraPermissionState === "checking";
  const consentAccepted = Boolean(state.settings.cameraAttentionConsentAccepted);
  const enabled = Boolean(state.settings.cameraAttentionEnabled && consentAccepted && permissionGranted);
  const permissionRequired = !consentAccepted || !permissionGranted;
  if (el.cameraStatusState) {
    el.cameraStatusState.textContent = permissionChecking ? "Checking permission" : permissionRequired ? "Permission Required" : enabled ? "On" : "Off";
    el.cameraStatusState.dataset.state = permissionChecking ? "checking" : permissionRequired ? "required" : enabled ? "on" : "off";
  }
  if (el.focusCameraAttentionInput) {
    el.focusCameraAttentionInput.checked = enabled;
    el.focusCameraAttentionInput.disabled = !permissionGranted || !consentAccepted;
  }
  if (el.cameraStatusPermissionBtn) {
    el.cameraStatusPermissionBtn.textContent = !consentAccepted ? "Review Camera Use →" : permissionChecking ? "Checking..." : permissionGranted ? "Settings →" : "Allow Camera →";
    el.cameraStatusPermissionBtn.disabled = cameraConsentSaving || (consentAccepted && permissionChecking);
    el.cameraStatusPermissionBtn.title = !consentAccepted ? "Review camera processing before enabling Camera Focus Check." : permissionGranted ? "Open Camera Focus Check settings." : "Allow camera access to use Camera Focus Check.";
  }
  if (el.cameraSettingsState) el.cameraSettingsState.textContent = !consentAccepted
    ? "Review and accept the camera disclosure before enabling Camera Focus Check."
    : cameraPermissionState !== "granted"
      ? cameraPermissionState === "checking" ? "Checking camera permission..." : "Camera permission is required. Choose Allow Camera Access to continue."
    : cameraAttentionLabel(session);
}
async function applyCameraPermissionState(permissionState) {
  cameraPermissionState = permissionState || "unsupported";
  if ((cameraPermissionState !== "granted" || !state.settings.cameraAttentionConsentAccepted) && state.settings.cameraAttentionEnabled) {
    try {
      await updateSettings({ cameraAttentionEnabled: false });
      if (hasChrome) await sendMessage({ type: "syncAttentionMonitor" });
    } catch {}
  }
  render();
  return cameraPermissionState === "granted";
}
async function refreshCameraPermissionStatus() {
  if (!navigator.permissions?.query) return applyCameraPermissionState("unsupported");
  try {
    const permission = await navigator.permissions.query({ name: "camera" });
    if (cameraPermissionQuery !== permission) {
      if (cameraPermissionQuery) cameraPermissionQuery.onchange = null;
      cameraPermissionQuery = permission;
      cameraPermissionQuery.onchange = () => { void applyCameraPermissionState(permission.state); };
    }
    return await applyCameraPermissionState(permission.state);
  } catch {
    return applyCameraPermissionState("unsupported");
  }
}
function setFocusEnhancementsExpanded(expanded) {
  focusEnhancementsExpanded = Boolean(expanded);
  try { sessionStorage.setItem("studizenFocusEnhancementsExpanded", String(focusEnhancementsExpanded)); } catch {}
  if (el.focusEnhancements) el.focusEnhancements.dataset.expanded = String(focusEnhancementsExpanded);
  el.focusEnhancementsToggle?.setAttribute("aria-expanded", String(focusEnhancementsExpanded));
  if (el.focusEnhancementsBody) {
    el.focusEnhancementsBody.classList.toggle("is-expanded", focusEnhancementsExpanded);
    el.focusEnhancementsBody.setAttribute("aria-hidden", String(!focusEnhancementsExpanded));
    el.focusEnhancementsBody.toggleAttribute("inert", !focusEnhancementsExpanded);
  }
}
function renderFocusEnhancements() {
  if (!el.focusEnhancements) return;
  el.focusEnhancements.dataset.expanded = String(focusEnhancementsExpanded);
  el.focusEnhancementsToggle?.setAttribute("aria-expanded", String(focusEnhancementsExpanded));
  if (el.focusEnhancementsBody) {
    el.focusEnhancementsBody.classList.toggle("is-expanded", focusEnhancementsExpanded);
    el.focusEnhancementsBody.setAttribute("aria-hidden", String(!focusEnhancementsExpanded));
    el.focusEnhancementsBody.toggleAttribute("inert", !focusEnhancementsExpanded);
  }
  const incognitoEnabled = Boolean(state.settings.incognitoProtection && incognitoAccessAllowed === true);
  const incognitoLabel = incognitoAccessAllowed === null
    ? "Checking access"
    : incognitoAccessAllowed === false ? "Permission Required" : incognitoEnabled ? "On" : "Off";
  if (el.incognitoEnhancementStatus) {
    el.incognitoEnhancementStatus.textContent = incognitoLabel;
    el.incognitoEnhancementStatus.dataset.state = incognitoAccessAllowed === null ? "checking" : incognitoAccessAllowed === false ? "required" : incognitoEnabled ? "on" : "off";
  }
  $$('[data-focus-enhancement-settings="incognito"]').forEach((button) => {
    if (button.firstChild) button.firstChild.textContent = incognitoAccessAllowed === false ? "Allow in Chrome " : incognitoAccessAllowed === null ? "Checking " : "Settings ";
    button.disabled = incognitoAccessAllowed === null;
    button.title = incognitoAccessAllowed === false
      ? "Open Chrome extension settings and enable Allow in Incognito for Studizen."
      : "Open Incognito Protection settings.";
  });
  if (el.focusIncognitoProtectionInput) {
    el.focusIncognitoProtectionInput.checked = incognitoEnabled;
    el.focusIncognitoProtectionInput.disabled = incognitoAccessAllowed !== true;
  }
  if (el.incognitoProtectionInput) {
    el.incognitoProtectionInput.checked = incognitoEnabled;
    el.incognitoProtectionInput.disabled = incognitoAccessAllowed !== true;
  }
  const cameraEnabled = Boolean(state.settings.cameraAttentionEnabled && state.settings.cameraAttentionConsentAccepted && cameraPermissionState === "granted");
  const youtubeEnabled = Boolean(state.settings.youtubeStudyModeEnabled);
  if (el.focusCameraAttentionInput) {
    el.focusCameraAttentionInput.checked = cameraEnabled;
    el.focusCameraAttentionInput.disabled = cameraPermissionState !== "granted" || !state.settings.cameraAttentionConsentAccepted;
  }
  if (el.focusYouTubeStudyModeInput) el.focusYouTubeStudyModeInput.checked = youtubeEnabled;
  if (el.youtubeStudyModeEnabledInput) el.youtubeStudyModeEnabledInput.checked = youtubeEnabled;
  if (el.youtubeEnhancementStatus) {
    el.youtubeEnhancementStatus.textContent = youtubeEnabled ? "On" : "Off";
    el.youtubeEnhancementStatus.dataset.state = youtubeEnabled ? "on" : "off";
  }
}
async function dismissFocusEnhancementsIntro() {
  if (state.profile?.focusEnhancementsIntroDismissed) return;
  await saveState({ ...state, profile: { ...(state.profile || {}), focusEnhancementsIntroDismissed: true } }, { skipGuidedTourRender: true });
  renderFocusEnhancements();
}
async function openFocusEnhancementSettings(feature) {
  const targets = { incognito: "incognitoProtectionHeading", camera: "cameraAttentionHeading", youtube: "youtubeStudyModeHeading" };
  const targetId = targets[feature];
  if (!targetId) return;
  setActiveTab("settings");
  syncGuidedTourToManualTab("settings");
  renderSettings();
  await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
  const target = document.getElementById(targetId);
  target?.scrollIntoView({ block: "center", behavior: "smooth" });
  target?.focus({ preventScroll: true });
}
function validUrl(raw) { const url = safeUrl(raw); return url && /^https?:/.test(url.protocol) ? url.href : ""; }
function inferTitle(url) { const host = safeUrl(url)?.hostname.replace(/^www\./, "") || "Study"; return host.includes("youtube") || host.includes("youtu.be") ? "YouTube Course" : host; }
function completedAnalytics() { const history = state.analytics?.focusHistory || []; const signature = String(state.profile?.studyProfile || "") + "|" + history.map((item) => [item?.id, item?.status, item?.completed, item?.actualMinutes, item?.endedAt, item?.recordedDate].join(":" )).join("|"); if (completedAnalyticsCache.signature !== signature) completedAnalyticsCache = { signature, summary: completedFocusAnalytics(state) }; return completedAnalyticsCache.summary; }
function recordedAnalytics() { const history = state.analytics?.focusHistory || []; const signature = String(state.profile?.studyProfile || "") + "|" + String(state.goals?.analyticsTargets?.customSubjects || "") + "|" + (state.courses || []).map((course) => [course.id, course.subject].join(":" )).join("|") + "|" + history.map((item) => [item?.id, item?.actualTracked, item?.status, item?.actualMinutes, item?.durationMinutes, item?.endedAt, item?.recordedDate, item?.subject, item?.courseId, item?.courseTitle, item?.timingVersion, item?.activeIntervalStartedAt, JSON.stringify(item?.activeIntervals || [])].join(":" )).join("|"); if (recordedAnalyticsCache.signature !== signature) recordedAnalyticsCache = { signature, summary: recordedStudyAnalytics(state) }; return recordedAnalyticsCache.summary; }
function completedFocusSessions(days = null) { const summary = completedAnalytics(); if (!days) return summary.sessions; const keys = new Set(dateSeries(days)); return summary.sessions.filter((item) => keys.has(item.recordedDate)); }
function actualFocusSessions(days = null) { return completedFocusSessions(days); }
function sessionActualMinutes(item) { return Math.max(0, Number(item?.actualMinutes ?? item?.durationMinutes) || 0); }
function actualMinutesToday() { return actualStudyMinutesForDate(state, todayKey()); }
function completedMinutesToday() { return completedAnalytics().todayMinutes; }
function completedSessionsToday() { const today = completedAnalytics().today; return completedFocusSessions().filter((item) => item.recordedDate === today).length; }
function currentSubjects() { return [...new Set([...subjectsForProfile(state.profile?.studyProfile), ...(state.goals?.analyticsTargets?.customSubjects || []), ...(state.courses || []).map((course) => String(course.subject || "").trim()), ...(state.analytics?.focusHistory || []).map((item) => String(item.subject || "").trim())].filter(Boolean))]; }
function subjectTotalsFromHistory(days = null) { const subjects = currentSubjects(); const totals = Object.fromEntries(subjects.map((subject) => [subject, { minutes: 0, sessions: 0 }])); const keys = days ? new Set(dateSeries(days)) : null; completedFocusSessions().forEach((item) => { if (keys && !keys.has(item.recordedDate)) return; const subject = normalizeSubject(item.subject, state.profile?.studyProfile); if (!totals[subject]) totals[subject] = { minutes: 0, sessions: 0 }; totals[subject].minutes += sessionActualMinutes(item); totals[subject].sessions += 1; }); return totals; }
function courseStudyMinutes(courseId) { const course = state.courses.find((item) => item.id === courseId); return completedFocusSessions().filter((item) => item.courseId === courseId || (!item.courseId && item.courseTitle === course?.title)).reduce((sum, item) => sum + sessionActualMinutes(item), 0); }
function playUiSound(kind = "soft") {
  if (!state.settings.soundEnabled || Number(state.settings.soundVolume || 0) <= 0) return;
  try {
    uiSoundCtx ||= new (window.AudioContext || window.webkitAudioContext)();
    const ctx = uiSoundCtx;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const volume = Math.max(0, Math.min(0.18, Number(state.settings.soundVolume || 35) / 600));
    osc.type = "sine";
    osc.frequency.value = kind === "complete" ? 740 : 440;
    gain.gain.setValueAtTime(0, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(volume, ctx.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.22);
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.24);
  } catch {}
}
function setActiveTab(tab) {
  const button = document.querySelector(".tab-button[data-tab='" + tab + "']");
  const panel = $("#tab-" + tab);
  if (!button || !panel) return;
  setAnalyticsXpOpen(false);
  if (button.closest(".secondary-nav") && el.sidebarMoreNav) el.sidebarMoreNav.open = true;
  $$(".tab-button").forEach((b) => b.classList.toggle("active", b === button));
  $$(".tab-panel").forEach((p) => p.classList.toggle("active", p === panel));
  renderHeader();
  renderFocusEnhancements();
  if (tab === "focus") rotateFocusQuote();
  if (tab === "analytics") requestAnimationFrame(() => renderAnalytics());
  if (tab === "daily") requestAnimationFrame(() => renderMissions());
}

function guidedTourIsEligible() {
  const profile = state.profile || {};
  return Boolean(profile.onboarded)
    && profile.guidedTourStatus === "not_started"
    && Number(profile.guidedTourVersion) === GUIDED_TOUR_VERSION;
}

function guidedTourStoredStep() {
  return Math.max(0, Math.min(GUIDED_TOUR_STEPS.length - 1, Number(state.profile?.guidedTourStep) || 0));
}

function guidedTourHandoff() {
  return normalizeGuidedTourHandoff(state.profile?.guidedTourHandoff);
}

function guidedTourCourseRequirementMet() {
  const handoff = guidedTourHandoff();
  return handoff ? Boolean(savedVideoCourse(handoff.url)) : state.courses.length > 0;
}

function guidedTourCourseFormIsReady() {
  const handoff = guidedTourHandoff();
  return Boolean(handoff && canonicalYouTubeVideoUrl(el.courseUrlInput?.value || "") === handoff.url && !savedVideoCourse(handoff.url));
}

async function clearGuidedTourHandoff(handoffId = null) {
  const handoff = guidedTourHandoff();
  if (!handoff || (handoffId && handoff.id !== handoffId)) return false;
  await saveState({ ...state, profile: { ...(state.profile || {}), guidedTourHandoff: null } }, { skipGuidedTourRender: true });
  return true;
}

function currentDashboardTabId() {
  if (!hasChrome || !chrome.tabs) return Promise.resolve(null);
  return new Promise((resolve) => {
    if (!chrome.tabs.getCurrent) return resolve(null);
    try {
      chrome.tabs.getCurrent((tab) => {
        void chrome.runtime.lastError;
        resolve(Number.isInteger(tab?.id) && tab.id >= 0 ? tab.id : null);
      });
    } catch { resolve(null); }
  });
}

async function dashboardTabExists(tabId) {
  if (!Number.isInteger(tabId) || !hasChrome || !chrome.tabs?.get) return false;
  try {
    const tab = await chrome.tabs.get(tabId);
    return Boolean(tab?.url?.startsWith(chrome.runtime.getURL("dashboard.html")));
  } catch {
    return false;
  }
}

async function guidedTourOwnedByAnotherTab() {
  const storedTabId = Number(state.profile?.guidedTourTabId);
  if (!state.profile?.guidedTourActive || !Number.isInteger(storedTabId)) return false;
  if (guidedTourTabId && storedTabId === guidedTourTabId) return false;
  return dashboardTabExists(storedTabId);
}

async function persistGuidedTourSession(active, step = guidedTourStepIndex, tabId = guidedTourTabId) {
  const previousSessionId = state.profile?.guidedTourSessionId || null;
  const sessionId = active ? previousSessionId || uid("guided-tour-session") : previousSessionId;
  const nextProfile = {
    ...(state.profile || {}),
    guidedTourStatus: active ? "not_started" : (state.profile?.guidedTourStatus || "completed"),
    guidedTourVersion: GUIDED_TOUR_VERSION,
    guidedTourActive: Boolean(active),
    guidedTourStep: Math.max(0, Math.min(GUIDED_TOUR_STEPS.length - 1, Number(step) || 0)),
    guidedTourTabId: active && Number.isInteger(tabId) ? tabId : null,
    guidedTourSessionId: active ? sessionId : null,
    guidedTourUpdatedAt: Date.now()
  };
  await saveState({ ...state, profile: nextProfile }, { skipGuidedTourRender: true });
  if (hasChrome && sessionId) {
    try {
      await sendMessage({ type: "syncGuidedTourSession", payload: { active: Boolean(active), sessionId, step: nextProfile.guidedTourStep, tabId } });
    } catch {}
  }
}

function setGuidedTourSuspended(suspended) {
  guidedTourSuspended = Boolean(suspended);
  if (!el.guidedTour) return;
  el.guidedTour.classList.toggle("hidden", guidedTourSuspended || !guidedTourActive);
}

function nextAnimationFrame() {
  return new Promise((resolve) => requestAnimationFrame(resolve));
}

async function settleGuidedTourLayout() {
  // A tab change may schedule chart/list rendering for the following frame.
  await nextAnimationFrame();
  await nextAnimationFrame();
}

function guidedTourValue(value, step) {
  return typeof value === "function" ? value(step) : value;
}

function guidedTourTarget(step = GUIDED_TOUR_STEPS[guidedTourStepIndex]) {
  const selector = guidedTourValue(step?.selector, step);
  return selector ? document.querySelector(selector) : null;
}

function isGuidedTourTargetVisible(target) {
  if (!target?.isConnected || !target.getClientRects().length) return false;
  const rect = target.getBoundingClientRect();
  return rect.width > 1 && rect.height > 1;
}

function guidedTourSpotlightRect(target, step = GUIDED_TOUR_STEPS[guidedTourStepIndex], reservedBelow = 0) {
  if (!isGuidedTourTargetVisible(target)) return null;
  const rect = target.getBoundingClientRect();
  const inset = 7;
  const edge = 8;
  const left = Math.max(edge, rect.left - inset);
  const top = Math.max(edge, rect.top - inset);
  const right = Math.min(window.innerWidth - edge, rect.right + inset);
  let bottom = Math.min(window.innerHeight - edge, rect.bottom + inset);
  // Workspace steps show the real dashboard area, but intentionally leave a
  // usable strip below it for the coach mark and its navigation controls.
  if (guidedTourValue(step?.spotlight, step) === "workspace") {
    const minimumHeight = 112;
    const preferredBottom = top + Math.max(190, Math.floor(window.innerHeight * .56));
    const reservedBottom = window.innerHeight - 12 - Math.max(0, reservedBelow);
    const availableBottom = reservedBottom > top + minimumHeight ? reservedBottom : preferredBottom;
    bottom = Math.min(bottom, preferredBottom, availableBottom);
  }
  if (right <= left || bottom <= top) return null;
  return { left, top, right, bottom, width: right - left, height: bottom - top };
}

function guidedTourRectsOverlap(first, second) {
  return first.left < second.right && first.right > second.left && first.top < second.bottom && first.bottom > second.top;
}

async function settleGuidedTourTarget(step) {
  await settleGuidedTourLayout();
  let target = guidedTourTarget(step);
  if (!isGuidedTourTargetVisible(target)) return null;
  const initialRect = target.getBoundingClientRect();
  const edge = 18;
  const spotlightMode = guidedTourValue(step?.spotlight, step);
  const workspaceStep = spotlightMode === "workspace";
  const focusStep = spotlightMode === "focus";
  const needsWorkspaceTopRoom = (workspaceStep || focusStep) && initialRect.top > Math.max(90, Math.floor(window.innerHeight * .22));
  const outsideViewport = initialRect.left < edge || initialRect.right > window.innerWidth - edge
    || (workspaceStep ? initialRect.bottom < edge || initialRect.top > window.innerHeight - edge : initialRect.top < edge || initialRect.bottom > window.innerHeight - edge);
  if (outsideViewport || needsWorkspaceTopRoom) {
    target.scrollIntoView({ block: workspaceStep || focusStep ? "start" : "center", inline: "nearest", behavior: "auto" });
    await settleGuidedTourLayout();
    target = guidedTourTarget(step);
  }
  return isGuidedTourTargetVisible(target) ? target : null;
}

function positionGuidedTour(target = null, step = GUIDED_TOUR_STEPS[guidedTourStepIndex]) {
  if (!guidedTourActive || !el.guidedTourCard || !el.guidedTourSpotlight || !el.guidedTour) return;
  const card = el.guidedTourCard;
  const spotlight = el.guidedTourSpotlight;
  const workspaceStep = guidedTourValue(step?.spotlight, step) === "workspace";
  card.style.removeProperty("visibility");
  if (workspaceStep) {
    card.style.maxHeight = Math.max(180, Math.floor(window.innerHeight * .42)) + "px";
  } else {
    card.style.removeProperty("max-height");
  }
  const cardWidth = card.getBoundingClientRect().width || Math.min(360, window.innerWidth - 24);
  const cardHeight = card.getBoundingClientRect().height || 220;
  const gap = 14;
  const spotlightRect = guidedTourSpotlightRect(target, step, workspaceStep ? cardHeight + gap : 0);
  const hasTarget = Boolean(spotlightRect);
  el.guidedTour.classList.toggle("has-spotlight", hasTarget);
  el.guidedTour.classList.toggle("is-centered", !hasTarget);
  el.guidedTour.classList.remove("is-fallback");
  if (!hasTarget) {
    ["left", "top", "width", "height"].forEach((property) => spotlight.style.removeProperty(property));
    card.style.removeProperty("left");
    card.style.removeProperty("top");
    card.style.removeProperty("max-height");
    card.style.removeProperty("visibility");
    return;
  }
  const { left, top, right, bottom, width, height } = spotlightRect;
  spotlight.style.left = left + "px";
  spotlight.style.top = top + "px";
  spotlight.style.width = width + "px";
  spotlight.style.height = height + "px";
  const edge = 12;
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const centeredLeft = clamp(left + (width - cardWidth) / 2, edge, window.innerWidth - cardWidth - edge);
  const candidates = [
    { left: centeredLeft, top: bottom + gap },
    { left: centeredLeft, top: top - cardHeight - gap },
    { left: right + gap, top: clamp(top, edge, window.innerHeight - cardHeight - edge) },
    { left: left - cardWidth - gap, top: clamp(top, edge, window.innerHeight - cardHeight - edge) }
  ];
  const fitsWithoutOverlap = (candidate) => {
    const cardRect = { left: candidate.left, top: candidate.top, right: candidate.left + cardWidth, bottom: candidate.top + cardHeight };
    return candidate.left >= edge && candidate.top >= edge
      && cardRect.right <= window.innerWidth - edge && cardRect.bottom <= window.innerHeight - edge
      && !guidedTourRectsOverlap(cardRect, spotlightRect);
  };
  const position = candidates.find(fitsWithoutOverlap);
  const cornerPositions = [
    { left: edge, top: edge },
    { left: window.innerWidth - cardWidth - edge, top: edge },
    { left: edge, top: window.innerHeight - cardHeight - edge },
    { left: window.innerWidth - cardWidth - edge, top: window.innerHeight - cardHeight - edge }
  ];
  const fallback = cornerPositions.find(fitsWithoutOverlap);
  const resolvedPosition = position || fallback;
  if (!resolvedPosition) {
    // Exact controls are deliberately small; this only occurs in an unusually short viewport.
    // Keep the card visible without ever placing it over the highlighted control.
    el.guidedTour.classList.add("is-fallback");
    card.style.maxHeight = Math.max(154, Math.floor(window.innerHeight * .42)) + "px";
    const reducedHeight = card.getBoundingClientRect().height;
    const reducedCorners = [
      { left: edge, top: edge },
      { left: window.innerWidth - cardWidth - edge, top: edge },
      { left: edge, top: window.innerHeight - reducedHeight - edge },
      { left: window.innerWidth - cardWidth - edge, top: window.innerHeight - reducedHeight - edge }
    ].find((candidate) => {
      const cardRect = { left: candidate.left, top: candidate.top, right: candidate.left + cardWidth, bottom: candidate.top + reducedHeight };
      return candidate.left >= edge && candidate.top >= edge && cardRect.right <= window.innerWidth - edge && cardRect.bottom <= window.innerHeight - edge && !guidedTourRectsOverlap(cardRect, spotlightRect);
    });
    if (reducedCorners) {
      card.style.left = reducedCorners.left + "px";
      card.style.top = reducedCorners.top + "px";
    } else {
      // Keep the coach mark usable even when the target fills an unusually short viewport.
      // The body scrolls independently, so the footer remains available at normal zoom.
      const visibleHeight = Math.min(reducedHeight, Math.max(120, window.innerHeight - edge * 2));
      card.style.maxHeight = visibleHeight + "px";
      card.style.left = clamp(centeredLeft, edge, window.innerWidth - cardWidth - edge) + "px";
      card.style.top = clamp(window.innerHeight - visibleHeight - edge, edge, window.innerHeight - edge) + "px";
    }
    return;
  }
  if (!workspaceStep) card.style.removeProperty("max-height");
  card.style.left = resolvedPosition.left + "px";
  card.style.top = resolvedPosition.top + "px";
}

function queueGuidedTourPosition() {
  if (!guidedTourActive || guidedTourSuspended || guidedTourPositionFrame) return;
  guidedTourPositionFrame = requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      guidedTourPositionFrame = 0;
      positionGuidedTour(guidedTourTarget(), GUIDED_TOUR_STEPS[guidedTourStepIndex]);
    });
  });
}

async function renderGuidedTourStep() {
  if (!guidedTourActive || guidedTourSuspended || !el.guidedTour) return;
  const step = GUIDED_TOUR_STEPS[guidedTourStepIndex] || GUIDED_TOUR_STEPS[0];
  const stepTab = guidedTourValue(step.tab, step);
  if (stepTab) setActiveTab(stepTab);
  const courseFormReady = guidedTourCourseFormIsReady();
  const courseFormTitleMissing = courseFormReady && !safeYouTubeTitle(el.courseTitleInput?.value, "");
  const waitingForCourse = Boolean(step.waitForCourse && !guidedTourCourseRequirementMet());
  const isCoursesStep = step.action === "courses";
  const isAnalyticsStep = step.action === "analytics";
  const isPopupStep = step.action === "popup";
  const isSettingsStep = step.action === "settings";
  const isFocusEnhancementStep = step.spotlight === "focus";
  if (isSettingsStep && !siteControlExpanded) {
    setSiteControlExpanded(true);
    await new Promise((resolve) => setTimeout(resolve, 260));
  }
  el.guidedTourTitle.textContent = courseFormReady ? (courseFormTitleMissing ? "Add the video title" : "Your video is ready") : guidedTourValue(step.title, step);
  el.guidedTourDescription.textContent = courseFormReady
    ? (courseFormTitleMissing ? "Enter the title in Name, then click Add Course to save your video." : "Your video is ready. Now click Add Course to save it.")
    : guidedTourValue(step.text, step);
  el.guidedTourProgressText.textContent = (guidedTourStepIndex + 1) + " of " + GUIDED_TOUR_STEPS.length;
  el.guidedTourProgressFill.style.width = ((guidedTourStepIndex + 1) / GUIDED_TOUR_STEPS.length * 100) + "%";
  el.guidedTourBackBtn.disabled = guidedTourStepIndex === 0;
  el.guidedTourNextBtn.disabled = waitingForCourse;
  el.guidedTourNextBtn.textContent = step.action === "start" ? "Start guided tour" : step.action === "completion" ? (state.courses.length ? "Start focusing" : "Add a course") : isCoursesStep ? "Continue" : "Next";
  el.guidedTourCoursesFlow?.classList.toggle("hidden", !isCoursesStep);
  el.guidedTourAnalyticsPreview?.classList.toggle("hidden", !isAnalyticsStep);
  el.guidedTourPopupGuide?.classList.toggle("hidden", !isPopupStep);
  el.guidedTourDistractionGuide?.classList.toggle("hidden", !isSettingsStep);
  el.guidedTourFeatureIntro?.classList.toggle("hidden", !isFocusEnhancementStep || Boolean(state.profile?.focusEnhancementsIntroDismissed));
  el.guidedTour.classList.toggle("is-external-step", isPopupStep);
  el.guidedTourYouTubeBtn?.classList.toggle("hidden", !isCoursesStep);
  const courseNeedsYouTube = isCoursesStep && !courseFormReady && waitingForCourse;
  el.guidedTourYouTubeBtn?.classList.toggle("primary", courseNeedsYouTube);
  el.guidedTourYouTubeBtn?.classList.toggle("secondary", !courseNeedsYouTube);
  el.guidedTourNextBtn?.classList.toggle("primary", !courseNeedsYouTube);
  el.guidedTourNextBtn?.classList.toggle("secondary", courseNeedsYouTube);
  const canOpenPopup = Boolean(globalThis.chrome?.action?.openPopup);
  el.guidedTourPopupBtn?.classList.toggle("hidden", !isPopupStep || !canOpenPopup);
  const target = await settleGuidedTourTarget(step);
  if (!guidedTourActive || guidedTourSuspended) return;
  positionGuidedTour(target, step);
  if (!waitingForCourse) el.guidedTourNextBtn.focus({ preventScroll: true });
}

async function startGuidedTour({ restart = false } = {}) {
  if (!el.guidedTour || guidedTourActive || !state.profile?.onboarded) return;
  if (!el.onboardingOverlay?.classList.contains("hidden")) return;
  guidedTourTabId = await currentDashboardTabId();
  if (hasChrome && !Number.isInteger(guidedTourTabId)) {
    showToast("Open Studizen in a browser tab before starting the guided tour.");
    return;
  }
  if (restart) {
    if (await guidedTourOwnedByAnotherTab()) return;
    await saveState({ ...state, profile: { ...(state.profile || {}), guidedTourStatus: "not_started", guidedTourVersion: GUIDED_TOUR_VERSION, guidedTourActive: false, guidedTourStep: 0, guidedTourTabId: null, guidedTourSessionId: null, guidedTourHandoff: null, guidedTourUpdatedAt: Date.now() } }, { skipGuidedTourRender: true });
  }
  if (!guidedTourIsEligible()) return;
  if (await guidedTourOwnedByAnotherTab()) return;
  guidedTourAutoStartHandled = true;
  guidedTourActive = true;
  guidedTourStepIndex = state.profile?.guidedTourActive ? guidedTourStoredStep() : 0;
  await persistGuidedTourSession(true, guidedTourStepIndex, guidedTourTabId);
  document.body.classList.add("guided-tour-active");
  el.guidedTour.classList.remove("hidden");
  await renderGuidedTourStep();
}

async function finishGuidedTour(status) {
  if (!guidedTourActive) return;
  const nextStatus = status === "completed" ? "completed" : "skipped";
  const currentStep = GUIDED_TOUR_STEPS[guidedTourStepIndex];
  guidedTourActive = false;
  guidedTourSuspended = false;
  guidedTourTransition = false;
  if (guidedTourPositionFrame) cancelAnimationFrame(guidedTourPositionFrame);
  guidedTourPositionFrame = 0;
  document.body.classList.remove("guided-tour-active");
  el.guidedTour?.classList.add("hidden");
  const endedSessionId = state.profile?.guidedTourSessionId || null;
  await saveState({ ...state, profile: { ...(state.profile || {}), ...(currentStep?.spotlight === "focus" ? { focusEnhancementsIntroDismissed: true } : {}), guidedTourStatus: nextStatus, guidedTourVersion: GUIDED_TOUR_VERSION, guidedTourActive: false, guidedTourStep: 0, guidedTourTabId: null, guidedTourSessionId: null, guidedTourHandoff: null, guidedTourUpdatedAt: Date.now() } }, { skipGuidedTourRender: true });
  if (hasChrome && endedSessionId) {
    try { await sendMessage({ type: "syncGuidedTourSession", payload: { active: false, sessionId: endedSessionId, tabId: guidedTourTabId } }); } catch {}
  }
  showToast(nextStatus === "completed" ? "Guided tour complete." : "Guided tour skipped. Start it again from Settings whenever you want.");
}

async function maybeStartGuidedTour() {
  if (guidedTourAutoStartHandled || guidedTourActive || !guidedTourIsEligible()) return;
  guidedTourTabId ||= await currentDashboardTabId();
  if (await guidedTourOwnedByAnotherTab()) {
    guidedTourAutoStartHandled = true;
    return;
  }
  guidedTourAutoStartHandled = true;
  setTimeout(() => { void startGuidedTour(); }, 260);
}

async function moveGuidedTour(stepChange) {
  if (!guidedTourActive || guidedTourTransition) return;
  const currentStep = GUIDED_TOUR_STEPS[guidedTourStepIndex];
  if (stepChange > 0 && currentStep?.waitForCourse && !guidedTourCourseRequirementMet()) return;
  guidedTourTransition = true;
  try {
    const nextIndex = guidedTourStepIndex + stepChange;
    if (nextIndex >= GUIDED_TOUR_STEPS.length) {
      if (currentStep?.action === "completion" && !state.courses.length) setActiveTab("courses");
      return finishGuidedTour("completed");
    }
    if (stepChange > 0 && currentStep?.spotlight === "focus" && !state.profile?.focusEnhancementsIntroDismissed) {
      await saveState({ ...state, profile: { ...(state.profile || {}), focusEnhancementsIntroDismissed: true } }, { skipGuidedTourRender: true });
    }
    guidedTourStepIndex = Math.max(0, nextIndex);
    await persistGuidedTourSession(true, guidedTourStepIndex, guidedTourTabId);
    const nextStep = GUIDED_TOUR_STEPS[guidedTourStepIndex];
    if (nextStep?.action === "completion") setActiveTab(guidedTourValue(nextStep.tab, nextStep));
    await renderGuidedTourStep();
  } finally {
    guidedTourTransition = false;
  }
}

function syncGuidedTourToManualTab(tab) {
  if (!guidedTourActive) return;
  const currentStep = GUIDED_TOUR_STEPS[guidedTourStepIndex];
  if (currentStep?.waitForCourse && !guidedTourCourseRequirementMet() && tab !== "courses") {
    setActiveTab("courses");
    void renderGuidedTourStep();
    return;
  }
  const stepIndex = GUIDED_TOUR_TAB_STEPS[tab];
  if (stepIndex === undefined || stepIndex === guidedTourStepIndex) {
    queueGuidedTourPosition();
    return;
  }
  guidedTourStepIndex = stepIndex;
  void persistGuidedTourSession(true, guidedTourStepIndex, guidedTourTabId);
  void renderGuidedTourStep();
}

async function openGuidedTourPopup() {
  if (!globalThis.chrome?.action?.openPopup) {
    showToast("Click the Studizen icon in Chrome's toolbar to open the popup.");
    return;
  }
  try {
    await chrome.action.openPopup();
  } catch {
    showToast("Click the Studizen icon in Chrome's toolbar to open the popup.");
  }
}

async function openGuidedTourYouTube() {
  if (!guidedTourActive) return;
  await persistGuidedTourSession(true, guidedTourStepIndex, guidedTourTabId);
  if (!hasChrome || !chrome.tabs?.create) {
    showToast("Open YouTube in another tab, then use Add to Studizen on a video thumbnail.");
    return;
  }
  try {
    await chrome.tabs.create({ url: "https://www.youtube.com/", active: true });
  } catch {
    showToast("Could not open YouTube. Use the Studizen shortcut from a YouTube video instead.");
  }
}

async function resumeGuidedTourYouTubeHandoff(handoffId, expectedTabId = null, expectedSessionId = null, expectedVideoUrl = "", expectedVideoTitle = null) {
  await loadState();
  const handoff = guidedTourHandoff();
  const ownTabId = await currentDashboardTabId();
  if (!handoff || handoff.id !== handoffId || handoff.step !== 2) return false;
  if (expectedTabId && ownTabId !== Number(expectedTabId)) return false;
  if (expectedSessionId && handoff.sessionId !== expectedSessionId) return false;
  if (state.profile?.guidedTourSessionId && handoff.sessionId !== state.profile.guidedTourSessionId) return false;
  if (expectedVideoUrl && canonicalYouTubeVideoUrl(expectedVideoUrl) !== handoff.url) return false;
  if (expectedVideoTitle !== null && safeYouTubeTitle(expectedVideoTitle, "") !== handoff.title) return false;
  if (!state.profile?.guidedTourActive || state.profile.guidedTourStatus !== "not_started") return false;
  guidedTourTabId = ownTabId || handoff.tabId || guidedTourTabId;
  guidedTourStepIndex = handoff.step;
  guidedTourActive = true;
  guidedTourSuspended = false;
  document.body.classList.add("guided-tour-active");
  el.guidedTour?.classList.remove("hidden");
  await persistGuidedTourSession(true, guidedTourStepIndex, guidedTourTabId);
  setActiveTab("courses");
  return prepareGuidedTourCourseAdd(handoff.url, handoff.title, handoff.id);
}

function rotateFocusQuote() {
  if (!el.focusQuote || !FOCUS_QUOTES.length) return;
  let index = Math.floor(Math.random() * FOCUS_QUOTES.length);
  if (FOCUS_QUOTES.length > 1 && index === focusQuoteIndex) index = (index + 1) % FOCUS_QUOTES.length;
  focusQuoteIndex = index;
  focusQuoteShown = true;
  el.focusQuote.textContent = FOCUS_QUOTES[index];
}

async function loadState() {
  document.body.classList.add("is-loading");
  if (hasChrome) {
    const result = await sendMessage({ type: "getState" });
    if (result?.ok) state = ensureToday(mergeState(result.response));
    else {
      const data = await chrome.storage.local.get(STATE_KEY);
      state = ensureToday(mergeState(data[STATE_KEY]));
    }
  } else {
    try { state = ensureToday(mergeState(JSON.parse(localStorage.getItem(STATE_KEY) || "null"))); } catch { state = defaultState(); }
  }
  applyTheme();
  render();
  void refreshIncognitoAccessStatus();
  void refreshWebsiteProtectionPermission();
  void refreshCameraPermissionStatus();
  document.body.classList.remove("is-loading");
}
async function saveState(next, options = {}) {
  const candidate = ensureToday(mergeState(next));
  if (hasChrome) {
    const result = await sendMessage({ type: "saveState", patch: createStatePatch(state, candidate) });
    if (!result?.ok) throw new Error(result?.error || "Could not save your changes.");
    state = ensureToday(mergeState(result.response));
  } else {
    state = candidate;
    localStorage.setItem(STATE_KEY, JSON.stringify(state));
  }
  applyTheme();
  render();
  if (guidedTourActive && !options.skipGuidedTourRender) void renderGuidedTourStep();
}
async function updateSettings(patch, options = {}) { await saveState({ ...state, settings: { ...state.settings, ...patch } }, options); }
async function addCurrentSupportingSite() {
  if (!hasChrome || !chrome.tabs?.query) return showToast("Open this in Chrome to add a supporting site.");
  const tabs = await chrome.tabs.query({});
  const candidate = tabs
    .filter((tab) => {
      const url = safeUrl(tab.url);
      return url && ["http:", "https:"].includes(url.protocol);
    })
    .sort((a, b) => Number(b.lastAccessed || 0) - Number(a.lastAccessed || 0))[0];
  const url = safeUrl(candidate?.url);
  if (!url) return showToast("Open a website first, then add it as a supporting site.");
  const domain = url.hostname.replace(/^www\./, "").toLowerCase();
  if (state.settings.allowedSites.includes(domain)) return showToast(domain + " is already allowed.");
  await updateSettings({ allowedSites: cleanPatterns([...state.settings.allowedSites, domain]) });
  showToast(domain + " is now allowed when Focus Protection is on.");
}

function fillSelects() {
  [el.studyProfileSelect].forEach((select) => {
    if (!select) return;
    const selected = state.profile?.studyProfile || "jee";
    select.innerHTML = "";
    STUDY_PROFILES.forEach((profile) => { const option = document.createElement("option"); option.value = profile.id; option.textContent = profile.name; option.selected = profile.id === selected; select.append(option); });
  });
  [el.courseSubjectInput].forEach((select) => {
    if (!select) return;
    const selected = normalizeSubject(select.value || "Other", state.profile?.studyProfile, currentSubjects());
    select.innerHTML = "";
    currentSubjects().forEach((subject) => { const option = document.createElement("option"); option.value = subject; option.textContent = subject; option.selected = subject === selected; select.append(option); });
  });
  if (el.courseLibraryInput) {
    const selected = el.courseLibraryInput.value || state.courseLibraries?.[0]?.id || "library-main";
    el.courseLibraryInput.innerHTML = "";
    (state.courseLibraries || []).forEach((library) => {
      const option = document.createElement("option");
      option.value = library.id;
      option.textContent = library.name;
      option.selected = library.id === selected;
      el.courseLibraryInput.append(option);
    });
  }
}

function renderHeader() {
  const session = activeSession();
  const course = getActiveCourse(state);
  const activeTab = document.querySelector(".tab-panel.active")?.id.replace("tab-", "") || "focus";
  const header = dashboardHeaderPresentation({ tab: activeTab, session, course, profileName: state.profile?.name });
  el.connectionLabel.textContent = hasChrome ? "Chrome extension active" : "Preview mode";
  el.stateEyebrow.textContent = header.eyebrow;
  el.mainTitle.textContent = header.title;
  if (el.activeFocusIndicator) el.activeFocusIndicator.hidden = !header.showSessionIndicator;
  if (header.showSessionIndicator) {
    if (el.activeFocusStatus) el.activeFocusStatus.textContent = header.sessionStatus;
    if (el.activeFocusCourse) {
      el.activeFocusCourse.textContent = header.sessionTitle;
      el.activeFocusCourse.title = el.activeFocusCourse.textContent;
    }
  }
  if (el.focusOpenCourseBtn) el.focusOpenCourseBtn.disabled = !course;
  el.stopFocusBtn.classList.toggle("hidden", !session);
}
function renderClock() {
  if (!el.liveClock) return;
  el.liveClock.textContent = "\uD83D\uDD52 " + new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  if ($("#tab-focus")?.classList.contains("active")) renderHeader();
}
function renderFocusDurationPicker() {
  const duration = Number(el.durationInput?.value || state.settings.focusMinutesDefault || 50);
  const custom = focusDurationCustom || ![25, 50, 90].includes(duration);
  el.focusCustomDurationField?.classList.toggle("hidden", !custom);
  el.focusDurationPresets?.querySelectorAll("[data-focus-duration]").forEach((button) => {
    const selected = button.dataset.focusDuration === "custom" ? custom : Number(button.dataset.focusDuration) === duration && !custom;
    button.setAttribute("aria-pressed", String(selected));
  });
}
function formatBreakSpan(milliseconds) {
  const seconds = Math.max(0, Math.round(Number(milliseconds || 0) / 1000));
  const hoursPart = Math.floor(seconds / 3600);
  const minutesPart = Math.floor((seconds % 3600) / 60);
  const secondsPart = seconds % 60;
  return [hoursPart ? hoursPart + "h" : "", minutesPart ? minutesPart + "m" : "", secondsPart ? secondsPart + "s" : ""].filter(Boolean).join(" ") || "0m";
}
function currentBreakSchedule() {
  return validateBreakSchedule(
    Number(el.durationInput?.value),
    Number(el.focusCyclesInput?.value),
    Number(el.breakDurationInput?.value)
  );
}
function renderBreakSchedulePreview() {
  const totalMinutes = Number(el.durationInput?.value);
  const breaksCount = Number(el.focusCyclesInput?.value);
  const breakMinutes = Number(el.breakDurationInput?.value);
  const validation = validateBreakSchedule(totalMinutes, breaksCount, breakMinutes);
  let sequence = "Adjust the values to see a valid schedule.";
  if (validation.valid) {
    sequence = validation.studyBlockDurationsMs.map((blockMs, index) => {
      const parts = [formatBreakSpan(blockMs) + " Study"];
      if (index < breaksCount) parts.push(formatBreakSpan(breakMinutes * 60000) + " Break");
      return parts.join(" → ");
    }).join(" → ").replaceAll(" Study", " study").replaceAll(" Break", " break");
  }
  if (el.focusBreakPreviewSequence) el.focusBreakPreviewSequence.textContent = sequence;
  if (el.breakHelpExample) el.breakHelpExample.textContent = validation.valid
    ? formatBreakSpan(totalMinutes * 60000) + " total study · " + sequence + "."
    : "Choose a valid duration and break schedule to preview it.";
  if (el.focusBreakPreviewStudy) el.focusBreakPreviewStudy.textContent = "Total focused study: " + formatBreakSpan(totalMinutes * 60000) + ".";
  if (el.focusBreakPreviewElapsed) el.focusBreakPreviewElapsed.textContent = "Estimated elapsed: " + formatBreakSpan((totalMinutes + (validation.valid ? breaksCount * breakMinutes : 0)) * 60000) + ".";
}
async function persistBreakDefaults() {
  const breakDurationMinutes = Number(el.breakDurationInput?.value);
  const breaksCount = Number(el.focusCyclesInput?.value);
  const mode = focusModeDraft || state.settings.defaultFocusMode || "normal";
  if (mode === "breaks" && !updateBreakScheduleValidation(mode).valid) return;
  if (!Number.isInteger(breakDurationMinutes) || breakDurationMinutes < (mode === "breaks" ? 1 : 0) || breakDurationMinutes > 60 || !Number.isInteger(breaksCount) || breaksCount < (mode === "breaks" ? 1 : 0) || breaksCount > 12) return;
  lastFocusBreakSuggestionDuration = Number(el.durationInput?.value) || lastFocusBreakSuggestionDuration;
  await updateSettings({ focusMinutesDefault: Number(el.durationInput?.value) || state.settings.focusMinutesDefault, focusBreakMinutesDefault: breakDurationMinutes, focusBreakCyclesDefault: breaksCount });
}
function applySuggestedBreakSettings(totalMinutes = Number(el.durationInput?.value)) {
  const mode = focusModeDraft || state.settings.defaultFocusMode || "normal";
  const suggestion = suggestedBreakSettings(totalMinutes, mode);
  if (el.breakDurationInput) el.breakDurationInput.value = suggestion.breakDurationMinutes;
  if (el.focusCyclesInput) el.focusCyclesInput.value = suggestion.breaksCount;
  renderBreakSchedulePreview();
  updateBreakScheduleValidation();
  return suggestion;
}
function toggleBreakHelp(forceOpen = null) {
  const open = forceOpen === null ? el.breakHelpPopover?.classList.contains("hidden") : Boolean(forceOpen);
  el.breakHelpPopover?.classList.toggle("hidden", !open);
  el.breakHelpBtn?.setAttribute("aria-expanded", String(open));
  renderBreakSchedulePreview();
}
function syncBreakHelpPlacement(session = activeSession()) {
  const sessionIsActive = Boolean(session?.active);
  const activeBreakSession = sessionIsActive && session.mode === "breaks";
  const host = activeBreakSession ? el.breakSessionPhaseHeading : el.focusModeSelectionRow;
  if (host && el.breakHelpAnchor?.parentElement !== host) host.append(el.breakHelpAnchor);
  el.breakHelpAnchor?.classList.toggle("hidden", sessionIsActive && !activeBreakSession);
}
async function updateBreakSuggestionsForDuration() {
  const durationMinutes = Number(el.durationInput?.value);
  if (!Number.isInteger(durationMinutes) || durationMinutes < 5 || durationMinutes > 240) {
    updateBreakScheduleValidation();
    return;
  }
  if (durationMinutes === lastFocusBreakSuggestionDuration) {
    updateBreakScheduleValidation();
    return;
  }
  lastFocusBreakSuggestionDuration = durationMinutes;
  const suggestion = applySuggestedBreakSettings(durationMinutes);
  await updateSettings({ focusMinutesDefault: durationMinutes, focusBreakMinutesDefault: suggestion.breakDurationMinutes, focusBreakCyclesDefault: suggestion.breaksCount });
}
function focusStudyElapsedMs(session, now = Date.now()) {
  const totalMs = Math.max(0, Number(session?.durationMinutes) * 60000);
  if (!session || !totalMs) return 0;
  if (session.endConfirmationUntil && Number.isFinite(Number(session.endConfirmationStudyElapsedMs))) return Math.min(totalMs, Math.max(0, Number(session.endConfirmationStudyElapsedMs)));
  if (session.mode === "breaks" && Number(session.scheduleVersion) === 2) {
    const completedMs = Math.max(0, Number(session.completedStudyMs) || 0);
    const blockIndex = Math.min(Number(session.studyBlocksCompleted) || 0, Math.max(0, (Number(session.studyBlocksTotal) || 1) - 1));
    const blockMs = Math.max(0, Number(session.studyBlockDurationsMs?.[blockIndex]) || Number(session.phaseDurationMs) || 0);
    const storedMs = Math.min(blockMs, Math.max(0, Number(session.studyBlockElapsedMs) || 0));
    const activeStart = Number(session.activeIntervalStartedAt) || 0;
    const liveMs = session.phase === "study" && !session.paused && !session.endConfirmationUntil && activeStart > 0
      ? Math.max(0, Math.min(Number(session.endsAt) || now, now) - activeStart)
      : 0;
    return Math.min(totalMs, completedMs + storedMs + Math.min(blockMs - storedMs, liveMs));
  }
  if (session.mode === "breaks") {
    const current = session.phase === "study" ? Math.min(Number(session.phaseDurationMs) || 0, Math.max(0, now - Number(session.phaseStartedAt || now))) : 0;
    return Math.min(totalMs, Math.max(0, Number(session.completedStudyMs) || 0) + current);
  }
  return Math.max(0, totalMs - sessionRemainingMs(session, now));
}
function updateBreakScheduleValidation(mode = focusModeDraft || state.settings.defaultFocusMode || "normal") {
  const result = currentBreakSchedule();
  if (el.focusCyclesInput) {
    el.focusCyclesInput.min = mode === "breaks" ? "1" : "0";
    el.focusCyclesInput.max = String(result.maxBreaks);
  }
  if (el.breakDurationInput) el.breakDurationInput.min = mode === "breaks" ? "1" : "0";
  renderBreakSchedulePreview();
  const visible = mode === "breaks" && !activeSession();
  if (el.focusBreakValidation) {
    el.focusBreakValidation.textContent = visible ? result.message : "";
    el.focusBreakValidation.hidden = !visible || result.valid;
  }
  if (el.startFocusBtn && !activeSession()) el.startFocusBtn.disabled = !getActiveCourse(state) || focusActionPending || (visible && !result.valid);
  return result;
}
function renderBreakSessionDetails(session) {
  const visible = Boolean(session?.active && session.mode === "breaks");
  syncBreakHelpPlacement(session);
  el.breakSessionDetails?.classList.toggle("hidden", !visible);
  if (!visible) return;
  const breaksTotal = Math.max(0, Number(session.breaksTotal) || 0);
  const blocksTotal = Math.max(1, Number(session.studyBlocksTotal) || breaksTotal + 1);
  const blocksCompleted = Math.min(blocksTotal, Math.max(0, Number(session.studyBlocksCompleted) || 0));
  const isBreak = session.phase === "break";
  const endPending = Number(session.endConfirmationUntil) > Date.now();
  const currentBlock = Math.min(blocksTotal, blocksCompleted + 1);
  const breakNumber = Math.max(1, Math.min(breaksTotal || 1, Number(session.cyclesCompleted) || blocksCompleted));
  if (el.breakSessionBlock) el.breakSessionBlock.textContent = isBreak ? "Break " + breakNumber + " of " + breaksTotal : "Study block " + currentBlock + " of " + blocksTotal;
  if (el.breakSessionPhase) el.breakSessionPhase.textContent = isBreak ? "On break" : "Studying";
  if (el.breakSessionMessage) {
    el.breakSessionMessage.hidden = !isBreak;
    el.breakSessionMessage.textContent = isBreak ? "Your next study block starts automatically." : "";
  }
  if (el.breakSessionTimeline) {
    el.breakSessionTimeline.replaceChildren();
    const blockDurations = Array.isArray(session.studyBlockDurationsMs) && session.studyBlockDurationsMs.length
      ? session.studyBlockDurationsMs.slice(0, blocksTotal)
      : createBreakStudyBlocks(session.durationMinutes, breaksTotal);
    const completedBreaks = Math.max(0, Number(session.cyclesCompleted || 0) - (isBreak ? 1 : 0));
    blockDurations.forEach((duration, index) => {
      const studyState = index < blocksCompleted ? "complete" : !isBreak && index === blocksCompleted ? "current" : "upcoming";
      const studyItem = document.createElement("div");
      studyItem.className = "break-timeline-item";
      if (studyState === "current") studyItem.classList.add("is-current");
      studyItem.setAttribute("role", "listitem");
      studyItem.setAttribute("aria-label", "Study block " + (index + 1) + " of " + blocksTotal + ", " + studyState + ", " + formatBreakSpan(duration));
      const studySegment = document.createElement("span");
      studySegment.className = "break-timeline-segment study-segment is-" + studyState;
      studySegment.setAttribute("aria-hidden", "true");
      const studyLabel = document.createElement("span");
      studyLabel.className = "break-timeline-label";
      studyLabel.textContent = "Study · " + formatBreakSpan(duration);
      studyItem.append(studySegment, studyLabel);
      el.breakSessionTimeline.append(studyItem);
      if (index < breaksTotal) {
        const breakState = index < completedBreaks ? "complete" : isBreak && index === blocksCompleted - 1 ? "current" : "upcoming";
        const breakDuration = Math.max(0, Number(session.breakDurationMinutes) * 60000);
        const breakItem = document.createElement("div");
        breakItem.className = "break-timeline-item";
        if (breakState === "current") breakItem.classList.add("is-current");
        breakItem.setAttribute("role", "listitem");
        breakItem.setAttribute("aria-label", "Break " + (index + 1) + " of " + breaksTotal + ", " + breakState + ", " + formatBreakSpan(breakDuration));
        const breakSegment = document.createElement("span");
        breakSegment.className = "break-timeline-segment break-segment is-" + breakState;
        breakSegment.setAttribute("aria-hidden", "true");
        const breakLabel = document.createElement("span");
        breakLabel.className = "break-timeline-label";
        breakLabel.textContent = "Break · " + formatBreakSpan(breakDuration);
        breakItem.append(breakSegment, breakLabel);
        el.breakSessionTimeline.append(breakItem);
      }
    });
  }
  el.breakSessionTimeline?.setAttribute("role", "list");
  el.focusWorkspace?.classList.toggle("is-on-break", isBreak);
  if (el.breakSessionDetails) el.breakSessionDetails.dataset.pendingEnd = String(endPending);
}
function renderFocus() {
  const session = activeSession();
  const course = getActiveCourse(state);
  if (lastFocusBreakSuggestionDuration === null) lastFocusBreakSuggestionDuration = Number(state.settings.focusMinutesDefault) || 50;
  el.courseSelect.value = course?.id || "";
  if (document.activeElement !== el.durationInput) el.durationInput.value = state.settings.focusMinutesDefault || 50;
  if (el.breakDurationInput && document.activeElement !== el.breakDurationInput) el.breakDurationInput.value = state.settings.focusBreakMinutesDefault ?? 5;
  if (el.focusCyclesInput && document.activeElement !== el.focusCyclesInput) el.focusCyclesInput.value = state.settings.focusBreakCyclesDefault ?? 1;
  if (!session && !focusModeDraft) focusModeDraft = state.settings.defaultFocusMode || "normal";
  el.todayFocus.textContent = formatDuration(actualMinutesToday());
  el.todaySessions.textContent = String(completedSessionsToday());
  if (el.todayBlocks) el.todayBlocks.textContent = String(state.stats.distractions || 0);
  el.todayScore.textContent = String(productivityScore(state));
  el.selectedCourseTitle.textContent = course?.title || "No course selected";
  el.selectedCourseMeta.textContent = course ? (course.subject || "Other") + " - " + safeUrl(course.url)?.hostname.replace(/^www\./, "") : "Choose a course in the Courses tab.";
  const displayedMode = session?.mode || focusModeDraft || state.settings.defaultFocusMode || "normal";
  const modeName = focusModeLabel(displayedMode);
  const modeDescriptions = {
    normal: "Pause anytime; Focus Protection pauses with the timer. Outside Focus Protection keeps its separate setting.",
    strict: "No pause; ending includes a 10-second cancel window.",
    breaks: "Focus Protection pauses during scheduled breaks, then resumes with study time."
  };
  if (el.focusModeDescription) {
    el.focusModeDescription.textContent = modeDescriptions[displayedMode] || modeDescriptions.normal;
    el.focusModeDescription.classList.toggle("hidden", Boolean(session));
  }
  if (el.focusWorkspace) {
    el.focusWorkspace.dataset.focusMode = displayedMode;
    el.focusWorkspace.dataset.focusPhase = session?.phase || "ready";
    el.focusWorkspace.dataset.focusActive = String(Boolean(session));
  }
  if (el.startForm) {
    el.startForm.dataset.focusMode = displayedMode;
    el.startForm.dataset.focusActive = String(Boolean(session));
  }
  if (el.focusModeKicker) el.focusModeKicker.textContent = session ? modeName : "Focus Mode";
  syncBreakHelpPlacement(session);
  el.focusModePicker?.classList.toggle("hidden", Boolean(session));
  el.focusSessionSetup?.classList.toggle("hidden", Boolean(session));
  el.focusConfigFields?.classList.toggle("hidden", Boolean(session));
  el.focusBreakOptions?.classList.toggle("hidden", Boolean(session) || displayedMode !== "breaks");
  renderFocusDurationPicker();
  const breakSchedule = updateBreakScheduleValidation(displayedMode);
  el.focusModePicker?.querySelectorAll("[data-focus-mode]").forEach((button) => {
    const selected = button.dataset.focusMode === displayedMode;
    button.classList.toggle("is-selected", selected);
    button.setAttribute("aria-pressed", String(selected));
    button.disabled = Boolean(session);
  });
  const circumference = 427;
  if (!session) {
    el.breakSessionDetails?.classList.add("hidden");
    el.focusWorkspace?.classList.remove("is-on-break");
    lastLiveFocusMinutes = null;
    el.focusHeadline.textContent = course ? "Ready to focus?" : "Choose a course";
    el.focusPill.textContent = course ? "Ready" : "Choose course";
    el.focusPill.classList.remove("active");
    el.startFocusBtn.disabled = !course || focusActionPending || (displayedMode === "breaks" && !breakSchedule.valid);
    const startFocusLabel = el.startFocusBtn.querySelector("span");
    if (startFocusLabel) startFocusLabel.textContent = "Start Focus";
    else el.startFocusBtn.textContent = "Start Focus";
    el.startFocusBtn.classList.remove("hidden");
    if (el.pauseFocusBtn) {
      el.pauseFocusBtn.hidden = true;
      el.pauseFocusBtn.classList.add("hidden");
      el.pauseFocusBtn.disabled = true;
    }
    el.resumeFocusBtn?.classList.add("hidden");
    el.stopFocusBtn.classList.add("hidden");
    el.focusExitConfirmation?.classList.add("hidden");
    if (el.focusSessionProgressWrap) el.focusSessionProgressWrap.hidden = true;
    el.focusRemainingText?.classList.add("hidden");
    el.timerProgress.style.strokeDashoffset = String(circumference);
    el.timerText.textContent = "00:00";
    el.timerCaption.textContent = course ? "Ready to begin" : "Choose a course";
    el.focusHeadline.textContent = course ? "Ready to focus?" : "Choose a course";
    el.focusPill.textContent = course ? "Ready" : "Choose course";
    el.focusPill.classList.remove("active");
    renderCameraAttention(null);
    return;
  }
  const phaseDurationMs = Math.max(1, Number(session.phaseDurationMs) || Number(session.durationMinutes) * 60000);
  const remainingMs = sessionRemainingMs(session);
  const totalStudyMs = Math.max(1, Number(session.durationMinutes) * 60000);
  const elapsedStudyMs = focusStudyElapsedMs(session);
  const ratio = Math.min(1, Math.max(0, elapsedStudyMs / totalStudyMs));
  const remainingText = formatClock(remainingMs) + " remaining";
  const isBreak = session.mode === "breaks" && session.phase === "break";
  const normalMode = (session.mode || "normal") === "normal";
  const isEnding = ["strict", "breaks"].includes(session.mode) && Number(session.endConfirmationUntil) > Date.now();
  el.focusHeadline.textContent = isBreak ? "Break Mode" : session.paused ? "Focus paused" : modeName;
  el.focusPill.textContent = isBreak ? "Break" : session.paused ? "Paused" : "Focusing";
  el.startFocusBtn.classList.add("hidden");
  if (el.pauseFocusBtn) {
    const hidePause = !normalMode || session.paused || isBreak;
    el.pauseFocusBtn.hidden = hidePause;
    el.pauseFocusBtn.classList.toggle("hidden", hidePause);
    el.pauseFocusBtn.disabled = session.paused || focusActionPending;
  }
  el.resumeFocusBtn?.classList.toggle("hidden", !normalMode || !session.paused);
  if (el.resumeFocusBtn) el.resumeFocusBtn.disabled = !session.paused || focusActionPending;
  el.stopFocusBtn.classList.toggle("hidden", isEnding);
  el.stopFocusBtn.textContent = normalMode ? "End Focus" : "End Session";
  el.stopFocusBtn.disabled = focusActionPending || isEnding;
  el.focusExitConfirmation?.classList.toggle("hidden", !isEnding);
  if (isEnding && el.focusExitCountdown) el.focusExitCountdown.textContent = "Session ending in " + Math.max(1, Math.ceil((session.endConfirmationUntil - Date.now()) / 1000)) + " seconds.";
  el.focusPill.classList.add("active");
  el.timerProgress.style.strokeDashoffset = String(circumference - circumference * ratio);
  el.timerText.textContent = formatClock(remainingMs);
  const percentComplete = Math.round(ratio * 100);
  el.timerCaption.textContent = isBreak
    ? "Break · " + Math.max(1, Number(session.cyclesCompleted) || 1) + " of " + Math.max(1, Number(session.breaksTotal ?? session.cyclesTotal) || 1) + " scheduled breaks"
    : session.paused ? percentComplete + "% of study time · paused" : percentComplete + "% of study time";
  if (el.focusSessionProgressWrap) el.focusSessionProgressWrap.hidden = false;
  if (el.focusSessionProgressLabel) el.focusSessionProgressLabel.textContent = isBreak ? "Break in progress · study " + percentComplete + "%" : session.mode === "breaks" ? "Study block " + (Number(session.studyBlocksCompleted || 0) + 1) + " of " + (session.studyBlocksTotal || 1) : "Study session progress";
  if (el.focusSessionProgressValue) el.focusSessionProgressValue.textContent = percentComplete + "%";
  if (el.focusSessionProgressFill) el.focusSessionProgressFill.style.width = percentComplete + "%";
  if (el.focusRemainingText) {
    el.focusRemainingText.textContent = remainingText;
    el.focusRemainingText.classList.toggle("hidden", session.mode === "breaks");
  }
  renderCameraAttention(session);
  renderBreakSessionDetails(session);
}
function renderFocusTick() {
  const session = activeSession();
  if (!session) return;
  if (!hasChrome && session.endConfirmationUntil && session.endConfirmationUntil <= Date.now()) {
    void stopFocus("early-exit-confirmed");
    return;
  }
  const circumference = 427;
  const totalMs = Math.max(1, Number(session.durationMinutes || 0) * 60000);
  const remainingMs = sessionRemainingMs(session);
  const isBreak = session.mode === "breaks" && session.phase === "break";
  const elapsedMs = focusStudyElapsedMs(session);
  const ratio = Math.min(1, Math.max(0, elapsedMs / totalMs));
  const percentComplete = Math.round(ratio * 100);
  el.timerProgress.style.strokeDashoffset = String(circumference - circumference * ratio);
  el.timerText.textContent = formatClock(remainingMs);
  el.timerCaption.textContent = isBreak ? "Break · " + Math.max(1, Number(session.cyclesCompleted) || 1) + " of " + Math.max(1, Number(session.breaksTotal ?? session.cyclesTotal) || 1) + " scheduled breaks" : session.paused ? percentComplete + "% of study time · paused" : percentComplete + "% of study time";
  if (el.focusSessionProgressWrap) el.focusSessionProgressWrap.hidden = false;
  if (el.focusSessionProgressLabel) el.focusSessionProgressLabel.textContent = isBreak ? "Break in progress · study " + percentComplete + "%" : session.mode === "breaks" ? "Study block " + (Number(session.studyBlocksCompleted || 0) + 1) + " of " + (session.studyBlocksTotal || 1) : "Study session progress";
  if (el.focusSessionProgressValue) el.focusSessionProgressValue.textContent = percentComplete + "%";
  if (el.focusSessionProgressFill) el.focusSessionProgressFill.style.width = percentComplete + "%";
  if (["strict", "breaks"].includes(session.mode) && session.endConfirmationUntil > Date.now() && el.focusExitCountdown) el.focusExitCountdown.textContent = "Session ending in " + Math.max(1, Math.ceil((session.endConfirmationUntil - Date.now()) / 1000)) + " seconds.";
  if (el.focusRemainingText) {
    el.focusRemainingText.textContent = formatClock(remainingMs) + " remaining";
    el.focusRemainingText.classList.toggle("hidden", session.mode === "breaks");
  }
  renderBreakSessionDetails(session);
  const liveMinutes = actualMinutesToday();
  if (liveMinutes !== lastLiveFocusMinutes) {
    lastLiveFocusMinutes = liveMinutes;
    el.todayFocus.textContent = formatDuration(liveMinutes);
    el.todayScore.textContent = String(productivityScore(state));
    renderTodayInsight();
    if ($("#tab-daily")?.classList.contains("active")) renderSystemGoals();
    if ($("#tab-analytics")?.classList.contains("active")) {
      el.goalProgress.textContent = goalProgressPercent(state) + "%";
      const weeklyMinutes = actualFocusSessions(7).reduce((sum, item) => sum + sessionActualMinutes(item), 0) + focusElapsedMinutes(session);
      const avgMinutes = Math.round(weeklyMinutes / 7);
      if (el.averageStudy) el.averageStudy.textContent = hours(avgMinutes);
      const todayMinutes = liveMinutes;
      if (el.dailyComparison) el.dailyComparison.textContent = (todayMinutes >= avgMinutes ? "+" : "-") + formatDuration(Math.abs(todayMinutes - avgMinutes));
    }
  }
}
function renderTodayInsight() {
  if (!el.todayInsightTitle || !el.todayInsightText) return;
  const insight = buildTodayInsight(state);
  el.todayInsightTitle.textContent = insight.title;
  el.todayInsightText.textContent = insight.text;
}
function renderCourses() {
  fillSelects();
  el.courseCount.textContent = state.courses.length + (state.courses.length === 1 ? " course" : " courses");
  renderLibraryManagement();
  renderCourseOverview();
  renderCourseLibraries();
  if (pendingYouTubeVideo && el.youtubeAddModal && !el.youtubeAddModal.classList.contains("hidden")) fillYouTubeAddSelects();
}
function courseName(courseId) { return state.courses.find((course) => course.id === courseId)?.title || "General study"; }
function escapeHtml(value = "") { return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;"); }
function inlineMarkdown(value = "") {
  return escapeHtml(value)
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/\*([^*]+)\*/g, "<em>$1</em>")
    .replace(/\[([^\]]+)]\((https?:\/\/[^\s)]+)\)/g, "<a href=\"$2\" target=\"_blank\" rel=\"noopener\">$1</a>");
}
function renderMarkdownPreview(value = "") {
  return String(value).split(/\r?\n/).map((line) => {
    if (/^###\s+/.test(line)) return "<h5>" + inlineMarkdown(line.replace(/^###\s+/, "")) + "</h5>";
    if (/^##\s+/.test(line)) return "<h4>" + inlineMarkdown(line.replace(/^##\s+/, "")) + "</h4>";
    if (/^#\s+/.test(line)) return "<h3>" + inlineMarkdown(line.replace(/^#\s+/, "")) + "</h3>";
    if (/^-\s+/.test(line)) return "<p class=\"markdown-bullet\">• " + inlineMarkdown(line.replace(/^-\s+/, "")) + "</p>";
    return line ? "<p>" + inlineMarkdown(line) + "</p>" : "<br>";
  }).join("");
}
function readNoteDraft() { try { return JSON.parse(localStorage.getItem(NOTE_DRAFT_KEY) || "null"); } catch { return null; } }
function clearNoteDraft() { clearTimeout(noteDraftTimer); localStorage.removeItem(NOTE_DRAFT_KEY); }
function queueNoteDraft() {
  clearTimeout(noteDraftTimer);
  noteDraftTimer = setTimeout(() => {
    const draft = {
      courseId: el.noteCourseInput?.value || "",
      title: el.noteTitleInput?.value || "",
      body: el.noteBodyInput?.value || "",
      checklist: el.noteChecklistInput?.value || "",
      pinned: Boolean(el.notePinnedInput?.checked),
      selectedNoteId
    };
    if (draft.title || draft.body || draft.checklist) localStorage.setItem(NOTE_DRAFT_KEY, JSON.stringify(draft));
  }, 450);
}
function noteChecklistFromInput(value) { return String(value || "").split("|").map((item) => item.trim()).filter(Boolean).slice(0, 80).map((text) => ({ id: uid("check"), text, done: false })); }
function setNoteEditor(note = null) {
  const draft = note ? null : readNoteDraft();
  selectedNoteId = note?.id || draft?.selectedNoteId || null;
  if (!el.noteForm) return;
  el.noteCourseInput.value = note?.courseId || draft?.courseId || state.settings.defaultCourseId || "";
  el.noteTitleInput.value = note?.title || draft?.title || "";
  el.noteBodyInput.value = note?.body || draft?.body || "";
  el.noteChecklistInput.value = note ? (note.checklist || []).map((item) => item.text).join(" | ") : (draft?.checklist || "");
  el.notePinnedInput.checked = note ? Boolean(note.pinned) : Boolean(draft?.pinned);
  el.noteSaveBtn.textContent = note ? "Update Note" : "Save Note";
  renderNoteCharacterCount();
}
function renderNoteCharacterCount() {
  if (el.noteCharacterCount) el.noteCharacterCount.textContent = (el.noteBodyInput?.value?.length || 0).toLocaleString() + " / 50,000";
}
function renderNotes() {
  if (!el.noteList) return;
  renderNoteCharacterCount();
  const search = String(el.noteSearchInput?.value || "").trim().toLowerCase();
  const notes = [...state.notes].filter((note) => !search || [note.title, note.body, note.checklist.map((item) => item.text).join(" "), courseName(note.courseId)].join(" ").toLowerCase().includes(search)).sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt - a.updatedAt);
  el.noteList.innerHTML = "";
  if (!notes.length) {
    el.noteList.innerHTML = "<div class='empty-state compact-empty'><h4>No notes yet</h4><p>Save a short summary, formula, or checklist for the course you are studying.</p></div>";
    return;
  }
  notes.forEach((note) => {
    const card = document.createElement("article");
    card.className = "note-card" + (note.pinned ? " pinned" : "");
    card.innerHTML = "<div class='note-card-header'><div><span class='tag'></span><h4></h4><p></p></div><div class='note-actions'><button class='button secondary compact-button edit' type='button'>Edit</button><button class='icon-button danger remove' type='button' aria-label='Delete note'>x</button></div></div><div class='note-body'></div><div class='note-checklist'></div>";
    card.querySelector(".tag").textContent = note.pinned ? "Pinned" : courseName(note.courseId);
    card.querySelector("h4").textContent = note.title;
    card.querySelector(".note-card-header p").textContent = "Updated " + new Date(note.updatedAt).toLocaleDateString();
    card.querySelector(".note-body").innerHTML = note.body ? renderMarkdownPreview(note.body) : "<p>Checklist only</p>";
    const checklist = card.querySelector(".note-checklist");
    (note.checklist || []).forEach((item) => {
      const label = document.createElement("label");
      const check = document.createElement("input");
      check.type = "checkbox";
      check.checked = item.done;
      check.addEventListener("change", () => updateNote(note.id, { checklist: note.checklist.map((entry) => entry.id === item.id ? { ...entry, done: check.checked } : entry) }));
      const text = document.createElement("span");
      text.textContent = item.text;
      label.append(check, text);
      checklist.append(label);
    });
    card.querySelector(".edit").addEventListener("click", () => setNoteEditor(note));
    card.querySelector(".remove").addEventListener("click", () => deleteNote(note.id));
    el.noteList.append(card);
  });
}
async function updateNote(id, patch) {
  await saveState({ ...state, notes: state.notes.map((note) => note.id === id ? { ...note, ...patch, updatedAt: Date.now() } : note) });
}
async function saveNote(event) {
  event.preventDefault();
  const title = el.noteTitleInput.value.trim();
  const body = el.noteBodyInput.value.trim();
  const checklist = noteChecklistFromInput(el.noteChecklistInput.value);
  if (!title && !body && !checklist.length) return showToast("Add a title, note, or checklist first.");
  const previous = state.notes.find((note) => note.id === selectedNoteId);
  const next = {
    id: previous?.id || uid("note"),
    courseId: el.noteCourseInput.value || null,
    title: title || "Untitled note",
    body,
    checklist: previous?.checklist?.length && el.noteChecklistInput.value === previous.checklist.map((item) => item.text).join(" | ") ? previous.checklist : checklist,
    pinned: el.notePinnedInput.checked,
    createdAt: previous?.createdAt || Date.now(),
    updatedAt: Date.now()
  };
  await saveState({ ...state, notes: previous ? state.notes.map((note) => note.id === previous.id ? next : note) : [next, ...state.notes] });
  clearNoteDraft();
  setNoteEditor(null);
  showToast(previous ? "Note updated." : "Note saved.");
}
async function deleteNote(id) {
  const note = state.notes.find((item) => item.id === id);
  if (!note || !confirm("Delete note '" + note.title + "'?")) return;
  const previous = state;
  await saveState({ ...state, notes: state.notes.filter((item) => item.id !== id) });
  if (selectedNoteId === id) setNoteEditor(null);
  showUndo("Note deleted.", previous);
}
function exportNotes() {
  const blob = new Blob([JSON.stringify({ notes: state.notes }, null, 2)], { type: "application/json" });
  const anchor = document.createElement("a");
  anchor.href = URL.createObjectURL(blob);
  anchor.download = "studizen-notes.json";
  anchor.click();
  URL.revokeObjectURL(anchor.href);
}
async function importNotes(event) {
  const file = event.target.files?.[0];
  if (!file) return;
  try {
    const parsed = JSON.parse(await file.text());
    const incoming = Array.isArray(parsed) ? parsed : parsed.notes;
    if (!Array.isArray(incoming)) throw new Error("Invalid note backup.");
    const merged = [...state.notes];
    incoming.forEach((note) => {
      const index = merged.findIndex((item) => item.id === note.id);
      if (index >= 0) merged[index] = note; else merged.push(note);
    });
    await saveState({ ...state, notes: merged });
    showToast("Notes imported.");
  } catch { showToast("That note backup could not be imported."); }
  event.target.value = "";
}
function nextReviewCard() {
  const cards = state.flashcards || [];
  if (!cards.length) return null;
  const current = cards.find((card) => card.id === reviewFlashcardId);
  if (current) return current;
  return [...cards].sort((a, b) => (a.lastReviewedAt || 0) - (b.lastReviewedAt || 0))[0];
}
function renderFlashcards() {
  if (!el.flashcardReview || !el.flashcardList) return;
  const cards = state.flashcards || [];
  el.flashcardCount.textContent = cards.length + (cards.length === 1 ? " card" : " cards");
  const review = nextReviewCard();
  el.flashcardReview.innerHTML = "";
  if (!review) el.flashcardReview.innerHTML = "<div class='empty-state compact-empty'><h4>Ready when you are</h4><p>Add a question and answer pair to begin a quick revision.</p></div>";
  else {
    const card = document.createElement("article");
    card.className = "flashcard-review-card" + (flashcardAnswerVisible ? " revealed" : "");
    card.innerHTML = "<span></span><strong></strong><p></p><div class='flashcard-actions'></div>";
    card.querySelector("span").textContent = review.category + " - " + courseName(review.courseId);
    card.querySelector("strong").textContent = flashcardAnswerVisible ? "Answer" : "Question";
    card.querySelector("p").textContent = flashcardAnswerVisible ? review.back : review.front;
    const actions = card.querySelector(".flashcard-actions");
    if (!flashcardAnswerVisible) {
      const reveal = document.createElement("button");
      reveal.className = "button primary";
      reveal.type = "button";
      reveal.textContent = "Reveal Answer";
      reveal.addEventListener("click", () => { flashcardAnswerVisible = true; renderFlashcards(); });
      actions.append(reveal);
    } else {
      [["Again", "secondary"], ["I knew it", "primary"]].forEach(([label, tone]) => {
        const button = document.createElement("button");
        button.className = "button " + tone;
        button.type = "button";
        button.textContent = label;
        button.addEventListener("click", () => reviewFlashcard(review.id));
        actions.append(button);
      });
    }
    el.flashcardReview.append(card);
  }
  el.flashcardList.innerHTML = "";
  cards.slice().sort((a, b) => (b.lastReviewedAt || 0) - (a.lastReviewedAt || 0)).slice(0, 10).forEach((card) => {
    const row = document.createElement("article");
    row.className = "flashcard-row";
    row.innerHTML = "<div><span></span><strong></strong><p></p></div><button class='button secondary compact-button review' type='button'>Review</button><button class='icon-button danger remove' type='button' aria-label='Delete flashcard'>x</button>";
    row.querySelector("span").textContent = card.category;
    row.querySelector("strong").textContent = card.front;
    row.querySelector("p").textContent = card.reviews + " reviews";
    row.querySelector(".review").addEventListener("click", () => { reviewFlashcardId = card.id; flashcardAnswerVisible = false; renderFlashcards(); });
    row.querySelector(".remove").addEventListener("click", () => deleteFlashcard(card.id));
    el.flashcardList.append(row);
  });
}
async function addFlashcard(event) {
  event.preventDefault();
  const front = el.flashcardFrontInput.value.trim();
  const back = el.flashcardBackInput.value.trim();
  if (!front || !back) return showToast("Add both a question and an answer.");
  const card = { id: uid("card"), courseId: el.flashcardCourseInput.value || null, category: el.flashcardCategoryInput.value.trim() || "General", front, back, reviews: 0, lastReviewedAt: null, createdAt: Date.now() };
  await saveState({ ...state, flashcards: [card, ...state.flashcards] });
  el.flashcardForm.reset();
  flashcardAnswerVisible = false;
  reviewFlashcardId = card.id;
  showToast("Flashcard added.");
}
async function reviewFlashcard(id) {
  await saveState({ ...state, flashcards: state.flashcards.map((card) => card.id === id ? { ...card, reviews: (card.reviews || 0) + 1, lastReviewedAt: Date.now() } : card) });
  reviewFlashcardId = null;
  flashcardAnswerVisible = false;
}
async function deleteFlashcard(id) {
  if (!confirm("Delete this flashcard?")) return;
  await saveState({ ...state, flashcards: state.flashcards.filter((card) => card.id !== id) });
  if (reviewFlashcardId === id) reviewFlashcardId = null;
}
function resourceSource(url) {
  const host = safeUrl(url)?.hostname.replace(/^www\./, "").toLowerCase() || "resource";
  if (host === "youtu.be" || host.endsWith("youtube.com")) return { type: "youtube", label: "YouTube", host, mark: "YT" };
  return { type: "web", label: host, host, mark: host.slice(0, 2).toUpperCase() || "WEB" };
}
function studyLinkRecords() {
  return state.courses.flatMap((course) => {
    const primary = [{ id: "course:" + course.id, kind: "course", course, title: course.title, url: course.url, addedAt: Number(course.createdAt || 0), source: resourceSource(course.url) }];
    const videos = (Array.isArray(course.videos) ? course.videos : []).map((video) => ({ id: "video:" + course.id + ":" + video.id, kind: "video", course, video, title: video.title || "YouTube video", url: video.url, addedAt: Number(video.addedAt || course.createdAt || 0), source: resourceSource(video.url) }));
    return [...primary, ...videos];
  });
}
function resetStudyLinkFilters() {
  courseLibraryQuery = "";
  courseLibrarySource = "all";
  courseLibrarySort = "priority";
  courseLibraryLimit = 60;
  renderCourseLibraries();
}
function setCourseLibraryExpanded(expanded) {
  courseLibraryExpanded = Boolean(expanded);
  try { sessionStorage.setItem("courseFocusProStudyLinkLibraryExpanded", String(courseLibraryExpanded)); } catch {}
  if (el.studyLinkLibraryPanel) el.studyLinkLibraryPanel.dataset.expanded = String(courseLibraryExpanded);
  if (el.studyLinkLibraryToggle) el.studyLinkLibraryToggle.setAttribute("aria-expanded", String(courseLibraryExpanded));
}
function setSiteControlExpanded(expanded) {
  siteControlExpanded = Boolean(expanded);
  try { sessionStorage.setItem("courseFocusProSiteControlExpanded", String(siteControlExpanded)); } catch {}
  if (el.siteControlSection) el.siteControlSection.dataset.expanded = String(siteControlExpanded);
  if (el.siteControlToggle) el.siteControlToggle.setAttribute("aria-expanded", String(siteControlExpanded));
  if (el.siteControlBody) {
    el.siteControlBody.classList.toggle("is-expanded", siteControlExpanded);
    el.siteControlBody.setAttribute("aria-hidden", String(!siteControlExpanded));
    el.siteControlBody.toggleAttribute("inert", !siteControlExpanded);
  }
}
function setSettingsDisclosureExpanded(key, expanded) {
  if (!Object.hasOwn(settingsDisclosureExpanded, key)) return;
  settingsDisclosureExpanded[key] = Boolean(expanded);
  try { sessionStorage.setItem("studizenSettingsDisclosureExpanded", JSON.stringify(settingsDisclosureExpanded)); } catch {}
  const panel = document.querySelector("[data-settings-disclosure='" + key + "']");
  const toggles = document.querySelectorAll("[data-settings-disclosure-toggle='" + key + "']");
  const body = panel?.querySelector(".settings-disclosure-body");
  if (panel) panel.dataset.expanded = String(settingsDisclosureExpanded[key]);
  toggles.forEach((toggle) => toggle.setAttribute("aria-expanded", String(settingsDisclosureExpanded[key])));
  if (body) {
    body.classList.toggle("is-expanded", settingsDisclosureExpanded[key]);
    body.setAttribute("aria-hidden", String(!settingsDisclosureExpanded[key]));
    body.toggleAttribute("inert", !settingsDisclosureExpanded[key]);
  }
}
function sortStudyLinks(links) {
  const sorted = [...links];
  if (courseLibrarySort === "alpha") return sorted.sort((a, b) => a.title.localeCompare(b.title) || a.source.label.localeCompare(b.source.label));
  if (courseLibrarySort === "recent") return sorted.sort((a, b) => b.addedAt - a.addedAt || a.title.localeCompare(b.title));
  return sorted.sort((a, b) => {
    const aPriority = (a.course.id === state.settings.defaultCourseId ? 4 : 0) + (a.kind === "course" ? 2 : 0) + (a.course.lastUsedAt ? 1 : 0);
    const bPriority = (b.course.id === state.settings.defaultCourseId ? 4 : 0) + (b.kind === "course" ? 2 : 0) + (b.course.lastUsedAt ? 1 : 0);
    return bPriority - aPriority || b.addedAt - a.addedAt || a.title.localeCompare(b.title);
  });
}
function visibleStudyLinks() {
  const query = courseLibraryQuery.trim().toLowerCase();
  const filtered = studyLinkRecords().filter((link) => {
    if (courseLibrarySource !== "all" && link.source.type !== courseLibrarySource) return false;
    if (!query) return true;
    return [link.title, link.url, link.source.label, link.course.title, link.course.subject].some((value) => String(value || "").toLowerCase().includes(query));
  });
  return { all: filtered, visible: sortStudyLinks(filtered).slice(0, courseLibraryLimit) };
}
function isProtectedCourseLibrary(library) {
  return Boolean(library && (library.id === "library-main" || library.system === true || library.isDefault === true || String(library.name || "").trim().toLowerCase() === "my library"));
}
function renderLibraryManagement() {
  const list = el.libraryManagementList;
  if (!list) return;
  list.replaceChildren();
  const libraries = state.courseLibraries || [];
  const customLibraries = libraries.filter((library) => !isProtectedCourseLibrary(library));
  libraries.forEach((library) => {
    const row = document.createElement("article");
    row.className = "library-manage-row";
    row.dataset.libraryId = library.id;
    const identity = document.createElement("div");
    identity.className = "library-manage-identity";
    const icon = document.createElement("span");
    icon.className = "library-folder-icon";
    icon.setAttribute("aria-hidden", "true");
    icon.innerHTML = "<svg viewBox='0 0 20 20' focusable='false'><path d='M2.5 5.5a1.5 1.5 0 0 1 1.5-1.5h4l1.6 1.8h6.4A1.5 1.5 0 0 1 17.5 7v7.5A1.5 1.5 0 0 1 16 16H4a1.5 1.5 0 0 1-1.5-1.5z'/></svg>";
    const copy = document.createElement("div");
    copy.className = "library-manage-copy";
    const name = document.createElement("strong");
    name.textContent = library.name;
    name.title = library.name;
    const courseCount = libraries.length && state.courses.filter((course) => course.libraryId === library.id).length;
    const count = document.createElement("small");
    count.textContent = courseCount + (courseCount === 1 ? " course" : " courses");
    copy.append(name, count);
    identity.append(icon, copy);
    row.append(identity);

    if (isProtectedCourseLibrary(library)) {
      const badge = document.createElement("span");
      badge.className = "library-default-badge";
      badge.textContent = "Default";
      row.append(badge);
    } else if (editingLibraryId === library.id) {
      const form = document.createElement("form");
      form.className = "library-rename-form";
      const input = document.createElement("input");
      input.type = "text";
      input.value = library.name;
      input.maxLength = 48;
      input.required = true;
      input.setAttribute("aria-label", "New name for " + library.name);
      const save = document.createElement("button");
      save.type = "submit";
      save.className = "button primary compact-button";
      save.textContent = "Save";
      const cancel = document.createElement("button");
      cancel.type = "button";
      cancel.className = "button secondary compact-button";
      cancel.textContent = "Cancel";
      cancel.addEventListener("click", () => { editingLibraryId = null; renderLibraryManagement(); });
      form.append(input, save, cancel);
      form.addEventListener("submit", (event) => { event.preventDefault(); void renameLibrary(library.id, input.value); });
      row.append(form);
      requestAnimationFrame(() => { input.focus(); input.select(); });
    } else {
      const actions = document.createElement("div");
      actions.className = "library-manage-actions";
      const trigger = document.createElement("button");
      trigger.type = "button";
      trigger.className = "icon-button library-manage-menu-trigger";
      trigger.textContent = "⋯";
      trigger.title = "Library actions";
      trigger.setAttribute("aria-label", "Actions for " + library.name);
      trigger.setAttribute("aria-haspopup", "menu");
      trigger.setAttribute("aria-expanded", String(openLibraryMenuId === library.id));
      trigger.addEventListener("click", (event) => {
        event.stopPropagation();
        openLibraryMenuId = openLibraryMenuId === library.id ? null : library.id;
        renderLibraryManagement();
        list.querySelector("[data-library-id='" + CSS.escape(library.id) + "'] .library-manage-menu-trigger")?.focus({ preventScroll: true });
      });
      actions.append(trigger);
      if (openLibraryMenuId === library.id) {
        const menu = document.createElement("div");
        menu.className = "library-manage-menu";
        menu.setAttribute("role", "menu");
        const rename = document.createElement("button");
        rename.type = "button";
        rename.className = "library-manage-menu-item";
        rename.setAttribute("role", "menuitem");
        rename.textContent = "Rename";
        rename.addEventListener("click", () => { openLibraryMenuId = null; editingLibraryId = library.id; renderLibraryManagement(); });
        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "library-manage-menu-item danger";
        remove.setAttribute("role", "menuitem");
        remove.textContent = "Delete library";
        remove.addEventListener("click", () => { openLibraryMenuId = null; openLibraryDeleteDialog(library.id); });
        menu.append(rename, remove);
        actions.append(menu);
      }
      row.append(actions);
    }
    list.append(row);
  });
  if (!customLibraries.length) {
    const empty = document.createElement("p");
    empty.className = "library-management-empty";
    empty.textContent = "No custom libraries yet. Create one above to organize courses.";
    list.append(empty);
  }
}
function actionButton(label, handler, danger = false) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "study-link-menu-button" + (danger ? " danger" : "");
  button.textContent = label;
  button.addEventListener("click", handler);
  return button;
}
function closeStudyLinkMenu() {
  if (!activeStudyLinkMenu) return;
  activeStudyLinkMenu.trigger.setAttribute("aria-expanded", "false");
  activeStudyLinkMenu.menu.remove();
  activeStudyLinkMenu = null;
}
function positionStudyLinkMenu(menu, trigger) {
  const margin = 8;
  const triggerRect = trigger.getBoundingClientRect();
  const menuRect = menu.getBoundingClientRect();
  const maxLeft = Math.max(margin, window.innerWidth - menuRect.width - margin);
  const maxTop = Math.max(margin, window.innerHeight - menuRect.height - margin);
  const left = Math.max(margin, Math.min(maxLeft, triggerRect.right - menuRect.width));
  const below = triggerRect.bottom + 6;
  const above = triggerRect.top - menuRect.height - 6;
  const top = below <= maxTop ? below : Math.max(margin, Math.min(maxTop, above));
  menu.style.left = Math.round(left) + "px";
  menu.style.top = Math.round(top) + "px";
  menu.style.visibility = "visible";
}
function openStudyLinkMenu(trigger, link) {
  if (activeStudyLinkMenu?.linkId === link.id) {
    closeStudyLinkMenu();
    return;
  }
  closeStudyLinkMenu();
  const menu = document.createElement("div");
  menu.className = "study-link-menu-items";
  menu.setAttribute("role", "menu");
  menu.setAttribute("aria-label", "Actions for " + link.title);
  menu.style.visibility = "hidden";
  menu.append(studyLinkMenuItems(link));
  menu.addEventListener("click", (event) => {
    event.stopPropagation();
    if (event.target.closest?.(".study-link-menu-button")) queueMicrotask(closeStudyLinkMenu);
  });
  document.body.append(menu);
  activeStudyLinkMenu = { linkId: link.id, menu, trigger };
  trigger.setAttribute("aria-expanded", "true");
  positionStudyLinkMenu(menu, trigger);
}
async function editStudyLink(link) {
  if (link.kind === "course") {
    const title = prompt("Course title", link.course.title)?.trim();
    if (!title) return;
    const url = validUrl(prompt("Course link", link.course.url) || "");
    if (!url) return showToast("Paste a valid course link.");
    await saveState({ ...state, courses: state.courses.map((course) => course.id === link.course.id ? { ...course, title: title.slice(0, 180), url: normalizeUrl(url) } : course) });
    showToast("Course link updated.");
    return;
  }
  const title = prompt("Video title", link.video.title)?.trim();
  if (!title) return;
  const url = canonicalYouTubeVideoUrl(prompt("YouTube video link", link.video.url) || "");
  if (!url) return showToast("Paste a supported YouTube video link.");
  const duplicate = state.courses.some((course) => canonicalYouTubeVideoUrl(course.url) === url || (course.videos || []).some((video) => video.id !== link.video.id && canonicalYouTubeVideoUrl(video.url) === url));
  if (duplicate) return showToast("This video is already in Studizen.");
  await saveState({ ...state, courses: state.courses.map((course) => course.id === link.course.id ? { ...course, videos: (course.videos || []).map((video) => video.id === link.video.id ? { ...video, title: title.slice(0, 180), url } : video) } : course) });
  showToast("Video updated.");
}
function studyLinkMenuItems(link) {
  const actions = document.createElement("div");
  actions.className = "study-link-menu-actions";
  actions.append(actionButton("Edit", () => editStudyLink(link)));
  if (link.kind === "course") {
    actions.append(actionButton(link.course.id === state.settings.defaultCourseId ? "Current course" : "Set as current", () => updateSettings({ defaultCourseId: link.course.id }).then(() => showToast("Course selected."))));
    actions.append(actionButton("Start focus", () => startFocus(link.course.id)));
    const move = document.createElement("label");
    move.className = "study-link-menu-select";
    move.textContent = "Move to";
    const select = document.createElement("select");
    state.courseLibraries.forEach((library) => {
      const option = document.createElement("option");
      option.value = library.id;
      option.textContent = library.name;
      option.selected = library.id === link.course.libraryId;
      select.append(option);
    });
    select.addEventListener("change", () => { moveCourseToLibrary(link.course.id, select.value); closeStudyLinkMenu(); });
    move.append(select);
    actions.append(move);
    actions.append(actionButton("Delete course", () => deleteCourse(link.course.id), true));
  } else actions.append(actionButton("Delete link", () => removeCourseVideo(link.course.id, link.video.id), true));
  return actions;
}
function studyLinkMenu(link) {
  const menu = document.createElement("div");
  menu.className = "study-link-action-menu";
  const trigger = document.createElement("button");
  trigger.type = "button";
  trigger.className = "study-link-menu-trigger";
  trigger.setAttribute("aria-label", "More actions for " + link.title);
  trigger.setAttribute("aria-haspopup", "menu");
  trigger.setAttribute("aria-expanded", "false");
  trigger.title = "More actions";
  trigger.textContent = "...";
  trigger.addEventListener("click", (event) => { event.stopPropagation(); openStudyLinkMenu(trigger, link); });
  menu.append(trigger);
  return menu;
}
function studyLinkRow(link) {
  const row = document.createElement("article");
  row.className = "study-link-row" + (link.course.id === state.settings.defaultCourseId && link.kind === "course" ? " is-current" : "");
  const icon = document.createElement("span");
  icon.className = "study-link-source" + (link.source.type === "youtube" ? " youtube" : "");
  icon.textContent = link.source.mark;
  icon.setAttribute("aria-hidden", "true");
  const copy = document.createElement("div");
  copy.className = "study-link-copy";
  const subject = document.createElement("span");
  subject.className = "study-link-subject";
  subject.textContent = link.course.subject || "Study resource";
  const title = document.createElement("strong");
  title.textContent = link.title;
  title.title = link.title;
  const meta = document.createElement("span");
  const status = link.course.id === state.settings.defaultCourseId ? "Current" : "Saved";
  meta.className = "study-link-meta";
  meta.textContent = link.source.label + " · " + status;
  copy.append(subject, title, meta);
  const open = document.createElement("button");
  open.type = "button";
  open.className = "button secondary compact-button study-link-open";
  open.textContent = "Open";
  open.addEventListener("click", () => openCourse(link.url));
  row.append(icon, copy, open, studyLinkMenu(link));
  return row;
}
function courseLinkGroup(course, links) {
  const group = document.createElement("section");
  group.className = "study-link-course-group";
  const rows = document.createElement("div");
  rows.className = "study-link-list";
  links.forEach((link) => rows.append(studyLinkRow(link)));
  group.append(rows);
  return group;
}
function renderCourseOverview() {
  if (!el.courseOverview) return;
  el.courseOverview.innerHTML = "";
  const coursesById = new Map(state.courses.map((course) => [course.id, course]));
  const recentByCourse = new Map();
  (Array.isArray(state.analytics?.focusHistory) ? state.analytics.focusHistory : []).forEach((session) => {
    const minutes = sessionActualMinutes(session);
    const endedAt = Number(session?.endedAt || session?.startedAt || 0);
    if (!minutes || !Number.isFinite(endedAt) || endedAt <= 0) return;
    const course = coursesById.get(session.courseId) || state.courses.find((item) => item.title === session.courseTitle);
    if (!course) return;
    const existing = recentByCourse.get(course.id);
    if (!existing || endedAt > existing.endedAt) recentByCourse.set(course.id, { course, session, minutes, endedAt });
  });
  const recent = [...recentByCourse.values()].sort((a, b) => b.endedAt - a.endedAt).slice(0, 3);
  if (!recent.length) {
    el.courseOverview.innerHTML = "<div class='recent-study-empty'><strong>No recent study yet</strong><span>Your recent study activity will appear here after your first Focus session.</span></div>";
    return;
  }
  const list = document.createElement("div");
  list.className = "recent-study-list";
  recent.forEach(({ course, session, minutes, endedAt }) => {
    const row = document.createElement("section");
    row.className = "recent-study-row";
    const date = new Date(endedAt);
    const dateKey = session.recordedDate || todayKey(date);
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const day = dateKey === todayKey() ? "Today" : dateKey === todayKey(yesterday) ? "Yesterday" : date.toLocaleDateString([], { month: "short", day: "numeric", year: date.getFullYear() === new Date().getFullYear() ? undefined : "numeric" });
    row.innerHTML = "<div class='recent-study-copy'><span class='recent-study-subject'></span><h4 title=''></h4><p></p></div><button class='button secondary recent-study-open' type='button'>Open course</button>";
    row.querySelector(".recent-study-subject").textContent = course.subject || session.subject || "Study course";
    const title = row.querySelector("h4");
    title.textContent = course.title;
    title.title = course.title;
    row.querySelector("p").textContent = "Studied " + formatDuration(minutes) + " · " + day;
    row.querySelector(".recent-study-open").addEventListener("click", () => openCourse(course.url));
    list.append(row);
  });
  el.courseOverview.append(list);
}
function renderCourseLibraries() {
  if (!el.courseLibrariesList) return;
  closeStudyLinkMenu();
  setCourseLibraryExpanded(courseLibraryExpanded);
  el.courseLibrariesList.innerHTML = "";
  const totalLinks = studyLinkRecords().length;
  if (el.courseCount) el.courseCount.textContent = state.courses.length + (state.courses.length === 1 ? " course" : " courses") + " · " + totalLinks + (totalLinks === 1 ? " link" : " links");
  if (el.courseLibrarySearch) el.courseLibrarySearch.value = courseLibraryQuery;
  if (el.courseLibrarySource) el.courseLibrarySource.value = courseLibrarySource;
  if (el.courseLibrarySort) el.courseLibrarySort.value = courseLibrarySort;
  if (!state.courses.length) { el.courseLibrariesList.innerHTML = "<div class='empty-state study-link-empty'><h4>No saved study links yet</h4><p>Add a course above, or right-click a YouTube video and choose Add to Studizen.</p></div>"; return; }
  const { all, visible } = visibleStudyLinks();
  if (!all.length) {
    const empty = document.createElement("div");
    empty.className = "empty-state study-link-empty";
    empty.innerHTML = "<h4>No matching study links</h4><p>Try another title, source, or sort option.</p>";
    const clear = document.createElement("button");
    clear.type = "button";
    clear.className = "button secondary compact-button";
    clear.textContent = "Clear filters";
    clear.addEventListener("click", resetStudyLinkFilters);
    empty.append(clear);
    el.courseLibrariesList.append(empty);
    return;
  }
  state.courseLibraries.forEach((library) => {
    const links = visible.filter((link) => link.course.libraryId === library.id);
    const totalInLibrary = all.filter((link) => link.course.libraryId === library.id).length;
    if (!links.length && !totalInLibrary) return;
    const section = document.createElement("details");
    section.className = "course-library study-link-library";
    section.open = courseLibraryQuery || courseLibrarySource !== "all" ? true : !library.collapsed;
    section.innerHTML = "<summary><span></span><strong></strong></summary><div class='course-library-list'></div>";
    section.querySelector("span").textContent = library.name;
    section.querySelector("strong").textContent = totalInLibrary + (totalInLibrary === 1 ? " link" : " links");
    section.addEventListener("toggle", () => setLibraryCollapsed(library.id, !section.open));
    const list = section.querySelector(".course-library-list");
    if (!links.length) list.innerHTML = "<div class='empty-state compact-empty'><p>Matching links are outside the current view. Load more to see them.</p></div>";
    const courseIds = [...new Set(links.map((link) => link.course.id))];
    courseIds.forEach((courseId) => {
      const course = state.courses.find((item) => item.id === courseId);
      const courseLinks = links.filter((link) => link.course.id === courseId);
      if (course && courseLinks.length) list.append(courseLinkGroup(course, courseLinks));
    });
    el.courseLibrariesList.append(section);
  });
  if (all.length > visible.length) {
    const more = document.createElement("button");
    more.type = "button";
    more.className = "button secondary study-link-load-more";
    more.textContent = "Show 60 more links (" + (all.length - visible.length) + " remaining)";
    more.addEventListener("click", () => { courseLibraryLimit += 60; renderCourseLibraries(); });
    el.courseLibrariesList.append(more);
  }
}
function siteRuleInfo(pattern) {
  const domain = String(pattern || "").replace(/^https?:\/\//, "").replace(/^www\./, "");
  const host = domain.split("/")[0];
  const named = { "docs.google.com": "Google Docs", "drive.google.com": "Google Drive", "classroom.google.com": "Google Classroom", "youtube.com": "YouTube", "wikipedia.org": "Wikipedia", "github.com": "GitHub", "instagram.com": "Instagram", "reddit.com": "Reddit", "facebook.com": "Facebook", "netflix.com": "Netflix", "discord.com": "Discord", "twitter.com": "X / Twitter", "x.com": "X / Twitter" };
  const key = Object.keys(named).find((item) => host === item || host.endsWith("." + item));
  const name = key ? named[key] : host.replace(/^www\./, "").split(".")[0].replace(/[-_]/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
  return { domain, name, mark: name.slice(0, 2).toUpperCase() };
}
function renderSiteRuleList(container, patterns, query, mode) {
  if (!container) return;
  const all = cleanPatterns(patterns);
  const visible = all.filter((pattern) => (siteRuleInfo(pattern).name + " " + pattern).toLowerCase().includes(query.toLowerCase()));
  container.innerHTML = "";
  if (!visible.length) { const empty = document.createElement("div"); empty.className = "site-rule-empty"; empty.innerHTML = "<strong>" + (all.length ? "No matching sites" : mode === "allowed" ? "No supporting sites yet" : "No distracting sites saved") + "</strong><span>" + (all.length ? "Try a different search." : mode === "allowed" ? "Add the study tools you need during Focus Mode." : "Add a site to keep it visible in your distraction watchlist.") + "</span>"; container.append(empty); return; }
  visible.slice(0, 80).forEach((pattern) => {
    const info = siteRuleInfo(pattern); const row = document.createElement("article"); row.className = "site-rule-row " + mode; row.title = info.domain;
    const badge = document.createElement("span"); badge.className = "site-rule-icon"; badge.textContent = info.mark;
    const copy = document.createElement("div"); copy.className = "site-rule-copy"; const title = document.createElement("strong"); title.textContent = info.name; const domain = document.createElement("span"); domain.textContent = info.domain; domain.title = info.domain; copy.append(title, domain);
    const protectionEnabled = isDistractionProtectionEnabled(state.settings);
    const protectionStatus = websiteProtectionPermissionGranted === false && protectionEnabled ? "Permission required" : websiteProtectionPermissionGranted === null && protectionEnabled ? "Checking" : protectionEnabled && websiteProtectionPermissionGranted === true ? "Protected" : "Off";
    const status = document.createElement("span"); status.className = "site-rule-status"; status.textContent = mode === "allowed" ? "Focus Mode" : protectionStatus;
    const actions = document.createElement("div"); actions.className = "site-rule-actions";
    const open = actionButton("Open", () => openCourse("https://" + info.domain)); const edit = actionButton("Edit", async () => { const next = prompt("Edit site domain", pattern)?.trim().toLowerCase(); if (!next || next === pattern) return; const key = mode === "allowed" ? "allowedSites" : "blockedSites"; await updateSettings({ [key]: cleanPatterns(state.settings[key].map((item) => item === pattern ? next : item)) }); }); const remove = actionButton("Remove", () => { const key = mode === "allowed" ? "allowedSites" : "blockedSites"; updateSettings({ [key]: state.settings[key].filter((item) => item !== pattern) }); });
    [open, edit, remove].forEach((button) => button.classList.add("site-rule-action")); remove.classList.add("danger"); actions.append(open, edit, remove); row.append(badge, copy, status, actions); container.append(row);
  });
  if (visible.length > 80) { const note = document.createElement("p"); note.className = "site-rule-limit"; note.textContent = "Showing the first 80 matching sites. Refine your search to narrow the list."; container.append(note); }
}
function renderShield() {
  if (el.allowedCount) el.allowedCount.textContent = String(state.settings.allowedSites.length);
  if (el.blockedCount) el.blockedCount.textContent = String(state.settings.blockedSites.length);
  const distractionProtectionEnabled = isOutsideFocusProtectionEnabled(state.settings) && websiteProtectionPermissionGranted === true;
  if (el.distractionProtectionInput) {
    el.distractionProtectionInput.checked = distractionProtectionEnabled;
    el.distractionProtectionInput.setAttribute("aria-checked", String(distractionProtectionEnabled));
  }
  if (el.distractionProtectionState) {
    el.distractionProtectionState.textContent = websiteProtectionPermissionGranted === false ? "Permission required" : distractionProtectionEnabled ? "On" : websiteProtectionPermissionGranted === null ? "Checking" : "Off";
    el.distractionProtectionState.dataset.state = distractionProtectionEnabled ? "on" : websiteProtectionPermissionGranted === false && isOutsideFocusProtectionEnabled(state.settings) ? "permission-required" : "off";
  }
  renderDistractionProtectionConsent();
  renderFocusSessionProtection();
  const incognitoEnabled = Boolean(state.settings.incognitoProtection && incognitoAccessAllowed === true);
  if (el.incognitoProtectionInput) {
    el.incognitoProtectionInput.checked = incognitoEnabled;
    el.incognitoProtectionInput.disabled = incognitoAccessAllowed !== true;
  }
  if (el.incognitoProtectionState) {
    el.incognitoProtectionState.textContent = incognitoAccessAllowed === false ? "Permission Required" : incognitoAccessAllowed === null ? "Checking" : incognitoEnabled ? "On" : "Off";
    el.incognitoProtectionState.dataset.state = incognitoAccessAllowed === false ? "required" : incognitoAccessAllowed === null ? "checking" : incognitoEnabled ? "on" : "off";
  }
  if (el.openIncognitoSettingsBtn) {
    el.openIncognitoSettingsBtn.hidden = !hasChrome || incognitoAccessAllowed !== false;
    el.openIncognitoSettingsBtn.disabled = incognitoAccessAllowed === null;
  }
  if (el.youtubeStudyModeState) {
    el.youtubeStudyModeState.textContent = state.settings.youtubeStudyModeEnabled ? "On" : "Off";
    el.youtubeStudyModeState.dataset.state = state.settings.youtubeStudyModeEnabled ? "on" : "off";
  }
  renderSiteRuleList(el.allowedList, state.settings.allowedSites, allowedSiteQuery, "allowed");
  renderSiteRuleList(el.blockedList, state.settings.blockedSites, blockedSiteQuery, "blocked");
  renderFocusEnhancements();
}
function renderDistractionProtectionConsent() {
  const visible = distractionProtectionConsentPromptVisible && !state.settings.distractionProtectionConsentAccepted;
  if (el.distractionProtectionConsent) {
    el.distractionProtectionConsent.hidden = !visible;
    el.distractionProtectionConsent.classList.toggle("hidden", !visible);
    el.distractionProtectionConsent.setAttribute("aria-busy", String(distractionProtectionConsentSaving));
  }
  if (el.distractionProtectionInput) {
    el.distractionProtectionInput.setAttribute("aria-expanded", String(visible));
    if (el.distractionProtectionConsent) el.distractionProtectionInput.setAttribute("aria-controls", "distractionProtectionConsent");
  }
  [el.distractionProtectionConsentAccept, el.distractionProtectionConsentDecline].filter(Boolean).forEach((button) => {
    button.disabled = distractionProtectionConsentSaving;
  });
}
function renderFocusSessionProtectionConsent() {
  const visible = focusSessionProtectionConsentPromptVisible && !state.settings.distractionProtectionConsentAccepted;
  if (el.focusSessionProtectionConsent) {
    el.focusSessionProtectionConsent.hidden = !visible;
    el.focusSessionProtectionConsent.classList.toggle("hidden", !visible);
    el.focusSessionProtectionConsent.setAttribute("aria-busy", String(distractionProtectionConsentSaving));
  }
  if (el.focusSessionProtectionInput) {
    el.focusSessionProtectionInput.setAttribute("aria-checked", String(el.focusSessionProtectionInput.checked));
    el.focusSessionProtectionInput.setAttribute("aria-expanded", String(visible));
    if (el.focusSessionProtectionConsent) el.focusSessionProtectionInput.setAttribute("aria-controls", "focusSessionProtectionConsent");
  }
  [el.focusSessionProtectionConsentAccept, el.focusSessionProtectionConsentDecline].filter(Boolean).forEach((button) => {
    button.disabled = distractionProtectionConsentSaving;
  });
}
function renderFocusSessionProtection() {
  const preferenceEnabled = isFocusSessionProtectionEnabled(state.settings);
  const enabled = preferenceEnabled && websiteProtectionPermissionGranted === true;
  const session = state.focusSession;
  const active = enabled && isFocusSessionProtectionActive(state);
  const paused = Boolean(enabled && session?.active && (session.paused || session.phase === "break"));
  if (el.focusSessionProtectionInput) {
    el.focusSessionProtectionInput.checked = enabled;
    el.focusSessionProtectionInput.setAttribute("aria-checked", String(enabled));
  }
  if (el.focusSessionProtectionState) {
    const status = websiteProtectionPermissionGranted === false
      ? "Permission required"
      : websiteProtectionPermissionGranted === null
        ? "Checking"
        : !preferenceEnabled
          ? "Off"
          : active
            ? "Active"
            : paused
              ? "Paused"
              : "Ready";
    el.focusSessionProtectionState.textContent = status;
    el.focusSessionProtectionState.dataset.state = status.toLowerCase().replace(/\s+/g, "-");
  }
  renderFocusSessionProtectionConsent();
}
const WEBSITE_PROTECTION_PERMISSION = { permissions: ["tabs"] };
async function refreshWebsiteProtectionPermission() {
  if (!hasChrome || !chrome.permissions?.contains) {
    websiteProtectionPermissionGranted = false;
    renderShield();
    return false;
  }
  try {
    websiteProtectionPermissionGranted = Boolean(await chrome.permissions.contains(WEBSITE_PROTECTION_PERMISSION));
  } catch {
    websiteProtectionPermissionGranted = false;
  }
  renderShield();
  return websiteProtectionPermissionGranted;
}
async function requestWebsiteProtectionPermission() {
  if (!hasChrome || !chrome.permissions?.request || !chrome.permissions?.contains) {
    websiteProtectionPermissionGranted = false;
    return false;
  }
  try {
    const alreadyGranted = await chrome.permissions.contains(WEBSITE_PROTECTION_PERMISSION);
    if (alreadyGranted) {
      websiteProtectionPermissionGranted = true;
      renderShield();
      return true;
    }
    const granted = await chrome.permissions.request(WEBSITE_PROTECTION_PERMISSION);
    websiteProtectionPermissionGranted = Boolean(granted && await chrome.permissions.contains(WEBSITE_PROTECTION_PERMISSION));
  } catch {
    websiteProtectionPermissionGranted = false;
  }
  renderShield();
  return websiteProtectionPermissionGranted;
}
async function setDistractionProtection(enabled) {
  if (!enabled) {
    distractionProtectionConsentPromptVisible = false;
    try {
      await updateSettings({ guardBlockedOutsideFocus: false });
      showToast("Outside Focus Protection is off.");
    } catch (error) {
      showToast(error.message || "Distraction Protection could not be updated.");
    } finally {
      renderShield();
      el.distractionProtectionInput?.focus();
    }
    return;
  }
  if (!state.settings.distractionProtectionConsentAccepted) {
    focusSessionProtectionConsentPromptVisible = false;
    distractionProtectionConsentPromptVisible = true;
    // The preference is not effective until consent is accepted; restore the switch to Off while prompting.
    renderShield();
    el.distractionProtectionConsent?.focus();
    return;
  }
  try {
    if (!await requestWebsiteProtectionPermission()) throw new Error("Chrome's Tabs permission is required. Outside Focus Protection remains off.");
    await updateSettings({ guardBlockedOutsideFocus: true });
    showToast("Outside Focus Protection is on.");
  } catch (error) {
    showToast(error.message || "Distraction Protection could not be updated.");
  } finally {
    renderShield();
  }
}
async function acceptDistractionProtectionConsent() {
  if (!distractionProtectionConsentPromptVisible || distractionProtectionConsentSaving || state.settings.distractionProtectionConsentAccepted) return;
  distractionProtectionConsentSaving = true;
  renderDistractionProtectionConsent();
  try {
    if (!await requestWebsiteProtectionPermission()) throw new Error("Chrome's Tabs permission is required. Protection remains off.");
    await updateSettings({ distractionProtectionConsentAccepted: true, guardBlockedOutsideFocus: true });
    distractionProtectionConsentPromptVisible = false;
    showToast("Outside Focus Protection is on.");
  } catch (error) {
    showToast(error.message || "Consent could not be saved. Protection remains off.");
  } finally {
    distractionProtectionConsentSaving = false;
    renderShield();
  }
}
async function declineDistractionProtectionConsent() {
  if (!distractionProtectionConsentPromptVisible || distractionProtectionConsentSaving) return;
  distractionProtectionConsentPromptVisible = false;
  try {
    await updateSettings({ guardBlockedOutsideFocus: false });
    showToast("Distraction Protection remains off.");
  } catch (error) {
    showToast(error.message || "Protection remains off; your preference could not be saved.");
  } finally {
    renderShield();
    el.distractionProtectionInput?.focus();
  }
}
async function setFocusSessionProtection(enabled) {
  if (!enabled) {
    focusSessionProtectionConsentPromptVisible = false;
    try {
      await updateSettings({ focusSessionProtectionEnabled: false });
      showToast("Focus Protection is off.");
    } catch (error) {
      showToast(error.message || "Focus Protection could not be updated.");
    } finally {
      renderShield();
      el.focusSessionProtectionInput?.focus();
    }
    return;
  }
  if (!state.settings.distractionProtectionConsentAccepted) {
    distractionProtectionConsentPromptVisible = false;
    focusSessionProtectionConsentPromptVisible = true;
    renderShield();
    el.focusSessionProtectionConsent?.focus();
    return;
  }
  try {
    if (!await requestWebsiteProtectionPermission()) throw new Error("Chrome's Tabs permission is required. Focus Protection remains off.");
    await updateSettings({ focusSessionProtectionEnabled: true });
    showToast("Focus Protection is on.");
  } catch (error) {
    showToast(error.message || "Focus Protection could not be updated.");
  } finally {
    renderShield();
  }
}
async function acceptFocusSessionProtectionConsent() {
  if (!focusSessionProtectionConsentPromptVisible || distractionProtectionConsentSaving || state.settings.distractionProtectionConsentAccepted) return;
  distractionProtectionConsentSaving = true;
  renderFocusSessionProtectionConsent();
  try {
    if (!await requestWebsiteProtectionPermission()) throw new Error("Chrome's Tabs permission is required. Protection remains off.");
    await updateSettings({ distractionProtectionConsentAccepted: true, focusSessionProtectionEnabled: true });
    focusSessionProtectionConsentPromptVisible = false;
    showToast("Focus Protection is on.");
  } catch (error) {
    showToast(error.message || "Consent could not be saved. Focus Protection remains off.");
  } finally {
    distractionProtectionConsentSaving = false;
    renderShield();
  }
}
async function declineFocusSessionProtectionConsent() {
  if (!focusSessionProtectionConsentPromptVisible || distractionProtectionConsentSaving) return;
  focusSessionProtectionConsentPromptVisible = false;
  try {
    await updateSettings({ focusSessionProtectionEnabled: false });
    showToast("Focus Protection remains off.");
  } catch (error) {
    showToast(error.message || "Protection remains off; your preference could not be saved.");
  } finally {
    renderShield();
    el.focusSessionProtectionInput?.focus();
  }
}
async function refreshIncognitoAccessStatus() {
  if (!hasChrome) { incognitoAccessAllowed = false; renderShield(); return false; }
  const result = await sendMessage({ type: "getIncognitoAccess" });
  incognitoAccessAllowed = Boolean(result?.ok && result.response?.allowed);
  if (!incognitoAccessAllowed && state.settings.incognitoProtection) await updateSettings({ incognitoProtection: false });
  renderShield();
  return incognitoAccessAllowed;
}
async function openIncognitoSettings() {
  const result = await sendMessage({ type: "openIncognitoSettings" });
  if (!result?.ok) return showToast("Chrome settings could not be opened.");
  showToast("In Chrome, turn on Allow in Incognito for Studizen.");
}
async function setIncognitoProtection(enabled) {
  try {
    if (!enabled) {
      await updateSettings({ incognitoProtection: false });
      showToast("Incognito Protection is off.");
      return;
    }
    if (!await refreshIncognitoAccessStatus()) {
      renderShield();
      showToast("Allow Studizen in Incognito in Chrome before turning this on.");
      return;
    }
    await updateSettings({ incognitoProtection: true });
    showToast("Incognito Protection is on.");
  } catch (error) {
    renderShield();
    showToast(error.message || "Incognito Protection could not be updated.");
  }
}
async function setYouTubeStudyMode(enabled) {
  try {
    await updateSettings({ youtubeStudyModeEnabled: Boolean(enabled) });
    showToast(enabled ? "YouTube Study Mode will be used during Focus." : "YouTube Study Mode is off.");
  } catch (error) {
    render();
    showToast(error.message || "YouTube Study Mode could not be updated.");
  }
}
function cssVar(name) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim(); }
function chartPalette() { return { blue: cssVar("--chart-blue") || cssVar("--blue") || "#2f7cf6", muted: cssVar("--muted") || "#687789", grid: cssVar("--chart-grid") || "rgba(100,116,139,.16)", text: cssVar("--ink") || "#142033", surface: cssVar("--surface-raised") || cssVar("--surface") || "#fff", font: cssVar("--font-display") || "Manrope, Arial, sans-serif" }; }
function chartAlpha(color, alpha) {
  if (!color) return "rgba(47,124,246," + alpha + ")";
  const hex = color.trim();
  if (/^#[0-9a-f]{6}$/i.test(hex)) {
    const n = parseInt(hex.slice(1), 16);
    return "rgba(" + ((n >> 16) & 255) + "," + ((n >> 8) & 255) + "," + (n & 255) + "," + alpha + ")";
  }
  return color;
}
function destroyChart(key) { if (!charts[key]) return; charts[key].destroy(); delete charts[key]; }
function chart(key, canvas, config) {
  if (!canvas || !globalThis.Chart) return;
  const existing = charts[key];
  if (existing?.canvas === canvas && existing.config.type === config.type) {
    existing.data = config.data;
    existing.options = config.options;
    existing.update();
    return;
  }
  destroyChart(key);
  charts[key] = new Chart(canvas, config);
}
function gamificationStats() {
  const history = completedFocusSessions();
  const focusXp = history.reduce((sum, item) => sum + (Number.isFinite(Number(item.xpEarned)) ? Number(item.xpEarned) : sessionXp(item.durationMinutes, item.completed)), 0);
  const xp = Math.round(focusXp + rewardXpTotal(state));
  const level = levelForXp(xp);
  const levelStart = (level - 1) * 300;
  const nextLevel = level * 300;
  const progress = Math.min(100, Math.round(((xp - levelStart) / Math.max(1, nextLevel - levelStart)) * 100));
  const rank = rankForLevel(level);
  const badges = [];
  if (history.length >= 1) badges.push("First Focus");
  if ((state.analytics.streak?.current || 0) >= 3) badges.push("3-Day Streak");
  if (completedMinutesToday() >= 120) badges.push("Deep Work Day");
  if ((state.stats.distractions || 0) === 0 && (state.stats.focusMinutes || 0) > 0) badges.push("Clean Session");
  return { xp, level, progress, rank, badges };
}
function renderGamification() {
  const stats = gamificationStats();
  if (stats.level > lastShownLevel) {
    lastShownLevel = stats.level;
    sessionStorage.setItem("courseFocusProLastLevel", String(stats.level));
    el.xpPanel?.classList.remove("level-up");
    void el.xpPanel?.offsetWidth;
    el.xpPanel?.classList.add("level-up");
    showToast("Level " + stats.level + " reached - " + stats.rank + ".");
  } else if (stats.level < lastShownLevel) {
    lastShownLevel = stats.level;
    sessionStorage.setItem("courseFocusProLastLevel", String(stats.level));
  }
  el.rankTitle.textContent = "Level " + stats.level + " - " + stats.rank;
  el.rankMeta.textContent = stats.xp + " XP earned from verified focus sessions, system goals, and streaks";
  el.xpProgressFill.style.width = stats.progress + "%";
  el.badgeRow.innerHTML = "";
  if (!stats.badges.length) {
    el.badgeRow.innerHTML = "<span class='badge muted'>Badges appear as you study</span>";
    return;
  }
  stats.badges.slice(0, 5).forEach((badge) => {
    const item = document.createElement("span");
    item.className = "badge";
    item.textContent = badge;
    el.badgeRow.append(item);
  });
}
function setAnalyticsXpOpen(open, restoreFocus = false) {
  if (!el.analyticsXpPopover || !el.analyticsXpBtn) return;
  const wasOpen = !el.analyticsXpPopover.classList.contains("hidden");
  const next = Boolean(open);
  el.analyticsXpPopover.classList.toggle("hidden", !next);
  el.analyticsXpBtn.setAttribute("aria-expanded", String(next));
  if (!next && restoreFocus && wasOpen) el.analyticsXpBtn.focus();
}

function selectedAnalyticsVisualPeriod() {
  return analyticsHistoryPeriod || "current-week";
}

function analyticsVisualPeriodLabel(period) {
  if (period === "previous-month") return "Previous month";
  if (period === "previous-week") return "Previous week";
  return "This week";
}

function renderStudyActivity(week, now = new Date(), options = {}) {
  const historical = Boolean(options.historical);
  const historicalTargets = historical ? (options.dailyTargetsMinutes || []) : [];
  const dailyGoalMinutes = historical
    ? Math.max(0, ...historicalTargets.filter(Number.isFinite))
    : resolveStudyTargets(state).dailyMinutes;
  const maxDayMinutes = Math.max(0, ...week.days.map((day) => day.milliseconds / 60000));
  const { maximumHours, ticks } = studyDurationScale(maxDayMinutes, dailyGoalMinutes);
  const hasActivity = week.totalMilliseconds > 0;
  const previousWeek = analyticsHistoryPeriod === "previous-week";
  const weekLabel = historical ? analyticsVisualPeriodLabel(options.periodName) : previousWeek ? "Previous week" : "This week";
  const periodPhrase = options.periodName === "previous-month" ? "last month" : "last week";
  if (el.dailyChartMeta) el.dailyChartMeta.textContent = weekLabel;
  if (el.dailyChartDescription) el.dailyChartDescription.textContent = historical
    ? "Your focused study time throughout " + periodPhrase + "."
    : previousWeek ? "Your focused study time throughout last week." : "Your focused study time throughout this week.";
  if (el.dailyChartEmpty) {
    el.dailyChartEmpty.classList.toggle("hidden", hasActivity);
    const copy = el.dailyChartEmpty.querySelector(".analytics-empty-copy");
    if (copy) copy.textContent = historical
      ? "No focused study time was recorded " + periodPhrase + "."
      : "Your study activity will appear here once you complete your first focus session.";
  }
  el.dailyChartWrap?.classList.toggle("hidden", !hasActivity);
  if (!hasActivity) {
    destroyChart("dailyStudyByDay");
    return;
  }
  if (!el.dailyChart || !globalThis.Chart) return;

  const palette = chartPalette();
  const targetHours = dailyGoalMinutes / 60;
  const currentDateKey = todayKey(now);
  const dayColors = week.days.map((day) => !historical && day.dateKey === currentDateKey ? palette.blue : chartAlpha(palette.blue, .58));
  const dailyGoalPlugin = {
    id: "dailyGoalReference",
    afterDraw(instance) {
      const configured = instance.options.plugins.dailyGoalReference;
      const dailyTargets = configured?.targetsHours;
      if (Array.isArray(dailyTargets)) {
        const x = instance.scales.x;
        const y = instance.scales.y;
        const { left, right } = instance.chartArea;
        const ctx = instance.ctx;
        const slotWidth = (right - left) / Math.max(1, dailyTargets.length);
        ctx.save();
        ctx.strokeStyle = configured.color;
        ctx.lineWidth = 1;
        ctx.setLineDash([3, 3]);
        dailyTargets.forEach((goal, index) => {
          if (!Number.isFinite(goal) || goal <= y.min || goal > y.max) return;
          const center = x.getPixelForValue(index);
          const markerY = y.getPixelForValue(goal);
          ctx.beginPath();
          ctx.moveTo(Math.max(left, center - slotWidth * .2), markerY);
          ctx.lineTo(Math.min(right, center + slotWidth * .2), markerY);
          ctx.stroke();
        });
        ctx.restore();
        return;
      }
      const goal = Number(configured?.targetHours) || 0;
      const scale = instance.scales.y;
      if (!goal || goal > scale.max || goal <= scale.min) return;
      const y = scale.getPixelForValue(goal);
      const { left, right } = instance.chartArea;
      const ctx = instance.ctx;
      ctx.save();
      ctx.strokeStyle = configured.color;
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(left, y);
      ctx.lineTo(right, y);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = configured.color;
      ctx.font = `500 9px ${instance.options.font.family}`;
      ctx.textAlign = "right";
      ctx.textBaseline = "bottom";
      ctx.fillText("Daily goal", right - 3, y - 3);
      ctx.restore();
    }
  };
  const durationLabelsPlugin = {
    id: "dailyDurationLabels",
    afterDatasetsDraw(instance) {
      const dataset = instance.data.datasets[0];
      const meta = instance.getDatasetMeta(0);
      const ctx = instance.ctx;
      const configured = instance.options.plugins.dailyDurationLabels;
      if (configured.showLabels === false) return;
      ctx.save();
      ctx.fillStyle = configured.color;
      ctx.font = `500 10px ${configured.font}`;
      ctx.textAlign = "center";
      ctx.textBaseline = "bottom";
      meta.data.forEach((bar, index) => {
        const milliseconds = dataset.actualMilliseconds?.[index] || 0;
        if (!milliseconds) return;
        const position = bar.tooltipPosition();
        const y = Math.max(instance.chartArea.top + 12, position.y - 5);
        ctx.fillText(formatDuration(milliseconds / 60000), position.x, y);
      });
      ctx.restore();
    }
  };
  chart("dailyStudyByDay", el.dailyChart, {
    type: "bar",
    data: {
      labels: week.days.map((day) => options.compactDateLabels
        ? new Date(day.dateKey + "T12:00:00").toLocaleDateString(undefined, { month: "short", day: "numeric" })
        : day.label),
      datasets: [{
        data: week.days.map((day) => day.milliseconds / 3600000),
        actualMilliseconds: week.days.map((day) => day.milliseconds),
        dateLabels: week.days.map((day) => day.dateLabel),
        backgroundColor: dayColors,
        hoverBackgroundColor: week.days.map((day) => day.dateKey === currentDateKey ? chartAlpha(palette.blue, .95) : chartAlpha(palette.blue, .74)),
        borderColor: dayColors,
        borderWidth: 0,
        borderRadius: { topLeft: 5, topRight: 5, bottomLeft: 0, bottomRight: 0 },
        borderSkipped: "bottom",
        barPercentage: .68,
        categoryPercentage: .76
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 220, easing: "easeOutQuart" },
      layout: { padding: { top: 19, right: 5, bottom: 0, left: 0 } },
      font: { family: palette.font },
      plugins: {
        legend: { display: false },
        dailyGoalReference: {
          targetHours: historical ? 0 : targetHours,
          targetsHours: historical ? historicalTargets.map((minutes) => Number.isFinite(minutes) ? minutes / 60 : null) : null,
          color: chartAlpha(palette.muted, .64)
        },
        dailyDurationLabels: { color: palette.text, font: palette.font, showLabels: options.showDurationLabels !== false },
        tooltip: {
          displayColors: false,
          backgroundColor: palette.surface,
          borderColor: chartAlpha(palette.blue, .25),
          borderWidth: 1,
          titleColor: palette.text,
          bodyColor: palette.muted,
          titleFont: { family: palette.font, size: 11, weight: "600" },
          bodyFont: { family: palette.font, size: 11, weight: "500" },
          padding: 9,
          cornerRadius: 7,
          callbacks: {
            title: (items) => items.length ? (items[0].dataset.dateLabels?.[items[0].dataIndex] || "") : "",
            label: (context) => "Focused study · " + formatDuration((context.dataset.actualMilliseconds?.[context.dataIndex] || 0) / 60000)
          }
        }
      },
      scales: {
        x: {
          grid: { display: false },
          border: { display: false },
          ticks: {
            color: palette.muted,
            font: { family: palette.font, size: 10, weight: "500" },
            maxRotation: 0,
            autoSkip: Boolean(options.compactDateLabels),
            maxTicksLimit: options.compactDateLabels ? 10 : undefined
          }
        },
        y: {
          beginAtZero: true,
          min: 0,
          max: maximumHours,
          border: { display: false, dash: [3, 4] },
          grid: { color: chartAlpha(palette.muted, .16), drawTicks: false, lineWidth: 1 },
          ticks: {
            stepSize: ticks.length > 1 ? ticks[1] - ticks[0] : 1,
            color: palette.muted,
            padding: 7,
            font: { family: palette.font, size: 10 },
            callback: (value) => value + "h"
          }
        }
      }
    },
    plugins: [dailyGoalPlugin, durationLabelsPlugin]
  });
}

function renderStudyTiming(timing, periodPhrase = "today") {
  if (!el.studyTimingRows) return;
  const { periods, totalMilliseconds, unclassifiedMilliseconds } = timing;
  el.studyTimingRows.replaceChildren();
  const hasActivity = totalMilliseconds > 0;
  el.studyTimingRows.classList.toggle("hidden", !hasActivity);
  el.studyTimingEmpty?.classList.toggle("hidden", hasActivity);
  el.studyTimingInsight?.classList.toggle("hidden", !hasActivity);
  el.studyTimingNote?.classList.toggle("hidden", unclassifiedMilliseconds <= 0 || !hasActivity);
  if (el.studyTimingNote && unclassifiedMilliseconds > 0 && hasActivity) {
    el.studyTimingNote.textContent = "Some older study records have no interval timestamps, so their time of day cannot be determined.";
  }
  if (!hasActivity) {
    const timingEmptyCopy = el.studyTimingEmpty?.querySelector(".analytics-empty-copy");
    if (timingEmptyCopy) timingEmptyCopy.textContent = unclassifiedMilliseconds > 0
      ? "Time-of-day details aren't available for older study records."
      : periodPhrase === "today"
        ? "Your study timing insights will appear as you build your study routine."
        : "No study timing activity was recorded " + periodPhrase + ".";
    return;
  }

  const percentages = allocateStudyPercentages(periods);
  periods.forEach((period, index) => {
    const percentage = percentages[index];
    const share = period.milliseconds / totalMilliseconds * 100;
    const row = document.createElement("div");
    row.className = "study-timing-row study-timing-" + period.id;
    const heading = document.createElement("div");
    heading.className = "study-timing-row-heading";
    const name = document.createElement("strong");
    name.textContent = period.name;
    const value = document.createElement("span");
    value.textContent = formatDuration(period.milliseconds / 60000) + " · " + percentage + "%";
    heading.append(name, value);
    const track = document.createElement("div");
    track.className = "study-timing-track";
    track.setAttribute("role", "img");
    track.setAttribute("aria-label", period.name + ": " + formatDuration(period.milliseconds / 60000) + ", " + percentage + "% of " + periodPhrase + " focused study time");
    const fill = document.createElement("span");
    fill.className = "study-timing-fill";
    fill.style.width = share + "%";
    track.append(fill);
    row.append(heading, track);
    el.studyTimingRows.append(row);
  });

  const highest = Math.max(...periods.map((period) => period.milliseconds));
  const leaders = periods.filter((period) => period.milliseconds === highest && highest > 0);
  const leaderShare = (highest / totalMilliseconds * 100).toFixed(1).replace(/\.0$/, "");
  const leaderName = leaders.map((period) => period.name).join(" & ");
  const durationText = formatDuration(highest / 60000) + (leaders.length > 1 ? " each" : "");
  if (el.studyTimingInsight) {
    el.studyTimingInsight.replaceChildren();
    el.studyTimingInsight.className = "study-timing-insight";
    const label = document.createElement("strong");
    label.textContent = "Your most active study period";
    const text = document.createElement("span");
    text.textContent = leaders.length > 1
      ? leaderName + " tied at " + durationText + " (" + leaderShare + "% each of " + periodPhrase + " focused study time)."
      : leaderName + " · " + durationText + " (" + leaderShare + "% of " + periodPhrase + " focused study time).";
    el.studyTimingInsight.classList.remove("hidden");
    leaders.forEach((period) => el.studyTimingInsight.classList.add("is-" + period.id));
    el.studyTimingInsight.append(label, text);
  }
}

const SUBJECT_CHART_COLORS = ["#7898ff", "#34c6aa", "#b185f5", "#f0b45c", "#e7799b", "#58bdd3", "#9ac765", "#e58b60", "#7bb5e8", "#c28abf", "#a9bd73", "#d48a70"];
function subjectColorMap(entries) {
  const names = entries.map((entry) => entry.subject).sort((a, b) => a.localeCompare(b));
  return new Map(names.map((name, index) => {
    if (name === "Unassigned") return [name, "#8290a5"];
    const color = index < SUBJECT_CHART_COLORS.length
      ? SUBJECT_CHART_COLORS[index]
      : `hsl(${Math.round((index * 137.508) % 360)} 66% 68%)`;
    return [name, color];
  }));
}

function renderSubjectDistribution(summary, now = new Date(), options = {}) {
  const targets = resolveStudyTargets(state);
  const dateKey = todayKey(now);
  const configured = [...(targets.selectedSubjects || []), ...Object.keys(targets.subjectTargets || {}), ...(targets.customSubjects || []), ...(state.courses || []).map((course) => course.subject), ...(state.analytics?.focusHistory || []).map((session) => session.subject)];
  const historical = Boolean(options.periodData);
  let distribution;
  if (historical) {
    const normalizeHistorySubject = (subject) => {
      const value = String(subject || "").trim();
      if (!value || ["other", "unassigned"].includes(value.toLowerCase())) return "Unassigned";
      return normalizeSubject(value, state.profile?.studyProfile, targets.customSubjects);
    };
    const values = new Map();
    configured.forEach((subject) => {
      const name = normalizeHistorySubject(subject);
      if (name !== "Unassigned" && !values.has(name)) values.set(name, { subject: name, milliseconds: 0, sessions: 0 });
    });
    options.periodData.sessions.forEach((session) => {
      if (session.focusedMilliseconds <= 0) return;
      const name = normalizeHistorySubject(session.subject);
      const entry = values.get(name) || { subject: name, milliseconds: 0, sessions: 0 };
      entry.milliseconds += session.focusedMilliseconds;
      entry.sessions += 1;
      values.set(name, entry);
    });
    const entries = [...values.values()].sort((a, b) => b.milliseconds - a.milliseconds || a.subject.localeCompare(b.subject));
    distribution = {
      entries,
      totalMilliseconds: options.periodData.days.reduce((sum, day) => sum + day.milliseconds, 0)
    };
  } else {
    distribution = subjectStudyDistribution(summary.sessions || [], configured, dateKey, now.getTime(), state.focusSession);
  }
  const entries = distribution.entries;
  const percentages = allocateStudyPercentages(entries);
  const colors = subjectColorMap(entries);
  const totalMs = distribution.totalMilliseconds;
  const periodLabel = options.periodLabel || "Today";
  const periodPhrase = options.periodPhrase || "today's";
  const periodDescription = options.periodDescription || "Today's focused study time by subject.";
  const periodEmptyMessage = options.periodEmptyMessage || "Complete your first focus session to see how your study time is distributed across subjects.";
  const periodMeta = document.querySelector("#subjectDistributionPeriod");
  const description = document.querySelector("#subjectDistributionDescription");
  if (periodMeta) periodMeta.textContent = periodLabel;
  if (description) description.textContent = periodDescription;
  if (el.subjectDistributionTotal) el.subjectDistributionTotal.textContent = formatDuration(totalMs / 60000);
  if (el.subjectDistributionLegend) {
    el.subjectDistributionLegend.replaceChildren();
    entries.forEach((entry, index) => {
      const row = document.createElement("div");
      row.className = "subject-distribution-item";
      row.style.setProperty("--subject-color", colors.get(entry.subject));
      const name = document.createElement("strong");
      name.className = "subject-distribution-name";
      name.textContent = entry.subject;
      name.title = entry.subject;
      const duration = document.createElement("span");
      duration.className = "subject-distribution-duration";
      duration.textContent = formatDuration(entry.milliseconds / 60000);
      const share = document.createElement("span");
      share.className = "subject-distribution-percent";
      share.textContent = percentages[index] + "%";
      row.append(name, duration, share);
      row.setAttribute("aria-label", entry.subject + ": " + formatDuration(entry.milliseconds / 60000) + ", " + percentages[index] + "% of " + periodPhrase + " focused study time, " + entry.sessions + " session" + (entry.sessions === 1 ? "" : "s"));
      el.subjectDistributionLegend.append(row);
    });
  }
  const hasActivity = totalMs > 0;
  el.subjectDistributionChart?.closest(".subject-distribution-layout")?.classList.toggle("is-empty", !hasActivity);
  el.subjectDistributionChart?.classList.toggle("hidden", !hasActivity);
  el.subjectDistributionEmpty?.classList.toggle("hidden", hasActivity);
  const subjectEmptyCopy = el.subjectDistributionEmpty?.querySelector(".analytics-empty-copy");
  if (subjectEmptyCopy) subjectEmptyCopy.textContent = periodEmptyMessage;
  if (!hasActivity || !el.subjectDistributionChart) {
    destroyChart("subjectDistribution");
    return;
  }
  if (el.subjectDistributionChart) el.subjectDistributionChart.setAttribute("aria-label", "Subject Study Distribution " + periodLabel.toLowerCase() + ": " + entries.map((entry, index) => ({ entry, percentage: percentages[index] })).filter(({ entry }) => entry.milliseconds > 0).map(({ entry, percentage }) => entry.subject + " " + formatDuration(entry.milliseconds / 60000) + " " + percentage + "%").join(", "));
  const palette = chartPalette();
  chart("subjectDistribution", el.subjectDistributionChart, {
    type: "doughnut",
    data: {
      labels: entries.map((entry) => entry.subject),
      datasets: [{
        data: entries.map((entry) => entry.milliseconds),
        backgroundColor: entries.map((entry) => colors.get(entry.subject)),
        borderColor: cssVar("--surface-raised") || palette.surface,
        borderWidth: 2,
        hoverBorderWidth: 2,
        hoverOffset: 4,
        spacing: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      aspectRatio: 1,
      cutout: "70%",
      animation: { duration: 220, easing: "easeOutQuart" },
      plugins: {
        legend: { display: false },
        tooltip: {
          displayColors: true,
          backgroundColor: palette.surface,
          borderColor: chartAlpha(palette.blue, .25),
          borderWidth: 1,
          titleColor: palette.text,
          bodyColor: palette.muted,
          titleFont: { family: palette.font, size: 12, weight: "600" },
          bodyFont: { family: palette.font, size: 11, weight: "500" },
          padding: 9,
          cornerRadius: 7,
          callbacks: {
            label: (context) => {
              const index = context.dataIndex;
              return " " + context.label + " · " + formatDuration(Number(context.raw || 0) / 60000) + " · " + percentages[index] + "%";
            }
          }
        }
      }
    }
  });
}

function renderGoalConsistency(period, periodName, historicalTargets = null) {
  const targets = resolveStudyTargets(state);
  const goalMinutes = historicalTargets
    ? historicalTargets.weeklyAvailable ? Math.round(historicalTargets.periodGoalMinutes) : historicalTargets.dailyAvailable ? historicalTargets.dailyMinutes : null
    : Math.round(targets.weeklyMinutes * (periodName === "previous-month" ? period.keys.length / 7 : 1));
  const progress = studyTargetProgress(period.minutes, goalMinutes);
  const averageSession = period.recordedSessions ? Math.round(period.minutes / period.recordedSessions) : 0;
  const longest = (period.sessions || []).reduce((maximum, session) => Math.max(maximum, sessionActualMinutes(session)), 0);
  if (el.consistencyMeta) el.consistencyMeta.textContent = analyticsVisualPeriodLabel(periodName);
  if (el.consistencyGoalLabel) el.consistencyGoalLabel.textContent = historicalTargets ? (periodName === "previous-month" ? "Historical monthly goal" : "Historical weekly goal") : periodName === "previous-month" ? "Monthly goal" : "Weekly goal";
  if (el.consistencyGoalValue) el.consistencyGoalValue.textContent = goalMinutes > 0
    ? formatDuration(period.minutes) + " / " + formatDuration(goalMinutes)
    : historicalTargets ? formatDuration(period.minutes) + " · historical target unavailable" : formatDuration(period.minutes) + " · no goal set";
  if (el.consistencyGoalPercent) el.consistencyGoalPercent.textContent = progress === null ? "—" : progress + "%";
  if (el.consistencyGoalFill) el.consistencyGoalFill.style.width = Math.min(100, progress || 0) + "%";
  if (el.consistencyDailyAverage) el.consistencyDailyAverage.textContent = formatDuration(period.dailyAverageMinutes);
  if (el.consistencySessions) el.consistencySessions.textContent = String(period.completedSessions);
  if (el.consistencyAverageSession) el.consistencyAverageSession.textContent = formatDuration(averageSession);
  if (el.consistencyLongestSession) el.consistencyLongestSession.textContent = formatDuration(longest);
}

function makeAnalyticsTargetSubjectRow(subject, targetMinutes = 0, custom = false) {
  const row = document.createElement("div");
  row.className = "analytics-target-subject-row";
  row.dataset.subjectName = subject;
  row.dataset.custom = String(custom);
  const copy = document.createElement("div");
  copy.className = "analytics-target-subject-copy";
  if (custom) {
    const name = document.createElement("input");
    name.className = "analytics-target-subject-name";
    name.type = "text";
    name.maxLength = 48;
    name.value = subject;
    name.setAttribute("aria-label", "Subject name");
    copy.append(name);
  } else {
    const name = document.createElement("strong");
    name.textContent = subject;
    copy.append(name);
  }
  const target = document.createElement("label");
  target.className = "analytics-target-subject-hours";
  target.append(document.createTextNode("Hours / day"));
  const input = document.createElement("input");
  input.className = "analytics-target-subject-input";
  input.type = "text";
  input.maxLength = 16;
  input.inputMode = "text";
  input.placeholder = "e.g. 2h 30m";
  input.value = formatDuration(Number(targetMinutes) || 0);
  input.setAttribute("aria-label", subject + " daily target, hours and minutes");
  target.append(input);
  row.append(copy, target);
  if (custom) {
    const remove = document.createElement("button");
    remove.className = "button secondary analytics-target-subject-remove";
    remove.type = "button";
    remove.textContent = "Remove";
    remove.setAttribute("aria-label", "Remove " + subject + " from study targets");
    row.append(remove);
  }
  return row;
}

function parseSubjectTargetDuration(value) {
  const raw = String(value ?? "").trim().toLowerCase();
  if (!raw) return 0;
  if (!/[hm]/.test(raw)) {
    const hours = Number(raw);
    return Number.isFinite(hours) ? Math.round(Math.max(0, Math.min(24, hours)) * 60) : null;
  }
  const match = raw.match(/^\s*(?:(\d+(?:\.\d+)?)\s*h)?\s*(?:(\d+(?:\.\d+)?)\s*m)?\s*$/);
  if (!match || (!match[1] && !match[2])) return null;
  const hours = Number(match[1] || 0);
  const minutes = Number(match[2] || 0);
  if (minutes >= 60 || !Number.isFinite(hours) || !Number.isFinite(minutes)) return null;
  return Math.round(Math.min(24 * 60, hours * 60 + minutes));
}

function renderAnalyticsTargetEditor() {
  if (!el.analyticsTargetSubjectList) return;
  const targets = resolveStudyTargets(state);
  const profileId = state.profile?.studyProfile || "jee";
  const profile = STUDY_PROFILES.find((item) => item.id === profileId);
  if (el.analyticsTargetsProfileNote) el.analyticsTargetsProfileNote.textContent = (profile?.name || "Your profile") + " suggestions are a starting point. Edit them to fit your schedule.";
  if (el.analyticsDailyTargetInput) el.analyticsDailyTargetInput.value = String(Number((targets.dailyMinutes / 60).toFixed(2)));
  if (el.analyticsWeeklyTargetInput) el.analyticsWeeklyTargetInput.value = String(Number((targets.weeklyMinutes / 60).toFixed(2)));
  const suggestedSubjects = targets.selectedSubjects;
  const profileSubjects = new Set(suggestedSubjects);
  const names = [...new Set([...suggestedSubjects, ...Object.keys(targets.subjectTargets), ...targets.customSubjects])].slice(0, 80);
  el.analyticsTargetSubjectList.innerHTML = "";
  const customizableProfile = ["school", "college", "custom"].includes(profileId);
  names.forEach((name) => el.analyticsTargetSubjectList.append(makeAnalyticsTargetSubjectRow(name, targets.subjectTargets[name] || 0, customizableProfile || targets.customSubjects.includes(name) || !profileSubjects.has(name))));
}

function setAnalyticsTargetsEditor(open) {
  const isOpen = Boolean(open);
  el.analyticsTargetsEditor?.classList.toggle("hidden", !isOpen);
  el.analyticsTargetsToggle?.setAttribute("aria-expanded", String(isOpen));
  if (isOpen) {
    renderAnalyticsTargetEditor();
    el.analyticsTargetsEditor?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  } else {
    el.analyticsAddSubjectRow?.classList.add("hidden");
  }
}

function renameTrackedSubject(source, previousName, nextName) {
  if (!previousName || !nextName || previousName === nextName) return source;
  const courses = (source.courses || []).map((course) => course.subject === previousName ? { ...course, subject: nextName } : course);
  const analytics = { ...(source.analytics || {}) };
  analytics.focusHistory = (analytics.focusHistory || []).map((session) => session.subject === previousName ? { ...session, subject: nextName } : session);
  analytics.daily = Object.fromEntries(Object.entries(analytics.daily || {}).map(([date, day]) => {
    const subjects = { ...(day.subjects || {}) };
    if (subjects[previousName]) {
      const oldEntry = subjects[previousName];
      const current = subjects[nextName] || { subject: nextName, studyMinutes: 0, sessions: 0, completion: 0 };
      subjects[nextName] = { ...current, subject: nextName, studyMinutes: Number(current.studyMinutes || 0) + Number(oldEntry.studyMinutes || 0), sessions: Number(current.sessions || 0) + Number(oldEntry.sessions || 0), completion: Math.max(Number(current.completion || 0), Number(oldEntry.completion || 0)) };
      delete subjects[previousName];
    }
    return [date, { ...day, subjects }];
  }));
  return { ...source, courses, analytics };
}

async function saveAnalyticsTargets(event) {
  event.preventDefault();
  const rows = [...(el.analyticsTargetSubjectList?.querySelectorAll(".analytics-target-subject-row") || [])];
  const seen = new Set(); const subjectTargets = {}; const customSubjects = []; const renames = [];
  for (const row of rows) {
    const original = String(row.dataset.subjectName || "").trim();
    const name = String(row.querySelector(".analytics-target-subject-name")?.value || original).trim().replace(/\s+/g, " ").slice(0, 48);
    if (!name) { showToast("Enter a name for each subject."); return; }
    const key = name.toLocaleLowerCase();
    if (seen.has(key)) { showToast("Each subject name must be unique."); return; }
    seen.add(key);
    const targetMinutes = parseSubjectTargetDuration(row.querySelector(".analytics-target-subject-input")?.value);
    if (targetMinutes === null) { row.querySelector(".analytics-target-subject-input")?.focus(); showToast("Use a daily duration such as 2h 30m."); return; }
    subjectTargets[name] = targetMinutes;
    if (row.dataset.custom === "true") {
      customSubjects.push(name);
      if (original && original !== name) renames.push([original, name]);
    }
  }
  let nextState = state;
  renames.forEach(([from, to]) => { nextState = renameTrackedSubject(nextState, from, to); });
  const dailyHours = Number(el.analyticsDailyTargetInput?.value || 0);
  const weeklyHours = Number(el.analyticsWeeklyTargetInput?.value || 0);
  const goals = {
    ...nextState.goals,
    studyHours: Math.max(0, Math.min(24, Number.isFinite(dailyHours) ? dailyHours : 0)),
    analyticsTargets: {
      profileId: nextState.profile?.studyProfile || "jee",
      weeklyMinutes: Math.round(Math.max(0, Math.min(168, Number.isFinite(weeklyHours) ? weeklyHours : 0)) * 60),
      studyDays: resolveStudyTargets(nextState).studyDays,
      subjectTargets,
      selectedSubjects: Object.keys(subjectTargets),
      subjectTargetPeriod: "daily",
      customSubjects: [...new Set(customSubjects)],
      sortBy: resolveStudyTargets(nextState).sortBy
    }
  };
  try {
    await saveState({ ...nextState, goals });
    setAnalyticsTargetsEditor(false);
    showToast("Study targets saved.");
  } catch (error) {
    showToast(error?.message || "Study targets could not be saved.");
  }
}

async function restoreSuggestedStudyTargets() {
  const profileId = state.profile?.studyProfile || "jee";
  const suggested = studyTargetSuggestions(profileId);
  if (!confirm("Restore the suggested daily, weekly, and subject targets for " + (STUDY_PROFILES.find((item) => item.id === profileId)?.name || "your profile") + "?")) return;
  await saveState({ ...state, goals: { ...state.goals, studyHours: suggested.dailyMinutes / 60, analyticsTargets: { profileId, weeklyMinutes: suggested.weeklyMinutes, studyDays: suggested.studyDays, subjectTargets: suggested.subjectTargets, selectedSubjects: Object.keys(suggested.subjectTargets), subjectTargetPeriod: "daily", customSubjects: [], sortBy: "actual" } } });
  renderAnalyticsTargetEditor();
  showToast("Profile suggestions restored.");
}

function addAnalyticsTargetSubject() {
  const name = String(el.analyticsNewSubjectInput?.value || "").trim().replace(/\s+/g, " ").slice(0, 48);
  if (!name) { el.analyticsNewSubjectInput?.focus(); return; }
  const exists = [...(el.analyticsTargetSubjectList?.querySelectorAll(".analytics-target-subject-row") || [])].some((row) => (row.querySelector(".analytics-target-subject-name")?.value || row.dataset.subjectName || "").trim().toLocaleLowerCase() === name.toLocaleLowerCase());
  if (exists) { showToast("That subject is already in your targets."); return; }
  const selectedNames = [...(el.analyticsTargetSubjectList?.querySelectorAll(".analytics-target-subject-row") || [])]
    .map((row) => String(row.querySelector(".analytics-target-subject-name")?.value || row.dataset.subjectName || "").trim()).filter(Boolean);
  const suggested = studyTargetSuggestions(state.profile?.studyProfile || "jee", [...selectedNames, name]);
  el.analyticsTargetSubjectList?.append(makeAnalyticsTargetSubjectRow(name, suggested.subjectTargets[name] ?? 120, true));
  el.analyticsNewSubjectInput.value = "";
  el.analyticsAddSubjectRow?.classList.add("hidden");
  el.analyticsTargetSubjectList?.lastElementChild?.querySelector(".analytics-target-subject-name")?.focus();
}

function renderHistoricalAnalytics(summary, now, periodName) {
  const targets = resolveStudyTargets(state);
  const periodDefinition = completedPeriodAnalytics(summary, periodName, now, state.goals?.studyHours, targets.weeklyMinutes);
  const period = recordedStudyPeriod(summary.sessions || [], periodDefinition.keys, now.getTime(), null);
  const phrase = periodName === "previous-month" ? "last month" : "last week";
  const title = document.querySelector("#analyticsPeriodTitle");
  const intro = document.querySelector("#analyticsPeriodIntro");
  if (title) title.textContent = "Your progress " + phrase;
  if (intro) intro.textContent = "A look at your recorded study activity " + phrase + ".";

  const activeDays = period.days.filter((day) => day.milliseconds > 0).length;
  const targetHistory = historicalStudyTargets(state.analytics?.daily || {}, period.keys);
  const historicalGoal = targetHistory.weeklyAvailable
    ? Math.round(targetHistory.periodGoalMinutes)
    : targetHistory.dailyAvailable ? targetHistory.dailyMinutes : null;
  const hasHistoricalGoal = Number.isFinite(historicalGoal) && historicalGoal >= 0;
  const goalPercent = historicalGoal > 0 ? studyTargetProgress(period.minutes, historicalGoal) : null;
  const setText = (selector, value) => {
    const node = document.querySelector(selector);
    if (node) node.textContent = value;
  };
  setText("#analyticsTodayLabel", "Total study");
  setText("#analyticsToday", formatDuration(period.minutes));
  setText("#analyticsTodayHint", periodDefinition.keys[0] + " – " + periodDefinition.keys.at(-1));
  setText("#analyticsWeekLabel", "Daily average");
  setText("#analyticsWeek", formatDuration(period.dailyAverageMinutes));
  setText("#analyticsWeekHint", "Across " + period.keys.length + " calendar day" + (period.keys.length === 1 ? "" : "s"));
  setText("#analyticsSessionsLabel", "Focus sessions");
  setText("#analyticsSessions", String(period.recordedSessions));
  setText("#analyticsSessionsHint", "Distinct sessions with focused time");
  setText("#analyticsGoalLabel", "Period goal");
  setText("#goalProgress", goalPercent === null ? "—" : goalPercent + "%");
  setText("#analyticsGoalHint", hasHistoricalGoal
    ? formatDuration(period.minutes) + " of " + formatDuration(historicalGoal) + " · saved historical target"
    : "Historical target unavailable");
  setText("#analyticsStreakLabel", "Active days");
  setText("#currentStreak", activeDays + " day" + (activeDays === 1 ? "" : "s"));
  setText("#analyticsStreakHint", "Days with recorded focus time");
  document.querySelector("#analyticsSummaryGrid")?.setAttribute("aria-label", "Study summary for " + phrase);

  const comparison = document.querySelector("#analyticsPeriodComparison");
  if (comparison) {
    const comparisonIcon = document.querySelector("#analyticsPeriodComparisonIcon");
    const comparisonCopy = document.querySelector("#analyticsPeriodComparisonCopy");
    const comparisonValue = document.querySelector("#analyticsPeriodComparisonValue");
    const previousDefinition = completedPeriodAnalytics(
      summary,
      periodName,
      new Date(period.keys[0] + "T12:00:00"),
      state.goals?.studyHours,
      targets.weeklyMinutes
    );
    const previous = recordedStudyPeriod(summary.sessions || [], previousDefinition.keys, now.getTime(), null);
    comparison.classList.remove("hidden");
    if (period.recordedSessions > 0 && previous.recordedSessions > 0) {
      const difference = Math.round(period.minutes - previous.minutes);
      comparison.classList.add("is-available");
      comparisonIcon?.classList.add("hidden");
      comparisonCopy?.classList.add("hidden");
      comparisonValue?.classList.remove("hidden");
      if (comparisonValue) comparisonValue.textContent = "Compared with the preceding " + (periodName === "previous-month" ? "month" : "week") + ": "
        + (difference >= 0 ? "+" : "−") + formatDuration(Math.abs(difference)) + " focused study time.";
    } else {
      comparison.classList.remove("is-available");
      comparisonIcon?.classList.remove("hidden");
      comparisonCopy?.classList.remove("hidden");
      comparisonValue?.classList.add("hidden");
      if (comparisonValue) comparisonValue.textContent = "";
    }
  }

  const dailyRecords = state.analytics?.daily || {};
  const dailyTargets = period.keys.map((key) => {
    const record = dailyRecords[key];
    const savedTargets = record?.goalTargets;
    const savedDaily = record?.dailyGoal;
    const value = savedTargets && Object.hasOwn(savedTargets, "dailyMinutes")
      ? Number(savedTargets.dailyMinutes)
      : savedDaily && Object.hasOwn(savedDaily, "targetMinutes") ? Number(savedDaily.targetMinutes) : null;
    return Number.isFinite(value) && value >= 0 ? value : null;
  });
  renderStudyActivity(period, now, {
    historical: true,
    periodName,
    dailyTargetsMinutes: dailyTargets,
    compactDateLabels: periodName === "previous-month",
    showDurationLabels: periodName !== "previous-month"
  });
  renderSubjectDistribution(summary, now, {
    periodData: period,
    periodLabel: periodName === "previous-month" ? "Previous month" : "Previous week",
    periodPhrase: phrase,
    periodDescription: "Focused study time by subject " + phrase + ".",
    periodEmptyMessage: "No subject study activity was recorded " + phrase + "."
  });

  const timing = {
    periods: [
      { id: "morning", name: "Morning", milliseconds: 0 },
      { id: "afternoon", name: "Afternoon", milliseconds: 0 },
      { id: "evening", name: "Evening", milliseconds: 0 },
      { id: "night", name: "Night", milliseconds: 0 }
    ],
    totalMilliseconds: 0,
    unclassifiedMilliseconds: 0
  };
  period.keys.forEach((key) => {
    const dayTiming = studyTimingForLocalDay(summary.sessions || [], key, now.getTime(), null);
    timing.periods.forEach((item, index) => { item.milliseconds += dayTiming.periods[index]?.milliseconds || 0; });
    timing.totalMilliseconds += dayTiming.totalMilliseconds;
    timing.unclassifiedMilliseconds += dayTiming.unclassifiedMilliseconds;
  });
  const timingLabel = document.querySelector("#studyTimingPeriod");
  const timingDescription = document.querySelector("#studyTimingDescription");
  if (timingLabel) timingLabel.textContent = periodName === "previous-month" ? "Previous month" : "Previous week";
  if (timingDescription) timingDescription.textContent = "When focused study time happened " + phrase + ".";
  renderStudyTiming(timing, phrase);
  renderGoalConsistency(period, periodName, targetHistory);
  destroyChart("weekly");
  renderCourseHistory(summary);
}

function renderAnalytics() {
  const now = new Date();
  const summary = recordedAnalytics();
  [[el.analyticsCurrentBtn, null], [el.analyticsPreviousWeekBtn, "previous-week"], [el.analyticsPreviousMonthBtn, "previous-month"]].forEach(([button, period]) => {
    if (!button) return;
    const active = analyticsHistoryPeriod === period;
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", String(active));
  });
  if (analyticsHistoryPeriod) {
    renderHistoricalAnalytics(summary, now, analyticsHistoryPeriod);
    return;
  }
  // Restore the untouched This Week presentation after leaving a historical view.
  const comparison = document.querySelector("#analyticsPeriodComparison");
  comparison?.classList.add("hidden");
  comparison?.classList.remove("is-available");
  document.querySelector("#analyticsPeriodComparisonIcon")?.classList.remove("hidden");
  document.querySelector("#analyticsPeriodComparisonCopy")?.classList.remove("hidden");
  const comparisonValue = document.querySelector("#analyticsPeriodComparisonValue");
  comparisonValue?.classList.add("hidden");
  if (comparisonValue) comparisonValue.textContent = "";
  const setCurrentText = (selector, value) => {
    const node = document.querySelector(selector);
    if (node) node.textContent = value;
  };
  setCurrentText("#analyticsTodayLabel", "Today");
  setCurrentText("#analyticsTodayHint", "Time you studied today");
  setCurrentText("#analyticsSessionsLabel", "Sessions");
  setCurrentText("#analyticsSessionsHint", "Completed this week");
  setCurrentText("#analyticsGoalLabel", "Daily goal");
  setCurrentText("#analyticsStreakLabel", "Study streak");
  setCurrentText("#analyticsStreakHint", "Current study streak");
  el.analyticsSummaryGrid?.setAttribute("aria-label", "Your progress this week");
  setCurrentText("#studyTimingPeriod", "Today");
  setCurrentText("#studyTimingDescription", "See when your focused study time happens.");
  const currentDateKey = todayKey(now);
  const todaySessions = studySessionsForLocalDay(summary.sessions || [], currentDateKey, now.getTime(), state.focusSession);
  const studyTiming = studyTimingForLocalDay(summary.sessions || [], currentDateKey, now.getTime(), state.focusSession);
  const todayMinutes = todaySessions.reduce((total, session) => total + session.focusedMilliseconds, 0) / 60000;
  const targets = resolveStudyTargets(state);
  const currentPeriod = completedPeriodAnalytics(summary, "current-week", now, state.goals?.studyHours, targets.weeklyMinutes);
  const weeklyMinutes = currentPeriod.minutes;
  const avgMinutes = Math.round(weeklyMinutes / 7);
  const sixWeekMinutes = dateSeries(42).reduce((sum, key) => sum + (summary.byDate.get(key) || 0), 0);
  const weeklyAverageMinutes = Math.round(sixWeekMinutes / 6);
  const streak = Math.max(0, Number(state.analytics.streak?.current) || 0);
  el.currentStreak.textContent = streak + " day" + (streak === 1 ? "" : "s");
  if (el.analyticsToday) el.analyticsToday.textContent = formatDuration(todayMinutes);
  const visualPeriodName = selectedAnalyticsVisualPeriod();
  const visualPeriod = completedPeriodAnalytics(summary, visualPeriodName, now, state.goals?.studyHours, targets.weeklyMinutes);
  const periodLabel = analyticsVisualPeriodLabel(visualPeriodName);
  const periodPhrase = visualPeriodName === "previous-week" ? "last week" : visualPeriodName === "previous-month" ? "last month" : "this week";
  const periodTitle = $("#analyticsPeriodTitle");
  const periodIntro = $("#analyticsPeriodIntro");
  if (periodTitle) periodTitle.textContent = "Your progress " + periodPhrase;
  if (periodIntro) periodIntro.textContent = visualPeriodName === "current-week"
    ? "A quick look at what you studied and how your week is going."
    : "A quick look at what you studied " + periodPhrase + ".";
  if (el.analyticsWeekLabel) el.analyticsWeekLabel.textContent = periodLabel;
  if (el.analyticsWeek) el.analyticsWeek.textContent = formatDuration(visualPeriod.minutes);
  if (el.analyticsWeekHint) el.analyticsWeekHint.textContent = "Study time " + periodPhrase;
  if (el.analyticsSessions) el.analyticsSessions.textContent = String(visualPeriod.completedSessions);
  if (el.analyticsSessionsHint) el.analyticsSessionsHint.textContent = "Completed sessions " + periodPhrase;
  if (el.weeklyHours) el.weeklyHours.textContent = hours(weeklyAverageMinutes);
  if (el.averageStudy) el.averageStudy.textContent = hours(avgMinutes);
  const dailyGoalPercent = studyTargetProgress(todayMinutes, targets.dailyMinutes);
  el.goalProgress.textContent = dailyGoalPercent === null ? "—" : dailyGoalPercent + "%";
  if (el.analyticsGoalHint) el.analyticsGoalHint.textContent = dailyGoalPercent === null ? "Set a daily study target" : formatDuration(todayMinutes) + " of " + formatDuration(targets.dailyMinutes) + " today";
  if (el.dailyComparison) el.dailyComparison.textContent = (todayMinutes >= avgMinutes ? "+" : "-") + formatDuration(Math.abs(todayMinutes - avgMinutes));
  renderGamification();
  const chartWeek = studyWeekForLocalWeek(summary.sessions || [], now, now.getTime(), null, analyticsHistoryPeriod === "previous-week" ? -1 : 0);
  renderStudyActivity(chartWeek, now);
  renderSubjectDistribution(summary, now);
  renderStudyTiming(studyTiming);
  renderGoalConsistency(visualPeriod, visualPeriodName);
  destroyChart("weekly");
  renderCourseHistory(summary);
}
function setCourseHistoryExpanded(expanded) {
  courseHistoryExpanded = Boolean(expanded);
  try { sessionStorage.setItem("courseFocusProCourseHistoryExpanded", String(courseHistoryExpanded)); } catch {}
  if (el.courseHistoryPanel) el.courseHistoryPanel.dataset.expanded = String(courseHistoryExpanded);
  if (el.courseHistoryToggle) el.courseHistoryToggle.setAttribute("aria-expanded", String(courseHistoryExpanded));
}
function renderCourseHistory(summary = recordedAnalytics()) {
  if (!el.courseHistoryList) return;
  const query = courseHistoryQuery.trim().toLowerCase();
  const courseMeta = new Map();
  summary.sessions.forEach((session) => {
    const key = String(session.courseId || session.courseTitle || "Focus session");
    const entry = courseMeta.get(key) || { lastStudied: 0, subjects: new Map() };
    entry.lastStudied = Math.max(entry.lastStudied, Number(session.endedAt) || 0);
    const subject = String(session.subject || "").trim();
    if (subject) entry.subjects.set(subject, (entry.subjects.get(subject) || 0) + sessionActualMinutes(session));
    courseMeta.set(key, entry);
  });
  const courses = summary.courseEntries.map((course) => {
    const meta = courseMeta.get(String(course.id || course.title)) || { lastStudied: 0, subjects: new Map() };
    const subject = [...meta.subjects.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0]?.[0] || "Subject not recorded";
    return { ...course, subject, lastStudied: meta.lastStudied };
  }).filter((course) => (course.title + " " + course.id + " " + course.subject).toLowerCase().includes(query));
  if (courseHistorySort === "recent") courses.sort((a, b) => b.lastStudied - a.lastStudied || b.minutes - a.minutes || a.title.localeCompare(b.title));
  else if (courseHistorySort === "name") courses.sort((a, b) => a.title.localeCompare(b.title, undefined, { sensitivity: "base" }));
  else courses.sort((a, b) => b.minutes - a.minutes || b.sessions - a.sessions || a.title.localeCompare(b.title));
  setCourseHistoryExpanded(courseHistoryExpanded);
  if (el.courseHistoryCount) el.courseHistoryCount.textContent = summary.courseEntries.length + " course" + (summary.courseEntries.length === 1 ? "" : "s");
  el.courseHistoryList.innerHTML = "";
  if (!courses.length) { el.courseHistoryList.innerHTML = "<div class='course-history-empty'><strong>" + (summary.recordedSessions ? "No matching courses" : "No course history yet") + "</strong><span>" + (summary.recordedSessions ? "Try a different course name." : "Complete a Focus session to see your study history here.") + "</span></div>"; return; }
  courses.forEach((course) => {
    const share = summary.totalMinutes ? Math.round((course.minutes / summary.totalMinutes) * 100) : 0;
    const row = document.createElement("details"); row.className = "course-history-row";
    const related = summary.sessions.filter((item) => String(item.courseId || item.courseTitle || "Focus session") === String(course.id || course.title));
    row.innerHTML = "<summary><span class='course-history-course-copy'><strong class='course-history-name' title=''></strong><small class='course-history-subject'></small></span><span class='course-history-time'></span><span class='course-history-sessions'></span><span class='course-history-share'><i></i><b></b></span><span class='course-history-expand'>Details</span></summary><div class='course-history-details'></div>";
    const name = row.querySelector(".course-history-name"); name.textContent = course.title; name.title = course.title;
    row.querySelector(".course-history-subject").textContent = course.subject;
    row.querySelector(".course-history-time").textContent = formatDuration(course.minutes);
    row.querySelector(".course-history-share i").style.setProperty("--progress", share + "%"); row.querySelector(".course-history-share b").textContent = share + "%";
    row.querySelector(".course-history-sessions").textContent = course.sessions + " session" + (course.sessions === 1 ? "" : "s");
    const details = row.querySelector(".course-history-details"); details.textContent = related.length ? related.slice(0, 4).map((item) => historyDateLabel(item.endedAt) + " · " + formatDuration(item.actualMinutes) + (item.status === "completed" ? " · completed" : " · " + item.status)).join("\n") : "No study sessions recorded.";
    el.courseHistoryList.append(row);
  });
}
function minutesForDate(key) {
  const daily = state.analytics?.daily?.[key] || {};
  return Number(daily.studyMinutes || 0);
}
function renderAdvancedAnalytics() {
  if (el.analyticsInsightGrid) {
    const summary = completedAnalytics();
    const history = summary.sessions;
    const byHour = new Map();
    history.forEach((session) => {
      const hour = new Date(session.startedAt || session.endedAt || 0).getHours();
      byHour.set(hour, (byHour.get(hour) || 0) + sessionActualMinutes(session));
    });
    const productiveHour = [...byHour.entries()].sort((a, b) => b[1] - a[1])[0];
    const topSubject = Object.entries(subjectTotalsFromHistory()).sort((a, b) => b[1].minutes - a[1].minutes)[0];
    const thisWeek = summary.weekMinutes;
    const distractionThisWeek = dateSeries(7).reduce((sum, key) => sum + Number(state.analytics?.daily?.[key]?.distractionsBlocked || 0), 0);
    const weeklyHours = thisWeek / 60;
    const averageSession = history.length ? Math.round(history.reduce((sum, session) => sum + sessionActualMinutes(session), 0) / history.length) : 0;
    const dailyTotals = dateSeries(7).map((key) => ({ key, minutes: summary.byDate.get(key) || 0 }));
    const strongestDay = [...dailyTotals].sort((a, b) => b.minutes - a.minutes)[0];
    const insights = [
      { label: "Best study window", value: productiveHour ? new Date(2000, 0, 1, productiveHour[0]).toLocaleTimeString([], { hour: "numeric" }) : "Not enough data", detail: productiveHour ? formatDuration(productiveHour[1]) + " focused at this hour" : "Focus time will reveal your pattern" },
      { label: "Most focused subject", value: topSubject?.[1]?.minutes ? topSubject[0] : "Not enough data", detail: topSubject?.[1]?.minutes ? formatDuration(topSubject[1].minutes) + " of actual focus" : "Your first session will appear here" },
      { label: "Average session", value: averageSession ? formatDuration(averageSession) : "Not enough data", detail: averageSession ? "your average focused block" : "Focus time will set a baseline" },
      { label: "Strongest day", value: strongestDay?.minutes ? new Date(strongestDay.key + "T00:00:00").toLocaleDateString([], { weekday: "long" }) : "Not enough data", detail: strongestDay?.minutes ? formatDuration(strongestDay.minutes) + " focused on that day" : "Your strongest day will appear here" },
      { label: "Distraction trend", value: distractionThisWeek + " blocked", detail: distractionThisWeek ? "this week across protected sites" : "a clean week so far" },
      { label: "Monthly estimate", value: hours(Math.round(weeklyHours * 4.35 * 60)), detail: "at your current 7-day pace" },
      { label: "Yearly estimate", value: hours(Math.round(weeklyHours * 52 * 60)), detail: "at your current 7-day pace" }
    ];
    el.analyticsInsightGrid.innerHTML = "";
    insights.forEach((insight) => {
      const item = document.createElement("article");
      item.className = "analytics-insight";
      item.innerHTML = "<span></span><strong></strong><p></p>";
      item.querySelector("span").textContent = insight.label;
      item.querySelector("strong").textContent = insight.value;
      item.querySelector("p").textContent = insight.detail;
      el.analyticsInsightGrid.append(item);
    });
  }
  if (el.studyHeatmap) {
    const keys = dateSeries(84);
    const values = keys.map(minutesForDate);
    const max = Math.max(1, ...values);
    el.studyHeatmap.innerHTML = "";
    keys.forEach((key, index) => {
      const minutes = values[index];
      const cell = document.createElement("span");
      const intensity = minutes ? Math.max(1, Math.ceil(minutes / max * 4)) : 0;
      cell.className = "heatmap-cell level-" + intensity;
      cell.title = new Date(key + "T00:00:00").toLocaleDateString([], { month: "short", day: "numeric" }) + ": " + formatDuration(minutes);
      cell.setAttribute("aria-label", cell.title);
      el.studyHeatmap.append(cell);
    });
  }
}
function historyDateLabel(timestamp, active = false) {
  if (active) return "Now • In progress";
  const date = new Date(Number(timestamp) || 0);
  if (!Number.isFinite(date.getTime())) return "Date unavailable";
  const day = todayKey(date) === todayKey() ? "Today" : date.toLocaleDateString([], { month: "short", day: "numeric", year: date.getFullYear() === new Date().getFullYear() ? undefined : "numeric" });
  return day + " • " + date.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}
function missionCompletionPercent() {
  const tasks = state.daily.tasks || [];
  if (!tasks.length) return 0;
  const total = tasks.reduce((sum, task) => sum + Math.max(10, Number(task.minutes) || 20), 0);
  const done = tasks.filter((task) => task.done).reduce((sum, task) => sum + Math.max(10, Number(task.minutes) || 20), 0);
  return Math.round((done / Math.max(1, total)) * 100);
}
function systemGoalsData() { return dailySystemGoals(state); }
function renderSystemGoals() {
  if (!el.systemGoalsList) return;
  el.systemGoalsList.innerHTML = "";
  systemGoalsData().forEach((goal) => {
    const card = document.createElement("article");
    card.className = "system-goal-card" + (goal.done ? " done" : "");
    card.innerHTML = "<div><span></span><h4></h4><p></p></div><strong></strong><div class='progress-bar'><span></span></div>";
    card.querySelector("span").textContent = goal.done ? "Complete" : "In progress";
    card.querySelector("h4").textContent = goal.title;
    card.querySelector("p").textContent = goal.display || Math.min(goal.value, goal.target) + " / " + goal.target;
    card.querySelector("strong").textContent = "+" + goal.xp + " XP";
    card.querySelector(".progress-bar span").style.width = goal.percent + "%";
    el.systemGoalsList.append(card);
  });
}
function missionCard(task, index) {
  const item = document.createElement("article");
  item.className = "mission-item personal-goal-card" + (task.done ? " done" : "");
  item.innerHTML = "<input class='done' type='checkbox'><div class='personal-goal-copy'><strong></strong><span></span><p></p><small>No XP - personal goal</small></div><div class='mission-actions'><button class='button secondary compact-button edit' type='button'>Edit</button><button class='icon-button danger del' type='button'>x</button></div>";
  item.querySelector(".done").checked = task.done;
  item.querySelector("strong").textContent = task.title || "Personal goal";
  item.querySelector("span").textContent = (task.area || "Personal") + (Number(task.minutes || 0) ? " - " + task.minutes + " min" : "");
  item.querySelector("p").textContent = task.note || "No note added.";
  item.querySelector(".done").addEventListener("change", (e) => updateTask(index, { done: e.target.checked }));
  item.querySelector(".edit").addEventListener("click", () => editTask(index));
  item.querySelector(".del").addEventListener("click", () => deleteTask(index));
  return item;
}
function renderMissions() {
  renderSystemGoals();
  if (el.personalTaskList) {
    el.personalTaskList.innerHTML = "";
    const percent = missionCompletionPercent();
    el.missionProgressText.textContent = percent + "%";
    el.missionProgressFill.style.width = percent + "%";
    const indexed = state.daily.tasks.map((task, index) => ({ task, index }));
    if (!indexed.length) el.personalTaskList.innerHTML = "<div class='empty-state'><h4>No personal goals yet</h4><p>Add homework, assignments, revision, or any custom goal here. These do not award XP.</p></div>";
    else indexed.forEach(({ task, index }) => el.personalTaskList.append(missionCard(task, index)));
  }
}
function renderPlanner() {
  if (!el.plannerTimeline) return;
  if (el.plannerDateInput && !el.plannerDateInput.value) el.plannerDateInput.value = todayKey();
  el.plannerTimeline.innerHTML = "";
  const items = [...(state.planner?.items || [])].sort((a, b) => a.date.localeCompare(b.date) || Number(a.done) - Number(b.done)).slice(0, 18);
  if (!items.length) {
    el.plannerTimeline.innerHTML = "<div class='empty-state compact-empty'><h4>Nothing scheduled yet</h4><p>Schedule the next revision, study block, or deadline. Planner items help you organize but do not award XP.</p></div>";
    return;
  }
  items.forEach((item) => {
    const row = document.createElement("article");
    row.className = "planner-item" + (item.done ? " done" : "");
    row.innerHTML = "<input type='checkbox'><div><span></span><strong></strong><p></p></div><button class='icon-button danger remove' type='button' aria-label='Delete plan'>x</button>";
    const check = row.querySelector("input");
    check.checked = item.done;
    check.addEventListener("change", () => updatePlannerItem(item.id, { done: check.checked }));
    row.querySelector("span").textContent = item.kind + " - " + new Date(item.date + "T00:00:00").toLocaleDateString([], { month: "short", day: "numeric" });
    row.querySelector("strong").textContent = item.title;
    row.querySelector("p").textContent = courseName(item.courseId) + (item.minutes ? " - " + item.minutes + " min" : "");
    row.querySelector(".remove").addEventListener("click", () => deletePlannerItem(item.id));
    el.plannerTimeline.append(row);
  });
}
async function addPlannerItem(event) {
  event.preventDefault();
  const title = el.plannerTitleInput.value.trim();
  if (!title) return showToast("Give the study plan a clear title.");
  const item = { id: uid("plan"), title, date: el.plannerDateInput.value || todayKey(), kind: el.plannerKindInput.value, courseId: el.plannerCourseInput.value || null, minutes: Math.max(0, Number(el.plannerMinutesInput.value) || 0), done: false, createdAt: Date.now() };
  await saveState({ ...state, planner: { items: [...(state.planner?.items || []), item] } });
  el.plannerForm.reset();
  el.plannerDateInput.value = todayKey();
  showToast("Study block scheduled.");
}
async function updatePlannerItem(id, patch) {
  await saveState({ ...state, planner: { items: (state.planner?.items || []).map((item) => item.id === id ? { ...item, ...patch } : item) } });
}
async function deletePlannerItem(id) {
  if (!confirm("Delete this study plan?")) return;
  const previous = state;
  await saveState({ ...state, planner: { items: (state.planner?.items || []).filter((item) => item.id !== id) } });
  showUndo("Study plan deleted.", previous);
}
function musicMetadata(track) { return { id: track.id, title: track.title, type: track.type, size: track.size || 0, name: track.name || track.title, lastModified: track.lastModified || 0, available: Boolean(track.url) }; }
function musicKey(source = music.source, id = music.currentImportedId || MUSIC_TRACKS[music.index]?.id) { return source === "imported" ? "imported:" + id : "built-in:" + id; }
function musicTrackFromKey(key) {
  const [source, id] = String(key || "").split(":");
  if (source === "imported") return { source, track: music.imported.find((item) => item.id === id) || null };
  return { source: "built-in", track: MUSIC_TRACKS.find((item) => item.id === id) || null };
}
function playMusicKey(key) {
  const item = musicTrackFromKey(key);
  if (!item.track) return false;
  if (item.source === "imported") playImported(item.track.id);
  else playMusic(MUSIC_TRACKS.findIndex((track) => track.id === item.track.id));
  return true;
}
function saveMusicLibrary() {
  try {
    localStorage.setItem(MUSIC_LIBRARY_KEY, JSON.stringify({
      imported: music.imported.map(musicMetadata),
      currentImportedId: music.currentImportedId
    }));
  } catch {}
}
function loadMusicLibrary() {
  try {
    const raw = JSON.parse(localStorage.getItem(MUSIC_LIBRARY_KEY) || "{}");
    music.imported = Array.isArray(raw.imported) ? raw.imported.map((track) => ({ ...track, available: false, url: "" })).slice(0, 80) : [];
    music.currentImportedId = raw.currentImportedId || null;
  } catch { music.imported = []; }
}
function stopImportedAudio() {
  if (music.audio) {
    try { music.audio.pause(); } catch {}
    music.audio.onended = null;
    music.audio = null;
  }
}
function activeImportedList() {
  return music.imported.filter((track) => track.available !== false);
}
function renderMyMusic() {
  if (!el.myMusicList) return;
  el.myMusicList.innerHTML = "";
  if (!music.imported.length) {
    el.myMusicList.innerHTML = "<div class='empty-state compact-empty'><h4>No imported songs</h4><p>Add MP3, WAV, or OGG files. They stay local and are never uploaded.</p></div>";
    return;
  }
  music.imported.forEach((track) => {
    const row = document.createElement("article");
    row.className = "music-track-row" + (music.source === "imported" && music.currentImportedId === track.id ? " active" : "") + (track.available === false ? " unavailable" : "");
    row.innerHTML = "<div><strong></strong><span></span></div><button class='button secondary compact-button play-track' type='button'>Play</button><button class='button danger compact-button' type='button'>Remove</button>";
    row.querySelector("strong").textContent = track.title;
    row.querySelector("span").textContent = track.available === false ? "Re-import needed after browser restart" : track.type.toUpperCase() + " ready";
    const play = row.querySelector(".play-track");
    play.textContent = track.available === false ? "Re-import" : "Play";
    play.addEventListener("click", () => track.available === false ? el.musicImportInput.click() : playImported(track.id));
    row.querySelector(".danger").addEventListener("click", () => removeImported(track.id));
    el.myMusicList.append(row);
  });
}
function renderMusic() {
  if (!el.musicCategories) return;
  el.musicCategories.innerHTML = "";
  MUSIC_TRACKS.forEach((track, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "music-category" + (music.source === "built-in" && index === music.index ? " active" : "");
    button.innerHTML = "<strong></strong><span></span>";
    button.querySelector("strong").textContent = track.title;
    button.querySelector("span").textContent = track.description;
    button.addEventListener("click", () => playMusic(index));
    el.musicCategories.append(button);
  });
  const imported = music.imported.find((track) => track.id === music.currentImportedId);
  const builtIn = MUSIC_TRACKS[music.index];
  const current = music.source === "imported" && imported ? imported : builtIn;
  el.musicTitle.textContent = current.title;
  el.musicDescription.textContent = music.source === "imported" && imported ? (imported.available === false ? "Re-import this local file to play it again." : "Imported local audio file.") : current.description;
  el.musicStatus.textContent = music.playing ? "Music Playing" : "Stopped";
  el.musicStatus.classList.toggle("active", music.playing);
  el.musicVolumeInput.value = Math.round(music.volume * 100);
  if (el.musicVolumeLabel) el.musicVolumeLabel.textContent = Math.round(music.volume * 100) + "%";
  el.musicLoopInput.checked = music.loop;
  el.musicShuffleBtn?.classList.toggle("active", music.shuffle);
  if (el.musicPlayBtn) {
    if (el.musicPlayIcon) el.musicPlayIcon.textContent = music.playing ? "Ⅱ" : "▶";
    if (el.musicPlayLabel) el.musicPlayLabel.textContent = music.playing ? "Pause" : "Play";
    el.musicPlayBtn.setAttribute("aria-label", music.playing ? "Pause music" : "Play music");
    el.musicPlayBtn.setAttribute("aria-pressed", String(music.playing));
    el.musicPlayBtn.classList.toggle("is-playing", music.playing);
  }
  const canSeek = music.source === "imported" && Boolean(music.audio);
  if (el.musicBackBtn) el.musicBackBtn.disabled = !canSeek;
  if (el.musicForwardBtn) el.musicForwardBtn.disabled = !canSeek;
  renderMyMusic();
}
function renderMusicLibraryControls() {
  if (!el.playlistSelect || !el.musicQueue) return;
  el.playlistSelect.innerHTML = "";
  if (!music.playlists.length) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "Create a playlist first";
    el.playlistSelect.append(option);
  } else {
    music.playlists.forEach((playlist) => {
      const option = document.createElement("option");
      option.value = playlist.id;
      option.textContent = playlist.name + " (" + playlist.trackIds.length + ")";
      option.selected = playlist.id === music.activePlaylistId;
      el.playlistSelect.append(option);
    });
  }
  el.playlistAddCurrentBtn.disabled = !music.activePlaylistId;
  const currentKey = musicKey();
  el.musicFavoriteBtn.textContent = music.favorites.includes(currentKey) ? "Favorited" : "Favorite";
  el.musicFavoriteBtn.classList.toggle("active", music.favorites.includes(currentKey));
  el.musicQueue.innerHTML = "";
  if (!music.queue.length) el.musicQueue.innerHTML = "<p class='form-status'>Queue is empty. Add a sound to line up the next study block.</p>";
  else music.queue.forEach((key, index) => {
    const item = musicTrackFromKey(key);
    if (!item.track) return;
    const row = document.createElement("div");
    row.className = "queue-row";
    row.innerHTML = "<span></span><strong></strong><button class='icon-button remove' type='button' aria-label='Remove queued track'>x</button>";
    row.querySelector("span").textContent = index + 1;
    row.querySelector("strong").textContent = item.track.title;
    row.querySelector(".remove").addEventListener("click", () => { music.queue.splice(index, 1); saveMusicLibrary(); renderMusic(); });
    el.musicQueue.append(row);
  });
}
function toggleMusicFavorite() {
  const key = musicKey();
  music.favorites = music.favorites.includes(key) ? music.favorites.filter((item) => item !== key) : [...music.favorites, key];
  saveMusicLibrary();
  renderMusic();
}
function enqueueCurrentMusic() {
  const key = musicKey();
  if (music.queue.length >= 80) return showToast("Music queue is full.");
  music.queue.push(key);
  saveMusicLibrary();
  renderMusic();
  showToast("Added to queue.");
}
function createPlaylist() {
  const name = el.playlistNameInput.value.trim().slice(0, 48);
  if (!name) return showToast("Name the playlist first.");
  const playlist = { id: uid("playlist"), name, trackIds: [] };
  music.playlists.push(playlist);
  music.activePlaylistId = playlist.id;
  el.playlistNameInput.value = "";
  saveMusicLibrary();
  renderMusic();
  showToast("Playlist created.");
}
function addCurrentToPlaylist() {
  const playlist = music.playlists.find((item) => item.id === music.activePlaylistId);
  if (!playlist) return showToast("Create or choose a playlist first.");
  const key = musicKey();
  if (!playlist.trackIds.includes(key)) playlist.trackIds.push(key);
  saveMusicLibrary();
  renderMusic();
  showToast("Added to " + playlist.name + ".");
}
function playActivePlaylist() {
  const playlist = music.playlists.find((item) => item.id === music.activePlaylistId);
  if (!playlist?.trackIds.length) return showToast("Add at least one track to this playlist.");
  music.queue = [...playlist.trackIds.slice(1), ...music.queue];
  saveMusicLibrary();
  playMusicKey(playlist.trackIds[0]);
  showToast("Playing " + playlist.name + ".");
}
function deleteActivePlaylist() {
  const playlist = music.playlists.find((item) => item.id === music.activePlaylistId);
  if (!playlist || !confirm("Delete playlist '" + playlist.name + "'?")) return;
  music.playlists = music.playlists.filter((item) => item.id !== playlist.id);
  music.activePlaylistId = music.playlists[0]?.id || null;
  saveMusicLibrary();
  renderMusic();
}
function setMusicSleepTimer(minutes) {
  clearTimeout(music.sleepTimer);
  music.sleepTimer = null;
  const duration = Math.max(0, Number(minutes) || 0);
  music.sleepEndsAt = duration ? Date.now() + duration * 60000 : null;
  if (duration) music.sleepTimer = setTimeout(() => { music.sleepEndsAt = null; pauseMusic(true); showToast("Music sleep timer finished."); }, duration * 60000);
  renderMusic();
}
function ensureMusicContext() {
  if (!music.ctx) {
    music.ctx = new (window.AudioContext || window.webkitAudioContext)();
    music.gain = music.ctx.createGain();
    music.gain.gain.value = music.volume;
    music.gain.connect(music.ctx.destination);
  }
  return music.ctx;
}
function stopMusicNodes() {
  clearTimeout(music.endTimer);
  music.endTimer = null;
  music.nodes.forEach((node) => { try { node.stop?.(); } catch {} try { node.disconnect?.(); } catch {} });
  music.nodes = [];
}
function crossfadeMusicNodes() {
  if (!music.nodes.length || !music.gain || !music.ctx) return stopMusicNodes();
  clearTimeout(music.endTimer);
  music.endTimer = null;
  const previousNodes = music.nodes;
  music.nodes = [];
  const now = music.ctx.currentTime;
  music.gain.gain.cancelScheduledValues(now);
  music.gain.gain.setValueAtTime(Math.max(0.0001, music.gain.gain.value), now);
  music.gain.gain.linearRampToValueAtTime(0.0001, now + 0.14);
  setTimeout(() => {
    previousNodes.forEach((node) => { try { node.stop?.(); } catch {} try { node.disconnect?.(); } catch {} });
    const resumeAt = music.ctx.currentTime;
    music.gain.gain.setValueAtTime(0.0001, resumeAt);
    music.gain.gain.linearRampToValueAtTime(music.volume, resumeAt + 0.16);
  }, 145);
}
function makeNoiseBuffer(ctx, brown = false) {
  const length = ctx.sampleRate * 2;
  const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  let last = 0;
  for (let i = 0; i < length; i++) {
    const white = Math.random() * 2 - 1;
    data[i] = brown ? (last = (last + 0.02 * white) / 1.02) * 3.5 : white * 0.42;
  }
  return buffer;
}
function makeRainBuffer(ctx) {
  const length = ctx.sampleRate * 8;
  const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  let smooth = 0;
  for (let i = 0; i < length; i++) {
    const t = i / ctx.sampleRate;
    const white = Math.random() * 2 - 1;
    smooth = smooth * 0.78 + white * 0.22;
    const shower = white * 0.28 + smooth * 0.42;
    const droplets = Math.random() > 0.993 ? (Math.random() * 2 - 1) * 0.7 : 0;
    const thunderA = t > 1.2 && t < 2.8 ? Math.sin((t - 1.2) * Math.PI / 1.6) : 0;
    const thunderB = t > 5.4 && t < 7.1 ? Math.sin((t - 5.4) * Math.PI / 1.7) : 0;
    const rumble = (thunderA + thunderB) * smooth * 1.8;
    data[i] = Math.max(-1, Math.min(1, shower + droplets + rumble));
  }
  return buffer;
}
function createFilteredNoise(ctx, { buffer = makeNoiseBuffer(ctx), filter = 1200, gain = 0.14, filterType = "lowpass" } = {}) {
  const source = ctx.createBufferSource();
  const biquad = ctx.createBiquadFilter();
  const level = ctx.createGain();
  source.buffer = buffer;
  source.loop = true;
  biquad.type = filterType;
  biquad.frequency.value = filter;
  level.gain.value = gain;
  source.connect(biquad).connect(level).connect(music.gain);
  source.start();
  music.nodes.push(source, biquad, level);
  return level;
}
function playRainMusic(ctx) {
  createFilteredNoise(ctx, { buffer: makeRainBuffer(ctx), filter: 3600, gain: 0.17 });
  createFilteredNoise(ctx, { buffer: makeNoiseBuffer(ctx, true), filter: 150, gain: 0.12 });
}
function playCoffeeAmbience(ctx) {
  createFilteredNoise(ctx, { buffer: makeNoiseBuffer(ctx, true), filter: 720, gain: 0.075 });
  [118, 164, 226].forEach((frequency, index) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = frequency;
    gain.gain.value = 0.018 - index * 0.003;
    osc.connect(gain).connect(music.gain);
    osc.start();
    music.nodes.push(osc, gain);
  });
}
function playOceanWave(ctx) {
  const waveGain = createFilteredNoise(ctx, { buffer: makeNoiseBuffer(ctx, true), filter: 760, gain: 0.12 });
  const lfo = ctx.createOscillator();
  const lfoGain = ctx.createGain();
  lfo.frequency.value = 0.09;
  lfoGain.gain.value = 0.08;
  lfo.connect(lfoGain).connect(waveGain.gain);
  lfo.start();
  music.nodes.push(lfo, lfoGain);
}
function playMusic(index = music.index) {
  music.index = (index + MUSIC_TRACKS.length) % MUSIC_TRACKS.length;
  music.source = "built-in";
  stopImportedAudio();
  const track = MUSIC_TRACKS[music.index];
  const ctx = ensureMusicContext();
  ctx.resume?.();
  stopMusicNodes();
  if (track.type === "tone") {
    const osc = ctx.createOscillator();
    const lfo = ctx.createOscillator();
    const lfoGain = ctx.createGain();
    osc.type = track.wave;
    osc.frequency.value = track.frequency;
    lfo.frequency.value = track.lfoFrequency || (track.id === "piano" ? 1.1 : 0.32);
    lfoGain.gain.value = track.lfoGain ?? (track.id === "piano" ? 0.18 : 0.07);
    const toneGain = ctx.createGain();
    toneGain.gain.value = track.gain ?? 0.18;
    lfo.connect(lfoGain);
    lfoGain.connect(toneGain.gain);
    osc.connect(toneGain).connect(music.gain);
    osc.start();
    lfo.start();
    music.nodes.push(osc, lfo, toneGain, lfoGain);
  } else if (track.type === "rain") {
    playRainMusic(ctx);
  } else if (track.type === "coffee") {
    playCoffeeAmbience(ctx);
  } else if (track.type === "oceanwave") {
    playOceanWave(ctx);
  } else {
    createFilteredNoise(ctx, { buffer: makeNoiseBuffer(ctx, track.id === "brown"), filter: track.filter || 1000, gain: track.id === "white" ? 0.09 : 0.16 });
  }
  music.playing = true;
  if (!music.loop) music.endTimer = setTimeout(() => nextMusic(), 10 * 60 * 1000);
  saveMusicLibrary();
  renderMusic();
}
function playImported(id) {
  const track = music.imported.find((item) => item.id === id);
  if (!track) return;
  if (track.available === false || !track.url) { showToast("Re-import this song to play it again."); el.musicImportInput.click(); return; }
  music.source = "imported";
  music.currentImportedId = id;
  stopMusicNodes();
  stopImportedAudio();
  const audio = new Audio(track.url);
  audio.volume = music.volume;
  audio.loop = music.loop;
  audio.onended = () => { if (!music.loop) nextMusic(); };
  music.audio = audio;
  music.playing = true;
  audio.play().catch(() => { music.playing = false; showToast("Click Play again if Chrome blocked audio start."); renderMusic(); });
  saveMusicLibrary();
  renderMusic();
}
function pauseMusic() {
  stopMusicNodes();
  stopImportedAudio();
  music.playing = false;
  renderMusic();
}
function randomOtherIndex(length, current) {
  if (length <= 1) return 0;
  let next = Math.floor(Math.random() * length);
  if (next === current) next = (next + 1) % length;
  return next;
}
function previousMusic() {
  if (music.source === "imported") {
    const list = activeImportedList();
    const index = list.findIndex((track) => track.id === music.currentImportedId);
    if (list.length) playImported(list[(index - 1 + list.length) % list.length].id);
    return;
  }
  playMusic(music.shuffle ? randomOtherIndex(MUSIC_TRACKS.length, music.index) : music.index - 1);
}
function nextMusic() {
  if (music.source === "imported") {
    const list = activeImportedList();
    const index = list.findIndex((track) => track.id === music.currentImportedId);
    if (list.length) playImported(list[music.shuffle ? randomOtherIndex(list.length, index) : (index + 1) % list.length].id);
    return;
  }
  playMusic(music.shuffle ? randomOtherIndex(MUSIC_TRACKS.length, music.index) : music.index + 1);
}
function handleMusicCommand(action) {
  if (action === "play") { music.source === "imported" && music.currentImportedId ? playImported(music.currentImportedId) : playMusic(); return true; }
  if (action === "pause") { pauseMusic(); return true; }
  if (action === "next") { nextMusic(); return true; }
  if (action === "previous") { previousMusic(); return true; }
  return false;
}
function seekImportedMusic(seconds) {
  if (!music.audio) return showToast("Seeking works with imported songs only.");
  const duration = Number.isFinite(music.audio.duration) ? music.audio.duration : 0;
  const next = Math.max(0, Math.min(duration || music.audio.currentTime + seconds, music.audio.currentTime + seconds));
  music.audio.currentTime = next;
}
function setMusicVolume(value) {
  music.volume = Math.max(0, Math.min(1, Number(value) / 100));
  if (music.gain) music.gain.gain.value = music.volume;
  if (music.audio) music.audio.volume = music.volume;
  if (el.musicVolumeLabel) el.musicVolumeLabel.textContent = Math.round(music.volume * 100) + "%";
}
function importMusicFiles(files) {
  const accepted = ["audio/mpeg", "audio/wav", "audio/ogg", "audio/x-wav"];
  let added = 0;
  Array.from(files || []).forEach((file) => {
    const ext = file.name.split(".").pop()?.toLowerCase();
    if (!accepted.includes(file.type) && !["mp3", "wav", "ogg"].includes(ext)) return;
    const existing = music.imported.find((track) => track.name === file.name && track.size === file.size && track.lastModified === file.lastModified);
    const next = { id: existing?.id || uid("song"), title: file.name.replace(/\.[^.]+$/, ""), name: file.name, type: ext || "audio", url: URL.createObjectURL(file), size: file.size, lastModified: file.lastModified, available: true };
    if (existing) {
      if (existing.url) URL.revokeObjectURL(existing.url);
      Object.assign(existing, next);
    } else {
      music.imported.push(next);
    }
    added += 1;
  });
  if (added) { saveMusicLibrary(); showToast(added + " song" + (added === 1 ? "" : "s") + " ready."); }
  renderMusic();
}
function removeImported(id) {
  const track = music.imported.find((item) => item.id === id);
  if (!track || !confirm("Remove this imported song from My Music?")) return;
  if (music.currentImportedId === id) pauseMusic();
  if (track.url) URL.revokeObjectURL(track.url);
  music.imported = music.imported.filter((item) => item.id !== id);
    saveMusicLibrary();
  renderMusic();
}
const HELP_INFO = Object.freeze({
  "xp-rank": { title: "XP & Rank", text: "XP comes from completed focus sessions, verified system goals, and study streaks. Your level and rank update automatically as XP grows." },
  "focus-mode": { title: "Focus Mode", text: "Starts a timed session for your selected course. When Focus Protection is on, the course, saved course links, and Supporting Websites are allowed; other websites are redirected." },
  "today-study-time": { title: "Today Study Time", text: "Shows focused time recorded today. Paused time never counts, and an early stop keeps only the time you actually focused." },
  "today-sessions": { title: "Today Sessions", text: "Counts focus sessions that reached their planned end today." },
  "productivity-score": { title: "Productivity Score", text: "A 0-100 daily score based on actual study time, completed sessions, and blocked distraction attempts." },
  "study-music": { title: "Study Music", text: "Plays built-in focus sounds or local audio while you study. It does not upload your music." },
  "my-music": { title: "My Music", text: "Imports MP3, WAV, or OGG files from your device. Files stay local; after a browser restart, re-import them to reconnect playback." },
  "add-course": { title: "Add Course", text: "Saves an educational web page or video as a course you can open and use in Focus Mode." },
  "study-analytics": { title: "Study Analytics", text: "Shows time from each recorded focus session, including tracked sessions you ended early. Completion-based streaks and rewards remain separate." },
  "daily-goal": { title: "Daily Goal", text: "Compares today's recorded study minutes with your daily time target. Sessions, XP, and streaks do not change this percentage." },
  "study-streak": { title: "Study Streak", text: "Counts consecutive local calendar days with at least one completed focus session. Completing a session today continues the streak." },
  "daily-study-time": { title: "Daily Study Time", text: "Compare today's focused study time with your daily target. The marker shows the target, and the scale expands when your study time goes beyond it." },
  "subject-study-time": { title: "Subject Study Time", text: "Compares tracked minutes for each subject with its target for the selected period. Edit targets to match your plan." },
  "system-goals": { title: "System Goals", text: "Automatically tracked goals that complete only from verified study activity and can contribute to XP." },
  "personal-goals": { title: "Personal Goals", text: "Your private planning list for tasks and reminders. Marking these complete does not award XP." },
  "supporting-sites": { title: "Supporting Websites", text: "These domains stay allowed during active Focus study time when Focus Protection is enabled. Outside a session, normal browsing applies unless Outside Focus Protection is enabled." },
  "distraction-protection": { title: "Outside Focus Protection", text: "Redirects only the sites in your Distracting Sites list when Focus study time is not active. The Focus tab has a separate Focus Protection switch." },
  "camera-focus-check": { title: "Camera Focus Check", text: "An optional beta attention cue that runs only during active focus sessions. It processes temporary camera frames locally and never saves or uploads video." },
  "incognito-protection": { title: "Incognito Protection", text: "Extends your existing protection rules to Incognito windows after Chrome's Allow in incognito permission is enabled." },
  "youtube-study-mode": { title: "YouTube Study Mode", text: "During an active Focus session, keeps YouTube playback controls visible and hides feeds and recommendations. It turns off when Focus ends and during scheduled breaks." },
  "general-settings": { title: "General Settings", text: "Sets the defaults for new focus sessions, including duration, study profile, theme, and sound." },
  default: { title: "Help", text: "Learn what this control does before changing it." }
});
function showHelp(button) {
  const info = HELP_INFO[button.dataset.helpKey] || HELP_INFO.default;
  el.helpPopover.innerHTML = "";
  const heading = document.createElement("strong");
  heading.textContent = info.title;
  const copy = document.createElement("p");
  copy.textContent = info.text;
  el.helpPopover.append(heading, copy);
  const rect = button.getBoundingClientRect();
  el.helpPopover.style.left = Math.min(window.innerWidth - 300, Math.max(12, rect.left)) + "px";
  el.helpPopover.style.top = Math.min(window.innerHeight - 120, rect.bottom + 8) + "px";
  el.helpPopover.classList.remove("hidden");
}
function renderSettings() {
  if (!el.settingsForm) return;
  el.settingsFocusMinutesInput.value = state.settings.focusMinutesDefault || 50;
  if (el.settingsFocusModeSelect) el.settingsFocusModeSelect.value = state.settings.defaultFocusMode || "normal";
  if (el.settingsBreakMinutesInput) el.settingsBreakMinutesInput.value = state.settings.focusBreakMinutesDefault ?? 5;
  if (el.settingsFocusCyclesInput) el.settingsFocusCyclesInput.value = state.settings.focusBreakCyclesDefault ?? 1;
  if (el.studyProfileSelect) el.studyProfileSelect.value = state.profile?.studyProfile || "jee";
  el.themeModeSelect.value = state.settings.themeMode || "dark";
  if (el.soundEnabledInput) el.soundEnabledInput.checked = Boolean(state.settings.soundEnabled);
  if (el.soundVolumeInput) el.soundVolumeInput.value = Number(state.settings.soundVolume ?? 35);
  if (el.soundVolumeLabel) el.soundVolumeLabel.textContent = Number(state.settings.soundVolume ?? 35) + "%";
  if (el.soundVolumeSetting) el.soundVolumeSetting.hidden = !Boolean(el.soundEnabledInput?.checked);
  if (el.settingsFocusBreakDefaults) el.settingsFocusBreakDefaults.hidden = (el.settingsFocusModeSelect?.value || "normal") !== "breaks";
  updateSettingsBreakValidation();
  if (el.cameraAttentionEnabledInput) {
    el.cameraAttentionEnabledInput.checked = Boolean(state.settings.cameraAttentionEnabled && state.settings.cameraAttentionConsentAccepted && cameraPermissionState === "granted");
    el.cameraAttentionEnabledInput.disabled = cameraPermissionState !== "granted" || !state.settings.cameraAttentionConsentAccepted;
  }
  if (el.youtubeStudyModeEnabledInput) el.youtubeStudyModeEnabledInput.checked = Boolean(state.settings.youtubeStudyModeEnabled);
  if (el.cameraAttentionSensitivityInput) el.cameraAttentionSensitivityInput.value = state.settings.cameraAttentionSensitivity || "balanced";
  if (el.cameraAttentionGraceInput) el.cameraAttentionGraceInput.value = String(state.settings.cameraAttentionGraceSeconds || 10);
  if (el.cameraAttentionVoiceInput) el.cameraAttentionVoiceInput.checked = Boolean(state.settings.cameraAttentionVoice);
  if (el.cameraPermissionBtn) {
    const permissionChecking = cameraPermissionState === "checking";
    const consentAccepted = Boolean(state.settings.cameraAttentionConsentAccepted);
    el.cameraPermissionBtn.hidden = consentAccepted && (permissionChecking || cameraPermissionState === "granted");
    el.cameraPermissionBtn.disabled = cameraConsentSaving || (consentAccepted && permissionChecking);
    el.cameraPermissionBtn.textContent = consentAccepted ? "Allow Camera →" : "Review Camera Use →";
  }
  if (el.cameraAdvancedSettings) {
    const cameraEnabled = Boolean(state.settings.cameraAttentionEnabled && state.settings.cameraAttentionConsentAccepted && cameraPermissionState === "granted");
    el.cameraAdvancedSettings.hidden = !cameraEnabled;
    if (!cameraEnabled) el.cameraAdvancedSettings.open = false;
  }
  if (el.youtubeStudyModeState) {
    el.youtubeStudyModeState.textContent = state.settings.youtubeStudyModeEnabled ? "On" : "Off";
    el.youtubeStudyModeState.dataset.state = state.settings.youtubeStudyModeEnabled ? "on" : "off";
  }
  if (el.cameraAttentionState) {
    const consentAccepted = Boolean(state.settings.cameraAttentionConsentAccepted);
    const cameraEnabled = cameraPermissionState === "granted" && consentAccepted && Boolean(state.settings.cameraAttentionEnabled);
    el.cameraAttentionState.textContent = !consentAccepted || cameraPermissionState !== "granted"
      ? cameraPermissionState === "checking" ? "Checking" : "Permission Required"
      : cameraEnabled ? "On" : "Off";
    el.cameraAttentionState.dataset.state = !consentAccepted || cameraPermissionState !== "granted"
      ? cameraPermissionState === "checking" ? "checking" : "required"
      : cameraEnabled ? "on" : "off";
  }
  renderCameraAttention();
}

function renderCourseSwitchModal() {
  if (!el.courseSwitchList) return;
  el.courseSwitchList.innerHTML = "";
  if (!state.courses.length) {
    el.courseSwitchList.innerHTML = "<div class='empty-state'><h4>No courses yet</h4><p>Add one educational link in the Courses tab first.</p></div>";
    return;
  }
  state.courses.forEach((course) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "course-switch-item" + (course.id === state.settings.defaultCourseId ? " active" : "");
    button.innerHTML = "<strong></strong><span></span>";
    button.querySelector("strong").textContent = course.title;
    button.querySelector("span").textContent = (course.subject || "Other") + " - " + (safeUrl(course.url)?.hostname.replace(/^www\./, "") || "study link");
    button.addEventListener("click", async () => {
      await updateSettings({ defaultCourseId: course.id });
      el.courseModal.classList.add("hidden");
      showToast("Course selected: " + course.title);
    });
    el.courseSwitchList.append(button);
  });
}

function openCourseSwitchModal() {
  renderCourseSwitchModal();
  el.courseModal.classList.remove("hidden");
}

function renderCompletion() {
  if (!el.completionModal) return;
  const summary = state.focusCompletion;
  el.completionModal.classList.toggle("hidden", !summary);
  if (!summary) return;
  el.completionSubject.textContent = summary.subject || "Study";
  el.completionDuration.textContent = formatDuration(summary.durationMinutes || 0);
  el.completionXp.textContent = "+" + (summary.xpEarned || sessionXp(summary.durationMinutes, true)) + " XP";
  el.completionToday.textContent = formatDuration(summary.todayTotalMinutes || completedMinutesToday());
  el.completionStreak.textContent = (summary.streak || state.analytics.streak?.current || 0) + " days";
}

function renderWelcomeBack() {
  if (!el.welcomeBackModal) return;
  const session = activeSession();
  const show = Boolean(session?.welcomeBack);
  el.welcomeBackModal.classList.toggle("hidden", !show);
  if (!show) return;
  const remaining = Math.max(1, Math.ceil(sessionRemainingMs(session) / 60000));
  el.welcomeBackTime.textContent = formatDuration(remaining);
}

async function clearWelcomeBack() {
  const session = activeSession();
  if (!session?.welcomeBack) return;
  await saveState({ ...state, focusSession: { ...session, welcomeBack: false } });
}

async function clearCompletion() {
  if (!state.focusCompletion) return;
  await saveState({ ...state, focusCompletion: null });
}

function renderOnboarding() {
  const profile = state.profile || {};
  const shouldShow = !profile.onboarded || Number(profile.onboardingVersion || 0) < ONBOARDING_VERSION;
  el.onboardingOverlay?.classList.toggle("hidden", !shouldShow);
  if (!shouldShow) return;
  el.onboardingOverlay?.classList.remove("fade-out");
  syncOnboardingControls();
  renderOnboardingProfileCards();
  renderOnboardingSummary();
  showOnboardingStep(onboardingStep);
}

function showOnboardingStep(step) {
  const previousStep = onboardingStep;
  onboardingStep = ONBOARDING_STEPS.includes(step) ? step : "welcome";
  $$(".onboarding-step").forEach((item) => item.classList.toggle("active", item.dataset.step === onboardingStep));
  const stepIndex = Math.max(0, ONBOARDING_STEPS.indexOf(onboardingStep));
  if (el.onboardingProgressText) el.onboardingProgressText.textContent = "Step " + (stepIndex + 1) + " of " + ONBOARDING_STEPS.length;
  if (el.onboardingProgressFill) el.onboardingProgressFill.style.width = ((stepIndex + 1) / ONBOARDING_STEPS.length * 100) + "%";
  el.onboardingCard?.setAttribute("data-step", onboardingStep);
  el.onboardingCard?.classList.remove("step-animate");
  void el.onboardingCard?.offsetWidth;
  el.onboardingCard?.classList.add("step-animate");
  if (onboardingStep === "profile") renderOnboardingTargetEditor();
  if (onboardingStep === "ready") renderOnboardingSummary();
  if (previousStep !== onboardingStep) {
    const nextStep = onboardingStep;
    requestAnimationFrame(() => {
      if (nextStep !== onboardingStep || el.onboardingOverlay?.classList.contains("hidden")) return;
      document.querySelector(".onboarding-step.active .button.primary")?.focus({ preventScroll: true });
    });
  }
}

function handleWelcomeOnboardingKeydown(event) {
  if (event.key !== "Enter" || event.isComposing || event.repeat) return;
  if (el.onboardingOverlay?.classList.contains("hidden")) return;
  if (onboardingStep === "profile" && event.target === el.onboardingNewSubjectInput && !el.onboardingAddSubjectRow?.classList.contains("hidden")) {
    event.preventDefault();
    addOnboardingTargetSubject();
    return;
  }
  const actions = {
    welcome: el.onboardingGetStartedBtn,
    profile: el.onboardingProfileNextBtn,
    protection: el.onboardingProtectionNextBtn,
    ready: el.finishTutorialBtn
  };
  const action = actions[onboardingStep];
  if (!action || action.disabled) return;
  const targetButton = event.target instanceof Element ? event.target.closest("button") : null;
  if (targetButton && targetButton !== action && targetButton.closest(".onboarding-step.active")) return;
  event.preventDefault();
  action.click();
}

function cleanOnboardingName() {
  return String(el.onboardingNameInput ? el.onboardingNameInput.value : (onboardingNameDraft ?? state.profile?.name ?? "")).trim().slice(0, 60);
}

function currentOnboardingProfileChoice() {
  if (onboardingProfileChoice && ONBOARDING_PROFILE_OPTIONS[onboardingProfileChoice]) return onboardingProfileChoice;
  const storedProfile = state.profile?.studyProfile || "jee";
  return Object.entries(ONBOARDING_PROFILE_OPTIONS).find(([, option]) => option.profileId === storedProfile)?.[0] || "jee";
}

function currentOnboardingProfileId() {
  return ONBOARDING_PROFILE_OPTIONS[currentOnboardingProfileChoice()]?.profileId || "jee";
}

function syncOnboardingControls() {
  if (onboardingNameDraft === null) onboardingNameDraft = state.profile?.name || "";
  if (el.onboardingNameInput) el.onboardingNameInput.value = onboardingNameDraft;
  if (onboardingThemeChoice === null) onboardingThemeChoice = state.settings?.themeMode || "dark";
  if (onboardingDurationDraft === null) onboardingDurationDraft = String(state.settings?.focusMinutesDefault || 50);
  if (el.onboardingFocusMinutesInput) el.onboardingFocusMinutesInput.value = String(onboardingDurationDraft);
  renderOnboardingThemeOptions();
}

function renderOnboardingThemeOptions() {
  el.onboardingThemeOptions?.querySelectorAll("[data-onboarding-theme]").forEach((button) => {
    const selected = button.dataset.onboardingTheme === onboardingThemeChoice;
    button.classList.toggle("selected", selected);
    button.setAttribute("aria-pressed", String(selected));
  });
}

async function selectOnboardingTheme(mode) {
  if (!Object.hasOwn(ONBOARDING_THEME_NAMES, mode)) return;
  onboardingThemeChoice = mode;
  renderOnboardingThemeOptions();
  document.documentElement.dataset.theme = resolvedTheme(mode);
  document.documentElement.dataset.themeMode = mode;
  try { localStorage.setItem(THEME_MODE_CACHE_KEY, mode); } catch {}
  try {
    await updateSettings({ themeMode: mode });
  } catch (error) {
    onboardingThemeChoice = state.settings?.themeMode || "dark";
    applyTheme();
    renderOnboardingThemeOptions();
    showToast(error?.message || "Theme could not be saved.");
  }
}

function renderOnboardingProfileCards() {
  const selected = currentOnboardingProfileChoice();
  $$(".onboarding-profile-option").forEach((card) => {
    const active = card.dataset.onboardingProfile === selected;
    card.classList.toggle("selected", active);
    card.setAttribute("aria-pressed", String(active));
  });
}

function showProfileTargetsConfirmation(pending) {
  pendingProfileTargetsChange = pending;
  const profile = STUDY_PROFILES.find((item) => item.id === pending.profileId);
  const suggestion = studyTargetSuggestions(pending.profileId);
  if (el.profileTargetsConfirmMessage) {
    el.profileTargetsConfirmMessage.textContent = (profile?.name || "This profile") + " suggests " + formatDuration(suggestion.dailyMinutes) + " per day and " + formatDuration(suggestion.weeklyMinutes) + " per week. Apply these suggestions or keep your current targets?";
  }
  el.profileTargetsConfirmModal?.classList.remove("hidden");
  requestAnimationFrame(() => el.applyProfileTargetsBtn?.focus({ preventScroll: true }));
}

function closeProfileTargetsConfirmation() {
  const pending = pendingProfileTargetsChange;
  pendingProfileTargetsChange = null;
  el.profileTargetsConfirmModal?.classList.add("hidden");
  if (pending?.source === "settings" && el.studyProfileSelect) el.studyProfileSelect.value = state.profile?.studyProfile || "jee";
  if (pending?.source === "onboarding") renderOnboardingProfileCards();
}

function applyOnboardingProfileChoice(choice, applySuggestions) {
  const nextProfileId = ONBOARDING_PROFILE_OPTIONS[choice]?.profileId;
  if (!nextProfileId) return;
  const previousProfileId = currentOnboardingProfileId();
  const currentDraft = captureOnboardingTargetDraft() || initialOnboardingTargets(previousProfileId);
  onboardingProfileChoice = choice;
  if (applySuggestions) {
    const suggestions = studyTargetSuggestions(nextProfileId);
    onboardingTargetsDraft = { ...suggestions, selectedSubjects: Object.keys(suggestions.subjectTargets), customSubjects: [], sortBy: "actual" };
    onboardingTargetsTouched = false;
  } else {
    onboardingTargetsDraft = { ...currentDraft, profileId: nextProfileId };
    onboardingTargetsTouched = true;
  }
  onboardingTargetsProfileId = nextProfileId;
  renderOnboardingTargetEditor();
  renderOnboardingProfileCards();
}

async function commitSettingsProfileChange(profileId, applySuggestions) {
  const snapshot = readSettingsPreferenceSnapshot();
  const currentTargets = resolveStudyTargets(state);
  const targetValues = applySuggestions ? studyTargetSuggestions(profileId) : currentTargets;
  const goals = {
    ...state.goals,
    ...(applySuggestions ? { studyHours: targetValues.dailyMinutes / 60 } : {}),
    analyticsTargets: {
      profileId,
      weeklyMinutes: targetValues.weeklyMinutes,
      studyDays: targetValues.studyDays,
      subjectTargets: { ...targetValues.subjectTargets },
      selectedSubjects: [...(targetValues.selectedSubjects || Object.keys(targetValues.subjectTargets))],
      subjectTargetPeriod: "daily",
      customSubjects: [...(targetValues.customSubjects || [])],
      sortBy: targetValues.sortBy || "actual"
    }
  };
  const nextState = {
    ...state,
    settings: { ...state.settings, ...snapshot.settings },
    profile: { ...state.profile, studyProfile: profileId },
    goals
  };
  const revision = ++settingsSaveRevision;
  setSettingsSaveStatus("Saving…", "saving");
  const task = settingsSaveQueue.catch(() => {}).then(async () => {
    try {
      await saveState(nextState);
      if (revision === settingsSaveRevision) setSettingsSaveStatus("Saved", "saved");
      showToast(applySuggestions ? "Profile suggestions applied." : "Profile changed. Your targets were kept.");
    } catch (error) {
      if (el.studyProfileSelect) el.studyProfileSelect.value = state.profile?.studyProfile || "jee";
      if (revision === settingsSaveRevision) setSettingsSaveStatus("Couldn’t save", "error");
      console.error("Studizen profile target update failed:", error);
      showToast(error?.message || "Study profile could not be saved.");
    }
  });
  settingsSaveQueue = task;
  await task;
}

async function resolveProfileTargetsConfirmation(applySuggestions) {
  const pending = pendingProfileTargetsChange;
  if (!pending) return;
  pendingProfileTargetsChange = null;
  el.profileTargetsConfirmModal?.classList.add("hidden");
  if (pending.source === "onboarding") {
    applyOnboardingProfileChoice(pending.choice, applySuggestions);
    return;
  }
  await commitSettingsProfileChange(pending.profileId, applySuggestions);
}

function selectOnboardingProfile(choice) {
  if (!ONBOARDING_PROFILE_OPTIONS[choice]) return;
  if (choice === currentOnboardingProfileChoice()) return;
  const previousProfileId = currentOnboardingProfileId();
  captureOnboardingTargetDraft();
  const nextProfileId = ONBOARDING_PROFILE_OPTIONS[choice].profileId;
  if (previousProfileId === nextProfileId) return;
  if (state.profile?.startedAt || state.goals?.analyticsTargets || onboardingTargetsTouched) {
    showProfileTargetsConfirmation({ source: "onboarding", profileId: nextProfileId, choice });
    return;
  }
  applyOnboardingProfileChoice(choice, true);
}

function normalizeOnboardingDuration(value) {
  const raw = String(value ?? "").trim();
  const numeric = raw ? Number(raw) : Number(state.settings?.focusMinutesDefault) || 50;
  const bounded = Math.max(5, Math.min(240, Number.isFinite(numeric) ? numeric : 50));
  return Math.max(5, Math.min(240, Math.round(bounded / 5) * 5));
}

function initialOnboardingTargets(profileId) {
  const suggestions = studyTargetSuggestions(profileId);
  const resolved = resolveStudyTargets({ ...state, profile: { ...(state.profile || {}), studyProfile: profileId } });
  const isNewSetup = !state.profile?.startedAt && !state.goals?.analyticsTargets;
  return {
    profileId,
    dailyMinutes: isNewSetup ? suggestions.dailyMinutes : resolved.dailyMinutes,
    weeklyMinutes: isNewSetup ? suggestions.weeklyMinutes : resolved.weeklyMinutes,
    studyDays: isNewSetup ? suggestions.studyDays : resolved.studyDays,
    subjectTargets: { ...suggestions.subjectTargets, ...resolved.subjectTargets },
    selectedSubjects: isNewSetup ? Object.keys(suggestions.subjectTargets) : [...new Set(resolved.selectedSubjects || Object.keys(resolved.subjectTargets))],
    customSubjects: [...resolved.customSubjects],
    sortBy: resolved.sortBy
  };
}

function captureOnboardingTargetDraft() {
  if (!el.onboardingTargetSubjectList) return onboardingTargetsDraft;
  const profileId = currentOnboardingProfileId();
  const base = onboardingTargetsDraft || initialOnboardingTargets(profileId);
  const readHours = (input, fallback, maximum) => {
    const value = input?.valueAsNumber;
    return Number.isFinite(value) ? Math.round(Math.max(0, Math.min(maximum, value)) * 60) : fallback;
  };
  const subjectTargets = {};
  const customSubjects = [];
  el.onboardingTargetSubjectList.querySelectorAll(".analytics-target-subject-row").forEach((row) => {
    const original = String(row.dataset.subjectName || "").trim();
    const subject = String(row.querySelector(".analytics-target-subject-name")?.value || original).trim().replace(/\s+/g, " ").slice(0, 48);
    if (!subject) return;
    const targetMinutes = parseSubjectTargetDuration(row.querySelector(".analytics-target-subject-input")?.value);
    subjectTargets[subject] = targetMinutes === null ? (base.subjectTargets?.[original] || 0) : targetMinutes;
    if (row.dataset.custom === "true") customSubjects.push(subject);
  });
  onboardingTargetsDraft = {
    profileId,
    dailyMinutes: readHours(el.onboardingDailyTargetInput, base.dailyMinutes, 24),
    weeklyMinutes: readHours(el.onboardingWeeklyTargetInput, base.weeklyMinutes, 168),
    studyDays: base.studyDays || studyTargetSuggestions(profileId).studyDays,
    subjectTargets,
    selectedSubjects: Object.keys(subjectTargets),
    customSubjects: [...new Set(customSubjects)],
    sortBy: base.sortBy || "actual"
  };
  onboardingTargetsProfileId = profileId;
  return onboardingTargetsDraft;
}

function onboardingSubjectIsEditable(name, profileId) {
  const customizableProfile = ["school", "college", "custom"].includes(profileId);
  return customizableProfile || onboardingTargetsDraft.customSubjects.includes(name) || !Object.hasOwn(studyTargetSuggestions(profileId).subjectTargets, name);
}

function renderOnboardingTargetEditor() {
  if (!el.onboardingTargetSubjectList) return;
  const profileId = currentOnboardingProfileId();
  if (!onboardingTargetsDraft) {
    onboardingTargetsDraft = initialOnboardingTargets(profileId);
    onboardingTargetsTouched = Boolean(state.profile?.startedAt || state.goals?.analyticsTargets);
    onboardingTargetsProfileId = profileId;
  }
  const suggestions = studyTargetSuggestions(profileId);
  const names = [...new Set([...(Array.isArray(onboardingTargetsDraft.selectedSubjects) ? onboardingTargetsDraft.selectedSubjects : Object.keys(suggestions.subjectTargets)), ...Object.keys(onboardingTargetsDraft.subjectTargets || {}), ...(onboardingTargetsDraft.customSubjects || [])])].slice(0, 80);
  if (el.onboardingDailyTargetInput) el.onboardingDailyTargetInput.value = String(Number((onboardingTargetsDraft.dailyMinutes / 60).toFixed(2)));
  if (el.onboardingWeeklyTargetInput) el.onboardingWeeklyTargetInput.value = String(Number((onboardingTargetsDraft.weeklyMinutes / 60).toFixed(2)));
  if (el.onboardingTargetSubjectList.children.length && el.onboardingTargetSubjectList.dataset.profileId === profileId) return;
  el.onboardingTargetSubjectList.innerHTML = "";
  names.forEach((name) => {
    const row = makeAnalyticsTargetSubjectRow(name, onboardingTargetsDraft.subjectTargets[name] || 0, onboardingSubjectIsEditable(name, profileId));
    row.classList.add("onboarding-target-subject-row");
    el.onboardingTargetSubjectList.append(row);
  });
  el.onboardingTargetSubjectList.dataset.profileId = profileId;
  onboardingTargetsProfileId = profileId;
}

function renderOnboardingSummary() {
  const choice = ONBOARDING_PROFILE_OPTIONS[currentOnboardingProfileChoice()] || ONBOARDING_PROFILE_OPTIONS.jee;
  const targets = onboardingTargetsDraft || initialOnboardingTargets(choice.profileId);
  const duration = normalizeOnboardingDuration(onboardingDurationDraft ?? state.settings?.focusMinutesDefault);
  if (el.onboardingReadyName) el.onboardingReadyName.textContent = cleanOnboardingName() || "Not provided";
  if (el.onboardingReadyProfile) el.onboardingReadyProfile.textContent = choice.name;
  if (el.onboardingReadyTheme) el.onboardingReadyTheme.textContent = ONBOARDING_THEME_NAMES[onboardingThemeChoice || state.settings?.themeMode] || "Dark";
  if (el.onboardingReadyDuration) el.onboardingReadyDuration.textContent = duration + " minutes";
  if (el.onboardingReadyDailyTarget) el.onboardingReadyDailyTarget.textContent = formatDuration(targets.dailyMinutes) + " / day";
  if (el.onboardingReadyWeeklyTarget) el.onboardingReadyWeeklyTarget.textContent = formatDuration(targets.weeklyMinutes) + " / week";
  if (el.onboardingReadySubjects) {
    el.onboardingReadySubjects.innerHTML = "";
    const entries = Object.entries(targets.subjectTargets || {}).sort(([a], [b]) => a.localeCompare(b));
    if (!entries.length) {
      const empty = document.createElement("small"); empty.textContent = "No subject targets set"; el.onboardingReadySubjects.append(empty);
    } else entries.forEach(([subject, minutes]) => {
      const item = document.createElement("small");
      item.textContent = subject + " · " + (minutes ? formatDuration(minutes) : "No target");
      el.onboardingReadySubjects.append(item);
    });
  }
  if (el.onboardingReadyMessage) el.onboardingReadyMessage.textContent = "Your preferences are saved. Add courses whenever you're ready.";
}

async function saveOnboardingWelcome() {
  const duration = normalizeOnboardingDuration(el.onboardingFocusMinutesInput?.value ?? onboardingDurationDraft);
  const name = cleanOnboardingName();
  onboardingNameDraft = name;
  onboardingDurationDraft = String(duration);
  if (el.onboardingFocusMinutesInput) el.onboardingFocusMinutesInput.value = onboardingDurationDraft;
  try {
    await saveState({
      ...state,
      settings: { ...state.settings, themeMode: onboardingThemeChoice || state.settings.themeMode || "dark", focusMinutesDefault: duration },
      profile: { ...(state.profile || {}), name }
    });
    showOnboardingStep("profile");
  } catch (error) {
    showToast(error?.message || "Your preferences could not be saved.");
  }
}

function addOnboardingTargetSubject() {
  const name = String(el.onboardingNewSubjectInput?.value || "").trim().replace(/\s+/g, " ").slice(0, 48);
  if (!name) { el.onboardingNewSubjectInput?.focus(); return; }
  const exists = [...(el.onboardingTargetSubjectList?.querySelectorAll(".analytics-target-subject-row") || [])]
    .some((row) => String(row.querySelector(".analytics-target-subject-name")?.value || row.dataset.subjectName || "").trim().toLocaleLowerCase() === name.toLocaleLowerCase());
  if (exists) { showToast("That subject is already in your targets."); return; }
  const selectedNames = [...(el.onboardingTargetSubjectList?.querySelectorAll(".analytics-target-subject-row") || [])]
    .map((item) => String(item.querySelector(".analytics-target-subject-name")?.value || item.dataset.subjectName || "").trim()).filter(Boolean);
  const suggestions = studyTargetSuggestions(currentOnboardingProfileId(), [...selectedNames, name]);
  const row = makeAnalyticsTargetSubjectRow(name, suggestions.subjectTargets[name] ?? 120, true);
  row.classList.add("onboarding-target-subject-row");
  el.onboardingTargetSubjectList?.append(row);
  if (el.onboardingNewSubjectInput) el.onboardingNewSubjectInput.value = "";
  el.onboardingAddSubjectRow?.classList.add("hidden");
  onboardingTargetsTouched = true;
  row.querySelector(".analytics-target-subject-name")?.focus();
}

async function saveOnboardingProfile() {
  const studyProfile = currentOnboardingProfileId();
  const name = cleanOnboardingName();
  onboardingNameDraft = name;
  const draft = captureOnboardingTargetDraft() || initialOnboardingTargets(studyProfile);
  const rows = [...(el.onboardingTargetSubjectList?.querySelectorAll(".analytics-target-subject-row") || [])];
  const seen = new Set();
  for (const row of rows) {
    const name = String(row.querySelector(".analytics-target-subject-name")?.value || row.dataset.subjectName || "").trim().replace(/\s+/g, " ");
    if (!name) { row.querySelector(".analytics-target-subject-name")?.focus(); showToast("Enter a name for each subject."); return; }
    const key = name.toLocaleLowerCase();
    if (seen.has(key)) { row.querySelector(".analytics-target-subject-name")?.focus(); showToast("Each subject name must be unique."); return; }
    seen.add(key);
  }
  const suggestions = studyTargetSuggestions(studyProfile);
  const selectedSubjects = [...new Set(draft.selectedSubjects || Object.keys(draft.subjectTargets))];
  for (const row of rows) {
    if (parseSubjectTargetDuration(row.querySelector(".analytics-target-subject-input")?.value) === null) {
      row.querySelector(".analytics-target-subject-input")?.focus();
      showToast("Use a daily duration such as 2h 30m.");
      return;
    }
  }
  const subjectTargets = Object.fromEntries(selectedSubjects.map((subject) => [subject, Math.max(0, Number(draft.subjectTargets[subject]) || 0)]));
  const nextProfile = {
    ...(state.profile || {}), name, profileType: "local", email: "", studyProfile,
    startedAt: state.profile?.startedAt || Date.now(), lastProfileAt: Date.now()
  };
  const nextGoals = {
    ...state.goals,
    studyHours: Math.max(0, Math.min(24, draft.dailyMinutes / 60)),
    analyticsTargets: {
      profileId: studyProfile,
      weeklyMinutes: Math.max(0, Math.min(10080, draft.weeklyMinutes)),
      studyDays: draft.studyDays || suggestions.studyDays,
      subjectTargets,
      selectedSubjects,
      subjectTargetPeriod: "daily",
      customSubjects: [...new Set(draft.customSubjects)],
      sortBy: draft.sortBy || "actual"
    }
  };
  let nextState = { ...state, profile: nextProfile, goals: nextGoals };
  const renames = rows.filter((row) => row.dataset.custom === "true").map((row) => [String(row.dataset.subjectName || "").trim(), String(row.querySelector(".analytics-target-subject-name")?.value || row.dataset.subjectName || "").trim().replace(/\s+/g, " ").slice(0, 48)]).filter(([from, to]) => from && to && from !== to);
  renames.forEach(([from, to]) => { nextState = renameTrackedSubject(nextState, from, to); });
  try {
    await saveState(nextState);
    onboardingTargetsDraft = { ...draft, profileId: studyProfile, subjectTargets, selectedSubjects, customSubjects: [...new Set(draft.customSubjects)] };
    onboardingTargetsTouched = true;
    showOnboardingStep("protection");
  } catch (error) {
    showToast(error?.message || "Your study targets could not be saved.");
  }
}

async function saveOnboardingPreferences() {
  renderOnboardingSummary();
  showOnboardingStep("ready");
}

async function completeOnboarding(destination = "focus") {
  const cleanName = cleanOnboardingName();
  el.onboardingOverlay?.classList.add("fade-out");
  await saveState({ ...state, profile: { ...(state.profile || {}), onboarded: true, onboardingVersion: ONBOARDING_VERSION, guidedTourStatus: "not_started", guidedTourVersion: GUIDED_TOUR_VERSION, guidedTourActive: false, guidedTourStep: 0, guidedTourTabId: null, guidedTourSessionId: null, guidedTourUpdatedAt: Date.now(), name: cleanName, profileType: "local", email: "", startedAt: state.profile?.startedAt || Date.now(), lastProfileAt: Date.now() } });
  setTimeout(() => {
    el.onboardingOverlay?.classList.add("hidden");
    void startGuidedTour();
  }, 220);
  setActiveTab(destination === "courses" ? "courses" : "focus");
  showToast(cleanName ? "Setup complete, " + cleanName + "." : "Setup complete.");
}

async function showWelcomeAgain() {
  onboardingStep = "welcome";
  onboardingProfileChoice = null;
  onboardingNameDraft = state.profile?.name || "";
  onboardingThemeChoice = null;
  onboardingDurationDraft = null;
  onboardingTargetsDraft = null;
  onboardingTargetsProfileId = null;
  onboardingTargetsTouched = false;
  guidedTourAutoStartHandled = false;
  if (el.onboardingNameInput) el.onboardingNameInput.value = onboardingNameDraft;
  if (el.onboardingTargetSubjectList) { el.onboardingTargetSubjectList.innerHTML = ""; delete el.onboardingTargetSubjectList.dataset.profileId; }
  el.onboardingOverlay?.classList.remove("fade-out");
  await saveState({ ...state, profile: { ...(state.profile || {}), onboarded: false, onboardingVersion: 0, guidedTourStatus: "completed", guidedTourVersion: 0, guidedTourActive: false, guidedTourStep: 0, guidedTourTabId: null, guidedTourSessionId: null, guidedTourUpdatedAt: Date.now() } });
}

function render() {
  renderClock();
  renderHeader();
  renderFocus();
  renderFocusEnhancements();
  renderTodayInsight();
  renderCourses();
  renderShield();
  if ($("#tab-analytics")?.classList.contains("active")) renderAnalytics();
  renderMissions();
  renderMusic();
  renderSettings();
  renderCourseSwitchModal();
  renderCompletion();
  renderWelcomeBack();
  renderOnboarding();
}

function savedVideoCourse(rawUrl) { return state.courses.find((course) => courseHasVideo(course, rawUrl)) || null; }
function fillYouTubeAddSelects() {
  if (!pendingYouTubeVideo) return;
  const selectedSubject = el.youtubeNewSubjectSelect?.value;
  const selectedLibraryId = el.youtubeNewLibrarySelect?.value;
  const title = safeYouTubeTitle(pendingYouTubeVideo.title, "");
  const titleDraft = pendingYouTubeVideo.titleEdited ? pendingYouTubeVideo.titleDraft : title;
  el.youtubeAddVideoTitle.textContent = pendingYouTubeVideo.lookupComplete
    ? "Title found. Review the course name before saving."
    : title || "We couldn't read the video title. Enter it below.";
  el.youtubeNewTitleInput.value = titleDraft;
  el.youtubeNewTitleInput.placeholder = titleDraft ? "" : "Enter video title";
  el.youtubeNewTitleInput.required = !titleDraft.trim();
  el.youtubeTitleConsent.classList.toggle("hidden", Boolean(title) || pendingYouTubeVideo.lookupComplete);
  el.youtubeTitleLookupBtn.disabled = Boolean(pendingYouTubeVideo.lookupInFlight);
  el.youtubeTitleLookupBtn.textContent = pendingYouTubeVideo.lookupInFlight ? "Looking up title…" : "Look up title on YouTube";
  el.youtubeTitleLookupStatus.textContent = pendingYouTubeVideo.lookupStatus
    || "No request has been made. Choose a lookup or enter the title manually.";
  el.youtubeNewSubjectSelect.innerHTML = "";
  currentSubjects().forEach((subject) => {
    const option = document.createElement("option");
    option.value = subject;
    option.textContent = subject;
    option.selected = subject === selectedSubject;
    el.youtubeNewSubjectSelect.append(option);
  });
  el.youtubeNewLibrarySelect.innerHTML = "";
  state.courseLibraries.forEach((library) => {
    const option = document.createElement("option");
    option.value = library.id;
    option.textContent = library.name;
    option.selected = library.id === selectedLibraryId;
    el.youtubeNewLibrarySelect.append(option);
  });
}
async function lookupPendingYouTubeTitle() {
  const pending = pendingYouTubeVideo;
  if (!pending || pending.lookupInFlight || pending.lookupComplete) return;

  pending.oembedChoice = "consented";
  pending.lookupInFlight = true;
  pending.lookupStatus = "Sending this selected video's URL to YouTube for a title. The course is not saved.";
  fillYouTubeAddSelects();
  try {
    const result = await sendMessage({ type: "lookupYouTubeTitle", videoUrl: pending.url, consent: true });
    if (pendingYouTubeVideo !== pending) return;
    const response = result?.response;
    const title = safeYouTubeTitle(response?.title, "");
    if (!result?.ok || response?.videoUrl !== pending.url || !title) {
      throw new Error("YouTube did not return a title for this video.");
    }
    pending.title = title;
    pending.lookupComplete = true;
    pending.lookupStatus = "";
    if (!pending.titleEdited) {
      pending.titleDraft = title;
      el.youtubeNewTitleInput.value = title;
      el.youtubeNewTitleInput.placeholder = "";
      el.youtubeNewTitleInput.required = false;
    }
    fillYouTubeAddSelects();
  } catch {
    if (pendingYouTubeVideo !== pending) return;
    pending.lookupStatus = "YouTube couldn't provide a title. No course was saved; try again or enter a title manually.";
  } finally {
    if (pendingYouTubeVideo === pending) {
      pending.lookupInFlight = false;
      fillYouTubeAddSelects();
    }
  }
}
function closeYouTubeAddModal() {
  pendingYouTubeVideo = null;
  el.youtubeTitleLookupStatus.textContent = "";
  el.youtubeTitleLookupBtn.disabled = false;
  el.youtubeTitleLookupBtn.textContent = "Look up title on YouTube";
  el.youtubeTitleConsent.classList.add("hidden");
  el.youtubeAddModal?.classList.add("hidden");
  if (guidedTourActive) {
    setGuidedTourSuspended(false);
    void renderGuidedTourStep();
  }
}
function openYouTubeAddModal(rawUrl, rawTitle = "") {
  const url = canonicalYouTubeVideoUrl(rawUrl);
  if (!url) return showToast("That YouTube link is not a supported video URL.");
  const existing = savedVideoCourse(url);
  if (existing) return showToast("This video is already saved in " + existing.title + ".");
  const title = safeYouTubeTitle(rawTitle, "");
  pendingYouTubeVideo = { url, title, titleDraft: title, titleEdited: false, lookupInFlight: false, lookupComplete: false, lookupStatus: "", oembedChoice: "undecided" };
  fillYouTubeAddSelects();
  el.youtubeAddModal.classList.remove("hidden");
  if (!pendingYouTubeVideo.title) el.youtubeNewTitleInput?.focus({ preventScroll: true });
  if (guidedTourActive) setGuidedTourSuspended(true);
}
async function prepareGuidedTourCourseAdd(rawUrl, rawTitle = "", handoffId = null) {
  const url = canonicalYouTubeVideoUrl(rawUrl);
  if (!url) {
    showToast("That YouTube link is not a supported video URL.");
    return false;
  }
  const handoff = guidedTourHandoff();
  if (handoffId && (!handoff || handoff.id !== handoffId || handoff.url !== url)) return false;
  const existing = savedVideoCourse(url);
  if (existing) {
    if (handoff) await clearGuidedTourHandoff(handoff.id);
    setGuidedTourSuspended(false);
    await renderGuidedTourStep();
    showToast("This video is already saved in " + existing.title + ". Continue when you're ready.");
    return true;
  }
  const title = safeYouTubeTitle(rawTitle, "");
  if (el.courseTitleInput) {
    el.courseTitleInput.value = title;
    el.courseTitleInput.placeholder = title ? "Physics lecture" : "Enter video title";
  }
  if (el.courseUrlInput) el.courseUrlInput.value = url;
  setGuidedTourSuspended(false);
  await renderGuidedTourStep();
  if (!title) el.courseTitleInput?.focus({ preventScroll: true });
  showToast(title ? "Video ready. Add it to Studizen to continue." : "We couldn't read the title. Enter it in Name; the video link is ready.");
  return true;
}
async function removeCourseVideo(courseId, videoId) {
  await saveState({ ...state, courses: state.courses.map((course) => course.id === courseId ? { ...course, videos: (course.videos || []).filter((video) => video.id !== videoId) } : course) });
  showToast("Video removed.");
}
async function addCourse(title, rawUrl, subject = "Other", libraryId = el.courseLibraryInput?.value || state.courseLibraries[0]?.id || "library-main") {
  const url = validUrl(rawUrl);
  if (!url) { showToast("Paste a valid course link."); return false; }
  const duplicate = canonicalYouTubeVideoUrl(url) ? savedVideoCourse(url) : null;
  if (duplicate) { showToast("This video is already saved in " + duplicate.title + "."); return false; }
  const youtubeVideoUrl = canonicalYouTubeVideoUrl(url);
  const courseTitle = youtubeVideoUrl ? safeYouTubeTitle(title, "") : String(title || "").trim();
  if (youtubeVideoUrl && !courseTitle) {
    showToast("Enter the video title before adding it.");
    const modalIsOpen = el.youtubeAddModal && !el.youtubeAddModal.classList.contains("hidden");
    (modalIsOpen ? el.youtubeNewTitleInput : el.courseTitleInput)?.focus({ preventScroll: true });
    return false;
  }
  const targetLibraryId = state.courseLibraries.some((library) => library.id === libraryId) ? libraryId : (state.courseLibraries[0]?.id || "library-main");
  const course = { id: uid("course"), title: courseTitle || inferTitle(url), subject: normalizeSubject(subject, state.profile?.studyProfile, currentSubjects()), libraryId: targetLibraryId, url: normalizeUrl(url), videos: [], createdAt: Date.now(), lastUsedAt: null };
  await saveState({ ...state, courses: [course, ...state.courses], settings: { ...state.settings, defaultCourseId: state.settings.defaultCourseId || course.id } });
  if (el.courseTitleInput) {
    el.courseTitleInput.value = "";
    el.courseTitleInput.placeholder = "Physics lecture";
  }
  if (el.courseUrlInput) el.courseUrlInput.value = "";
  const handoff = guidedTourHandoff();
  const addedHandoffVideo = Boolean(handoff && courseHasVideo(course, handoff.url));
  // A real manual course creation is also a valid completion of this guided
  // step. The handoff only waits for the selected video while it is pending.
  if (handoff) await clearGuidedTourHandoff(handoff.id);
  if (guidedTourActive && GUIDED_TOUR_STEPS[guidedTourStepIndex]?.action === "courses") {
    setGuidedTourSuspended(false);
    await renderGuidedTourStep();
  }
  showToast(addedHandoffVideo ? "Video added. Continue when you're ready." : "Course added. Continue when you're ready.");
  return true;
}
async function deleteCourse(id) { const course = state.courses.find((c) => c.id === id); if (!course) return; if (state.focusSession?.active && state.focusSession.courseId === id) return showToast("Stop the active focus session before deleting this course."); if (!confirm("Delete course '" + course.title + "'?")) return; const previous = state; const courses = state.courses.filter((c) => c.id !== id); await saveState({ ...state, courses, settings: { ...state.settings, defaultCourseId: state.settings.defaultCourseId === id ? courses[0]?.id || null : state.settings.defaultCourseId } }); showUndo("Course deleted.", previous); }
async function createLibrary(event) {
  event.preventDefault();
  const name = el.libraryNameInput.value.trim().slice(0, 48);
  if (!name) return showToast("Library name is required.");
  if (state.courseLibraries.some((library) => library.name.trim().toLocaleLowerCase() === name.toLocaleLowerCase())) return showToast("A library with that name already exists.");
  const library = { id: uid("library"), name, collapsed: false, createdAt: Date.now() };
  try {
    await saveState({ ...state, courseLibraries: [...state.courseLibraries, library] });
    el.libraryNameInput.value = "";
    showToast("Library created.");
  } catch (error) {
    showToast(error.message || "Library could not be created.");
  }
}
async function renameLibrary(id, rawName) {
  let courseLibraries;
  try {
    courseLibraries = renameCourseLibrary(state.courseLibraries, id, rawName);
  } catch (error) {
    showToast(error.message || "Library could not be renamed.");
    return false;
  }
  const previous = state;
  editingLibraryId = null;
  try {
    await saveState({ ...state, courseLibraries });
    showToast("Library renamed.");
    return true;
  } catch (error) {
    editingLibraryId = id;
    renderLibraryManagement();
    showToast(error.message || "Library could not be renamed.");
    return false;
  }
}
function openLibraryDeleteDialog(id) {
  const library = state.courseLibraries.find((item) => item.id === id);
  if (!library) return;
  if (isProtectedCourseLibrary(library)) return showToast("My Library is a protected default library.");
  deletingLibraryId = id;
  const courseCount = state.courses.filter((course) => course.libraryId === id).length;
  el.libraryDeleteTitle.textContent = "Delete “" + library.name + "”?";
  el.libraryDeleteMessage.textContent = courseCount
    ? "This library contains " + courseCount + (courseCount === 1 ? " saved course." : " saved courses.")
    : "This library is empty.";
  el.libraryDeleteCourseSummary.hidden = !courseCount;
  el.libraryDeleteCourseSummary.textContent = courseCount
    ? courseCount + (courseCount === 1 ? " course will be moved to My Library." : " courses will be moved to My Library.")
    : "";
  el.libraryDeleteSafety.textContent = courseCount
    ? "Your course titles, subjects, links and study history will be kept."
    : "You can cancel now; nothing changes until you confirm.";
  el.libraryDeleteConfirm.textContent = courseCount ? "Move to My Library & Delete" : "Delete Library";
  el.libraryDeleteModal.classList.remove("hidden");
  el.libraryDeleteConfirm.focus({ preventScroll: true });
}
function closeLibraryDeleteDialog() {
  deletingLibraryId = null;
  el.libraryDeleteModal?.classList.add("hidden");
}
async function confirmDeleteLibrary() {
  const id = deletingLibraryId;
  const library = state.courseLibraries.find((item) => item.id === id);
  if (!library || isProtectedCourseLibrary(library)) return closeLibraryDeleteDialog();
  const previous = state;
  let deletion;
  try {
    deletion = deleteCourseLibrary(state.courseLibraries, state.courses, id);
  } catch (error) {
    showToast(error.message || "Library could not be deleted.");
    return;
  }
  const defaultLibrary = deletion.libraries.find((item) => item.id === "library-main") || deletion.libraries.find(isProtectedCourseLibrary);
  if (el.courseLibraryInput?.value === id) el.courseLibraryInput.value = defaultLibrary?.id || "library-main";
  try {
    await saveState({ ...state, courseLibraries: deletion.libraries, courses: deletion.courses });
    closeLibraryDeleteDialog();
    showUndo("Library deleted. Courses moved to " + deletion.destination + ".", previous);
  } catch (error) {
    showToast(error.message || "Library could not be deleted.");
  }
}
async function setLibraryCollapsed(id, collapsed) { if (!state.courseLibraries.some((library) => library.id === id && library.collapsed !== collapsed)) return; await saveState({ ...state, courseLibraries: state.courseLibraries.map((library) => library.id === id ? { ...library, collapsed } : library) }); }
async function moveCourseToLibrary(courseId, libraryId) { await saveState({ ...state, courses: state.courses.map((course) => course.id === courseId ? { ...course, libraryId } : course) }); showToast("Course moved."); }
async function openCourse(url = getActiveCourse(state)?.url) { if (!url) return showToast("No course link available."); if (hasChrome) await sendMessage({ type: "openCourse", url }); else window.open(url, "_blank", "noopener"); }
function openFocusCommitment(courseId = getActiveCourse(state)?.id) {
  if (!courseId) { setActiveTab("courses"); return showToast("Add or select a course first."); }
  const mode = focusModeDraft || state.settings.defaultFocusMode || "normal";
  const rawDuration = Number(el.durationInput.value);
  const durationMinutes = mode === "breaks" ? rawDuration : Math.max(5, Math.min(240, rawDuration || state.settings.focusMinutesDefault));
  const breakDurationMinutes = Number(el.breakDurationInput?.value ?? state.settings.focusBreakMinutesDefault ?? 5);
  const breaksCount = Number(el.focusCyclesInput?.value ?? state.settings.focusBreakCyclesDefault ?? 1);
  if (mode === "breaks") {
    const validation = validateBreakSchedule(durationMinutes, breaksCount, breakDurationMinutes);
    if (!validation.valid) {
      updateBreakScheduleValidation(mode);
      el.focusBreakOptions?.classList.remove("hidden");
      return showToast(validation.message);
    }
  }
  pendingFocusStart = { courseId, mode, durationMinutes, breakDurationMinutes, breaksCount };
  el.commitmentMode.textContent = focusModeLabel(mode);
  el.commitmentStudyTime.textContent = mode === "breaks" ? durationMinutes + " minutes total · " + (breaksCount + 1) + " equal study blocks" : durationMinutes + " minutes";
  el.commitmentBreakSummary.hidden = mode !== "breaks";
  el.commitmentBreakTime.textContent = breaksCount ? breakDurationMinutes + " minute " + (breakDurationMinutes === 1 ? "break" : "breaks") + " · " + breaksCount + " scheduled " + (breaksCount === 1 ? "break" : "breaks") : "No scheduled breaks";
  el.focusCommitmentNote.textContent = mode === "normal"
      ? "You can pause and resume. Focus Protection pauses with the timer; Outside Focus Protection keeps its separate setting."
    : mode === "strict"
      ? "Strict Focus cannot be paused. Focus Protection follows its setting; a 10-second early-end countdown lets you cancel."
      : "Website protection pauses during scheduled breaks and resumes according to its separate settings.";
  el.focusCommitmentModal.classList.remove("hidden");
  el.confirmFocusCommitmentBtn.focus();
}

async function beginFocusSession() {
  const config = pendingFocusStart;
  if (!config || focusActionPending) return;
  if (config.mode === "breaks") {
    const validation = validateBreakSchedule(config.durationMinutes, config.breaksCount, config.breakDurationMinutes);
    if (!validation.valid) return showToast(validation.message);
  }
  focusActionPending = true;
  el.confirmFocusCommitmentBtn.disabled = true;
  if (hasChrome) {
    const result = await sendMessage({ type: "startFocus", payload: { ...config, commitmentConfirmed: true } });
    if (!result?.ok) {
      focusActionPending = false;
      el.confirmFocusCommitmentBtn.disabled = false;
      return showToast(result?.error || "Could not start focus.");
    }
    state = mergeState(result.response);
    applyTheme();
    render();
  } else {
    const course = state.courses.find((c) => c.id === config.courseId);
    if (!course) { focusActionPending = false; el.confirmFocusCommitmentBtn.disabled = false; return showToast("Choose a course before starting focus."); }
    const startedAt = Date.now();
    const blocks = config.mode === "breaks" ? createBreakStudyBlocks(config.durationMinutes, config.breaksCount) : [];
    const initialPhaseMs = config.mode === "breaks" ? blocks[0] : config.durationMinutes * 60000;
    const session = { id: uid("session"), active: true, mode: config.mode, phase: "study", courseId: config.courseId, courseTitle: course.title, courseUrl: course.url, subject: course.subject || "Other", startedAt, phaseStartedAt: startedAt, endsAt: startedAt + initialPhaseMs, durationMinutes: config.durationMinutes, studyDurationMinutes: config.durationMinutes, breakDurationMinutes: config.breakDurationMinutes, cyclesTotal: config.mode === "breaks" ? config.breaksCount + 1 : 1, cyclesCompleted: 0, scheduleVersion: config.mode === "breaks" ? 2 : 1, breaksTotal: config.mode === "breaks" ? config.breaksCount : 0, studyBlocksTotal: config.mode === "breaks" ? config.breaksCount + 1 : 1, studyBlocksCompleted: 0, studyBlockDurationsMs: blocks, studyBlockElapsedMs: 0, completedStudyMs: 0, timingVersion: 1, activeIntervals: [], activeIntervalStartedAt: startedAt, phaseDurationMs: initialPhaseMs, paused: false, pausedAt: null, remainingMs: initialPhaseMs, accumulatedPausedMs: 0, distractionsBlocked: 0 };
    await saveState({ ...state, settings: { ...state.settings, defaultCourseId: config.courseId, focusMinutesDefault: config.durationMinutes, defaultFocusMode: config.mode, ...(config.mode === "breaks" ? { focusBreakMinutesDefault: config.breakDurationMinutes, focusBreakCyclesDefault: config.breaksCount } : {}) }, courses: state.courses.map((item) => item.id === config.courseId ? { ...item, lastUsedAt: Date.now() } : item), focusSession: session, focusCompletion: null });
    openCourse(course.url);
  }
  el.focusCommitmentModal.classList.add("hidden");
  pendingFocusStart = null;
  focusActionPending = false;
  el.confirmFocusCommitmentBtn.disabled = false;
  focusModeDraft = null;
  render();
  showToast("Focus started. Opening your course.");
}
async function startFocus(courseId = getActiveCourse(state)?.id) {
  if (activeSession()) return;
  openFocusCommitment(courseId);
}
async function pauseFocus() {
  const session = activeSession();
  if (!session || session.mode !== "normal" || session.paused || focusActionPending) return;
  focusActionPending = true;
  renderFocus();
  if (hasChrome) {
    const result = await sendMessage({ type: "pauseFocus" });
    if (result?.ok) state = mergeState(result.response);
    else await loadState();
  } else {
    const now = Date.now();
    const remainingMs = sessionRemainingMs(session, now);
    const closed = closeFocusStudyInterval(session, now);
    await saveState({ ...state, focusSession: { ...closed, paused: true, pausedAt: now, remainingMs, endsAt: now + remainingMs } });
  }
  focusActionPending = false;
  applyTheme();
  render();
  showToast("Focus paused. Focus Protection pauses with the timer; Outside Focus Protection keeps its setting.");
}
async function resumeFocus() {
  const session = activeSession();
  if (!session?.paused || session.mode !== "normal" || focusActionPending) return;
  const remainingMs = Math.max(0, Number(session.remainingMs) || sessionRemainingMs(session));
  focusActionPending = true;
  renderFocus();
  if (hasChrome) {
    const result = await sendMessage({ type: "resumeFocus" });
    if (result?.ok) state = mergeState(result.response);
    else await loadState();
  } else {
    const now = Date.now();
    await saveState({ ...state, focusSession: { ...session, timingVersion: 1, activeIntervalStartedAt: now, paused: false, pausedAt: null, remainingMs, accumulatedPausedMs: (session.accumulatedPausedMs || 0) + Math.max(0, now - (session.pausedAt || now)), endsAt: now + remainingMs } });
  }
  focusActionPending = false;
  applyTheme();
  render();
  showToast("Focus resumed.");
}
async function stopFocus(reason = "manual") {
  const currentSession = activeSession();
  const mode = currentSession?.mode || "normal";
  if (!hasChrome && ["strict", "breaks"].includes(mode) && reason === "manual") {
    if (currentSession.endConfirmationUntil > Date.now()) return;
    const now = Date.now();
    const remainingMs = sessionRemainingMs(currentSession, now);
    if (remainingMs <= 0) return;
    let updated = currentSession;
    if (mode === "breaks" && currentSession.phase === "study") {
      if (Number(currentSession.scheduleVersion) === 2) {
        const blockIndex = Math.min(Number(currentSession.studyBlocksCompleted) || 0, Math.max(0, (Number(currentSession.studyBlocksTotal) || 1) - 1));
        const blockDuration = Number(currentSession.studyBlockDurationsMs?.[blockIndex]) || Number(currentSession.phaseDurationMs) || 0;
        const accrued = Math.max(0, Math.min(blockDuration, now - Number(currentSession.activeIntervalStartedAt || now)));
        updated = { ...closeFocusStudyInterval(currentSession, now), studyBlockElapsedMs: Math.min(blockDuration, (Number(currentSession.studyBlockElapsedMs) || 0) + accrued) };
      } else {
        const phaseDuration = Number(currentSession.phaseDurationMs) || Number(currentSession.studyDurationMinutes) * 60000;
        const elapsedInPhase = Math.max(0, Math.min(phaseDuration, now - Number(currentSession.phaseStartedAt || now)));
        updated = { ...closeFocusStudyInterval(currentSession, now), completedStudyMs: (Number(currentSession.completedStudyMs) || 0) + elapsedInPhase, phaseDurationMs: remainingMs, phaseStartedAt: now };
      }
    } else if (currentSession.phase === "study") updated = closeFocusStudyInterval(currentSession, now);
    await saveState({ ...state, focusSession: { ...updated, endsAt: now + remainingMs, remainingMs, endConfirmationUntil: now + 10000, endConfirmationRemainingMs: remainingMs, endConfirmationStudyElapsedMs: focusElapsedMs(currentSession, now), activeIntervalStartedAt: null } });
    render();
    showToast("Session ending in 10 seconds. Keep focusing to cancel, or end now.");
    return;
  }
  if (hasChrome) {
    const result = await sendMessage({ type: reason === "early-exit-confirmed" ? "confirmFocusEnd" : "stopFocus" });
    if (result?.ok) state = mergeState(result.response);
    applyTheme();
    render();
  } else {
    const session = state.focusSession;
    const elapsed = session ? focusElapsedMinutes(session) : 0;
    const completed = session ? reason === "complete" || (!session.endConfirmationUntil && !session.paused && sessionRemainingMs(session) <= 0) : false;
    await saveState({ ...state, focusSession: null, focusCompletion: completed ? { id: session.id, courseTitle: session.courseTitle, subject: session.subject || "Other", durationMinutes: elapsed, xpEarned: sessionXp(elapsed, completed), todayTotalMinutes: state.stats.focusMinutes + elapsed, streak: state.analytics.streak?.current || 1, completedAt: Date.now() } : state.focusCompletion, analytics: session ? recordFocusAnalytics(state.analytics, session, elapsed, completed) : state.analytics, stats: { ...state.stats, focusMinutes: state.stats.focusMinutes + elapsed, sessionsCompleted: state.stats.sessionsCompleted + (completed ? 1 : 0) } });
  }
  if (reason !== "manual" || !["strict", "breaks"].includes(mode)) showToast("Focus session ended.");
}

async function cancelFocusEnd() {
  if (hasChrome) {
    const result = await sendMessage({ type: "cancelFocusEnd" });
    if (result?.ok) state = mergeState(result.response);
    else return showToast(result?.error || "Could not cancel the session end.");
  } else if (state.focusSession) {
    const session = state.focusSession;
    const now = Date.now();
    const remainingMs = Math.max(0, Number(session.endConfirmationRemainingMs) || 0);
    await saveState({ ...state, focusSession: { ...session, endsAt: now + remainingMs, remainingMs, activeIntervalStartedAt: session.phase === "study" ? now : null, endConfirmationUntil: null, endConfirmationRemainingMs: null, endConfirmationStudyElapsedMs: null } });
  }
  applyTheme();
  render();
  showToast("Session continues. End countdown cancelled.");
}
async function updateTask(index, patch) {
  const now = Date.now();
  const tasks = state.daily.tasks.map((task, i) => {
    if (i !== index) return task;
    const next = { ...task, ...patch };
    if (Object.hasOwn(patch, "done")) {
      next.completedAt = patch.done ? now : null;
      next.completedDate = patch.done ? todayKey(new Date(now)) : null;
    }
    return next;
  });
  await saveState({ ...state, daily: { ...state.daily, tasks } });
}
async function deleteTask(index) { const task = state.daily.tasks[index]; if (!task || !confirm("Delete personal goal '" + task.title + "'?")) return; const previous = state; const tasks = state.daily.tasks.filter((_, i) => i !== index); await saveState({ ...state, daily: { ...state.daily, tasks } }); showUndo("Personal goal deleted.", previous); }
async function editTask(index) {
  const task = state.daily.tasks[index];
  if (!task) return;
  const title = prompt("Personal goal title", task.title || "")?.trim();
  if (!title) return;
  const area = prompt("Area or subject", task.area || "Personal")?.trim() || "Personal";
  const minutes = Math.max(0, Number(prompt("Estimated minutes", task.minutes || 0)) || 0);
  const note = prompt("Short note", task.note || "")?.trim() || "";
  await updateTask(index, { title: title.slice(0, 90), area: area.slice(0, 40), minutes, note: note.slice(0, 140) });
  showToast("Personal goal updated.");
}
async function addMission(event) { event.preventDefault(); const title = el.missionTitleInput.value.trim(); if (!title) return showToast("Personal goal title is required."); const task = { id: uid("task"), title, area: el.missionAreaInput.value.trim() || "Personal", minutes: Number(el.missionMinutesInput.value) || 0, note: el.missionNoteInput.value.trim(), priority: "personal", done: false }; await saveState({ ...state, daily: { ...state.daily, tasks: [...state.daily.tasks, task] } }); el.missionForm.reset(); showToast("Personal goal added."); }
async function resetMissions() { if (!confirm("Clear all personal goals?")) return; const previous = state; await saveState({ ...state, daily: { ...state.daily, tasks: [] } }); showUndo("Personal goals cleared.", previous); }
function openCameraConsent() {
  if (state.settings.cameraAttentionConsentAccepted || cameraConsentSaving) return false;
  el.cameraConsentModal?.classList.remove("hidden");
  el.cameraConsentAcceptBtn?.focus({ preventScroll: true });
  return true;
}
function closeCameraConsent() {
  el.cameraConsentModal?.classList.add("hidden");
}
async function handleCameraPermissionAction(button = el.cameraPermissionBtn, openSettingsWhenGranted = false) {
  if (!state.settings.cameraAttentionConsentAccepted) return openCameraConsent();
  if (cameraPermissionState === "checking") return false;
  if (openSettingsWhenGranted && cameraPermissionState === "granted") {
    await openFocusEnhancementSettings("camera");
    return true;
  }
  return requestCameraPermission(button);
}
async function acceptCameraConsent() {
  if (cameraConsentSaving || state.settings.cameraAttentionConsentAccepted) return false;
  cameraConsentSaving = true;
  if (el.cameraConsentAcceptBtn) el.cameraConsentAcceptBtn.disabled = true;
  if (el.cameraConsentDeclineBtn) el.cameraConsentDeclineBtn.disabled = true;
  const previousConsent = Boolean(state.settings.cameraAttentionConsentAccepted);
  const previousEnabled = Boolean(state.settings.cameraAttentionEnabled);
  try {
    await updateSettings({ cameraAttentionConsentAccepted: true, cameraAttentionEnabled: false });
    if (!state.settings.cameraAttentionConsentAccepted) throw new Error("Camera consent could not be saved.");
  } catch (error) {
    state.settings = {
      ...state.settings,
      cameraAttentionConsentAccepted: previousConsent,
      cameraAttentionEnabled: Boolean(previousEnabled && previousConsent && cameraPermissionState === "granted")
    };
    render();
    showToast(error?.message || "Camera consent could not be saved. Camera Focus Check remains off.");
    return false;
  } finally {
    cameraConsentSaving = false;
    if (el.cameraConsentAcceptBtn) el.cameraConsentAcceptBtn.disabled = false;
    if (el.cameraConsentDeclineBtn) el.cameraConsentDeclineBtn.disabled = false;
  }
  closeCameraConsent();
  const granted = await requestCameraPermission(el.cameraPermissionBtn, true);
  render();
  return Boolean(granted && state.settings.cameraAttentionEnabled && state.settings.cameraAttentionConsentAccepted && cameraPermissionState === "granted");
}
function declineCameraConsent() {
  if (cameraConsentSaving) return false;
  closeCameraConsent();
  if (!state.settings.cameraAttentionConsentAccepted) state.settings.cameraAttentionEnabled = false;
  render();
  return true;
}
async function requestCameraPermission(button = el.cameraPermissionBtn, enableAfterGrant = false) {
  if (!state.settings.cameraAttentionConsentAccepted) {
    openCameraConsent();
    return false;
  }
  if (!navigator.mediaDevices?.getUserMedia) {
    showToast("This Chrome installation cannot request camera access.");
    return false;
  }
  if (button) button.disabled = true;
  let stream = null;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: false, video: { facingMode: "user" } });
    stream.getTracks().forEach((track) => track.stop());
    stream = null;
    cameraPermissionState = "granted";
    render();
    if (navigator.permissions?.query) await refreshCameraPermissionStatus();
    if (cameraPermissionState !== "granted") throw new Error("Camera permission is not available.");
    if (enableAfterGrant) {
      if (!await saveCameraAttentionSettings(true)) return false;
    } else if (hasChrome) {
      const result = await sendMessage({ type: "syncAttentionMonitor" });
      if (!result?.ok) throw new Error(result?.error || "Camera access was granted, but monitoring could not start.");
      state = ensureToday(mergeState(result.response));
      applyTheme();
      render();
    }
    showToast(enableAfterGrant ? "Camera access granted. Camera Focus Check is ready." : "Camera access granted. Camera Focus Check beta is ready.");
    return true;
  } catch (error) {
    stream?.getTracks().forEach((track) => track.stop());
    if (navigator.permissions?.query) await refreshCameraPermissionStatus();
    else await applyCameraPermissionState(error?.name === "NotAllowedError" || error?.name === "SecurityError" ? "denied" : "unsupported");
    const denied = error?.name === "NotAllowedError" || error?.name === "SecurityError";
    showToast(denied ? "Camera access was blocked. Allow it in Chrome, then try again." : error?.message || "No camera could be started. Check that it is connected and not in use.");
    return false;
  } finally {
    if (button) button.disabled = false;
  }
}
async function saveCameraAttentionSettings(enabledOverride = null) {
  const settingsPatch = {
    cameraAttentionEnabled: typeof enabledOverride === "boolean" ? enabledOverride : el.cameraAttentionEnabledInput?.checked ?? false,
    cameraAttentionSensitivity: el.cameraAttentionSensitivityInput?.value || "balanced",
    cameraAttentionGraceSeconds: Math.max(5, Math.min(30, Number(el.cameraAttentionGraceInput?.value) || 10)),
    cameraAttentionVoice: el.cameraAttentionVoiceInput?.checked ?? true
  };

  if (settingsPatch.cameraAttentionEnabled && !state.settings.cameraAttentionConsentAccepted) {
    render();
    showToast("Review Camera Use before enabling Camera Focus Check.");
    return false;
  }
  if (settingsPatch.cameraAttentionEnabled && cameraPermissionState !== "granted") {
    render();
    showToast("Choose Allow Camera Access before enabling Camera Focus Check.");
    return false;
  }

  const previousConsent = Boolean(state.settings.cameraAttentionConsentAccepted);
  const previousEnabled = Boolean(state.settings.cameraAttentionEnabled);
  try {
    await updateSettings(settingsPatch);
    if (settingsPatch.cameraAttentionEnabled && (!state.settings.cameraAttentionConsentAccepted || !state.settings.cameraAttentionEnabled || cameraPermissionState !== "granted")) {
      state.settings.cameraAttentionEnabled = false;
      render();
      showToast("Camera Focus Check needs saved consent and camera permission before it can be enabled.");
      return false;
    }
    if (hasChrome) {
      const result = await sendMessage({ type: "syncAttentionMonitor" });
      if (!result?.ok) throw new Error(result?.error || "Camera Focus Check could not be updated.");
      state = ensureToday(mergeState(result.response));
      applyTheme();
      render();
    }
    showToast(settingsPatch.cameraAttentionEnabled ? "Camera Focus Check beta is ready for your next focus session." : "Camera Focus Check is off. Enable it in Settings to use attention checks during Focus.");
    return true;
  } catch (error) {
    state.settings = {
      ...state.settings,
      cameraAttentionConsentAccepted: previousConsent,
      cameraAttentionEnabled: Boolean(previousEnabled && previousConsent && cameraPermissionState === "granted")
    };
    render();
    showToast(error?.message || "Camera Focus Check could not be updated.");
    return false;
  }
}
function setSettingsSaveStatus(message, kind = "saved") {
  if (!el.settingsSaveStatus) return;
  clearTimeout(settingsSaveFeedbackTimer);
  el.settingsSaveStatus.textContent = message;
  el.settingsSaveStatus.dataset.state = kind;
  el.settingsSaveStatus.hidden = !message;
  if (message && kind !== "saving") settingsSaveFeedbackTimer = setTimeout(() => { el.settingsSaveStatus.hidden = true; }, kind === "error" ? 3600 : 1700);
}
function updateSettingsBreakValidation() {
  const mode = el.settingsFocusModeSelect?.value || "normal";
  const isBreakMode = mode === "breaks";
  if (el.settingsFocusCyclesInput) el.settingsFocusCyclesInput.min = isBreakMode ? "1" : "0";
  if (el.settingsBreakMinutesInput) el.settingsBreakMinutesInput.min = isBreakMode ? "1" : "0";
  const result = isBreakMode
    ? validateBreakSchedule(
      Number(el.settingsFocusMinutesInput?.value),
      Number(el.settingsFocusCyclesInput?.value),
      Number(el.settingsBreakMinutesInput?.value)
    )
    : { valid: true, message: "" };
  if (el.settingsFocusCyclesInput) el.settingsFocusCyclesInput.max = String(isBreakMode ? result.maxBreaks : 12);
  if (el.settingsBreakValidation) {
    el.settingsBreakValidation.textContent = isBreakMode ? result.message : "";
    el.settingsBreakValidation.hidden = !isBreakMode || result.valid;
  }
  return result;
}
function readSettingsPreferenceSnapshot() {
  const themeMode = ["system", "light", "dark", "amoled", "midnight", "beige"].includes(el.themeModeSelect?.value) ? el.themeModeSelect.value : "dark";
  const focusMinutesValue = Number(el.settingsFocusMinutesInput?.value);
  const breakMinutesValue = Number(el.settingsBreakMinutesInput?.value);
  const cyclesValue = Number(el.settingsFocusCyclesInput?.value);
  const volumeValue = Number(el.soundVolumeInput?.value);
  const studyProfile = el.studyProfileSelect?.value || state.profile?.studyProfile || "jee";
  return {
    settings: {
      themeMode,
      focusMinutesDefault: Math.max(5, Math.min(240, Number.isFinite(focusMinutesValue) && focusMinutesValue ? focusMinutesValue : 50)),
      defaultFocusMode: ["normal", "strict", "breaks"].includes(el.settingsFocusModeSelect?.value) ? el.settingsFocusModeSelect.value : "normal",
      focusBreakMinutesDefault: Math.max(0, Math.min(60, Number.isFinite(breakMinutesValue) ? breakMinutesValue : 5)),
      focusBreakCyclesDefault: Math.max(0, Math.min(12, Math.floor(Number.isFinite(cyclesValue) ? cyclesValue : 1))),
      soundEnabled: el.soundEnabledInput?.checked ?? true,
      soundVolume: Math.max(0, Math.min(100, Number.isFinite(volumeValue) ? volumeValue : 35))
    },
    profile: { ...(state.profile || {}), studyProfile }
  };
}
async function saveSettings(event = null) {
  event?.preventDefault();
  const preferenceIds = new Set([
    "settingsFocusMinutesInput", "settingsFocusModeSelect", "settingsBreakMinutesInput",
    "settingsFocusCyclesInput", "studyProfileSelect", "themeModeSelect",
    "soundEnabledInput", "soundVolumeInput"
  ]);
  if (event?.type === "change" && !preferenceIds.has(event.target?.id)) return;

  if (event?.type === "change" && event.target?.id === "settingsFocusMinutesInput") {
    const durationMinutes = Math.max(5, Math.min(240, Number(el.settingsFocusMinutesInput.value) || 50));
    const mode = el.settingsFocusModeSelect?.value || "normal";
    const suggestion = suggestedBreakSettings(durationMinutes, mode);
    if (el.settingsBreakMinutesInput) el.settingsBreakMinutesInput.value = suggestion.breakDurationMinutes;
    if (el.settingsFocusCyclesInput) el.settingsFocusCyclesInput.value = suggestion.breaksCount;
    lastFocusBreakSuggestionDuration = durationMinutes;
  }
  const snapshot = readSettingsPreferenceSnapshot();
  const breakSettingsChanged = ["settingsFocusMinutesInput", "settingsFocusModeSelect", "settingsBreakMinutesInput", "settingsFocusCyclesInput"].includes(event?.target?.id);
  if (snapshot.settings.defaultFocusMode === "breaks" && (event?.type === "submit" || (event?.type === "change" && breakSettingsChanged))) {
    const validation = updateSettingsBreakValidation();
    if (!validation.valid) {
      setSettingsSaveStatus(validation.message, "error");
      return;
    }
  }
  if (event?.type === "change" && event.target?.id === "studyProfileSelect" && snapshot.profile.studyProfile !== state.profile?.studyProfile) {
    if (state.profile?.startedAt || state.goals?.analyticsTargets) {
      showProfileTargetsConfirmation({ source: "settings", profileId: snapshot.profile.studyProfile });
      return;
    }
    await commitSettingsProfileChange(snapshot.profile.studyProfile, true);
    return;
  }
  const revision = ++settingsSaveRevision;
  if (event?.target === el.themeModeSelect) applyTheme(snapshot.settings.themeMode);
  setSettingsSaveStatus("Saving…", "saving");

  const saveTask = settingsSaveQueue.catch(() => {}).then(async () => {
    const previousState = state;
    try {
      await saveState({
        ...state,
        settings: { ...state.settings, ...snapshot.settings },
        profile: snapshot.profile
      });
      if (revision === settingsSaveRevision) setSettingsSaveStatus("Saved", "saved");
    } catch (error) {
      state = previousState;
      if (revision === settingsSaveRevision) {
        applyTheme();
        renderSettings();
        setSettingsSaveStatus("Couldn’t save", "error");
      }
      console.error("Studizen settings autosave failed:", error);
    }
  });
  settingsSaveQueue = saveTask;
  await saveTask;
}
async function resetAnalyticsData() {
  if (!confirm("Reset analytics, streaks, XP history, and subject study hours?")) return;
  const previous = state;
  await saveState({ ...state, analytics: defaultState().analytics, stats: { ...state.stats, focusMinutes: 0, distractions: 0, sessionsCompleted: 0 } });
  showUndo("Analytics reset.", previous);
}
async function clearAllData() {
  if (!confirm("Clear all local Studizen data? This removes courses, saved links, goals, study history, settings, and music-library details.")) return;
  const previous = state;
  let localSnapshot = [];
  try { localSnapshot = Array.from({ length: localStorage.length }, (_, index) => { const key = localStorage.key(index); return [key, localStorage.getItem(key)]; }).filter(([key]) => key); } catch {}
  await saveState(defaultState());
  try { localStorage.clear(); } catch {}
  showUndo("All data cleared.", previous, localSnapshot);
}
function exportJson() { const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" }); const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "studizen-backup.json"; a.click(); URL.revokeObjectURL(a.href); el.backupStatus.textContent = "JSON backup exported."; }
async function restoreBackupFile(event) { const file = event.target.files?.[0]; if (!file) return; if (!confirm("Restore this backup and replace current local data?")) { event.target.value = ""; return; } const previous = state; try { const text = await file.text(); await saveState(mergeState(JSON.parse(text))); el.backupStatus.textContent = "Backup restored."; showUndo("Backup restored.", previous); showToast("Backup restored."); } catch { el.backupStatus.textContent = "Backup restore failed."; } finally { event.target.value = ""; } }

function bindEvents() {
  $$(".help-button").forEach((button) => {
    const info = HELP_INFO[button.dataset.helpKey] || HELP_INFO.default;
    button.setAttribute("aria-label", "Help: " + info.title);
    button.setAttribute("title", "Learn more");
  });
  $$(".tab-button").forEach((button) => button.addEventListener("click", () => {
    const tab = button.dataset.tab;
    setActiveTab(tab);
    syncGuidedTourToManualTab(tab);
  }));
  el.focusEnhancementsToggle?.addEventListener("click", () => setFocusEnhancementsExpanded(!focusEnhancementsExpanded));
  $$('[data-focus-enhancement-settings]').forEach((button) => button.addEventListener("click", () => {
    if (button.dataset.focusEnhancementSettings === "incognito" && incognitoAccessAllowed !== true) void openIncognitoSettings();
    else openFocusEnhancementSettings(button.dataset.focusEnhancementSettings);
  }));
  el.cameraStatusPermissionBtn?.addEventListener("click", () => {
    void handleCameraPermissionAction(el.cameraStatusPermissionBtn, true);
  });
  el.cameraConsentAcceptBtn?.addEventListener("click", () => void acceptCameraConsent());
  el.cameraConsentDeclineBtn?.addEventListener("click", declineCameraConsent);
  el.focusIncognitoProtectionInput?.addEventListener("change", () => void setIncognitoProtection(el.focusIncognitoProtectionInput.checked));
  el.focusCameraAttentionInput?.addEventListener("change", () => void saveCameraAttentionSettings(el.focusCameraAttentionInput.checked));
  el.focusYouTubeStudyModeInput?.addEventListener("change", () => void setYouTubeStudyMode(el.focusYouTubeStudyModeInput.checked));
  if (el.sidebarMoreNav) {
    try { el.sidebarMoreNav.open = sessionStorage.getItem("courseFocusProSidebarMoreOpen") === "true"; } catch {}
    el.sidebarMoreNav.addEventListener("toggle", () => {
      try { sessionStorage.setItem("courseFocusProSidebarMoreOpen", String(el.sidebarMoreNav.open)); } catch {}
    });
  }
  setSiteControlExpanded(siteControlExpanded);
  Object.entries(settingsDisclosureExpanded).forEach(([key, expanded]) => setSettingsDisclosureExpanded(key, expanded));
  el.analyticsCurrentBtn?.addEventListener("click", () => { analyticsHistoryPeriod = null; renderAnalytics(); });
  el.analyticsPreviousWeekBtn?.addEventListener("click", () => { analyticsHistoryPeriod = "previous-week"; renderAnalytics(); });
  el.analyticsPreviousMonthBtn?.addEventListener("click", () => { analyticsHistoryPeriod = "previous-month"; renderAnalytics(); });
  el.analyticsTargetsToggle?.addEventListener("click", () => setAnalyticsTargetsEditor(el.analyticsTargetsEditor?.classList.contains("hidden")));
  [el.analyticsTargetsClose, el.analyticsTargetsCancel].forEach((button) => button?.addEventListener("click", () => setAnalyticsTargetsEditor(false)));
  el.analyticsTargetsForm?.addEventListener("submit", saveAnalyticsTargets);
  el.analyticsTargetsRestore?.addEventListener("click", restoreSuggestedStudyTargets);
  el.applyProfileTargetsBtn?.addEventListener("click", () => { void resolveProfileTargetsConfirmation(true); });
  el.keepProfileTargetsBtn?.addEventListener("click", () => { void resolveProfileTargetsConfirmation(false); });
  el.cancelProfileTargetsChangeBtn?.addEventListener("click", closeProfileTargetsConfirmation);
  el.profileTargetsConfirmModal?.addEventListener("click", (event) => { if (event.target === el.profileTargetsConfirmModal) closeProfileTargetsConfirmation(); });
  el.analyticsAddSubjectBtn?.addEventListener("click", () => { el.analyticsAddSubjectRow?.classList.toggle("hidden"); if (!el.analyticsAddSubjectRow?.classList.contains("hidden")) el.analyticsNewSubjectInput?.focus(); });
  el.analyticsConfirmAddSubject?.addEventListener("click", addAnalyticsTargetSubject);
  el.analyticsNewSubjectInput?.addEventListener("keydown", (event) => { if (event.key === "Enter") { event.preventDefault(); addAnalyticsTargetSubject(); } });
  el.analyticsTargetSubjectList?.addEventListener("click", (event) => { const button = event.target.closest(".analytics-target-subject-remove"); if (button) button.closest(".analytics-target-subject-row")?.remove(); });
  el.analyticsXpBtn?.addEventListener("click", () => { renderGamification(); setAnalyticsXpOpen(el.analyticsXpPopover?.classList.contains("hidden")); });
  el.analyticsXpCloseBtn?.addEventListener("click", () => setAnalyticsXpOpen(false, true));
  el.activeFocusViewBtn?.addEventListener("click", () => setActiveTab("focus"));
  el.changeCourseBtn?.addEventListener("click", openCourseSwitchModal);
  el.focusOpenCourseBtn?.addEventListener("click", () => openCourse());
  el.courseModalClose?.addEventListener("click", () => el.courseModal.classList.add("hidden"));
  el.courseModal?.addEventListener("click", (event) => { if (event.target === el.courseModal) el.courseModal.classList.add("hidden"); });
  [el.libraryDeleteClose, el.libraryDeleteCancel].forEach((button) => button?.addEventListener("click", closeLibraryDeleteDialog));
  el.libraryDeleteConfirm?.addEventListener("click", () => { void confirmDeleteLibrary(); });
  el.libraryDeleteModal?.addEventListener("click", (event) => { if (event.target === el.libraryDeleteModal) closeLibraryDeleteDialog(); });
  el.youtubeAddCloseBtn?.addEventListener("click", closeYouTubeAddModal);
  el.youtubeAddModal?.addEventListener("click", (event) => { if (event.target === el.youtubeAddModal) closeYouTubeAddModal(); });
  el.youtubeTitleLookupBtn?.addEventListener("click", () => { void lookupPendingYouTubeTitle(); });
  el.youtubeTitleManualBtn?.addEventListener("click", () => {
    if (!pendingYouTubeVideo) return;
    pendingYouTubeVideo.oembedChoice = "declined";
    pendingYouTubeVideo.lookupStatus = "No request was sent. Enter the title below; creating the course stays in Studizen.";
    el.youtubeTitleLookupStatus.textContent = pendingYouTubeVideo.lookupStatus;
    el.youtubeNewTitleInput?.focus({ preventScroll: true });
  });
  el.youtubeNewTitleInput?.addEventListener("input", () => {
    if (!pendingYouTubeVideo) return;
    pendingYouTubeVideo.titleDraft = el.youtubeNewTitleInput.value;
    pendingYouTubeVideo.titleEdited = true;
    el.youtubeNewTitleInput.required = !el.youtubeNewTitleInput.value.trim();
  });
  el.youtubeNewForm?.addEventListener("submit", async (event) => { event.preventDefault(); if (!pendingYouTubeVideo) return; const added = await addCourse(el.youtubeNewTitleInput.value, pendingYouTubeVideo.url, el.youtubeNewSubjectSelect.value, el.youtubeNewLibrarySelect.value); if (added) closeYouTubeAddModal(); });
  if (hasChrome) chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "guidedTourYouTubeHandoff") return;
    resumeGuidedTourYouTubeHandoff(message.handoffId, message.dashboardTabId, message.sessionId, message.videoUrl, message.videoTitle)
      .then((handled) => sendResponse({ handled }))
      .catch(() => sendResponse({ handled: false }));
    return true;
  });
  el.onboardingGetStartedBtn?.addEventListener("click", () => { void saveOnboardingWelcome(); });
  window.addEventListener("keydown", handleWelcomeOnboardingKeydown);
  el.onboardingNameInput?.addEventListener("input", () => { onboardingNameDraft = el.onboardingNameInput.value; el.onboardingNameInput.classList.remove("input-error"); });
  el.onboardingThemeOptions?.addEventListener("click", (event) => { const option = event.target.closest?.("[data-onboarding-theme]"); if (option) void selectOnboardingTheme(option.dataset.onboardingTheme); });
  el.onboardingFocusMinutesInput?.addEventListener("input", () => { onboardingDurationDraft = el.onboardingFocusMinutesInput.value; });
  el.onboardingProfileCards?.addEventListener("click", (event) => { const card = event.target.closest?.("[data-onboarding-profile]"); if (card) selectOnboardingProfile(card.dataset.onboardingProfile); });
  el.onboardingProfileNextBtn?.addEventListener("click", saveOnboardingProfile);
  el.onboardingTargetEditor?.addEventListener("input", () => { onboardingTargetsTouched = true; captureOnboardingTargetDraft(); });
  el.onboardingAddSubjectBtn?.addEventListener("click", () => { el.onboardingAddSubjectRow?.classList.toggle("hidden"); if (!el.onboardingAddSubjectRow?.classList.contains("hidden")) el.onboardingNewSubjectInput?.focus(); });
  el.onboardingConfirmAddSubject?.addEventListener("click", addOnboardingTargetSubject);
  el.onboardingTargetSubjectList?.addEventListener("click", (event) => { const button = event.target.closest(".analytics-target-subject-remove"); if (!button) return; button.closest(".analytics-target-subject-row")?.remove(); onboardingTargetsTouched = true; captureOnboardingTargetDraft(); });
  el.onboardingProtectionNextBtn?.addEventListener("click", saveOnboardingPreferences);
  $$(".onboarding-back").forEach((button) => button.addEventListener("click", () => showOnboardingStep(button.dataset.onboardingBack)));
  el.showOnboardingBtn?.addEventListener("click", showWelcomeAgain);
  el.startGuidedTourBtn?.addEventListener("click", () => { void startGuidedTour({ restart: true }); });
  el.finishTutorialBtn?.addEventListener("click", () => completeOnboarding("focus"));
  el.guidedTourNextBtn?.addEventListener("click", () => { void moveGuidedTour(1); });
  el.guidedTourBackBtn?.addEventListener("click", () => { void moveGuidedTour(-1); });
  el.guidedTourYouTubeBtn?.addEventListener("click", () => { void openGuidedTourYouTube(); });
  el.guidedTourPopupBtn?.addEventListener("click", () => { void openGuidedTourPopup(); });
  el.guidedTourSkipBtn?.addEventListener("click", () => { void finishGuidedTour("skipped"); });
  el.guidedTourFeatureIntroSkip?.addEventListener("click", async () => { await dismissFocusEnhancementsIntro(); el.guidedTourFeatureIntro?.classList.add("hidden"); });
  el.completionStartBtn?.addEventListener("click", async () => { await clearCompletion(); await startFocus(); });
  el.completionBreakBtn?.addEventListener("click", clearCompletion);
  el.completionCloseBtn?.addEventListener("click", clearCompletion);
  el.completionModal?.addEventListener("click", (event) => { if (event.target === el.completionModal) clearCompletion(); });
  el.welcomeResumeBtn?.addEventListener("click", async () => { if (activeSession()?.paused) await resumeFocus(); await clearWelcomeBack(); });
  el.welcomeEndBtn?.addEventListener("click", async () => { await clearWelcomeBack(); await stopFocus(); });
  el.welcomeDismissBtn?.addEventListener("click", clearWelcomeBack);
  el.welcomeBackModal?.addEventListener("click", (event) => { if (event.target === el.welcomeBackModal) clearWelcomeBack(); });
  el.musicPlayBtn.addEventListener("click", () => {
    if (music.playing) { pauseMusic(); return; }
    if (music.source === "imported" && music.currentImportedId) playImported(music.currentImportedId);
    else playMusic();
  });
  el.musicPrevBtn.addEventListener("click", previousMusic);
  el.musicBackBtn.addEventListener("click", () => seekImportedMusic(-10));
  el.musicNextBtn.addEventListener("click", nextMusic);
  el.musicForwardBtn.addEventListener("click", () => seekImportedMusic(10));
  el.musicShuffleBtn.addEventListener("click", () => { music.shuffle = !music.shuffle; if (music.playing && music.shuffle) nextMusic(); else renderMusic(); showToast("Shuffle " + (music.shuffle ? "on" : "off") + "."); });
  el.musicImportInput.addEventListener("change", (event) => { importMusicFiles(event.target.files); event.target.value = ""; });
  el.musicVolumeInput.addEventListener("input", (event) => setMusicVolume(event.target.value));
  el.musicLoopInput.addEventListener("change", (event) => { music.loop = event.target.checked; if (music.audio) music.audio.loop = music.loop; if (music.playing && music.source === "built-in") { clearTimeout(music.endTimer); music.endTimer = null; if (!music.loop) music.endTimer = setTimeout(() => nextMusic(), 10 * 60 * 1000); } });
  el.musicSleepInput?.addEventListener("change", (event) => setMusicSleepTimer(event.target.value));
  el.musicCrossfadeInput?.addEventListener("change", (event) => { music.crossfade = event.target.checked; saveMusicLibrary(); });
  el.playlistCreateBtn?.addEventListener("click", createPlaylist);
  el.playlistSelect?.addEventListener("change", (event) => { music.activePlaylistId = event.target.value || null; saveMusicLibrary(); renderMusic(); });
  el.playlistAddCurrentBtn?.addEventListener("click", addCurrentToPlaylist);
  el.playlistPlayBtn?.addEventListener("click", playActivePlaylist);
  el.playlistDeleteBtn?.addEventListener("click", deleteActivePlaylist);
  el.musicFavoriteBtn?.addEventListener("click", toggleMusicFavorite);
  el.musicQueueBtn?.addEventListener("click", enqueueCurrentMusic);
  document.addEventListener("click", (event) => { const help = event.target.closest?.(".help-button"); if (help) { closeStudyLinkMenu(); event.preventDefault(); event.stopPropagation(); showHelp(help); return; } if (!event.target.closest?.("#helpPopover")) el.helpPopover.classList.add("hidden"); if (!event.target.closest?.("#analyticsXpControl")) setAnalyticsXpOpen(false); if (!event.target.closest?.(".study-link-action-menu, .study-link-menu-items")) closeStudyLinkMenu(); });
  window.addEventListener("keydown", (event) => { if (event.key === "Escape") { closeStudyLinkMenu(); el.helpPopover.classList.add("hidden"); toggleBreakHelp(false); setAnalyticsXpOpen(false, true); el.courseModal?.classList.add("hidden"); closeYouTubeAddModal(); if (!el.completionModal?.classList.contains("hidden")) clearCompletion(); if (!el.welcomeBackModal?.classList.contains("hidden")) clearWelcomeBack(); if (!el.focusCommitmentModal?.classList.contains("hidden")) { pendingFocusStart = null; el.focusCommitmentModal.classList.add("hidden"); } } });
  el.startForm.addEventListener("submit", (e) => { e.preventDefault(); startFocus(); });
  el.focusDurationPresets?.addEventListener("click", (event) => {
    const option = event.target.closest("[data-focus-duration]");
    if (!option || activeSession()) return;
    if (option.dataset.focusDuration === "custom") {
      focusDurationCustom = true;
      el.focusCustomDurationField?.classList.remove("hidden");
      el.durationInput.focus();
      el.durationInput.select();
      renderFocus();
      return;
    }
    focusDurationCustom = false;
    el.durationInput.value = option.dataset.focusDuration;
    renderFocusDurationPicker();
    el.durationInput.dispatchEvent(new Event("change", { bubbles: true }));
  });
  el.durationInput.addEventListener("input", () => {
    focusDurationCustom = true;
    renderFocusDurationPicker();
    updateBreakScheduleValidation();
  });
  el.durationInput.addEventListener("change", () => { void updateBreakSuggestionsForDuration(); });
  [el.breakDurationInput, el.focusCyclesInput].filter(Boolean).forEach((input) => {
    input.addEventListener("input", () => {
      if ((focusModeDraft || state.settings.defaultFocusMode) === "breaks" && input.value !== "" && Number(input.value) < 1) input.value = "1";
      updateBreakScheduleValidation();
    });
    input.addEventListener("change", () => {
      if ((focusModeDraft || state.settings.defaultFocusMode) === "breaks" && input.value !== "" && Number(input.value) < 1) input.value = "1";
      void persistBreakDefaults();
    });
  });
  el.breakHelpBtn?.addEventListener("click", () => toggleBreakHelp());
  document.addEventListener("click", (event) => {
    if (el.breakHelpPopover?.classList.contains("hidden") || event.target.closest?.("#breakHelpPopover, #breakHelpBtn")) return;
    toggleBreakHelp(false);
  });
  el.focusModePicker?.addEventListener("click", (event) => {
    const option = event.target.closest("[data-focus-mode]");
    if (!option || activeSession()) return;
    const duration = el.durationInput.value;
    const breakDuration = el.breakDurationInput?.value;
    const cycles = el.focusCyclesInput?.value;
    focusModeDraft = option.dataset.focusMode;
    renderFocus();
    el.durationInput.value = duration;
    renderFocusDurationPicker();
    if (el.breakDurationInput && breakDuration) el.breakDurationInput.value = breakDuration;
    if (el.focusCyclesInput && cycles) el.focusCyclesInput.value = cycles;
    if (focusModeDraft === "breaks") {
      if (Number(el.focusCyclesInput?.value) < 1 && el.focusCyclesInput) el.focusCyclesInput.value = "1";
      if (Number(el.breakDurationInput?.value) < 1 && el.breakDurationInput) el.breakDurationInput.value = "1";
    }
    updateBreakScheduleValidation(focusModeDraft);
  });
  el.confirmFocusCommitmentBtn?.addEventListener("click", beginFocusSession);
  el.cancelFocusCommitmentBtn?.addEventListener("click", () => { pendingFocusStart = null; el.focusCommitmentModal?.classList.add("hidden"); });
  el.focusCommitmentModal?.addEventListener("click", (event) => { if (event.target === el.focusCommitmentModal) { pendingFocusStart = null; el.focusCommitmentModal.classList.add("hidden"); } });
  el.cancelFocusEndBtn?.addEventListener("click", cancelFocusEnd);
  el.endFocusNowBtn?.addEventListener("click", () => {
    if (hasChrome) sendMessage({ type: "confirmFocusEnd" }).then((result) => {
      if (!result?.ok) return showToast(result?.error || "Could not end the session.");
      state = mergeState(result.response);
      applyTheme();
      render();
      showToast("Focus session ended.");
    });
    else stopFocus("early-exit-confirmed");
  });
  el.pauseFocusBtn?.addEventListener("click", pauseFocus);
  el.resumeFocusBtn?.addEventListener("click", resumeFocus);
  el.stopFocusBtn.addEventListener("click", stopFocus);
  el.courseForm.addEventListener("submit", (e) => { e.preventDefault(); addCourse(el.courseTitleInput.value, el.courseUrlInput.value, el.courseSubjectInput.value, el.courseLibraryInput.value); });
  el.libraryForm?.addEventListener("submit", createLibrary);
  document.addEventListener("click", (event) => {
    if (openLibraryMenuId && event.target.closest?.(".library-manage-row")?.dataset.libraryId !== openLibraryMenuId) {
      openLibraryMenuId = null;
      renderLibraryManagement();
    }
  });
  window.addEventListener("keydown", (event) => {
    if (event.key !== "Escape") return;
    if (el.libraryDeleteModal && !el.libraryDeleteModal.classList.contains("hidden")) {
      event.preventDefault();
      closeLibraryDeleteDialog();
    } else if (openLibraryMenuId) {
      openLibraryMenuId = null;
      renderLibraryManagement();
    } else if (editingLibraryId) {
      editingLibraryId = null;
      renderLibraryManagement();
    }
  });
  el.studyLinkLibraryToggle?.addEventListener("click", () => setCourseLibraryExpanded(!courseLibraryExpanded));
  el.courseLibrarySearch?.addEventListener("input", (event) => { courseLibraryQuery = event.target.value || ""; courseLibraryLimit = 60; renderCourseLibraries(); });
  el.courseLibrarySource?.addEventListener("change", (event) => { courseLibrarySource = event.target.value || "all"; courseLibraryLimit = 60; renderCourseLibraries(); });
  el.courseLibrarySort?.addEventListener("change", (event) => { courseLibrarySort = event.target.value || "priority"; courseLibraryLimit = 60; renderCourseLibraries(); });
  el.noteForm?.addEventListener("submit", saveNote);
  el.noteNewBtn?.addEventListener("click", () => { clearNoteDraft(); selectedNoteId = null; setNoteEditor(null); });
  [el.noteCourseInput, el.noteTitleInput, el.noteBodyInput, el.noteChecklistInput, el.notePinnedInput].filter(Boolean).forEach((input) => input.addEventListener(input.type === "checkbox" || input.tagName === "SELECT" ? "change" : "input", () => { renderNoteCharacterCount(); queueNoteDraft(); }));
  el.noteSearchInput?.addEventListener("input", renderNotes);
  el.noteClearSearchBtn?.addEventListener("click", () => { el.noteSearchInput.value = ""; renderNotes(); });
  el.notesExportBtn?.addEventListener("click", exportNotes);
  el.notesImportBtn?.addEventListener("click", () => el.notesImportInput?.click());
  el.notesImportInput?.addEventListener("change", importNotes);
  el.flashcardForm?.addEventListener("submit", addFlashcard);
  el.allowedForm?.addEventListener("submit", (e) => { e.preventDefault(); const value = el.allowedInput.value.trim().toLowerCase(); if (!value) return; updateSettings({ allowedSites: cleanPatterns([...state.settings.allowedSites, value]) }); el.allowedInput.value = ""; });
  el.blockedForm?.addEventListener("submit", (e) => { e.preventDefault(); const value = el.blockedInput.value.trim().toLowerCase(); if (!value) return; updateSettings({ blockedSites: cleanPatterns([...state.settings.blockedSites, value]) }); el.blockedInput.value = ""; });
  el.distractionProtectionInput?.addEventListener("change", () => void setDistractionProtection(el.distractionProtectionInput.checked));
  el.distractionProtectionConsentAccept?.addEventListener("click", () => void acceptDistractionProtectionConsent());
  el.distractionProtectionConsentDecline?.addEventListener("click", () => void declineDistractionProtectionConsent());
  el.focusSessionProtectionInput?.addEventListener("change", () => void setFocusSessionProtection(el.focusSessionProtectionInput.checked));
  el.focusSessionProtectionConsentAccept?.addEventListener("click", () => void acceptFocusSessionProtectionConsent());
  el.focusSessionProtectionConsentDecline?.addEventListener("click", () => void declineFocusSessionProtectionConsent());
  el.incognitoProtectionInput?.addEventListener("change", () => void setIncognitoProtection(el.incognitoProtectionInput.checked));
  el.openIncognitoSettingsBtn?.addEventListener("click", openIncognitoSettings);
  el.youtubeStudyModeEnabledInput?.addEventListener("change", () => void setYouTubeStudyMode(el.youtubeStudyModeEnabledInput.checked));
  el.addSupportingSiteBtn?.addEventListener("click", () => { el.allowedForm?.classList.toggle("hidden"); if (!el.allowedForm?.classList.contains("hidden")) el.allowedInput?.focus(); });
  el.addBlockedSiteBtn?.addEventListener("click", () => { el.blockedForm?.classList.toggle("hidden"); if (!el.blockedForm?.classList.contains("hidden")) el.blockedInput?.focus(); });
  el.siteControlToggle?.addEventListener("click", () => setSiteControlExpanded(!siteControlExpanded));
  $$('[data-settings-disclosure-toggle]').forEach((button) => button.addEventListener("click", () => {
    const key = button.dataset.settingsDisclosureToggle;
    setSettingsDisclosureExpanded(key, !settingsDisclosureExpanded[key]);
  }));
  el.allowedSearch?.addEventListener("input", (event) => { allowedSiteQuery = event.target.value || ""; renderShield(); });
  el.blockedSearch?.addEventListener("input", (event) => { blockedSiteQuery = event.target.value || ""; renderShield(); });
  el.courseHistoryToggle?.addEventListener("click", () => setCourseHistoryExpanded(!courseHistoryExpanded));
  el.courseHistorySearch?.addEventListener("input", (event) => { courseHistoryQuery = event.target.value || ""; renderCourseHistory(); });
  el.courseHistorySort?.addEventListener("change", (event) => { courseHistorySort = event.target.value || "time"; renderCourseHistory(); });
  el.addCurrentSiteBtn?.addEventListener("click", addCurrentSupportingSite);
  el.missionForm.addEventListener("submit", addMission); el.resetTasksBtn.addEventListener("click", resetMissions);
  el.plannerForm?.addEventListener("submit", addPlannerItem);
  el.settingsFocusModeSelect?.addEventListener("change", () => {
    const isBreakMode = el.settingsFocusModeSelect.value === "breaks";
    if (el.settingsFocusBreakDefaults) el.settingsFocusBreakDefaults.hidden = !isBreakMode;
    if (isBreakMode) {
      if (Number(el.settingsFocusCyclesInput?.value) < 1 && el.settingsFocusCyclesInput) el.settingsFocusCyclesInput.value = "1";
      if (Number(el.settingsBreakMinutesInput?.value) < 1 && el.settingsBreakMinutesInput) el.settingsBreakMinutesInput.value = "1";
    }
    updateSettingsBreakValidation();
  });
  [el.settingsFocusMinutesInput, el.settingsBreakMinutesInput, el.settingsFocusCyclesInput].filter(Boolean).forEach((input) => input.addEventListener("input", () => {
    if (el.settingsFocusModeSelect?.value === "breaks" && input.value !== "" && Number(input.value) < 1 && [el.settingsBreakMinutesInput, el.settingsFocusCyclesInput].includes(input)) input.value = "1";
    updateSettingsBreakValidation();
  }));
  el.soundEnabledInput?.addEventListener("change", () => { if (el.soundVolumeSetting) el.soundVolumeSetting.hidden = !el.soundEnabledInput.checked; });
  el.soundVolumeInput?.addEventListener("input", (event) => { el.soundVolumeLabel.textContent = event.target.value + "%"; }); [el.cameraAttentionEnabledInput, el.cameraAttentionSensitivityInput, el.cameraAttentionGraceInput, el.cameraAttentionVoiceInput].filter(Boolean).forEach((input) => input.addEventListener("change", saveCameraAttentionSettings)); el.cameraPermissionBtn?.addEventListener("click", () => void handleCameraPermissionAction(el.cameraPermissionBtn)); el.settingsForm?.addEventListener("change", (event) => void saveSettings(event)); el.settingsForm?.addEventListener("submit", (event) => void saveSettings(event)); el.resetAnalyticsBtn.addEventListener("click", resetAnalyticsData); el.clearAllDataBtn.addEventListener("click", clearAllData); el.exportJsonBtn.addEventListener("click", exportJson); el.restoreBackupBtn.addEventListener("click", () => el.restoreBackupInput.click()); el.restoreBackupInput.addEventListener("change", restoreBackupFile);
  el.undoBtn.addEventListener("click", async () => { if (!undoSnapshot) return; const snapshot = undoSnapshot; const localSnapshot = undoLocalStorageSnapshot; undoSnapshot = null; undoLocalStorageSnapshot = null; el.undoBar.classList.add("hidden"); await saveState(snapshot); if (localSnapshot) { try { localStorage.clear(); localSnapshot.forEach(([key, value]) => localStorage.setItem(key, value)); } catch {} } showToast("Undo complete."); });
  systemThemeQuery?.addEventListener?.("change", () => { applyTheme(); renderAnalytics(); });
  window.addEventListener("resize", queueGuidedTourPosition);
  window.addEventListener("resize", closeStudyLinkMenu);
  window.addEventListener("scroll", (event) => { if (activeStudyLinkMenu && !activeStudyLinkMenu.menu.contains(event.target)) closeStudyLinkMenu(); }, true);
  window.addEventListener("scroll", queueGuidedTourPosition, true);
  window.addEventListener("keydown", (event) => {
    if (!guidedTourActive) return;
    if (event.key === "Enter" && !event.isComposing && !event.repeat) {
      const target = event.target instanceof Element ? event.target : null;
      const tourAction = target?.closest("#guidedTour button, #guidedTour a");
      const formControl = target?.closest("input, textarea, select, [contenteditable='true'], form");
      const settingsDisclosure = target?.closest(".settings-disclosure-toggle, #siteControlToggle");
      const plainTourCard = target?.closest("#guidedTour") && !tourAction && !formControl;
      const plainPage = !target?.closest("button, a, input, textarea, select, [contenteditable='true'], form");
      if (!tourAction && !formControl && (plainTourCard || plainPage || settingsDisclosure)) {
        event.preventDefault();
        if (!el.guidedTourNextBtn?.disabled) void moveGuidedTour(1);
        return;
      }
    }
    if (event.key === "Escape") { event.preventDefault(); void finishGuidedTour("skipped"); }
    if (event.key === "ArrowRight") { event.preventDefault(); void moveGuidedTour(1); }
    if (event.key === "ArrowLeft" && guidedTourStepIndex > 0) { event.preventDefault(); void moveGuidedTour(-1); }
  });
  if (hasChrome) chrome.storage.onChanged.addListener((changes, area) => { if (area !== "local") return; if (changes[STATE_KEY]?.newValue) { const previousReminderAt = state.attention?.lastEventAt || 0; state = ensureToday(mergeState(changes[STATE_KEY].newValue)); applyTheme(); render(); if (guidedTourActive) void renderGuidedTourStep(); const reminderAt = state.attention?.lastEventAt || 0; if (reminderAt && reminderAt !== previousReminderAt && reminderAt !== lastSeenAttentionReminderAt) { lastSeenAttentionReminderAt = reminderAt; showToast(attentionReminderText(state.attention?.reason)); } } if (changes[MUSIC_COMMAND_KEY]?.newValue) handleMusicCommand(changes[MUSIC_COMMAND_KEY].newValue.action); });
  if (hasChrome) {
    chrome.permissions?.onAdded?.addListener(() => { void refreshWebsiteProtectionPermission(); });
    chrome.permissions?.onRemoved?.addListener(() => { void refreshWebsiteProtectionPermission(); });
  }
  window.addEventListener("focus", () => { void refreshIncognitoAccessStatus(); void refreshWebsiteProtectionPermission(); void refreshCameraPermissionStatus(); });
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") void refreshCameraPermissionStatus();
  });
}
async function handleParams() {
  const params = new URLSearchParams(location.search);
  const section = params.get("section");
  const welcome = params.get("welcome");
  const commitment = params.get("commitment");
  const youtubeAdd = params.get("youtubeAdd");
  const guidedTourHandoffId = params.get("guidedTourHandoff");
  if (welcome) showToast("Extension ready. Add your first course link.");
  if (section) { const map = { shield: "settings", mission: "daily", focus: "focus", advice: "focus", about: "about" }; setActiveTab(map[section] || section); }
  if (commitment === "1" && !activeSession()) openFocusCommitment();
  if (guidedTourHandoffId) {
    await resumeGuidedTourYouTubeHandoff(guidedTourHandoffId);
    history.replaceState(null, "", location.pathname + "?section=courses");
  } else if (youtubeAdd === "1") {
    await prepareGuidedTourCourseAdd(params.get("youtubeUrl"), params.get("youtubeTitle"));
    history.replaceState(null, "", location.pathname + "?section=courses");
  } else if (youtubeAdd === "invalid") {
    showToast("Choose a YouTube video link or video page to add it.");
    history.replaceState(null, "", location.pathname + "?section=courses");
  }
}
async function refreshDailyStateIfNeeded() {
  const before = state.daily?.date + "|" + state.stats?.date;
  const next = ensureToday(state);
  const after = next.daily?.date + "|" + next.stats?.date;
  if (before !== after) await saveState(next);
}
fillSelects(); loadMusicLibrary(); bindEvents(); await loadState(); await handleParams(); await maybeStartGuidedTour(); if (!focusQuoteShown && $("#tab-focus")?.classList.contains("active")) rotateFocusQuote(); setInterval(() => { renderFocusTick(); renderWelcomeBack(); }, 1000); setInterval(renderClock, 60000); setInterval(refreshDailyStateIfNeeded, 60000);
