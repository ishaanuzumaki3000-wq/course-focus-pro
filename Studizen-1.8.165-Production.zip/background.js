import {
  ALARMS,
  STATE_KEY,
  applyStatePatch,
  awardVerifiedRewards,
  buildWeeklyStudyReport,
  attentionVoiceMessage,
  buildAssistantState,
  cleanPatterns,
  closeFocusStudyInterval,
  createBreakStudyBlocks,
  compactHost,
  canonicalYouTubeVideoUrl,
  contextMenuYouTubeUrl,
  courseMatchesUrl,
  defaultState,
  ensureToday,
  advanceFocusSessionPhase,
  focusElapsedMs,
  focusElapsedMinutes,
  focusModeLabel,
  focusPhaseDurationMs,
  getActiveCourse,
  isHttpUrl,
  isInternalUrl,
  isYouTubeStudyModeActive,
  mergeState,
  normalizeSubject,
  recordDistractionAnalytics,
  recordFocusAnalytics,
  recordProtectionEvent,
  requestYouTubeOembedTitle,
  sessionRemainingMs,
  isDistractionProtectionActive,
  isFocusSessionProtectionActive,
  sessionXp,
  safeYouTubeTitle,
  youtubeVideoId,
  shouldApplyProtectionToTab,
  shouldPersistProtectionEvent,
  shouldRedirectByDistractionProtection,
  uid,
  validateBreakSchedule
} from "./shared.js";
import { createAttentionNotificationController, isAttentionNotificationId } from "./attention-notifications.js";

const ICON_URL = chrome.runtime.getURL("icons/icon128.png");
const ATTENTION_DOCUMENT_PATH = "attention.html";
const LEGACY_WATER_ALARM = "water-reminder";
const ADD_TO_COURSE_CONTEXT_MENU_ID = "add-to-course-focus";
const GUIDED_TOUR_SESSION_KEY = "studizenGuidedTourSession";
const YOUTUBE_TAB_MATCHES = ["*://youtube.com/*", "*://*.youtube.com/*", "*://youtube-nocookie.com/*", "*://*.youtube-nocookie.com/*", "*://youtu.be/*"];
const WEBSITE_PROTECTION_PERMISSION = { permissions: ["tabs"] };
let courseContextMenuQueue = Promise.resolve();
const redirectCooldown = new Map();
const tabCheckCooldown = new Map();
let stateQueue = Promise.resolve();
let websiteProtectionPermissionCheck = null;

function hasWebsiteProtectionPermissions() {
  if (!chrome.permissions?.contains) return Promise.resolve(false);
  if (!websiteProtectionPermissionCheck) {
    websiteProtectionPermissionCheck = chrome.permissions.contains(WEBSITE_PROTECTION_PERMISSION)
      .then(Boolean)
      .catch(() => false);
  }
  return websiteProtectionPermissionCheck;
}

function resetWebsiteProtectionPermissionCheck() {
  websiteProtectionPermissionCheck = null;
}

function onWebsiteProtectionPermissionsChanged() {
  resetWebsiteProtectionPermissionCheck();
  void enforceRedirectRules().catch(() => {});
}
let attentionDocumentPromise = null;
let attentionCommandToken = 0;
const youtubeContextTargets = new Map();
let youtubeContextCaptureSequence = 0;
let calendarTransitionQueue = Promise.resolve();

function youtubeContextDebug(event, details = {}) {
  if (globalThis.__STUDIZEN_YOUTUBE_DEBUG__ !== true) return;
  console.debug("[Studizen YouTube context]", event, details);
}

async function getState() {
  const data = await chrome.storage.local.get(STATE_KEY);
  const source = data[STATE_KEY] || defaultState();
  let normalized = ensureToday(mergeState(source));
  const subjectTargetsNeedMigration = Boolean(source.goals?.analyticsTargets && source.goals.analyticsTargets.subjectTargetPeriod !== "daily");
  const calendarChanged = !data[STATE_KEY]
    || source.daily?.date !== normalized.daily.date
    || source.stats?.date !== normalized.stats.date
    || source.analytics?.calendar?.lastObservedDate !== normalized.analytics.calendar.lastObservedDate
    || source.analytics?.calendar?.timeZone !== normalized.analytics.calendar.timeZone
    || subjectTargetsNeedMigration;
  if (calendarChanged) {
    const transition = calendarTransitionQueue.then(async () => {
      const latestData = await chrome.storage.local.get(STATE_KEY);
      const latestSource = latestData[STATE_KEY] || source;
      const latest = ensureToday(mergeState(latestSource));
      const latestSubjectTargetsNeedMigration = Boolean(latestSource.goals?.analyticsTargets && latestSource.goals.analyticsTargets.subjectTargetPeriod !== "daily");
      const needsSave = !latestData[STATE_KEY]
        || latestSource.daily?.date !== latest.daily.date
        || latestSource.stats?.date !== latest.stats.date
        || latestSource.analytics?.calendar?.lastObservedDate !== latest.analytics.calendar.lastObservedDate
        || latestSource.analytics?.calendar?.timeZone !== latest.analytics.calendar.timeZone
        || latestSubjectTargetsNeedMigration;
      if (needsSave) await chrome.storage.local.set({ [STATE_KEY]: latest });
      return latest;
    });
    calendarTransitionQueue = transition.catch(() => {});
    normalized = await transition;
  }
  if (source.settings?.themeMode && source.settings.themeMode !== normalized.settings.themeMode) {
    const latestData = await chrome.storage.local.get(STATE_KEY);
    const latest = latestData[STATE_KEY];
    if (latest?.settings?.themeMode === source.settings.themeMode) {
      await chrome.storage.local.set({ [STATE_KEY]: { ...latest, settings: { ...latest.settings, themeMode: normalized.settings.themeMode } } });
    }
  }
  return normalized;
}

async function scheduleDailyRollover(now = Date.now()) {
  const nextMidnight = new Date(now);
  nextMidnight.setHours(24, 0, 5, 0);
  await chrome.alarms.clear(ALARMS.DAILY_ROLLOVER);
  await chrome.alarms.create(ALARMS.DAILY_ROLLOVER, { when: Math.max(now + 1000, nextMidnight.getTime()) });
}

function setState(updater) {
  const task = stateQueue.then(async () => {
    const current = await getState();
    const candidate = typeof updater === "function" ? updater(current) : updater;
    const next = awardVerifiedRewards(ensureToday(mergeState(candidate)));
    await chrome.storage.local.set({ [STATE_KEY]: next });
    await updateBadge(next);
    return next;
  });
  stateQueue = task.catch(() => {});
  return task;
}

async function updateBadge(state = null) {
  const current = state || await getState();
  if (current.focusSession?.active && sessionRemainingMs(current.focusSession) > 0) {
    const session = current.focusSession;
    await chrome.action.setBadgeText({ text: session.phase === "break" ? "BR" : session.paused ? "II" : "ON" });
    await chrome.action.setBadgeBackgroundColor({ color: session.phase === "break" ? "#36a68a" : session.paused ? "#e59b23" : "#2478ff" });
    return;
  }
  await chrome.action.setBadgeText({ text: "" });
}

async function syncYouTubeStudyModeTabs(state = null) {
  const current = state || await getState();
  const active = isYouTubeStudyModeActive(current.settings, current.focusSession);
  const tabs = await chrome.tabs.query({ url: YOUTUBE_TAB_MATCHES });
  await Promise.all(tabs.filter((tab) => Number.isInteger(tab.id)).map((tab) =>
    chrome.tabs.sendMessage(tab.id, { type: "setYouTubeStudyMode", active }).catch(() => {})
  ));
}

chrome.storage.onChanged.addListener((changes, area) => {
  const change = changes?.[STATE_KEY];
  if (area !== "local" || !change) return;
  const before = mergeState(change.oldValue || defaultState());
  const after = mergeState(change.newValue || defaultState());
  const wasActive = isYouTubeStudyModeActive(before.settings, before.focusSession);
  const isActive = isYouTubeStudyModeActive(after.settings, after.focusSession);
  if (wasActive !== isActive || before.settings.youtubeStudyModeEnabled !== after.settings.youtubeStudyModeEnabled) {
    syncYouTubeStudyModeTabs(after).catch(() => {});
  }
});

async function notify(idPrefix, title, message, buttons = []) {
  const id = idPrefix + ":" + Date.now();
  await chrome.notifications.create(id, {
    type: "basic",
    iconUrl: ICON_URL,
    title,
    message,
    priority: 2,
    requireInteraction: false,
    buttons: buttons.slice(0, 2).map((title) => ({ title }))
  });
  return id;
}

const attentionNotifications = createAttentionNotificationController({
  create: (id, options) => chrome.notifications.create(id, { ...options, iconUrl: ICON_URL }),
  getAll: () => chrome.notifications.getAll(),
  clear: (id) => chrome.notifications.clear(id),
  clearAlarm: () => chrome.alarms.clear(ALARMS.ATTENTION_DISMISS),
  createAlarm: (name, details) => chrome.alarms.create(name, details),
  alarmName: ALARMS.ATTENTION_DISMISS,
  uid
});
const clearAttentionNotification = () => attentionNotifications.clear();
const notifyAttention = (title, message, buttons = []) => attentionNotifications.show({ title, message, buttons });
const forgetClosedAttentionNotification = (id) => attentionNotifications.closed(id);

function attentionOptions(settings = {}) {
  return {
    sensitivity: settings.cameraAttentionSensitivity || "balanced",
    graceSeconds: Math.max(5, Math.min(30, Number(settings.cameraAttentionGraceSeconds) || 10))
  };
}

function sessionIsInStudyPhase(session) {
  return Boolean(session?.active && !session.paused && session.phase !== "break" && session.phase !== "completed");
}

async function attentionDocumentExists() {
  if (!chrome.runtime.getContexts) return false;
  const documentUrl = chrome.runtime.getURL(ATTENTION_DOCUMENT_PATH);
  const contexts = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"], documentUrls: [documentUrl] });
  return contexts.length > 0;
}

async function ensureAttentionDocument() {
  if (!chrome.offscreen) throw new Error("Camera Focus Check requires a newer version of Chrome.");
  if (await attentionDocumentExists()) return;
  if (!attentionDocumentPromise) {
    attentionDocumentPromise = chrome.offscreen.createDocument({
      url: ATTENTION_DOCUMENT_PATH,
      reasons: ["USER_MEDIA"],
      justification: "Run the optional local-only camera attention check during an active focus session."
    }).finally(() => { attentionDocumentPromise = null; });
  }
  await attentionDocumentPromise;
}

async function closeAttentionDocument() {
  if (!chrome.offscreen || !(await attentionDocumentExists())) return;
  await chrome.offscreen.closeDocument();
}

async function sendAttentionCommand(command, payload = {}, status = "off", commandToken = ++attentionCommandToken) {
  try {
    await chrome.runtime.sendMessage({ type: "attentionMonitorCommand", command, payload, status, commandToken });
  } catch {}
}

async function startAttentionMonitor(session, state) {
  const current = state || await getState();
  if (!current.settings.cameraAttentionConsentAccepted || !current.settings.cameraAttentionEnabled || !sessionIsInStudyPhase(session)) {
    await clearAttentionNotification();
    return setState((saved) => ({ ...saved, attention: { ...saved.attention, active: false, status: "off", reason: null, error: null } }));
  }
  try {
    const commandToken = ++attentionCommandToken;
    await ensureAttentionDocument();
    let accepted = false;
    const next = await setState((saved) => {
      const liveSession = saved.focusSession;
      if (!sessionIsInStudyPhase(liveSession) || liveSession.id !== session.id || !saved.settings.cameraAttentionConsentAccepted || !saved.settings.cameraAttentionEnabled) return saved;
      accepted = true;
      return { ...saved, attention: { ...saved.attention, active: true, status: "starting", reason: null, error: null } };
    });
    if (!accepted) return next;
    await sendAttentionCommand("start", { sessionId: session.id, options: attentionOptions(next.settings) }, "off", commandToken);
    return next;
  } catch (error) {
    return setState((saved) => {
      if (!saved.focusSession?.active || saved.focusSession.id !== session.id) return saved;
      return { ...saved, attention: { ...saved.attention, active: false, status: "error", reason: null, error: error?.message || "Camera Focus Check could not start." } };
    });
  }
}

async function stopAttentionMonitor(status = "off") {
  const commandToken = ++attentionCommandToken;
  await clearAttentionNotification();
  await sendAttentionCommand("stop", {}, status, commandToken);
  await new Promise((resolve) => setTimeout(resolve, 40));
  const current = await getState();
  if (sessionIsInStudyPhase(current.focusSession) && sessionRemainingMs(current.focusSession) > 0) return current;
  await closeAttentionDocument().catch(() => {});
  return setState((saved) => {
    if (sessionIsInStudyPhase(saved.focusSession) && sessionRemainingMs(saved.focusSession) > 0) return saved;
    return { ...saved, attention: { ...saved.attention, active: false, status, reason: null, error: null } };
  });
}

function attentionMessage(reason) {
  if (reason === "eyes closed") return "Your eyes have been closed for a while. Return to the lesson when ready.";
  if (reason === "eyes away from screen") return "Your gaze has been away from the lesson for a while. Bring your attention back.";
  return "You have been away from the course for a while. Take one breath and return to it.";
}

async function speakAttention(settings = {}, reason = "") {
  if (!settings.soundEnabled || !settings.cameraAttentionVoice || !chrome.tts) return;
  try {
    await Promise.resolve(chrome.tts.stop());
    await chrome.tts.speak(attentionVoiceMessage(reason), { enqueue: false, lang: "en-US", rate: 0.92, pitch: 1, volume: 0.9 });
  } catch {}
}

async function showAttentionOverlay(state, message) {
  const session = state.focusSession;
  const course = state.courses.find((item) => item.id === session?.courseId) || getActiveCourse(state);
  if (!course?.url || !chrome.scripting) return;
  const tabs = await chrome.tabs.query({});
  const tab = tabs.find((item) => item.active && courseMatchesUrl(course, item.url)) || tabs.find((item) => courseMatchesUrl(course, item.url));
  if (!tab?.id || !isHttpUrl(tab.url)) return;
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    args: [message, state.settings?.themeMode || "dark"],
    func: (copy, themeMode) => {
      const id = "studizen-attention-reminder";
      document.getElementById("course-focus-pro-attention-reminder")?.remove();
      document.getElementById(id)?.remove();
      const reminder = document.createElement("aside");
      reminder.id = id;
      reminder.setAttribute("role", "alert");
      reminder.setAttribute("aria-live", "assertive");
      reminder.setAttribute("aria-atomic", "true");
      reminder.dataset.theme = themeMode === "light" || themeMode === "beige" ? "light" : themeMode === "system" ? "system" : "dark";
      Object.assign(reminder.style, {
        position: "fixed", top: "clamp(14px, 4vw, 28px)", right: "clamp(14px, 4vw, 28px)", zIndex: "2147483647", width: "min(360px, calc(100vw - 28px))", boxSizing: "border-box", fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif"
      });
      const shadow = reminder.attachShadow({ mode: "open" });
      const style = document.createElement("style");
      style.textContent = `
        :host { color-scheme: light dark; }
        .card { --card: #111d30; --card-border: rgba(245, 185, 75, .5); --ink: #f7fbff; --muted: #b8c5d5; --accent: #f2b84b; display: flex; gap: 12px; align-items: flex-start; padding: 14px 16px; border: 1px solid var(--card-border); border-radius: 16px; background: linear-gradient(135deg, rgba(245, 185, 75, .14), transparent 52%), var(--card); color: var(--ink); box-shadow: 0 18px 45px rgba(0, 0, 0, .28), 0 4px 12px rgba(0, 0, 0, .16); opacity: 0; transform: translateY(-10px) scale(.98); animation: reminder-in .24s cubic-bezier(.2, .8, .2, 1) forwards; }
        .icon { flex: 0 0 32px; width: 32px; height: 32px; display: grid; place-items: center; border-radius: 10px; background: var(--accent); color: #182235; font: 900 19px/1 system-ui, sans-serif; box-shadow: 0 5px 14px rgba(245, 185, 75, .25); }
        .copy { min-width: 0; padding-top: 1px; }
        h2 { margin: 0; color: var(--ink); font: 800 14px/1.2 system-ui, sans-serif; letter-spacing: .01em; }
        p { margin: 5px 0 0; color: var(--muted); font: 600 13px/1.45 system-ui, sans-serif; overflow-wrap: anywhere; }
        .card.is-exiting { animation: reminder-out .22s ease-in forwards; }
        :host([data-theme="light"]) .card, :host([data-theme="system"]) .card { --card: #ffffff; --card-border: rgba(174, 119, 22, .42); --ink: #172238; --muted: #536176; --accent: #f3bd50; box-shadow: 0 16px 36px rgba(31, 46, 68, .18), 0 3px 10px rgba(31, 46, 68, .1); }
        @media (prefers-color-scheme: dark) { :host([data-theme="system"]) .card { --card: #111d30; --card-border: rgba(245, 185, 75, .5); --ink: #f7fbff; --muted: #b8c5d5; --accent: #f2b84b; box-shadow: 0 18px 45px rgba(0, 0, 0, .28), 0 4px 12px rgba(0, 0, 0, .16); } }
        @keyframes reminder-in { to { opacity: 1; transform: translateY(0) scale(1); } }
        @keyframes reminder-out { to { opacity: 0; transform: translateY(-8px) scale(.98); } }
        @media (prefers-reduced-motion: reduce) { .card { animation: none; opacity: 1; transform: none; } .card.is-exiting { animation: none; opacity: 0; } }
      `;
      const icon = document.createElement("span");
      icon.className = "icon";
      icon.setAttribute("aria-hidden", "true");
      icon.textContent = "!";
      const copyWrap = document.createElement("div");
      copyWrap.className = "copy";
      const heading = document.createElement("h2");
      heading.textContent = "Attention Needed";
      const text = document.createElement("p");
      text.textContent = copy;
      copyWrap.append(heading, text);
      const card = document.createElement("div");
      card.className = "card";
      card.append(icon, copyWrap);
      shadow.append(style, card);
      document.documentElement.append(reminder);
      window.setTimeout(() => {
        card.classList.add("is-exiting");
        window.setTimeout(() => reminder.remove(), 240);
      }, 3600);
    }
  }).catch(() => {});
}

async function receiveAttentionStatus(payload = {}) {
  const current = await getState();
  const session = current.focusSession;
  if (!sessionIsInStudyPhase(session) || (payload.sessionId && payload.sessionId !== session.id)) return current;
  const status = ["starting", "calibrating", "watching", "attention-lost", "needs-position", "permission-denied", "unsupported", "error"].includes(payload.status) ? payload.status : "error";
  const remind = Boolean(payload.shouldRemind && status === "attention-lost");
  let accepted = false;
  const next = await setState((saved) => {
    const liveSession = saved.focusSession;
    if (!sessionIsInStudyPhase(liveSession) || (payload.sessionId && payload.sessionId !== liveSession.id)) return saved;
    accepted = true;
    const previous = saved.attention || {};
    const attention = {
      ...previous,
      active: !["permission-denied", "unsupported", "error"].includes(status),
      status,
      reason: payload.reason || null,
      error: payload.error || null,
      diagnostics: payload.diagnostics || previous.diagnostics || null,
      calibratedAt: payload.calibrated ? Date.now() : previous.calibratedAt,
      lastEventAt: remind ? Date.now() : previous.lastEventAt,
      distractionCount: previous.distractionCount + (remind ? 1 : 0)
    };
    return { ...saved, attention };
  });
  if (!accepted) return next;
  if (payload.attentionState === "ATTENTIVE") await clearAttentionNotification();
  if (remind) {
    await speakAttention(next.settings, payload.reason);
    const message = attentionMessage(payload.reason);
      await showAttentionOverlay(next, message);
    await notifyAttention("Attention", message, ["Dashboard"]);
  }
  return next;
}
async function clearNotifications(prefix) {
  const all = await chrome.notifications.getAll();
  await Promise.all(Object.keys(all).filter((id) => id.startsWith(prefix)).map((id) => chrome.notifications.clear(id)));
}

async function clearLegacyHydrationArtifacts() {
  await chrome.alarms.clear(LEGACY_WATER_ALARM);
  await clearNotifications("water");
}

function contextVideoTarget(info = {}, tabId = null, tabUrl = "") {
  const captured = Number.isInteger(tabId) ? youtubeContextTargets.get(tabId) : null;
  const captureIsFresh = captured && Date.now() - captured.at < 10_000;
  const contextPageUrl = String(info?.pageUrl || tabUrl || "");
  const captureMatchesPage = !contextPageUrl || !captured?.pageUrl || contextPageUrl === captured.pageUrl;
  const freshCapture = captureIsFresh && captureMatchesPage ? captured : null;
  const url = contextMenuYouTubeUrl(info, tabUrl);
  if (!url) {
    youtubeContextDebug("target-rejected", {
      linkUrl: String(info?.linkUrl || ""),
      pageUrl: String(info?.pageUrl || ""),
      srcUrl: String(info?.srcUrl || ""),
      mediaType: String(info?.mediaType || ""),
      tabId,
      tabUrl: String(tabUrl || ""),
      reason: info?.linkUrl || info?.srcUrl ? "selected-context-is-not-a-supported-video" : "no-selected-video-url"
    });
    return null;
  }
  const title = freshCapture?.url === url ? safeYouTubeTitle(freshCapture.title, "") : "";
  const titleSource = title ? freshCapture?.titleSource || "youtube-thumbnail-dom" : "";
  const urlSources = [
    ["context-link-url", info?.linkUrl],
    ["context-page-url", info?.pageUrl],
    ["callback-tab-url", tabUrl],
    ["context-source-url", info?.srcUrl]
  ];
  const urlSource = urlSources.find(([, candidate]) => canonicalYouTubeVideoUrl(candidate) === url)?.[0] || "unknown";
  youtubeContextDebug("target-selected", {
    linkUrl: String(info?.linkUrl || ""),
    pageUrl: String(info?.pageUrl || ""),
    srcUrl: String(info?.srcUrl || ""),
    mediaType: String(info?.mediaType || ""),
    tabId,
    tabUrl: String(tabUrl || ""),
    selectedUrl: url,
    videoId: youtubeVideoId(url),
    urlSource,
    titleSource
  });
  return { url, title, titleSource };
}

function youtubePageTitleMetadata(expectedUrl) {
  const canonical = (raw = "") => {
    try {
      const url = new URL(raw, location.href);
      const host = url.hostname.toLowerCase().replace(/^www\./, "");
      let videoId = "";
      if (host === "youtu.be") videoId = url.pathname.split("/").filter(Boolean)[0] || "";
      else if (host === "youtube.com" || host.endsWith(".youtube.com") || host === "youtube-nocookie.com" || host.endsWith(".youtube-nocookie.com")) {
        videoId = url.pathname === "/watch" ? url.searchParams.get("v") || "" : (url.pathname.match(/^\/(?:shorts|embed|live)\/([^/?#]+)/i)?.[1] || "");
      }
      return videoId ? "https://www.youtube.com/watch?v=" + encodeURIComponent(videoId) : "";
    } catch {
      return "";
    }
  };
  const idFor = (raw = "") => {
    const canonicalUrl = canonical(raw);
    if (!canonicalUrl) return "";
    try { return new URL(canonicalUrl).searchParams.get("v") || ""; } catch { return ""; }
  };
  const safeTitle = (value = "") => {
    const title = String(value || "").replace(/\s+/g, " ").trim().slice(0, 180);
    if (!title || /^youtube video$/i.test(title) || /^(?:\d{1,2}:)?\d{1,2}:\d{2}$/.test(title) || /^\d+\s*(?:s|sec|secs|second|seconds|min|mins|minute|minutes)$/i.test(title)) return "";
    return title;
  };
  const textValue = (value) => typeof value === "string" ? value : value?.simpleText || (Array.isArray(value?.runs) ? value.runs.map((run) => run?.text || "").join("") : "");
  const titleFromInitialData = (expectedVideoId) => {
    const queue = [window.ytInitialData].filter(Boolean);
    const seen = new Set();
    let visited = 0;
    while (queue.length && visited < 40000) {
      const value = queue.pop();
      if (!value || typeof value !== "object" || seen.has(value)) continue;
      seen.add(value);
      visited += 1;
      if (value.videoId === expectedVideoId) {
        const title = safeTitle(textValue(value.title) || textValue(value.headline));
        if (title) return { title, source: "matching-youtube-initial-data", reason: "" };
      }
      Object.values(value).forEach((child) => { if (child && typeof child === "object") queue.push(child); });
    }
    return { title: "", source: "", reason: "video-id-not-found-in-youtube-data" };
  };
  const titleFromAnchor = (anchor) => {
    const renderer = anchor.closest("ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer, ytd-grid-video-renderer, ytd-rich-grid-media, ytd-playlist-video-renderer, yt-lockup-view-model");
    const titleNode = renderer?.querySelector("#video-title, #video-title-link, .yt-lockup-metadata-view-model__title, h3 a[title]");
    const candidates = [titleNode?.getAttribute("title"), titleNode?.innerText, titleNode?.textContent, anchor.getAttribute("title"), anchor.querySelector("#video-title")?.textContent];
    const structuredTitle = candidates.map(safeTitle).find(Boolean);
    if (structuredTitle) return { title: structuredTitle, source: "matching-thumbnail-dom", reason: "" };
    return titleFromInitialData(idFor(anchor.href));
  };

  const expectedVideoId = idFor(expectedUrl);
  if (!expectedVideoId) return { title: "", source: "", reason: "selected-url-has-no-video-id" };
  if (canonical(location.href) === expectedUrl) {
    const videoDetails = window.ytInitialPlayerResponse?.videoDetails;
    if (videoDetails?.videoId && videoDetails.videoId !== expectedVideoId) {
      return { title: "", source: "", reason: "current-player-video-id-mismatch" };
    }
    if (videoDetails?.videoId === expectedVideoId) {
      const playerTitle = safeTitle(videoDetails.title);
      if (playerTitle) return { title: playerTitle, source: "matching-player-video-details", reason: "" };
    }
    const headingTitle = safeTitle(document.querySelector("h1.ytd-watch-metadata yt-formatted-string, h1.ytd-watch-metadata, #title h1")?.textContent);
    if (headingTitle) return { title: headingTitle, source: "matching-current-video-heading", reason: "" };
    return { title: "", source: "", reason: "current-video-metadata-not-ready" };
  }

  const anchor = Array.from(document.querySelectorAll("a[href]")).find((item) => canonical(item.href) === expectedUrl);
  if (anchor) {
    const selectedTitle = titleFromAnchor(anchor);
    if (selectedTitle.title) return selectedTitle;
  }
  const initialDataTitle = titleFromInitialData(expectedVideoId);
  if (initialDataTitle.title) return initialDataTitle;
  return { title: "", source: "", reason: "selected-video-not-current-and-title-not-in-page-data" };
}

async function titleForContextVideo(tabId, targetUrl) {
  if (!Number.isInteger(tabId)) return { title: "", source: "", reason: "source-tab-unavailable" };
  let lastResult = { title: "", source: "", reason: "metadata-script-did-not-run" };
  try {
    for (let attempt = 0; attempt < 4; attempt += 1) {
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId },
        args: [targetUrl],
        func: youtubePageTitleMetadata
      });
      lastResult = {
        title: safeYouTubeTitle(result?.title, ""),
        source: String(result?.source || ""),
        reason: String(result?.reason || (result?.title ? "" : "title-not-found"))
      };
      if (lastResult.title) return lastResult;
      if (attempt < 3) await new Promise((resolve) => setTimeout(resolve, 180));
    }
    return lastResult;
  } catch (error) {
    return { title: "", source: "", reason: String(error?.message || error || "metadata-script-failed").slice(0, 160) };
  }
}

async function resolveContextVideoTarget(info = {}, tabId = null, tabUrl = "") {
  const target = contextVideoTarget(info, tabId, tabUrl);
  if (Number.isInteger(tabId)) youtubeContextTargets.delete(tabId);
  if (!target) return target;
  const domResult = await titleForContextVideo(tabId, target.url);
  let title = safeYouTubeTitle(domResult.title, "");
  let titleSource = title ? domResult.source : "";
  const titleFailures = title ? [] : [domResult.reason || "page-metadata-unavailable"];
  const contextPageUrl = canonicalYouTubeVideoUrl(info?.pageUrl) || canonicalYouTubeVideoUrl(tabUrl);
  const isCurrentPageVideo = contextPageUrl === target.url;
  if (!title && !isCurrentPageVideo) {
    title = safeYouTubeTitle(target.title, "");
    if (title) titleSource = target.titleSource || "context-thumbnail-capture";
    else titleFailures.push("context-thumbnail-title-unavailable");
  }
  if (!title) titleFailures.push("external-title-lookup-requires-user-consent");
  youtubeContextDebug("title-resolved", {
    selectedUrl: target.url,
    videoId: youtubeVideoId(target.url),
    titleSource: titleSource || "none",
    titleFound: Boolean(title),
    failureReason: title ? "" : titleFailures.join("; ")
  });
  return { ...target, title, titleSource };
}

function registerCourseContextMenu() {
  const task = courseContextMenuQueue.then(async () => {
    await new Promise((resolve) => chrome.contextMenus.remove(ADD_TO_COURSE_CONTEXT_MENU_ID, () => {
      void chrome.runtime.lastError;
      resolve();
    }));
    await new Promise((resolve) => chrome.contextMenus.create({
      id: ADD_TO_COURSE_CONTEXT_MENU_ID,
      title: "Add to Studizen",
      contexts: ["page", "link", "image", "video"],
      documentUrlPatterns: ["*://youtube.com/*", "*://*.youtube.com/*", "*://youtube-nocookie.com/*", "*://*.youtube-nocookie.com/*", "*://youtu.be/*"]
    }, () => {
      void chrome.runtime.lastError;
      resolve();
    }));
  });
  courseContextMenuQueue = task.catch(() => {});
  return task;
}

async function scheduleFocusEnd(session) {
  await chrome.alarms.clear(ALARMS.FOCUS_END);
  await chrome.alarms.clear(ALARMS.FOCUS_BREAK_ENDING);
  const confirmingEnd = Boolean(session?.endConfirmationUntil && session.endConfirmationUntil > Date.now());
  if (session?.active && !confirmingEnd && !session.paused && session.phase !== "completed" && sessionRemainingMs(session) > 0) {
    await chrome.alarms.create(ALARMS.FOCUS_END, { when: session.endsAt });
    if (session.phase === "break" && session.breakEndingFor !== session.endsAt) {
      const durationMs = focusPhaseDurationMs(session);
      const leadMs = Math.min(60000, Math.floor(durationMs / 2));
      const when = Number(session.endsAt) - leadMs;
      if (when > Date.now()) await chrome.alarms.create(ALARMS.FOCUS_BREAK_ENDING, { when });
    }
  }
  await chrome.alarms.clear(ALARMS.FOCUS_EXIT_CONFIRM);
  if (session?.active && session.endConfirmationUntil > Date.now()) await chrome.alarms.create(ALARMS.FOCUS_EXIT_CONFIRM, { when: session.endConfirmationUntil });
}

async function safeFocusNotification(title, message) {
  try { await notify("focus-mode", title, message); } catch {}
}

async function settleFocusDeadline() {
  for (let attempt = 0; attempt < 28; attempt += 1) {
    const current = await getState();
    const session = current.focusSession;
    if (session?.active && session.endConfirmationUntil) {
      if (session.endConfirmationUntil <= Date.now() && ["strict", "breaks"].includes(session.mode)) return stopFocus("early-exit-confirmed");
      if (session.endConfirmationUntil > Date.now()) return current;
    }
    if (!session?.active || session.paused || session.phase === "completed" || sessionRemainingMs(session) > 0) return current;
    if (session.mode !== "breaks") return stopFocus("complete");
    const transition = advanceFocusSessionPhase(session, Date.now());
    if (!transition) return current;
    let committed = false;
    const next = await setState((saved) => {
      const live = saved.focusSession;
      if (!live?.active || live.id !== session.id || live.phase !== session.phase || live.endsAt !== session.endsAt) return saved;
      committed = true;
      return { ...saved, focusSession: transition.session };
    });
    if (!committed) continue;
    await scheduleFocusEnd(next.focusSession);
    if (transition.session.phase === "break") {
      await stopAttentionMonitor("break");
      await safeFocusNotification("Study period complete", "Your scheduled break is starting.");
    } else if (transition.session.phase === "study") {
      await startAttentionMonitor(transition.session, next);
      await safeFocusNotification("Break complete", "Focus protection is back on.");
    } else if (transition.completed) {
      await stopFocus("complete");
      return getState();
    }
    await enforceRedirectRules();
  }
  return getState();
}

async function startFocus(payload = {}) {
  let current = await getState();
  if (current.focusSession?.active) {
    if (sessionRemainingMs(current.focusSession) <= 0) current = await settleFocusDeadline();
    if (current.focusSession?.active) {
      return current;
    }
  }
  if (payload.commitmentConfirmed !== true) throw new Error("Review and confirm your Focus session before starting.");
  const course = current.courses.find((item) => item.id === payload.courseId) || getActiveCourse(current);
  if (!course) throw new Error("Add a course link before starting focus.");
  const mode = ["normal", "strict", "breaks"].includes(payload.mode) ? payload.mode : current.settings.defaultFocusMode;
  const rawDuration = Number(payload.durationMinutes ?? current.settings.focusMinutesDefault);
  const duration = mode === "breaks" ? rawDuration : Math.max(5, Math.min(240, rawDuration || current.settings.focusMinutesDefault));
  const rawBreakDuration = Number(payload.breakDurationMinutes ?? current.settings.focusBreakMinutesDefault);
  const rawBreaksCount = Number(payload.breaksCount ?? payload.cycles ?? current.settings.focusBreakCyclesDefault);
  const breakDuration = mode === "breaks" ? rawBreakDuration : Math.max(1, Math.min(60, rawBreakDuration || 10));
  const breaksCount = mode === "breaks" ? rawBreaksCount : Math.max(0, Math.min(12, Math.floor(rawBreaksCount || 0)));
  const breakSchedule = mode === "breaks" ? validateBreakSchedule(duration, breaksCount, breakDuration) : null;
  if (breakSchedule && !breakSchedule.valid) throw new Error(breakSchedule.message);
  const startedAt = Date.now();
  const studyBlockDurationsMs = mode === "breaks" ? createBreakStudyBlocks(duration, breaksCount) : [];
  const phaseDurationMs = mode === "breaks" ? studyBlockDurationsMs[0] : duration * 60000;
  const subject = normalizeSubject(course.subject || "Other");
  const session = {
    id: uid("session"),
    active: true,
    courseId: course.id,
    courseTitle: course.title,
    courseUrl: course.url,
    subject,
    startedAt,
    phaseStartedAt: startedAt,
    endsAt: startedAt + phaseDurationMs,
    durationMinutes: duration,
    studyDurationMinutes: duration,
    breakDurationMinutes: breakDuration,
    cyclesTotal: mode === "breaks" ? breaksCount + 1 : 1,
    cyclesCompleted: 0,
    scheduleVersion: mode === "breaks" ? 2 : 1,
    breaksTotal: mode === "breaks" ? breaksCount : 0,
    studyBlocksTotal: mode === "breaks" ? breaksCount + 1 : 1,
    studyBlocksCompleted: 0,
    studyBlockDurationsMs,
    studyBlockElapsedMs: 0,
    completedStudyMs: 0,
    timingVersion: 1,
    activeIntervals: [],
    activeIntervalStartedAt: startedAt,
    phaseDurationMs,
    phase: "study",
    mode,
    paused: false,
    pausedAt: null,
    remainingMs: phaseDurationMs,
    accumulatedPausedMs: 0,
    distractionsBlocked: 0,
    lastReminderAt: 0
  };
  let started = false;
  const next = await setState((state) => {
    if (state.focusSession?.active) return state;
    started = true;
    return {
      ...state,
      settings: { ...state.settings, defaultCourseId: course.id, focusMinutesDefault: duration, defaultFocusMode: mode, ...(mode === "breaks" ? { focusBreakMinutesDefault: breakDuration, focusBreakCyclesDefault: breaksCount } : {}) },
      courses: state.courses.map((item) => item.id === course.id ? { ...item, subject, lastUsedAt: Date.now() } : item),
      focusSession: session,
      focusCompletion: null,
      attention: { ...state.attention, active: false, status: state.settings.cameraAttentionConsentAccepted && state.settings.cameraAttentionEnabled ? "starting" : "off", reason: null, error: null, distractionCount: 0, calibratedAt: null },
      assistant: buildAssistantState({ ...state, focusSession: session }, "steady")
    };
  });
  if (!started) return next;
  await scheduleFocusEnd(session);
  await startAttentionMonitor(session, next);
  await openCourse(course.url);
  await enforceRedirectRules();
  await notify("focus-start", "Focus started", focusModeLabel(mode) + " is ready. Site protection follows your Focus and Outside Focus settings.", ["Open course", "Dashboard"]);
  return getState();
}

async function stopFocus(reason = "manual") {
  const current = await getState();
  const session = current.focusSession;
  if (!session?.active) return current;
  if (["strict", "breaks"].includes(session.mode) && reason === "manual") return requestFocusEnd();
  let committed = false;
  let completedResult = false;
  const next = await setState((state) => {
    const liveSession = state.focusSession;
    if (!liveSession?.active || liveSession.id !== session.id) return state;
    const remaining = sessionRemainingMs(liveSession);
    const completed = reason === "complete" || (!liveSession.endConfirmationUntil && !liveSession.paused && remaining <= 0);
    const trackedElapsed = focusElapsedMinutes(liveSession);
    const elapsed = liveSession.mode === "breaks"
      ? (completed && Number(liveSession.scheduleVersion) === 2 ? Math.max(0, Number(liveSession.durationMinutes) || trackedElapsed) : trackedElapsed)
      : completed ? Math.max(1, Number(liveSession.durationMinutes) || trackedElapsed) : trackedElapsed;
    const historyStatus = reason === "interrupted" ? "interrupted" : completed ? "completed" : "incomplete";
    const analytics = recordFocusAnalytics(state.analytics, liveSession, elapsed, completed, historyStatus);
    committed = true;
    completedResult = completed;
    return {
      ...state,
      focusSession: null,
      focusCompletion: completed ? {
        id: liveSession.id,
        courseTitle: liveSession.courseTitle,
        subject: liveSession.subject || "Other",
        durationMinutes: elapsed,
        xpEarned: sessionXp(elapsed, true),
        todayTotalMinutes: (state.stats.focusMinutes || 0) + elapsed,
        streak: analytics.streak?.current || 1,
        completedAt: Date.now()
      } : state.focusCompletion,
      analytics,
      stats: {
        ...state.stats,
        focusMinutes: state.stats.focusMinutes + elapsed,
        sessionsCompleted: state.stats.sessionsCompleted + (completed ? 1 : 0)
      },
      assistant: buildAssistantState({ ...state, focusSession: null }, "steady")
    };
  });
  if (!committed) return next;
  await chrome.alarms.clear(ALARMS.FOCUS_END);
  await chrome.alarms.clear(ALARMS.FOCUS_BREAK_ENDING);
  await chrome.alarms.clear(ALARMS.FOCUS_EXIT_CONFIRM);
  await stopAttentionMonitor("off");
  await clearNotifications("focus-start");
  await enforceRedirectRules();
  if (completedResult) await notify("focus-complete", "Focus complete", "Session finished. Start the next block when you are ready.", ["Dashboard"]);
  return getState();
}

async function pauseFocus() {
  let current = await getState();
  if (current.focusSession?.active && !current.focusSession.paused && sessionRemainingMs(current.focusSession) <= 0) {
    await settleFocusDeadline();
    current = await getState();
  }
  const session = current.focusSession;
  if (!session?.active || session.paused || session.mode === "strict" || session.mode === "breaks" || session.phase === "break") return current;
  let committed = false;
  const next = await setState((state) => {
    const liveSession = state.focusSession;
    if (!liveSession?.active || liveSession.id !== session.id || liveSession.paused) return state;
    const now = Date.now();
    const remainingMs = sessionRemainingMs(liveSession, now);
    if (remainingMs <= 0) return state;
    committed = true;
    const closed = closeFocusStudyInterval(liveSession, now);
    return { ...state, focusSession: { ...closed, paused: true, pausedAt: now, remainingMs, endsAt: now + remainingMs } };
  });
  if (!committed) {
    await settleFocusDeadline();
    return getState();
  }
  await chrome.alarms.clear(ALARMS.FOCUS_END);
  await stopAttentionMonitor("paused");
  await enforceRedirectRules();
  return getState();
}

async function resumeFocus() {
  const current = await getState();
  const session = current.focusSession;
  if (!session?.active || !session.paused || session.mode === "strict" || session.mode === "breaks") return current;
  if (Number(session.remainingMs) <= 0) return stopFocus("complete");
  let committed = false;
  let resumed = null;
  const next = await setState((state) => {
    const liveSession = state.focusSession;
    if (!liveSession?.active || liveSession.id !== session.id || !liveSession.paused) return state;
    const remainingMs = Math.max(0, Number(liveSession.remainingMs) || 0);
    const now = Date.now();
    resumed = {
      ...liveSession,
      timingVersion: 1,
      activeIntervalStartedAt: now,
      paused: false,
      pausedAt: null,
      remainingMs,
      accumulatedPausedMs: (liveSession.accumulatedPausedMs || 0) + Math.max(0, now - (liveSession.pausedAt || now)),
      endsAt: now + remainingMs
    };
    committed = true;
    return { ...state, focusSession: resumed };
  });
  if (!committed) return next;
  await scheduleFocusEnd(resumed);
  await startAttentionMonitor(resumed, next);
  await enforceRedirectRules();
  return getState();
}

async function requestFocusEnd() {
  let current = await getState();
  let session = current.focusSession;
  if (!session?.active) return current;
  if (!["strict", "breaks"].includes(session.mode)) return stopFocus("manual");
  if (session.endConfirmationUntil && session.endConfirmationUntil <= Date.now()) return stopFocus("early-exit-confirmed");
  if (session.endConfirmationUntil > Date.now()) return current;
  if (sessionRemainingMs(session) <= 0) {
    await settleFocusDeadline();
    current = await getState();
    session = current.focusSession;
    if (!session?.active) return current;
  }
  const now = Date.now();
  const remainingMs = sessionRemainingMs(session, now);
  const until = now + 10000;
  let committed = false;
  const next = await setState((saved) => {
    const live = saved.focusSession;
    if (!live?.active || live.id !== session.id || live.endConfirmationUntil > now) return saved;
    let updated = live;
    if (live.mode === "breaks" && Number(live.scheduleVersion) === 2 && live.phase === "study") {
      const blockIndex = Math.min(Number(live.studyBlocksCompleted) || 0, Math.max(0, (Number(live.studyBlocksTotal) || 1) - 1));
      const blockDuration = Number(live.studyBlockDurationsMs?.[blockIndex]) || Number(live.phaseDurationMs) || 0;
      const intervalStart = Number(live.activeIntervalStartedAt) || now;
      const accrued = Math.max(0, Math.min(remainingMs ? blockDuration : 0, now - intervalStart));
      const closed = closeFocusStudyInterval(live, now);
      updated = { ...closed, studyBlockElapsedMs: Math.min(blockDuration, (Number(live.studyBlockElapsedMs) || 0) + accrued) };
    } else if (live.phase === "study" && live.mode === "breaks") {
      const phaseDuration = Math.max(0, Number(live.phaseDurationMs) || Number(live.studyDurationMinutes) * 60000);
      const elapsedInPhase = Math.max(0, Math.min(phaseDuration, now - Number(live.phaseStartedAt || now)));
      const closed = closeFocusStudyInterval(live, now);
      updated = {
        ...closed,
        completedStudyMs: Math.max(0, Number(live.completedStudyMs) || 0) + elapsedInPhase,
        phaseDurationMs: Math.max(0, remainingMs),
        phaseStartedAt: now
      };
    } else if (live.phase === "study") {
      updated = closeFocusStudyInterval(live, now);
    }
    committed = true;
    return { ...saved, focusSession: { ...updated, endConfirmationUntil: until, endConfirmationRemainingMs: remainingMs, endConfirmationStudyElapsedMs: focusElapsedMs(live, now), remainingMs, activeIntervalStartedAt: null } };
  });
  if (!committed) return next;
  await scheduleFocusEnd(next.focusSession);
  if (session.phase === "study") await stopAttentionMonitor("paused");
  return next;
}

async function cancelFocusEnd() {
  const current = await getState();
  const session = current.focusSession;
  if (!session?.active || !session.endConfirmationUntil) return current;
  if (session.endConfirmationUntil <= Date.now()) return stopFocus("early-exit-confirmed");
  const now = Date.now();
  let resumed = null;
  let committed = false;
  const next = await setState((saved) => {
    if (saved.focusSession?.id !== session.id || !saved.focusSession.endConfirmationUntil) return saved;
    const live = saved.focusSession;
    const remainingMs = Math.max(0, Number(live.endConfirmationRemainingMs) || 0);
    resumed = {
      ...live,
      endsAt: now + remainingMs,
      remainingMs,
      activeIntervalStartedAt: live.phase === "study" ? now : null,
      endConfirmationUntil: null,
      endConfirmationRemainingMs: null,
      endConfirmationStudyElapsedMs: null
    };
    committed = true;
    return { ...saved, focusSession: resumed };
  });
  if (!committed) return next;
  await chrome.alarms.clear(ALARMS.FOCUS_EXIT_CONFIRM);
  await scheduleFocusEnd(resumed);
  if (resumed.phase === "study") await startAttentionMonitor(resumed, next);
  await enforceRedirectRules();
  return getState();
}

async function confirmFocusEnd() { return stopFocus("early-exit-confirmed"); }

async function openCourse(url) {
  if (isHttpUrl(url)) await chrome.tabs.create({ url, active: true });
}

async function openDashboard(params = {}) {
  const query = new URLSearchParams(params).toString();
  return chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html" + (query ? "?" + query : "")) });
}

function guidedTourStateIsActive(state) {
  return Boolean(state?.profile?.onboarded
    && state.profile.guidedTourStatus === "not_started"
    && state.profile.guidedTourActive);
}

async function readGuidedTourSessionRecord() {
  try {
    const values = await chrome.storage.session.get(GUIDED_TOUR_SESSION_KEY);
    return values?.[GUIDED_TOUR_SESSION_KEY] || null;
  } catch { return null; }
}

async function findGuidedTourDashboardTab(state) {
  const profile = state?.profile || {};
  const saved = await readGuidedTourSessionRecord();
  const storedSessionMatches = saved?.active === true
    && saved.sessionId
    && saved.sessionId === profile.guidedTourSessionId
    && Number.isInteger(Number(saved.tabId));
  const rawTabId = storedSessionMatches ? saved.tabId : profile.guidedTourTabId;
  const tabId = rawTabId === null || rawTabId === undefined || rawTabId === "" ? null : Number(rawTabId);
  if (!Number.isInteger(tabId) || tabId < 0) return null;
  try { return await chrome.tabs.get(tabId); } catch { return null; }
}

async function focusDashboardTab(tab) {
  if (!Number.isInteger(tab?.id)) return;
  try { await chrome.tabs.update(tab.id, { active: true }); } catch {}
  try {
    if (Number.isInteger(tab.windowId) && chrome.windows?.update) await chrome.windows.update(tab.windowId, { focused: true });
  } catch {}
}

function guidedTourHandoffUrl(handoff) {
  const params = new URLSearchParams({ section: "courses", guidedTourHandoff: handoff.id });
  return chrome.runtime.getURL("dashboard.html?" + params.toString());
}

async function persistGuidedTourHandoff(state, target, tourTab) {
  const url = canonicalYouTubeVideoUrl(target?.url || "");
  if (!url) return null;
  const storedTourSession = await readGuidedTourSessionRecord();
  const sessionRecordMatchesProfile = storedTourSession?.active
    && Number(storedTourSession.tabId) === Number(state.profile?.guidedTourTabId);
  const sessionId = state.profile?.guidedTourSessionId
    || (sessionRecordMatchesProfile ? storedTourSession.sessionId : "")
    || uid("guided-tour-session");
  const rawStoredTabId = storedTourSession?.sessionId === sessionId && storedTourSession?.active
    ? storedTourSession.tabId
    : state.profile?.guidedTourTabId;
  const storedTabId = rawStoredTabId === null || rawStoredTabId === undefined || rawStoredTabId === "" ? null : Number(rawStoredTabId);
  const handoff = {
    id: uid("guided-tour-handoff"),
    sessionId,
    url,
    title: safeYouTubeTitle(target?.title, ""),
    step: 2,
    tabId: Number.isInteger(tourTab?.id) ? tourTab.id : (Number.isInteger(storedTabId) && storedTabId >= 0 ? storedTabId : null),
    createdAt: Date.now()
  };
  const next = await setState((current) => {
    if (!guidedTourStateIsActive(current)
      || Number(current.profile?.guidedTourStep) !== 2
      || (current.profile?.guidedTourSessionId && current.profile.guidedTourSessionId !== sessionId)) return current;
    const currentHandoff = current.profile?.guidedTourHandoff;
    if (currentHandoff?.url === url
      && currentHandoff?.sessionId === sessionId
      && Date.now() - Number(currentHandoff.createdAt || 0) < 60_000) return current;
    return {
      ...current,
      profile: {
        ...(current.profile || {}),
        guidedTourSessionId: sessionId,
        guidedTourStep: handoff.step,
        guidedTourTabId: handoff.tabId ?? current.profile?.guidedTourTabId ?? null,
        guidedTourHandoff: handoff,
        guidedTourUpdatedAt: handoff.createdAt
      }
    };
  });
  return next.profile?.guidedTourHandoff?.sessionId === sessionId ? next.profile.guidedTourHandoff : null;
}

async function reconnectGuidedTourTab(tourTab, handoff) {
  if (!Number.isInteger(tourTab?.id) || !handoff) return false;
  await focusDashboardTab(tourTab);
  try {
    const response = await chrome.tabs.sendMessage(tourTab.id, {
      type: "guidedTourYouTubeHandoff",
      dashboardTabId: tourTab.id,
      handoffId: handoff.id,
      sessionId: handoff.sessionId,
      videoUrl: handoff.url,
      videoTitle: handoff.title
    });
    if (response?.handled) return true;
  } catch {}
  // The original dashboard may still be loading. Reload that same tab with the
  // durable handoff id so it can resume without opening a second tutorial tab.
  try {
    await chrome.tabs.update(tourTab.id, { url: guidedTourHandoffUrl(handoff), active: true });
    await focusDashboardTab(tourTab);
    return true;
  } catch {
    return false;
  }
}

async function routeYouTubeAdd(target) {
  const state = await getState();
  const isCoursesTourStep = Number(state.profile?.guidedTourStep) === 2;
  if (target && guidedTourStateIsActive(state) && isCoursesTourStep) {
    const tourTab = await findGuidedTourDashboardTab(state);
    const handoff = await persistGuidedTourHandoff(state, target, tourTab);
    if (!handoff) return;
    if (tourTab) {
      if (await reconnectGuidedTourTab(tourTab, handoff)) return;
      try {
        const stillOpen = await chrome.tabs.get(tourTab.id);
        if (stillOpen) {
          await focusDashboardTab(stillOpen);
          return;
        }
      } catch {}
    }
    // Create a replacement only when the explicit originating tab no longer exists.
    const replacement = await openDashboard({ section: "courses", guidedTourHandoff: handoff.id });
    if (Number.isInteger(replacement?.id)) {
      await chrome.storage.session.set({
        [GUIDED_TOUR_SESSION_KEY]: {
          active: true,
          sessionId: handoff.sessionId,
          tabId: replacement.id,
          step: handoff.step,
          updatedAt: Date.now()
        }
      }).catch(() => {});
    }
    return;
  }
  await openDashboard({ section: "courses", youtubeAdd: target ? "1" : "invalid", youtubeUrl: target?.url || "", youtubeTitle: target?.title || "" });
}

function isIncognitoAccessAllowed() {
  return new Promise((resolve) => {
    try {
      chrome.extension.isAllowedIncognitoAccess((allowed) => {
        void chrome.runtime.lastError;
        resolve(Boolean(allowed));
      });
    } catch { resolve(false); }
  });
}

async function shouldRedirect(state, tab) {
  const url = tab?.url;
  if (!url || isInternalUrl(url) || !isHttpUrl(url)) return false;
  if (!await hasWebsiteProtectionPermissions()) return false;
  if (!shouldApplyProtectionToTab(state.settings, Boolean(tab?.incognito))) return false;
  if (url.includes(chrome.runtime.getURL("redirect.html")) || url.includes(chrome.runtime.getURL("dashboard.html"))) return false;
  return shouldRedirectByDistractionProtection(state, url);
}

async function recordDistraction(url, reason) {
  if (!await hasWebsiteProtectionPermissions()) return;
  const now = Date.now();
  return setState((state) => {
    if (!isDistractionProtectionActive(state)) return state;
    const session = isFocusSessionProtectionActive(state) ? { ...state.focusSession, distractionsBlocked: (state.focusSession.distractionsBlocked || 0) + 1, lastReminderAt: now } : state.focusSession;
    const protection = recordProtectionEvent(state.protection, "blockedAttempts", { at: now, type: "blocked", host: compactHost(url), reason });
    return {
      ...state,
      focusSession: session,
      stats: { ...state.stats, distractions: state.stats.distractions + 1 },
      analytics: recordDistractionAnalytics(state.analytics),
      protection,
      assistant: buildAssistantState({ ...state, protection, stats: { ...state.stats, distractions: state.stats.distractions + 1 } }, "repeatedDistractions")
    };
  });
}

async function redirectTab(tab, reason) {
  if (!tab?.id || !tab.url) return;
  const last = redirectCooldown.get(tab.id) || 0;
  if (Date.now() - last < 900) return;
  redirectCooldown.set(tab.id, Date.now());
  const state = await getState();
  if (!await shouldRedirect(state, tab)) return;
  const session = state.focusSession;
  const course = session ? state.courses.find((item) => item.id === session.courseId) : getActiveCourse(state);
  if (shouldPersistProtectionEvent(Boolean(tab.incognito))) await recordDistraction(tab.url, reason);
  const fallback = !course?.url;
  const params = new URLSearchParams({
    courseUrl: fallback ? chrome.runtime.getURL("dashboard.html?section=courses") : course.url,
    courseTitle: fallback ? "your Studizen dashboard" : course.title,
    source: compactHost(tab.url),
    reason,
    remainingSeconds: String(session?.paused ? 0 : Math.max(0, Math.ceil(sessionRemainingMs(session) / 1000))),
    fallback: fallback ? "1" : "0"
  });
  await chrome.tabs.update(tab.id, { url: chrome.runtime.getURL("redirect.html?" + params.toString()) });
}

async function checkTab(tab, reason = "tab-change") {
  if (!tab?.url) return;
  const previous = tabCheckCooldown.get(tab.id);
  if (previous?.url === tab.url && Date.now() - previous.at < 600) return;
  tabCheckCooldown.set(tab.id, { url: tab.url, at: Date.now() });
  let state = await settleFocusDeadline();
  if (await shouldRedirect(state, tab)) await redirectTab(tab, reason);
}

async function enforceRedirectRules() {
  const tabs = await chrome.tabs.query({});
  await Promise.all(tabs.map((tab) => checkTab(tab, "redirect-rules").catch(() => {})));
}

chrome.permissions?.onAdded?.addListener(onWebsiteProtectionPermissionsChanged);
chrome.permissions?.onRemoved?.addListener(onWebsiteProtectionPermissionsChanged);

chrome.runtime.onInstalled.addListener(async (details) => {
  await registerCourseContextMenu();
  await clearLegacyHydrationArtifacts();
  const state = await getState();
  await scheduleDailyRollover();
  await enforceRedirectRules();
  await syncYouTubeStudyModeTabs(state);
  await updateBadge(state);
  if (details.reason === "install") await openDashboard({ welcome: "1" });
});
async function restoreSchedules(markWelcome = false) {
  await registerCourseContextMenu();
  await clearAttentionNotification();
  await clearLegacyHydrationArtifacts();
  let state = await settleFocusDeadline();
  state = await getState();
  await scheduleDailyRollover();
  if (markWelcome && state.focusSession?.active && sessionRemainingMs(state.focusSession) > 0) {
    state = await setState((current) => ({
      ...current,
      focusSession: { ...current.focusSession, welcomeBack: true, restoredAt: Date.now() }
    }));
  }
  await scheduleFocusEnd(state.focusSession);
  if (sessionIsInStudyPhase(state.focusSession) && sessionRemainingMs(state.focusSession) > 0) await startAttentionMonitor(state.focusSession, state);
  else if (state.attention?.active) await stopAttentionMonitor(state.focusSession?.paused ? "paused" : "off");
  await enforceRedirectRules();
  await syncYouTubeStudyModeTabs(state);
  await updateBadge(state);
}
chrome.runtime.onStartup.addListener(() => restoreSchedules(true));
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === ALARMS.DAILY_ROLLOVER) {
    await getState();
    await scheduleDailyRollover();
  }
  if (alarm.name === ALARMS.FOCUS_END) await settleFocusDeadline();
  if (alarm.name === ALARMS.FOCUS_EXIT_CONFIRM) {
    const state = await getState();
    if (state.focusSession?.active && ["strict", "breaks"].includes(state.focusSession.mode) && state.focusSession.endConfirmationUntil && state.focusSession.endConfirmationUntil <= Date.now()) await stopFocus("early-exit-confirmed");
  }
  if (alarm.name === ALARMS.FOCUS_BREAK_ENDING) {
    const state = await getState();
    const session = state.focusSession;
    if (session?.active && session.phase === "break" && session.endsAt > Date.now() && session.breakEndingFor !== session.endsAt) {
      const phaseEnd = session.endsAt;
      await setState((saved) => saved.focusSession?.id === session.id && saved.focusSession.endsAt === phaseEnd
        ? { ...saved, focusSession: { ...saved.focusSession, breakEndingFor: phaseEnd } }
        : saved);
      await safeFocusNotification("Break almost over", "Your break is nearly over. Focus protection will return automatically.");
    }
  }
  if (alarm.name === ALARMS.ATTENTION_DISMISS) await clearAttentionNotification();
});
chrome.notifications.onButtonClicked.addListener(async (id, index) => {
  if (id.startsWith("focus-start") && index === 0) {
    const course = getActiveCourse(await getState());
    if (course?.url) await openCourse(course.url);
  } else await openDashboard();
  await chrome.notifications.clear(id);
});
chrome.notifications.onClicked.addListener(async (id) => { await openDashboard(); await chrome.notifications.clear(id); });
chrome.notifications.onClosed.addListener((id) => {
  if (isAttentionNotificationId(id)) forgetClosedAttentionNotification(id).catch(() => {});
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" || changeInfo.url) {
    const url = changeInfo.url || tab?.url;
    checkTab({ ...tab, id: tabId, url }, "tab-updated").catch(() => {});
  }
});
chrome.tabs.onActivated.addListener(async ({ tabId }) => { try { await checkTab(await chrome.tabs.get(tabId), "tab-activated"); } catch {} });
chrome.tabs.onCreated.addListener((tab) => { if (tab?.url) checkTab(tab, "tab-created").catch(() => {}); });
chrome.tabs.onRemoved.addListener((tabId) => { redirectCooldown.delete(tabId); tabCheckCooldown.delete(tabId); youtubeContextTargets.delete(tabId); });
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== ADD_TO_COURSE_CONTEXT_MENU_ID) return;
  const captureSequence = ++youtubeContextCaptureSequence;
  youtubeContextDebug("context-menu-click", {
    linkUrl: String(info?.linkUrl || ""),
    pageUrl: String(info?.pageUrl || ""),
    srcUrl: String(info?.srcUrl || ""),
    mediaType: String(info?.mediaType || ""),
    tabId: Number.isInteger(tab?.id) ? tab.id : null,
    tabUrl: String(tab?.url || "")
  });
  resolveContextVideoTarget(info, tab?.id, tab?.url || "").then((target) => {
    if (captureSequence !== youtubeContextCaptureSequence) {
      youtubeContextDebug("capture-discarded-as-stale", { captureSequence, latestSequence: youtubeContextCaptureSequence });
      return;
    }
    return routeYouTubeAdd(target);
  }).catch((error) => {
    youtubeContextDebug("handoff-failed", { reason: String(error?.message || error || "unknown").slice(0, 160) });
  });
});

if (chrome.contextMenus.onShown) {
  chrome.contextMenus.onShown.addListener((info, tab) => {
    chrome.contextMenus.update(ADD_TO_COURSE_CONTEXT_MENU_ID, { visible: Boolean(contextVideoTarget(info, tab?.id, tab?.url || "")) }, () => {
      void chrome.runtime.lastError;
      chrome.contextMenus.refresh();
    });
  });
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    const type = message?.type;
    if (type === "lookupYouTubeTitle") {
      const extensionRoot = chrome.runtime.getURL("/");
      if (sender?.id !== chrome.runtime.id || !String(sender?.url || "").startsWith(extensionRoot)) throw new Error("YouTube title lookup is available only from Studizen.");
      if (message?.consent !== true) return { videoUrl: canonicalYouTubeVideoUrl(message?.videoUrl || ""), title: "", reason: "consent-required" };
      return requestYouTubeOembedTitle(message?.videoUrl || "", { consent: message.consent });
    }
    if (type === "syncGuidedTourSession") {
      const senderTabId = sender?.tab?.id;
      const payload = message.payload || {};
      const sessionId = String(payload.sessionId || "").trim().slice(0, 96);
      if (!Number.isInteger(senderTabId) || !sessionId) return { synced: false };
      if (payload.active) {
        const current = await getState();
        if (!guidedTourStateIsActive(current)
          || current.profile?.guidedTourSessionId !== sessionId
          || Number(current.profile?.guidedTourTabId) !== senderTabId) return { synced: false };
        await chrome.storage.session.set({
          [GUIDED_TOUR_SESSION_KEY]: {
            active: true,
            sessionId,
            tabId: senderTabId,
            step: Math.max(0, Math.min(7, Number(payload.step) || 0)),
            updatedAt: Date.now()
          }
        });
        return { synced: true };
      }
      const current = await readGuidedTourSessionRecord();
      if (current?.sessionId === sessionId && Number(current.tabId) === senderTabId) {
        await chrome.storage.session.remove(GUIDED_TOUR_SESSION_KEY);
        return { synced: true };
      }
      return { synced: false };
    }
    if (type === "youtubeContextTarget") {
      const tabId = sender?.tab?.id;
      if (!Number.isInteger(tabId)) return { saved: false };
      const url = canonicalYouTubeVideoUrl(message?.payload?.url || "");
      youtubeContextTargets.set(tabId, {
        url,
        title: String(message?.payload?.title || "").trim().slice(0, 180),
        titleSource: String(message?.payload?.titleSource || "").slice(0, 64),
        pageUrl: String(message?.payload?.pageUrl || "").slice(0, 2048),
        at: Date.now()
      });
      youtubeContextDebug("thumbnail-capture", {
        selectedUrl: url,
        videoId: youtubeVideoId(url),
        titleSource: safeYouTubeTitle(message?.payload?.title, "") ? String(message?.payload?.titleSource || "unknown") : "none",
        titleFound: Boolean(safeYouTubeTitle(message?.payload?.title, ""))
      });
      return { saved: Boolean(url) };
    }
    if (type === "getState") return getState();
    if (type === "getWeeklyStudyReport") {
      const state = await getState();
      return buildWeeklyStudyReport(state, message.weekAnchor || new Date(), Date.now());
    }
    if (type === "saveState") {
      const changedSettings = message.patch?.settings || {};
      if (changedSettings.incognitoProtection === true && !await isIncognitoAccessAllowed()) throw new Error("Incognito access required. Enable Allow in Incognito in Chrome settings first.");
      const response = await setState((state) => applyStatePatch(state, message.patch || {}));
      if (["focusSessionProtectionEnabled", "guardBlockedOutsideFocus", "distractionProtectionConsentAccepted", "incognitoProtection", "blockedSites", "allowedSites"].some((key) => Object.hasOwn(changedSettings, key))) await enforceRedirectRules();
      return response;
    }
    if (type === "getIncognitoAccess") return { allowed: await isIncognitoAccessAllowed() };
    if (type === "getYouTubeStudyModeState") {
      const state = await getState();
      return { active: isYouTubeStudyModeActive(state.settings, state.focusSession) };
    }
    if (type === "openIncognitoSettings") {
      await chrome.tabs.create({ url: "chrome://extensions/?id=" + encodeURIComponent(chrome.runtime.id) });
      return { opened: true };
    }
    if (type === "attentionMonitorStatus") return receiveAttentionStatus(message.payload || {});
    if (type === "syncAttentionMonitor") {
      const state = await getState();
      if (sessionIsInStudyPhase(state.focusSession) && sessionRemainingMs(state.focusSession) > 0) return startAttentionMonitor(state.focusSession, state);
      return stopAttentionMonitor(state.focusSession?.paused ? "paused" : "off");
    }
    if (type === "startFocus") return startFocus(message.payload || {});
    if (type === "pauseFocus") return pauseFocus();
    if (type === "resumeFocus") return resumeFocus();
    if (type === "stopFocus") return stopFocus("manual");
    if (type === "requestFocusEnd") return requestFocusEnd();
    if (type === "cancelFocusEnd") return cancelFocusEnd();
    if (type === "confirmFocusEnd") return confirmFocusEnd();
    if (type === "openCourse") { await openCourse(message.url); return getState(); }
    if (type === "openDashboard") { await openDashboard(message.params || {}); return getState(); }
    return getState();
  })().then((response) => sendResponse({ ok: true, response })).catch((error) => sendResponse({ ok: false, error: error.message }));
  return true;
});
restoreSchedules(false);
