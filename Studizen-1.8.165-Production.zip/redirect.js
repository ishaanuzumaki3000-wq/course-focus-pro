import { STATE_KEY, mergeState } from "./shared.js";

const systemThemeQuery = globalThis.matchMedia?.("(prefers-color-scheme: dark)");
const THEME_MODE_CACHE_KEY = "courseFocusProThemeMode";
function resolvedTheme(mode = "dark") { const allowed = ["light", "dark", "midnight", "amoled", "beige"]; if (allowed.includes(mode)) return mode; if (mode === "system") return systemThemeQuery?.matches ? "dark" : "light"; return "dark"; }
async function applyRedirectTheme() { try { const data = await chrome.storage.local.get(STATE_KEY); const state = mergeState(data[STATE_KEY]); const mode = state.settings.themeMode || "dark"; document.documentElement.dataset.theme = resolvedTheme(mode); document.documentElement.dataset.themeMode = mode; try { localStorage.setItem(THEME_MODE_CACHE_KEY, mode); } catch {} } catch { document.documentElement.dataset.theme = resolvedTheme("dark"); } }
applyRedirectTheme();
systemThemeQuery?.addEventListener?.("change", applyRedirectTheme);

const params = new URLSearchParams(location.search);
const courseUrl = params.get("courseUrl") || "";
const courseTitle = params.get("courseTitle") || "your course";
const source = params.get("source") || "another tab";
const dashboardFallback = params.get("fallback") === "1";
const initialRemainingSeconds = Math.max(0, Number(params.get("remainingSeconds")) || 0);

const sourceName = document.querySelector("#sourceName");
const courseName = document.querySelector("#courseName");
const countdown = document.querySelector("#countdown");
const goNowBtn = document.querySelector("#goNowBtn");
const dashboardBtn = document.querySelector("#dashboardBtn");
const redirectHeadline = document.querySelector("#redirectHeadline");
const redirectMessage = document.querySelector("#redirectMessage");
const redirectReturning = document.querySelector("#redirectReturning");
const remainingFocusTime = document.querySelector("#remainingFocusTime");

let seconds = 3;
sourceName.textContent = source;
courseName.textContent = courseTitle;
countdown.textContent = String(seconds);
const messages = [
  "This page is outside your approved study and supporting sites.",
  "Keep this session simple: use your course or an approved study tool.",
  "A quick return keeps your study block on track.",
  "Focus Mode is keeping this session for your course and study tools."
];
const messageIndex = [...(source + courseTitle)].reduce((sum, char) => sum + char.charCodeAt(0), 0) % messages.length;
redirectMessage.textContent = messages[messageIndex];
function formatRemaining(totalSeconds) {
  const minutes = Math.floor(totalSeconds / 60);
  const secondsPart = totalSeconds % 60;
  return minutes ? minutes + "m " + String(secondsPart).padStart(2, "0") + "s remaining" : secondsPart + "s remaining";
}
function renderRemaining() {
  remainingFocusTime.textContent = initialRemainingSeconds > 0
    ? formatRemaining(Math.max(0, initialRemainingSeconds - (3 - seconds))) + " in this focus session"
    : "Focus session active";
}
renderRemaining();
if (dashboardFallback) {
  redirectHeadline.textContent = "Choose a Course";
  redirectMessage.textContent = "Focus Mode needs a selected course before it can return you to study.";
  redirectReturning.textContent = "Opening your dashboard in";
  goNowBtn.textContent = "Open Dashboard Now";
}

function goNow() {
  if (courseUrl) location.replace(courseUrl);
}

goNowBtn.addEventListener("click", goNow);
dashboardBtn.addEventListener("click", () => {
  location.href = chrome.runtime.getURL("dashboard.html");
});

const timer = setInterval(() => {
  seconds -= 1;
  countdown.textContent = String(seconds);
  renderRemaining();
  if (seconds <= 0) {
    clearInterval(timer);
    goNow();
  }
}, 1000);
