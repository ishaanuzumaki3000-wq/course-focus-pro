export const STATE_KEY = "courseFocusProState";
export const ALARMS = { FOCUS_END: "focus-end", FOCUS_BREAK_ENDING: "focus-break-ending", FOCUS_EXIT_CONFIRM: "focus-exit-confirm", ATTENTION_DISMISS: "attention-dismiss", DAILY_ROLLOVER: "daily-rollover" };
export const FOCUS_MODES = ["normal", "strict", "breaks"];
export function normalizeFocusMode(mode) { return FOCUS_MODES.includes(String(mode || "").toLowerCase()) ? String(mode).toLowerCase() : "normal"; }
export function focusModeLabel(mode) { return ({ normal: "Normal Focus", strict: "Strict Focus", breaks: "Focus with Breaks" })[normalizeFocusMode(mode)]; }
export const STUDY_PROFILES = [
  { id: "jee", name: "JEE", subjects: ["Physics", "Chemistry", "Mathematics", "Other"] },
  { id: "neet", name: "NEET", subjects: ["Physics", "Chemistry", "Biology", "Other"] },
  { id: "upsc", name: "UPSC", subjects: ["General Studies", "CSAT", "Current Affairs", "Optional Subject", "Optional Subject / Revision", "History", "Geography", "Politics", "Economy", "Environment", "Science & Tech", "Ethics", "Essay", "Other"] },
  { id: "nda", name: "NDA", subjects: ["Mathematics", "English", "General Ability", "Physics", "Chemistry", "History", "Geography", "Current Affairs", "Other"] },
  { id: "coding-ai", name: "Coding & AI", subjects: ["Programming", "DSA", "Web Development", "Databases", "AI", "Machine Learning", "Projects", "Other"] },
  { id: "school", name: "School", subjects: ["Physics", "Chemistry", "Biology", "Mathematics", "English", "Social Science", "Computer Science", "Other"] },
  { id: "college", name: "College", subjects: ["Core Subject", "Mathematics", "Programming", "Lab Work", "Assignments", "Projects", "Research", "Other"] },
  { id: "accounting", name: "Accounting", subjects: ["Financial Accounting", "Cost Accounting", "Taxation", "Auditing", "Business Studies", "Economics", "Other"] },
  { id: "custom", name: "Self Learner", subjects: ["General", "Revision", "Practice", "Other"] }
];
export const DEFAULT_STUDY_PROFILE = "jee";
export const SUBJECTS = STUDY_PROFILES.find((profile) => profile.id === DEFAULT_STUDY_PROFILE).subjects;
export const STUDY_PROFILE_TARGET_PRESETS = Object.freeze({
  jee: { dailyMinutes: 360, weeklyMinutes: 2160, studyDays: 6, subjectTargets: { Physics: 120, Chemistry: 120, Mathematics: 120 } },
  neet: { dailyMinutes: 360, weeklyMinutes: 2160, studyDays: 6, subjectTargets: { Physics: 120, Chemistry: 120, Biology: 120 } },
  school: { dailyMinutes: 120, weeklyMinutes: 600, studyDays: 5, distributeAcrossProfileSubjects: true },
  college: { dailyMinutes: 180, weeklyMinutes: 900, studyDays: 5, distributeAcrossProfileSubjects: true },
  upsc: { dailyMinutes: 300, weeklyMinutes: 1800, studyDays: 6, subjectTargets: { "General Studies": 180, "Current Affairs": 60, "Optional Subject / Revision": 60 } },
  custom: { dailyMinutes: 120, weeklyMinutes: 600, studyDays: 5, distributeAcrossProfileSubjects: true, defaultSubjects: ["General", "Revision", "Practice"] },
  // Keep suggestions for previously supported profiles so existing users remain compatible.
  nda: { dailyMinutes: 180, weeklyMinutes: 900, studyDays: 5, subjectTargets: { Mathematics: 45, English: 30, "General Ability": 45, Physics: 30, Chemistry: 30 } },
  "coding-ai": { dailyMinutes: 180, weeklyMinutes: 900, studyDays: 5, subjectTargets: { Programming: 45, DSA: 45, "Web Development": 30, AI: 30, Projects: 30 } },
  accounting: { dailyMinutes: 180, weeklyMinutes: 900, studyDays: 5, subjectTargets: { "Financial Accounting": 45, "Cost Accounting": 45, Taxation: 30, Auditing: 30, "Business Studies": 30 } }
});
const cleanStudySubject = (value) => String(value || "").trim().replace(/\s+/g, " ").slice(0, 48);
function distributeDailyTarget(totalMinutes, subjectNames = []) {
  const names = [...new Set(subjectNames.map(cleanStudySubject).filter((name) => name && name.toLowerCase() !== "other"))];
  if (!names.length) return {};
  const quarterHours = Math.floor(Math.max(0, num(totalMinutes)) / 15);
  const base = Math.floor(quarterHours / names.length);
  let remainder = quarterHours % names.length;
  return Object.fromEntries(names.map((name) => {
    const allocation = (base + (remainder-- > 0 ? 1 : 0)) * 15;
    return [name, allocation];
  }));
}
export function studyTargetSuggestions(profileId = DEFAULT_STUDY_PROFILE, selectedSubjects = null) {
  const id = normalizeStudyProfile(profileId);
  const suggestion = STUDY_PROFILE_TARGET_PRESETS[id] || STUDY_PROFILE_TARGET_PRESETS[DEFAULT_STUDY_PROFILE];
  const profileSubjects = STUDY_PROFILES.find((profile) => profile.id === id)?.subjects || [];
  const subjectNames = Array.isArray(selectedSubjects) ? selectedSubjects : (suggestion.defaultSubjects || profileSubjects);
  const subjectTargets = suggestion.distributeAcrossProfileSubjects
    ? distributeDailyTarget(suggestion.dailyMinutes, subjectNames)
    : Object.fromEntries(Object.entries(suggestion.subjectTargets || {}).filter(([subject]) => !Array.isArray(selectedSubjects) || selectedSubjects.includes(subject)));
  return { profileId: id, dailyMinutes: suggestion.dailyMinutes, weeklyMinutes: suggestion.weeklyMinutes, studyDays: suggestion.studyDays, subjectTargets };
}
export function normalizeStudyTargets(input = null, profileId = DEFAULT_STUDY_PROFILE) {
  if (!input || typeof input !== "object" || Array.isArray(input)) return null;
  const suggested = studyTargetSuggestions(input.profileId || profileId);
  const subjectTargets = {};
  Object.entries(input.subjectTargets || {}).slice(0, 80).forEach(([name, minutes]) => {
    const subject = cleanStudySubject(name);
    if (subject) {
      const savedMinutes = Math.max(0, Math.min(10080, num(minutes)));
      subjectTargets[subject] = input.subjectTargetPeriod === "weekly"
        ? Math.round(savedMinutes / 7)
        : Math.min(1440, savedMinutes);
    }
  });
  const customSubjects = [...new Set((Array.isArray(input.customSubjects) ? input.customSubjects : [])
    .map(cleanStudySubject).filter(Boolean))].slice(0, 40);
  const selectedSubjects = Array.isArray(input.selectedSubjects)
    ? [...new Set(input.selectedSubjects.map(cleanStudySubject).filter((name) => name && name.toLowerCase() !== "other"))].slice(0, 80)
    : null;
  return {
    profileId: normalizeStudyProfile(input.profileId || profileId),
    weeklyMinutes: Math.max(0, Math.min(10080, num(input.weeklyMinutes, suggested.weeklyMinutes))),
    studyDays: Math.max(1, Math.min(7, Math.floor(num(input.studyDays, suggested.studyDays)))),
    subjectTargets,
    selectedSubjects,
    subjectTargetPeriod: "daily",
    customSubjects,
    sortBy: input.sortBy === "target" ? "target" : "actual"
  };
}
export function resolveStudyTargets(input = {}) {
  const profileId = normalizeStudyProfile(input.profile?.studyProfile || DEFAULT_STUDY_PROFILE);
  const stored = normalizeStudyTargets(input.goals?.analyticsTargets, profileId);
  const savedSubjectNames = stored
    ? (stored.selectedSubjects || [...new Set([...Object.keys(stored.subjectTargets), ...stored.customSubjects])])
    : null;
  const hasSavedSubjectSelection = Array.isArray(stored?.selectedSubjects)
    || Boolean(stored && (Object.keys(stored.subjectTargets).length || stored.customSubjects.length));
  const selectedSubjects = hasSavedSubjectSelection ? savedSubjectNames : null;
  const suggested = studyTargetSuggestions(profileId, selectedSubjects);
  const selectedSet = Array.isArray(selectedSubjects) ? new Set(selectedSubjects) : null;
  const savedTargets = stored
    ? Object.fromEntries(Object.entries(stored.subjectTargets).filter(([subject]) => !selectedSet || selectedSet.has(subject)))
    : {};
  const resolvedSubjects = { ...suggested.subjectTargets, ...savedTargets };
  const dailyHours = Math.max(0, num(input.goals?.studyHours, suggested.dailyMinutes / 60));
  return {
    profileId,
    dailyMinutes: Math.round(dailyHours * 60),
    weeklyMinutes: stored ? stored.weeklyMinutes : suggested.weeklyMinutes,
    studyDays: stored ? stored.studyDays : suggested.studyDays,
    subjectTargets: resolvedSubjects,
    selectedSubjects: Array.isArray(selectedSubjects) ? [...selectedSubjects] : Object.keys(suggested.subjectTargets),
    customSubjects: (stored?.customSubjects || []).filter((subject) => !selectedSet || selectedSet.has(subject)),
    sortBy: stored?.sortBy || "actual",
    isCustomized: Boolean(stored)
  };
}
export function studyTargetProgress(actualMinutes = 0, targetMinutes = 0) {
  const target = Math.max(0, num(targetMinutes));
  return target ? Math.round((Math.max(0, num(actualMinutes)) / target) * 100) : null;
}
export function studySubjectPeriodTarget(dailyTargetMinutes = 0, periodDays = 7) {
  const dailyTarget = Math.max(0, num(dailyTargetMinutes));
  const days = Math.max(1, Math.min(366, Math.floor(num(periodDays, 7))));
  return Math.round(dailyTarget * days);
}
export function leastMetSubjectTarget(actualBySubject = {}, dailyTargets = {}, periodDays = 7) {
  return Object.entries(dailyTargets || {}).map(([subject, dailyTarget]) => {
    const targetMinutes = studySubjectPeriodTarget(dailyTarget, periodDays);
    const actualMinutes = Math.max(0, num(actualBySubject?.[subject]));
    return { subject, dailyTargetMinutes: Math.max(0, num(dailyTarget)), targetMinutes, actualMinutes, progress: studyTargetProgress(actualMinutes, targetMinutes) };
  }).filter((entry) => entry.targetMinutes > 0 && entry.actualMinutes < entry.targetMinutes)
    .sort((a, b) => a.progress - b.progress || (b.targetMinutes - b.actualMinutes) - (a.targetMinutes - a.actualMinutes) || a.subject.localeCompare(b.subject))[0] || null;
}
export const DEFAULT_COURSE_LIBRARIES = [
  { id: "library-main", name: "My Library", collapsed: false }
];
const LEGACY_PROFILE_LIBRARY_IDS = new Set(["group-jee", "group-coding", "group-ai", "group-upsc", "group-school", "group-college", "group-custom"]);
export const DEFAULT_BLOCKED_SITES = ["instagram.com", "twitter.com", "x.com", "facebook.com", "youtube.com/shorts", "reddit.com", "netflix.com", "primevideo.com", "hotstar.com", "twitch.tv", "discord.com/app", "snapchat.com", "roblox.com", "poki.com", "crazygames.com", "miniclip.com", "steamcommunity.com", "store.steampowered.com"];
export const DEFAULT_ALLOWED_SITES = ["google.com/search", "classroom.google.com", "docs.google.com", "drive.google.com", "sheets.google.com", "slides.google.com", "wikipedia.org", "khanacademy.org", "stackoverflow.com", "github.com", "developer.mozilla.org", "leetcode.com", "geeksforgeeks.org"];
export const DEFAULT_SETTINGS = { themeMode: "dark", focusMinutesDefault: 50, defaultFocusMode: "normal", focusBreakMinutesDefault: 5, focusBreakCyclesDefault: 1, defaultCourseId: null, focusSessionProtectionEnabled: false, guardBlockedOutsideFocus: false, distractionProtectionConsentAccepted: false, incognitoProtection: false, youtubeStudyModeEnabled: false, reminderCooldownMinutes: 2, soundEnabled: true, soundVolume: 35, cameraAttentionEnabled: false, cameraAttentionConsentAccepted: false, cameraAttentionSensitivity: "balanced", cameraAttentionGraceSeconds: 10, cameraAttentionVoice: true, blockedSites: DEFAULT_BLOCKED_SITES, allowedSites: DEFAULT_ALLOWED_SITES };
export const DEFAULT_STUDY_GOALS = { studyHours: 6, chapters: 2, questions: 60 };
export const DEFAULT_DAILY_TASKS = [];
export function attentionVoiceMessage(reason = "") {
  const normalized = String(reason || "").trim().toLowerCase();
  if (["head turned away", "head turned", "head away", "gaze away", "gaze away from screen"].includes(normalized)) return "Stay focused on the course.";
  if (["eyes away", "eyes away from screen"].includes(normalized)) return "Please pay attention to the course.";
  if (normalized === "face not visible") return "Please stay on the course.";
  if (normalized === "eyes closed") return "Please pay attention to the course.";
  return "Stay focused on the course.";
}
export const RANKS = [
  { minLevel: 120, name: "Legend" },
  { minLevel: 90, name: "Discipline Master" },
  { minLevel: 70, name: "Elite Scholar" },
  { minLevel: 50, name: "Focus Master" },
  { minLevel: 35, name: "Achiever" },
  { minLevel: 20, name: "Scholar" },
  { minLevel: 10, name: "Student" },
  { minLevel: 5, name: "Learner" },
  { minLevel: 1, name: "Beginner" }
];
const LEGACY_DEFAULT_TASK_TITLES = new Set(["revise yesterday's notes", "one jee concept block", "solve practice questions"]);
export const ASSISTANT_MESSAGES = { steady: "You only need one clean study block. Choose the course and begin before the mind starts bargaining.", repeatedDistractions: "Your attention is leaking. Choose one course, close the extra tabs, and protect the next ten minutes.", tabSwitching: "Too many tab switches. Keep one course tab, one notes tab, and let the rest wait.", blockedAttempts: "Blocked sites are repeating. Make the task smaller and return to the course now.", browsing: "Browsing is replacing studying. Pick a saved course and start one short focus block." };
export function localTimeZone() {
  try {
    const zone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    return zone === "Asia/Calcutta" ? "Asia/Kolkata" : zone || "Asia/Kolkata";
  } catch { return "Asia/Kolkata"; }
}
export function dateKeyInTimeZone(value = new Date(), timeZone = localTimeZone()) {
  const date = value instanceof Date ? value : new Date(value);
  if (!Number.isFinite(date.getTime())) return "";
  try {
    const parts = new Intl.DateTimeFormat("en-CA", { timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(date);
    const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
    return values.year + "-" + values.month + "-" + values.day;
  } catch {
    const year = date.getFullYear();
    return year + "-" + String(date.getMonth() + 1).padStart(2, "0") + "-" + String(date.getDate()).padStart(2, "0");
  }
}
export function todayKey(date = new Date()) { return dateKeyInTimeZone(date, localTimeZone()); }
export function uid(prefix = "id") { return prefix + "-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8); }
function num(value, fallback = 0) { const n = Number(value); return Number.isFinite(n) ? n : fallback; }
export function cleanPatterns(patterns = []) { return [...new Set((Array.isArray(patterns) ? patterns : []).map((p) => String(p || "").trim().toLowerCase()).filter(Boolean))]; }
export function normalizeUrl(raw = "") { const text = String(raw || "").trim(); if (!text) return ""; if (/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) return text; return "https://" + text; }
export function safeUrl(raw = "") { try { return new URL(normalizeUrl(raw)); } catch { return null; } }
export function isHttpUrl(raw = "") { const url = safeUrl(raw); return Boolean(url && ["http:", "https:"].includes(url.protocol)); }
export function isInternalUrl(raw = "") { return /^(chrome|chrome-extension|edge|about|devtools):/i.test(String(raw || "")); }
export function compactHost(raw = "") { const url = safeUrl(raw); return url ? url.hostname.replace(/^www\./, "") : String(raw || "").replace(/^https?:\/\//, "").split("/")[0]; }
export function patternMatchesUrl(pattern, rawUrl) { const clean = String(pattern || "").trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, ""); const url = safeUrl(rawUrl); if (!clean || !url) return false; const host = url.hostname.toLowerCase().replace(/^www\./, ""); const path = url.pathname.toLowerCase(); const hostAndPath = host + path; if (clean.includes("/")) return hostAndPath.includes(clean); return host === clean || host.endsWith("." + clean); }
export function isBlockedUrl(rawUrl, settings = DEFAULT_SETTINGS) { return cleanPatterns(settings.blockedSites || DEFAULT_BLOCKED_SITES).some((p) => patternMatchesUrl(p, rawUrl)); }
export function isAllowedSupportUrl(rawUrl, settings = DEFAULT_SETTINGS) { return cleanPatterns(settings.allowedSites || DEFAULT_ALLOWED_SITES).some((p) => patternMatchesUrl(p, rawUrl)); }
export function extractYouTube(raw = "") { const url = safeUrl(raw); if (!url) return { videoId: null, playlistId: null }; return { videoId: youtubeVideoId(raw), playlistId: url.searchParams.get("list") || null }; }
export function youtubeVideoId(raw = "") {
  const url = safeUrl(raw);
  if (!url) return null;
  const host = url.hostname.toLowerCase().replace(/^www\./, "");
  if (host === "youtu.be") return url.pathname.split("/").filter(Boolean)[0] || null;
  const youtubeHost = host === "youtube.com" || host.endsWith(".youtube.com")
    || host === "youtube-nocookie.com" || host.endsWith(".youtube-nocookie.com");
  if (!youtubeHost) return null;
  if (url.pathname === "/watch") return url.searchParams.get("v") || null;
  const match = url.pathname.match(/^\/(?:shorts|embed|live)\/([^/?#]+)/i);
  return match?.[1] || null;
}
export function canonicalYouTubeVideoUrl(raw = "") { const id = youtubeVideoId(raw); return id ? "https://www.youtube.com/watch?v=" + encodeURIComponent(id) : ""; }
export function safeYouTubeTitle(raw = "", fallback = "") {
  const title = String(raw || "").replace(/\s+/g, " ").trim().slice(0, 180);
  if (!title || /^youtube video$/i.test(title) || /^(?:\d{1,2}:)?\d{1,2}:\d{2}$/.test(title) || /^\d+\s*(?:s|sec|secs|second|seconds|min|mins|minute|minutes)$/i.test(title)) return fallback;
  return title;
}
export function isYouTubeVideoUrl(raw = "") { return Boolean(canonicalYouTubeVideoUrl(raw)); }
export async function requestYouTubeOembedTitle(rawUrl, { consent = false, fetchImpl = globalThis.fetch, timeoutMs = 3500 } = {}) {
  const videoUrl = canonicalYouTubeVideoUrl(rawUrl);
  if (consent !== true) return { videoUrl, title: "", reason: "consent-required" };
  if (!videoUrl) return { videoUrl: "", title: "", reason: "unsupported-selected-url" };
  if (typeof fetchImpl !== "function") return { videoUrl, title: "", reason: "fetch-unavailable" };

  const controller = typeof AbortController === "function" ? new AbortController() : null;
  const timeout = controller ? setTimeout(() => controller.abort(), timeoutMs) : null;
  try {
    const response = await fetchImpl("https://www.youtube.com/oembed?url=" + encodeURIComponent(videoUrl) + "&format=json", {
      credentials: "omit",
      ...(controller ? { signal: controller.signal } : {})
    });
    if (!response.ok) return { videoUrl, title: "", reason: "youtube-oembed-http-" + response.status };
    const data = await response.json();
    const title = safeYouTubeTitle(data?.title, "");
    return title ? { videoUrl, title, reason: "" } : { videoUrl, title: "", reason: "youtube-oembed-title-unavailable" };
  } catch (error) {
    return { videoUrl, title: "", reason: String(error?.name === "AbortError" ? "youtube-oembed-timeout" : error?.message || "youtube-oembed-request-failed").slice(0, 160) };
  } finally {
    if (timeout !== null) clearTimeout(timeout);
  }
}
export function normalizeGuidedTourHandoff(input = null) {
  if (!input || typeof input !== "object") return null;
  const id = String(input.id || "").trim().slice(0, 96);
  const url = canonicalYouTubeVideoUrl(input.url || "");
  const sessionId = String(input.sessionId || "").trim().slice(0, 96);
  const createdAt = Math.floor(num(input.createdAt));
  if (!id || !url || createdAt <= 0) return null;
  return {
    id,
    url,
    title: safeYouTubeTitle(input.title, ""),
    step: Math.max(0, Math.min(50, Math.floor(num(input.step)))),
    tabId: Number.isInteger(Number(input.tabId)) && Number(input.tabId) > 0 ? Number(input.tabId) : null,
    createdAt,
    ...(sessionId ? { sessionId } : {})
  };
}
// Prefer the clicked link, then the clicked page, then its callback tab URL.
// A media source is considered only when it is itself a YouTube video URL.
export function contextMenuYouTubeUrl(info = {}, tabUrl = "") {
  const linkUrl = String(info?.linkUrl || "").trim();
  const linkedVideo = canonicalYouTubeVideoUrl(linkUrl);
  if (linkedVideo) return linkedVideo;
  const pageVideo = canonicalYouTubeVideoUrl(info?.pageUrl || "");
  if (pageVideo) return pageVideo;
  const callbackTabVideo = canonicalYouTubeVideoUrl(tabUrl);
  if (callbackTabVideo) return callbackTabVideo;
  return canonicalYouTubeVideoUrl(info?.srcUrl || "");
}
export function courseHasVideo(course, rawUrl = "") {
  const id = youtubeVideoId(rawUrl);
  if (!id || !course) return false;
  if (youtubeVideoId(course.url) === id) return true;
  return (Array.isArray(course.videos) ? course.videos : []).some((video) => youtubeVideoId(video?.url) === id);
}
export function courseMatchesUrl(course, rawUrl) { if (!course?.url || !rawUrl) return false; const courseUrl = safeUrl(course.url); const targetUrl = safeUrl(rawUrl); if (!courseUrl || !targetUrl) return false; const cYt = extractYouTube(course.url); const tYt = extractYouTube(rawUrl); if (cYt.playlistId && tYt.playlistId === cYt.playlistId) return true; if (cYt.videoId && tYt.videoId === cYt.videoId) return true; const cHost = courseUrl.hostname.replace(/^www\./, "").toLowerCase(); const tHost = targetUrl.hostname.replace(/^www\./, "").toLowerCase(); const cPath = courseUrl.pathname.replace(/\/$/, ""); const tPath = targetUrl.pathname.replace(/\/$/, ""); if (cHost !== tHost && !tHost.endsWith("." + cHost)) return false; return !cPath || cPath === "/" || tPath.startsWith(cPath); }
export function courseResourceMatchesUrl(course, rawUrl = "") {
  if (courseMatchesUrl(course, rawUrl)) return true;
  return (Array.isArray(course?.videos) ? course.videos : []).some((video) => courseMatchesUrl({ url: video?.url || video }, rawUrl));
}
export function isDistractionProtectionAllowedUrl(input = {}, rawUrl = "") {
  const state = mergeState(input);
  if (isAllowedSupportUrl(rawUrl, state.settings)) return true;
  if (state.focusSession?.active && state.focusSession.courseUrl
    && courseMatchesUrl({ url: state.focusSession.courseUrl }, rawUrl)) return true;
  return state.courses.some((course) => courseResourceMatchesUrl(course, rawUrl));
}
export function isScheduledFocusBreak(session, now = Date.now()) {
  return Boolean(session?.active
    && normalizeFocusMode(session.mode) === "breaks"
    && session.phase === "break"
    && num(session.phaseStartedAt) <= now
    && (num(session.endConfirmationUntil) > now || num(session.endsAt) > now));
}
export function isYouTubeStudyModeActive(settings = {}, session = null, now = Date.now()) {
  return Boolean(settings?.youtubeStudyModeEnabled
    && session?.active
    && session.phase !== "break"
    && session.phase !== "completed"
    && sessionRemainingMs(session, now) > 0);
}
export function isFocusSessionProtectionEnabled(settings = {}) {
  return Boolean(settings?.focusSessionProtectionEnabled && settings?.distractionProtectionConsentAccepted);
}
export function isOutsideFocusProtectionEnabled(settings = {}) {
  return Boolean(settings?.guardBlockedOutsideFocus && settings?.distractionProtectionConsentAccepted);
}
export function isDistractionProtectionEnabled(settings = {}) {
  return isFocusSessionProtectionEnabled(settings) || isOutsideFocusProtectionEnabled(settings);
}
export function isFocusSessionProtectionActive(input = {}, now = Date.now()) {
  const state = mergeState(input);
  const session = state.focusSession;
  return Boolean(isFocusSessionProtectionEnabled(state.settings)
    && session?.active
    && !session.paused
    && session.phase !== "break"
    && session.phase !== "completed"
    && sessionRemainingMs(session, now) > 0);
}
export function isDistractionProtectionActive(input = {}, now = Date.now()) {
  const state = mergeState(input);
  const session = state.focusSession;
  if (isScheduledFocusBreak(session, now) || session?.phase === "break") return false;
  if (session?.active && !session.paused && session.phase !== "completed" && sessionRemainingMs(session, now) > 0) {
    return isFocusSessionProtectionEnabled(state.settings);
  }
  return isOutsideFocusProtectionEnabled(state.settings);
}
export function shouldRedirectByDistractionProtection(input = {}, rawUrl = "", now = Date.now()) {
  const state = mergeState(input);
  if (!isHttpUrl(rawUrl) || isInternalUrl(rawUrl)) return false;
  if (isFocusSessionProtectionActive(state, now)) {
    return !isDistractionProtectionAllowedUrl(state, rawUrl);
  }
  if (isScheduledFocusBreak(state.focusSession, now) || !isDistractionProtectionActive(state, now)) return false;
  if (isDistractionProtectionAllowedUrl(state, rawUrl)) return false;
  return isBlockedUrl(rawUrl, state.settings);
}
export function shouldApplyProtectionToTab(settings = {}, isIncognito = false) {
  return !isIncognito || Boolean(settings?.incognitoProtection);
}
export function shouldPersistProtectionEvent(isIncognito = false) { return !Boolean(isIncognito); }
export function normalizeStudyProfile(profileId) { return STUDY_PROFILES.some((profile) => profile.id === profileId) ? profileId : DEFAULT_STUDY_PROFILE; }
export function subjectsForProfile(profileId = DEFAULT_STUDY_PROFILE) { return STUDY_PROFILES.find((profile) => profile.id === normalizeStudyProfile(profileId))?.subjects || SUBJECTS; }
export function normalizeSubject(subject, profileId = null, customSubjects = []) {
  const rawText = String(subject || "").trim();
  const text = rawText === "Polity" ? "Politics" : rawText;
  const profileSubjects = profileId ? subjectsForProfile(profileId) : [];
  const allSubjects = [...new Set(STUDY_PROFILES.flatMap((profile) => profile.subjects))];
  if (profileSubjects.includes(text) || allSubjects.includes(text) || (Array.isArray(customSubjects) && customSubjects.includes(text))) return text;
  if (!profileId && cleanStudySubject(text)) return cleanStudySubject(text);
  return profileSubjects.includes("Other") || !profileSubjects.length ? "Other" : profileSubjects[0];
}
export function emptySubjectTracking(profileId = null) { const subjects = profileId ? subjectsForProfile(profileId) : [...new Set(STUDY_PROFILES.flatMap((profile) => profile.subjects))]; return Object.fromEntries(subjects.map((s) => [s, { subject: s, studyMinutes: 0, sessions: 0, completion: 0 }])); }
export function defaultAnalytics() { return { daily: {}, focusHistory: [], streak: { current: 0, longest: 0, lastStudyDate: null }, calendar: { timeZone: localTimeZone(), lastObservedDate: todayKey() } }; }
export function defaultAssistant() { return { mode: "steady", suggestion: ASSISTANT_MESSAGES.steady, nextTask: "Start your default course.", lastUpdatedAt: null }; }
export function defaultState() { return { version: 12, profile: { onboarded: false, onboardingVersion: 0, guidedTourStatus: "completed", guidedTourVersion: 0, guidedTourActive: false, guidedTourStep: 0, guidedTourTabId: null, guidedTourSessionId: null, guidedTourUpdatedAt: null, guidedTourHandoff: null, focusEnhancementsIntroDismissed: false, name: "", profileType: "local", email: "", studyProfile: DEFAULT_STUDY_PROFILE, startedAt: null, lastProfileAt: null }, settings: { ...DEFAULT_SETTINGS, blockedSites: [...DEFAULT_BLOCKED_SITES], allowedSites: [...DEFAULT_ALLOWED_SITES] }, courseLibraries: DEFAULT_COURSE_LIBRARIES.map((library) => ({ ...library })), courses: [], focusSession: null, focusCompletion: null, attention: { active: false, status: "off", reason: null, lastEventAt: null, distractionCount: 0, calibratedAt: null, error: null }, goals: { ...DEFAULT_STUDY_GOALS, analyticsTargets: null }, daily: { date: todayKey(), tasks: DEFAULT_DAILY_TASKS.map((t) => ({ ...t, done: false })) }, stats: { date: todayKey(), focusMinutes: 0, distractions: 0, sessionsCompleted: 0 }, analytics: defaultAnalytics(), rewards: { awardedGoalKeys: {}, entries: [] }, assistant: defaultAssistant(), protection: { tabSwitches: [], blockedAttempts: [], browsingEvents: [], lastAssistantNoticeAt: null }, backups: { lastExportedAt: null, lastRestoredAt: null, lastFormat: null } }; }
function normalizeSubjects(src = {}) {
  const base = emptySubjectTracking();
  Object.keys(src || {}).forEach((name) => {
    const subject = cleanStudySubject(name);
    if (subject && !base[subject]) base[subject] = { subject, studyMinutes: 0, sessions: 0, completion: 0 };
  });
  for (const s of Object.keys(base)) {
    const stored = s === "Politics" ? { ...(src.Polity || {}), ...(src.Politics || {}), studyMinutes: num(src.Polity?.studyMinutes) + num(src.Politics?.studyMinutes), sessions: num(src.Polity?.sessions) + num(src.Politics?.sessions), completion: Math.max(num(src.Polity?.completion), num(src.Politics?.completion)) } : (src[s] || {});
    base[s] = { ...base[s], ...stored, subject: s, studyMinutes: num(stored.studyMinutes), sessions: num(stored.sessions), completion: Math.max(0, Math.min(100, num(stored.completion))) };
  }
  return base;
}
function normalizeCourseLibraries(items = null) { const source = Array.isArray(items) && items.length ? items : DEFAULT_COURSE_LIBRARIES; const seen = new Set(); const libraries = source.map((library) => ({ id: String(library.id || uid("library")), name: String(library.name || "My Library").trim().slice(0, 48) || "My Library", collapsed: Boolean(library.collapsed), createdAt: num(library.createdAt, Date.now()) })).filter((library) => { if (seen.has(library.id)) return false; if (LEGACY_PROFILE_LIBRARY_IDS.has(library.id)) return false; seen.add(library.id); return true; }); return (libraries.length ? libraries : DEFAULT_COURSE_LIBRARIES.map((library) => ({ ...library, createdAt: Date.now() }))).slice(0, 60); }
function isDefaultCourseLibrary(library) { return Boolean(library && (library.id === "library-main" || library.isDefault === true || library.system === true || String(library.name || "").trim().toLowerCase() === "my library")); }
export function renameCourseLibrary(libraries = [], libraryId, rawName) {
  const current = Array.isArray(libraries) ? libraries : [];
  const target = current.find((library) => library.id === libraryId);
  if (!target) throw new Error("That library could not be found.");
  if (isDefaultCourseLibrary(target)) throw new Error("My Library cannot be renamed.");
  const name = String(rawName || "").trim().slice(0, 48);
  if (!name) throw new Error("Library name is required.");
  if (current.some((library) => library.id !== libraryId && String(library.name || "").trim().toLocaleLowerCase() === name.toLocaleLowerCase())) {
    throw new Error("A library with that name already exists.");
  }
  return current.map((library) => library.id === libraryId ? { ...library, name } : library);
}
export function deleteCourseLibrary(libraries = [], courses = [], libraryId, now = Date.now()) {
  const current = Array.isArray(libraries) ? libraries : [];
  const target = current.find((library) => library.id === libraryId);
  if (!target) throw new Error("That library could not be found.");
  if (isDefaultCourseLibrary(target)) throw new Error("My Library cannot be deleted.");
  let fallback = current.find(isDefaultCourseLibrary);
  if (!fallback) fallback = { id: "library-main", name: "My Library", collapsed: false, createdAt: now };
  const remaining = current.filter((library) => library.id !== libraryId);
  if (!remaining.some((library) => library.id === fallback.id)) remaining.unshift(fallback);
  const movedCount = (Array.isArray(courses) ? courses : []).filter((course) => course.libraryId === libraryId).length;
  const updatedCourses = (Array.isArray(courses) ? courses : []).map((course) => course.libraryId === libraryId ? { ...course, libraryId: fallback.id } : course);
  return { libraries: remaining, courses: updatedCourses, movedCount, destination: fallback.name };
}
function normalizeCourseVideos(items = []) {
  const seen = new Set();
  return (Array.isArray(items) ? items : []).map((video) => {
    const url = canonicalYouTubeVideoUrl(video?.url || video);
    const id = youtubeVideoId(url);
    if (!id || seen.has(id)) return null;
    seen.add(id);
    return { id: String(video?.id || uid("video")), title: String(video?.title || "YouTube video").trim().slice(0, 180) || "YouTube video", url, addedAt: num(video?.addedAt, Date.now()) };
  }).filter(Boolean).slice(0, 200);
}
function normalizeCourses(items = [], libraries = DEFAULT_COURSE_LIBRARIES, profileId = DEFAULT_STUDY_PROFILE, customSubjects = []) {
  const normalizedLibraries = normalizeCourseLibraries(libraries);
  const libraryIds = new Set(normalizedLibraries.map((library) => library.id));
  const fallbackLibraryId = normalizedLibraries[0]?.id || "library-main";
  const source = Array.isArray(items) ? items : [];
  const existingSubjects = source.map((course) => cleanStudySubject(course?.subject)).filter(Boolean);
  const acceptedSubjects = [...new Set([...(customSubjects || []), ...existingSubjects])];
  return source.map((c) => {
    const subject = normalizeSubject(c.subject, profileId, acceptedSubjects);
    const legacyGroupId = c.groupId && !LEGACY_PROFILE_LIBRARY_IDS.has(c.groupId) ? c.groupId : null;
    const libraryId = libraryIds.has(c.libraryId) ? c.libraryId : (libraryIds.has(legacyGroupId) ? legacyGroupId : fallbackLibraryId);
    const url = normalizeUrl(c.url || "");
    const primaryVideoId = youtubeVideoId(url);
    return { id: c.id || uid("course"), title: String(c.title || "Study course").trim(), subject, libraryId, url, videos: normalizeCourseVideos(c.videos).filter((video) => youtubeVideoId(video.url) !== primaryVideoId), createdAt: num(c.createdAt, Date.now()), lastUsedAt: c.lastUsedAt ? num(c.lastUsedAt) : null };
  }).filter((c) => isHttpUrl(c.url));
}
function normalizeTasks(items = DEFAULT_DAILY_TASKS) { return (Array.isArray(items) ? items : DEFAULT_DAILY_TASKS).filter((t) => !LEGACY_DEFAULT_TASK_TITLES.has(String(t?.title || "").trim().toLowerCase())).map((t) => ({ id: t.id || uid("task"), title: String(t.title || "Study task").trim(), area: String(t.area || "Personal"), minutes: Math.max(0, num(t.minutes)), note: String(t.note || ""), priority: "personal", done: Boolean(t.done), completedAt: num(t.completedAt) || null, completedDate: /^\d{4}-\d{2}-\d{2}$/.test(String(t.completedDate || "")) ? String(t.completedDate) : null })); }
function normalizeEvents(events = []) { return (Array.isArray(events) ? events : []).map((e) => ({ at: num(e.at, Date.now()), type: String(e.type || "event"), host: String(e.host || ""), reason: String(e.reason || "") })).filter((e) => Date.now() - e.at < 24 * 60 * 60000).slice(-120); }
export function normalizeStudyIntervals(intervals = []) {
  let lastEnd = 0;
  return (Array.isArray(intervals) ? intervals : []).map((interval) => ({
    startedAt: num(interval?.startedAt),
    endedAt: num(interval?.endedAt)
  })).filter((interval) => interval.startedAt > 0 && interval.endedAt > interval.startedAt)
    .sort((a, b) => a.startedAt - b.startedAt || a.endedAt - b.endedAt)
    .slice(-500)
    .flatMap((interval) => {
      const startedAt = Math.max(interval.startedAt, lastEnd);
      if (interval.endedAt <= startedAt) return [];
      lastEnd = interval.endedAt;
      return [{ startedAt, endedAt: interval.endedAt }];
    });
}
export function closeFocusStudyInterval(session, endedAt = Date.now()) {
  const activeIntervals = normalizeStudyIntervals(session?.activeIntervals);
  const startedAt = num(session?.activeIntervalStartedAt);
  const end = num(endedAt);
  if (session?.timingVersion === 1 && startedAt > 0 && end > startedAt) activeIntervals.push({ startedAt, endedAt: end });
  return { ...session, timingVersion: 1, activeIntervals: normalizeStudyIntervals(activeIntervals), activeIntervalStartedAt: null };
}
export function activeStudyIntervalsForSession(session, now = Date.now()) {
  const intervals = normalizeStudyIntervals(session?.activeIntervals);
  const startedAt = num(session?.activeIntervalStartedAt);
  if (session?.active && session.timingVersion === 1 && !session.paused && session.phase !== "break" && startedAt > 0) {
    const endedAt = Math.min(num(now), num(session.endsAt, num(now)));
    if (endedAt > startedAt) intervals.push({ startedAt, endedAt });
  }
  return normalizeStudyIntervals(intervals);
}
function localDayBounds(dateKey) {
  const [year, month, day] = String(dateKey || todayKey()).split("-").map(Number);
  const start = new Date(year || 1970, Math.max(0, (month || 1) - 1), day || 1);
  start.setHours(0, 0, 0, 0);
  const end = new Date(start);
  end.setDate(end.getDate() + 1);
  return { start: start.getTime(), end: end.getTime() };
}
export function studyIntervalsForLocalDay(intervals = [], dateKey = todayKey()) {
  const bounds = localDayBounds(dateKey);
  return normalizeStudyIntervals(intervals).flatMap((interval) => {
    const startedAt = Math.max(interval.startedAt, bounds.start);
    const endedAt = Math.min(interval.endedAt, bounds.end);
    return endedAt > startedAt ? [{ startedAt, endedAt }] : [];
  });
}
export function studySessionsForLocalDay(sessions = [], dateKey = todayKey(), now = Date.now(), liveSession = null) {
  const byId = new Map();
  const add = (session, isLive = false) => {
    const id = String(session?.id || "");
    if (!id || byId.has(id) || (!isLive && session?.actualTracked !== true)) return;
    const intervals = studyIntervalsForLocalDay(activeStudyIntervalsForSession(session, now), dateKey);
    let focusedMilliseconds = intervals.reduce((sum, interval) => sum + interval.endedAt - interval.startedAt, 0);
    const hasIntervalData = session?.timingVersion === 1 || (Array.isArray(session?.activeIntervals) && session.activeIntervals.length > 0);
    const legacy = !isLive && !hasIntervalData && session?.recordedDate === dateKey;
    if (!focusedMilliseconds && legacy) focusedMilliseconds = Math.max(0, num(session.actualMinutes, num(session.durationMinutes))) * 60000;
    if (!focusedMilliseconds && !isLive) return;
    const startedAt = num(session?.startedAt);
    if (!startedAt) return;
    if (!focusedMilliseconds && isLive && todayKey(new Date(startedAt)) !== dateKey) return;
    const rawSubject = String(session?.subject || "").trim();
    const subject = !rawSubject || ["other", "unassigned"].includes(rawSubject.toLowerCase()) ? "Unassigned" : rawSubject;
    byId.set(id, {
      id,
      courseId: session?.courseId || null,
      courseTitle: String(session?.courseTitle || "").trim(),
      subject,
      mode: String(session?.mode || "normal").toLowerCase(),
      startedAt,
      endedAt: num(session?.endedAt) || null,
      activeIntervals: intervals,
      focusedMilliseconds,
      status: isLive && session?.active ? "In Progress" : "Completed"
    });
  };
  if (liveSession?.active) add(liveSession, true);
  (Array.isArray(sessions) ? sessions : []).forEach((session) => add(session));
  return [...byId.values()].sort((a, b) => b.startedAt - a.startedAt || a.id.localeCompare(b.id));
}
function addSessionMinutesByLocalDate(byDate, intervals = [], fallbackDate = "", fallbackMinutes = 0) {
  const normalized = normalizeStudyIntervals(intervals);
  if (!normalized.length) {
    if (fallbackDate) byDate.set(fallbackDate, (byDate.get(fallbackDate) || 0) + Math.max(0, num(fallbackMinutes)));
    return;
  }
  normalized.forEach((interval) => {
    let cursor = interval.startedAt;
    while (cursor < interval.endedAt) {
      const dateKey = todayKey(new Date(cursor));
      const { end } = localDayBounds(dateKey);
      const segmentEnd = Math.min(interval.endedAt, end > cursor ? end : cursor + 86400000);
      if (segmentEnd <= cursor) break;
      byDate.set(dateKey, (byDate.get(dateKey) || 0) + (segmentEnd - cursor) / 60000);
      cursor = segmentEnd;
    }
  });
}
export function studyWeekForLocalWeek(sessions = [], referenceDate = new Date(), now = Date.now(), liveSession = null, offset = 0) {
  const reference = referenceDate instanceof Date ? new Date(referenceDate) : new Date(referenceDate);
  if (!Number.isFinite(reference.getTime())) throw new TypeError("A valid date is required to build a study week.");
  reference.setHours(0, 0, 0, 0);
  reference.setDate(reference.getDate() - ((reference.getDay() + 6) % 7) + (Number(offset) || 0) * 7);
  const days = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(reference);
    date.setDate(reference.getDate() + index);
    const dateKey = todayKey(date);
    const daySessions = studySessionsForLocalDay(sessions, dateKey, now, liveSession);
    const milliseconds = daySessions.reduce((sum, session) => sum + session.focusedMilliseconds, 0);
    return {
      dateKey,
      label: date.toLocaleDateString(undefined, { weekday: "short" }),
      dateLabel: date.toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric" }),
      milliseconds,
      sessions: daySessions
    };
  });
  return { days, totalMilliseconds: days.reduce((sum, day) => sum + day.milliseconds, 0) };
}
export function studyTimingForLocalDay(sessions = [], dateKey = todayKey(), now = Date.now(), liveSession = null) {
  const [year, month, day] = String(dateKey || todayKey()).split("-").map(Number);
  const dayStart = new Date(year, month - 1, day, 0, 0, 0, 0).getTime();
  const boundary = (hour) => new Date(year, month - 1, day, hour, 0, 0, 0).getTime();
  const morningStart = boundary(6);
  const afternoonStart = boundary(12);
  const eveningStart = boundary(17);
  const nightStart = boundary(21);
  const dayEnd = new Date(year, month - 1, day + 1, 0, 0, 0, 0).getTime();
  const periods = [
    { id: "morning", name: "Morning", milliseconds: 0 },
    { id: "afternoon", name: "Afternoon", milliseconds: 0 },
    { id: "evening", name: "Evening", milliseconds: 0 },
    { id: "night", name: "Night", milliseconds: 0 }
  ];
  const ranges = [
    [morningStart, afternoonStart, periods[0]],
    [afternoonStart, eveningStart, periods[1]],
    [eveningStart, nightStart, periods[2]],
    [dayStart, morningStart, periods[3]],
    [nightStart, dayEnd, periods[3]]
  ];
  let unclassifiedMilliseconds = 0;
  studySessionsForLocalDay(sessions, dateKey, now, liveSession).forEach((session) => {
    if (!session.activeIntervals.length && session.focusedMilliseconds > 0) {
      unclassifiedMilliseconds += session.focusedMilliseconds;
      return;
    }
    session.activeIntervals.forEach((interval) => {
      ranges.forEach(([start, end, period]) => {
        const overlap = Math.max(0, Math.min(interval.endedAt, end) - Math.max(interval.startedAt, start));
        period.milliseconds += overlap;
      });
    });
  });
  return {
    periods,
    totalMilliseconds: periods.reduce((sum, period) => sum + period.milliseconds, 0),
    unclassifiedMilliseconds
  };
}
export function studyDurationScale(actualMinutes = 0, targetMinutes = 0) {
  const neededHours = Math.max(1, Math.ceil(Math.max(0, num(actualMinutes), num(targetMinutes)) / 60));
  const hourStep = neededHours <= 8 ? 1 : Math.ceil(neededHours / 6);
  const maximumHours = Math.ceil(neededHours / hourStep) * hourStep;
  return { maximumHours, ticks: Array.from({ length: maximumHours / hourStep + 1 }, (_, index) => index * hourStep) };
}
export function subjectStudyDistribution(sessions = [], configuredSubjects = [], dateKey = todayKey(), now = Date.now(), liveSession = null) {
  const entries = new Map();
  const ensure = (subject) => {
    const title = String(subject || "").trim();
    const name = !title || title.toLowerCase() === "other" || title.toLowerCase() === "unassigned" ? "Unassigned" : title;
    if (!entries.has(name)) entries.set(name, { subject: name, milliseconds: 0, sessions: 0 });
    return entries.get(name);
  };
  configuredSubjects.forEach(ensure);
  studySessionsForLocalDay(sessions, dateKey, now, liveSession).forEach((session) => {
    const entry = ensure(session.subject);
    entry.milliseconds += session.focusedMilliseconds;
    if (session.focusedMilliseconds > 0) entry.sessions += 1;
  });
  const result = [...entries.values()].sort((a, b) => b.milliseconds - a.milliseconds || a.subject.localeCompare(b.subject));
  return { entries: result, totalMilliseconds: result.reduce((sum, entry) => sum + entry.milliseconds, 0) };
}
export function allocateStudyPercentages(entries = []) {
  const total = (Array.isArray(entries) ? entries : []).reduce((sum, entry) => sum + Math.max(0, num(entry?.milliseconds)), 0);
  if (!total) return (entries || []).map(() => 0);
  const exact = entries.map((entry) => Math.max(0, num(entry?.milliseconds)) / total * 100);
  const percentages = exact.map(Math.floor);
  let remaining = 100 - percentages.reduce((sum, value) => sum + value, 0);
  exact.map((value, index) => ({ index, remainder: value - percentages[index] })).sort((a, b) => b.remainder - a.remainder).slice(0, remaining).forEach(({ index }) => { percentages[index] += 1; });
  return percentages;
}
function normalizeFocusHistory(items = []) {
  const seen = new Set();
  return (Array.isArray(items) ? items : []).map((item) => {
    const id = String(item?.id || uid("session"));
    const plannedMinutes = Math.max(0, num(item?.plannedMinutes, num(item?.durationMinutes)));
    const actualMinutes = Math.max(0, num(item?.actualMinutes, num(item?.durationMinutes)));
    const status = ["completed", "incomplete", "interrupted"].includes(String(item?.status || "").toLowerCase())
      ? String(item.status).toLowerCase()
      : item?.interrupted ? "interrupted" : item?.completed ? "completed" : "incomplete";
    const completionPercent = Math.max(0, Math.min(100, num(item?.completionPercent, plannedMinutes ? (actualMinutes / plannedMinutes) * 100 : status === "completed" ? 100 : 0)));
    return {
      id,
      courseId: item?.courseId ? String(item.courseId) : null,
      courseTitle: String(item?.courseTitle || "Focus session"),
      subject: normalizeSubject(item?.subject),
      startedAt: num(item?.startedAt, Date.now()),
      endedAt: item?.endedAt ? num(item.endedAt) : null,
      recordedDate: /^\d{4}-\d{2}-\d{2}$/.test(String(item?.recordedDate || "")) ? item.recordedDate : todayKey(new Date(num(item?.endedAt || item?.startedAt, Date.now()))),
      actualTracked: item?.actualTracked !== undefined ? Boolean(item.actualTracked) : status === "completed",
      plannedMinutes,
      actualMinutes,
      durationMinutes: actualMinutes,
      activeIntervals: normalizeStudyIntervals(item?.activeIntervals),
      completionPercent: Math.round(completionPercent),
      completed: status === "completed",
      status,
      xpEarned: Math.max(0, num(item?.xpEarned)),
      distractionsBlocked: Math.max(0, num(item?.distractionsBlocked))
    };
  }).filter((item) => {
    if (seen.has(item.id)) return false;
    seen.add(item.id);
    return Number.isFinite(item.startedAt) && item.startedAt > 0 && item.actualMinutes >= 0;
  }).slice(0, 2000);
}
function emptyAnalyticsDay() { return { studyMinutes: 0, verifiedStudyMinutes: 0, sessions: 0, completedSessions: 0, distractionsBlocked: 0, subjects: emptySubjectTracking(), sessionIds: [], completedTasks: [], dailyGoal: null }; }
function analyticsDay(daily, date) {
  const item = { ...emptyAnalyticsDay(), ...(daily[date] || {}) };
  item.subjects = normalizeSubjects(item.subjects);
  item.sessionIds = [...new Set((Array.isArray(item.sessionIds) ? item.sessionIds : []).map(String).filter(Boolean))];
  item.completedTasks = Array.isArray(item.completedTasks) ? item.completedTasks.filter((task) => task && task.id).map((task) => ({ id: String(task.id), title: String(task.title || "Completed task").slice(0, 120), completedAt: num(task.completedAt) || null })) : [];
  item.dailyGoal = item.dailyGoal && typeof item.dailyGoal === "object" ? {
    targetMinutes: Math.max(0, num(item.dailyGoal.targetMinutes)),
    studyMinutes: Math.max(0, num(item.dailyGoal.studyMinutes)),
    percent: Math.max(0, num(item.dailyGoal.percent)),
    achieved: Boolean(item.dailyGoal.achieved)
  } : null;
  item.goalTargets = item.goalTargets && typeof item.goalTargets === "object" ? {
    dailyMinutes: Math.max(0, num(item.goalTargets.dailyMinutes)),
    weeklyMinutes: Math.max(0, num(item.goalTargets.weeklyMinutes)),
    studyDays: Math.max(1, Math.min(7, Math.floor(num(item.goalTargets.studyDays, 5))))
  } : null;
  daily[date] = item;
  return item;
}
function adjustSubjectStudy(subjects, subject, minuteChange = 0, sessionChange = 0) {
  const next = normalizeSubjects(subjects);
  const key = normalizeSubject(subject);
  const current = next[key] || { subject: key, studyMinutes: 0, sessions: 0, completion: 0 };
  next[key] = {
    ...current,
    studyMinutes: Math.max(0, num(current.studyMinutes) + num(minuteChange)),
    sessions: Math.max(0, num(current.sessions) + num(sessionChange))
  };
  return next;
}
function backfillActualFocusTime(analytics = {}) {
  const next = { ...defaultAnalytics(), ...(analytics || {}) };
  const daily = { ...(next.daily || {}) };
  const focusHistory = (next.focusHistory || []).map((entry) => ({ ...entry }));
  focusHistory.forEach((entry) => {
    if (entry.actualTracked) return;
    const date = entry.recordedDate || todayKey(new Date(num(entry.endedAt || entry.startedAt, Date.now())));
    const item = analyticsDay(daily, date);
    const minutes = Math.max(0, num(entry.actualMinutes, num(entry.durationMinutes)));
    item.studyMinutes += minutes;
    item.subjects = adjustSubjectStudy(item.subjects, entry.subject, minutes, entry.completed ? 1 : 0);
    entry.actualTracked = true;
  });
  return { ...next, daily, focusHistory };
}
function normalizeRewards(rewards = {}) {
  const cutoff = Date.now() - 365 * 24 * 60 * 60000;
  const entries = (Array.isArray(rewards.entries) ? rewards.entries : []).map((entry) => ({
    id: String(entry.id || uid("reward")),
    key: String(entry.key || entry.id || ""),
    type: String(entry.type || "goal"),
    label: String(entry.label || "Verified study progress"),
    xp: Math.max(0, num(entry.xp)),
    awardedAt: num(entry.awardedAt, Date.now())
  })).filter((entry) => entry.awardedAt >= cutoff).slice(-700);
  const awardedGoalKeys = Object.fromEntries(Object.entries(rewards.awardedGoalKeys || {}).filter(([key, value]) => key && num(value) >= cutoff));
  entries.forEach((entry) => { if (entry.key) awardedGoalKeys[entry.key] = entry.awardedAt; });
  return { awardedGoalKeys, entries };
}
function normalizeNotes(notes = []) {
  return (Array.isArray(notes) ? notes : []).map((note) => ({
    id: String(note.id || uid("note")),
    courseId: note.courseId ? String(note.courseId) : null,
    title: String(note.title || "Untitled note").trim().slice(0, 120) || "Untitled note",
    body: String(note.body || "").slice(0, 50000),
    checklist: (Array.isArray(note.checklist) ? note.checklist : []).map((item) => ({ id: String(item.id || uid("check")), text: String(item.text || "").trim().slice(0, 180), done: Boolean(item.done) })).filter((item) => item.text).slice(0, 80),
    pinned: Boolean(note.pinned),
    createdAt: num(note.createdAt, Date.now()),
    updatedAt: num(note.updatedAt, Date.now())
  })).slice(0, 300);
}
function normalizeFlashcards(cards = []) {
  return (Array.isArray(cards) ? cards : []).map((card) => ({
    id: String(card.id || uid("card")),
    courseId: card.courseId ? String(card.courseId) : null,
    category: String(card.category || "General").trim().slice(0, 50) || "General",
    front: String(card.front || "").trim().slice(0, 600),
    back: String(card.back || "").trim().slice(0, 1200),
    reviews: Math.max(0, num(card.reviews)),
    lastReviewedAt: card.lastReviewedAt ? num(card.lastReviewedAt) : null,
    createdAt: num(card.createdAt, Date.now())
  })).filter((card) => card.front && card.back).slice(0, 800);
}
function normalizePlanner(items = []) {
  return (Array.isArray(items) ? items : []).map((item) => ({
    id: String(item.id || uid("plan")),
    title: String(item.title || "Study plan").trim().slice(0, 120) || "Study plan",
    date: /^\d{4}-\d{2}-\d{2}$/.test(String(item.date || "")) ? String(item.date) : todayKey(),
    kind: ["daily", "weekly", "monthly", "revision"].includes(item.kind) ? item.kind : "daily",
    courseId: item.courseId ? String(item.courseId) : null,
    minutes: Math.max(0, Math.min(720, num(item.minutes))),
    done: Boolean(item.done),
    createdAt: num(item.createdAt, Date.now())
  })).slice(0, 500);
}
const STATE_PATCH_DELETE = "__courseFocusDelete";
function isStateRecord(value) { return Boolean(value) && typeof value === "object" && !Array.isArray(value); }
function cloneStateValue(value) { if (Array.isArray(value)) return value.map(cloneStateValue); if (isStateRecord(value)) return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, cloneStateValue(item)])); return value; }
function isDeletePatch(value) { return isStateRecord(value) && value[STATE_PATCH_DELETE] === true && Object.keys(value).length === 1; }
function diffStateValue(before, after) {
  if (Object.is(before, after)) return undefined;
  if (Array.isArray(before) && Array.isArray(after)) {
    if (before.length === after.length && before.every((item, index) => diffStateValue(item, after[index]) === undefined)) return undefined;
    return cloneStateValue(after);
  }
  if (isStateRecord(before) && isStateRecord(after)) {
    const patch = {};
    new Set([...Object.keys(before), ...Object.keys(after)]).forEach((key) => {
      if (!Object.prototype.hasOwnProperty.call(after, key)) patch[key] = { [STATE_PATCH_DELETE]: true };
      else {
        const change = diffStateValue(before[key], after[key]);
        if (change !== undefined) patch[key] = change;
      }
    });
    return Object.keys(patch).length ? patch : undefined;
  }
  return cloneStateValue(after);
}
function applyStatePatchValue(current, patch) {
  if (isDeletePatch(patch)) return undefined;
  if (Array.isArray(patch)) return cloneStateValue(patch);
  if (!isStateRecord(patch)) return patch;
  const next = isStateRecord(current) ? cloneStateValue(current) : {};
  Object.entries(patch).forEach(([key, change]) => {
    if (isDeletePatch(change)) delete next[key];
    else next[key] = isStateRecord(change) && isStateRecord(current?.[key]) ? applyStatePatchValue(current[key], change) : cloneStateValue(change);
  });
  return next;
}
export function createStatePatch(previous = {}, next = {}) { return diffStateValue(previous, next) || {}; }
export function applyStatePatch(current = {}, patch = {}) { return isStateRecord(patch) ? applyStatePatchValue(current, patch) : cloneStateValue(current); }
export function mergeState(input = {}) {
  const base = defaultState();
  const src = input && typeof input === "object" ? input : {};
  const settings = { ...base.settings, ...(src.settings || {}) };
  if (!["system", "light", "dark", "midnight", "amoled", "beige"].includes(settings.themeMode)) settings.themeMode = "dark";
  // Defaults seed a new profile once. A user can subsequently remove every item.
  settings.blockedSites = Array.isArray(src.settings?.blockedSites) ? cleanPatterns(src.settings.blockedSites) : [...DEFAULT_BLOCKED_SITES];
  settings.allowedSites = Array.isArray(src.settings?.allowedSites) ? cleanPatterns(src.settings.allowedSites) : [...DEFAULT_ALLOWED_SITES];
  settings.distractionProtectionConsentAccepted = Boolean(src.settings?.distractionProtectionConsentAccepted);
  const legacyOutsideProtection = src.settings?.guardBlockedOutsideFocus
    ?? src.settings?.alwaysGuardBlockedSites
    ?? (Object.keys(src.settings || {}).length > 0);
  const legacyFocusProtection = src.settings?.redirectDuringFocus
    ?? src.settings?.redirectEnabled
    ?? legacyOutsideProtection;
  const protectionConsentAccepted = settings.distractionProtectionConsentAccepted;
  settings.guardBlockedOutsideFocus = protectionConsentAccepted
    ? Boolean(src.settings?.guardBlockedOutsideFocus ?? src.settings?.alwaysGuardBlockedSites ?? legacyOutsideProtection)
    : false;
  settings.focusSessionProtectionEnabled = protectionConsentAccepted
    ? Boolean(src.settings?.focusSessionProtectionEnabled ?? legacyFocusProtection)
    : false;
  // These legacy flags controlled the removed allowlist-only Focus rule.
  delete settings.redirectEnabled;
  delete settings.redirectDuringFocus;
  settings.incognitoProtection = src.settings?.incognitoProtection !== undefined ? Boolean(src.settings.incognitoProtection) : false;
  settings.youtubeStudyModeEnabled = src.settings?.youtubeStudyModeEnabled !== undefined ? Boolean(src.settings.youtubeStudyModeEnabled) : false;
  settings.defaultFocusMode = normalizeFocusMode(settings.defaultFocusMode);
  settings.focusMinutesDefault = Math.max(5, Math.min(240, num(settings.focusMinutesDefault, 50)));
  settings.focusBreakMinutesDefault = Math.max(0, Math.min(60, num(settings.focusBreakMinutesDefault, 5)));
  settings.focusBreakCyclesDefault = Math.max(0, Math.min(12, Math.floor(num(settings.focusBreakCyclesDefault, 1))));
  settings.soundEnabled = src.settings?.soundEnabled !== undefined ? Boolean(src.settings.soundEnabled) : Boolean(settings.soundEnabled);
  settings.soundVolume = Math.max(0, Math.min(100, num(settings.soundVolume, 35)));
  settings.cameraAttentionConsentAccepted = Boolean(src.settings?.cameraAttentionConsentAccepted);
  settings.cameraAttentionEnabled = Boolean(src.settings?.cameraAttentionEnabled && settings.cameraAttentionConsentAccepted);
  settings.cameraAttentionSensitivity = ["gentle", "balanced", "strict"].includes(settings.cameraAttentionSensitivity) ? settings.cameraAttentionSensitivity : "balanced";
  settings.cameraAttentionGraceSeconds = Math.max(5, Math.min(30, num(settings.cameraAttentionGraceSeconds, 10)));
  settings.cameraAttentionVoice = src.settings?.cameraAttentionVoice !== undefined ? Boolean(src.settings.cameraAttentionVoice) : Boolean(settings.cameraAttentionVoice);
  delete settings.autoOpenCourseOnFocus;

  const profile = { ...base.profile, ...(src.profile || {}) };
  const oldProfileKindKey = "log" + "inType";
  const oldProfileDateKey = "last" + "Log" + "inAt";
  profile.profileType = profile.profileType || profile[oldProfileKindKey] || "local";
  profile.lastProfileAt = profile.lastProfileAt || profile[oldProfileDateKey] || null;
  profile.studyProfile = normalizeStudyProfile(profile.studyProfile || src.settings?.studyProfile);
  profile.guidedTourStatus = ["not_started", "skipped", "completed"].includes(profile.guidedTourStatus) ? profile.guidedTourStatus : "completed";
  profile.focusEnhancementsIntroDismissed = Boolean(profile.focusEnhancementsIntroDismissed);
  profile.guidedTourVersion = Math.max(0, Math.floor(num(profile.guidedTourVersion)));
  profile.guidedTourActive = Boolean(profile.guidedTourActive && profile.guidedTourStatus === "not_started");
  profile.guidedTourStep = Math.max(0, Math.min(50, Math.floor(num(profile.guidedTourStep))));
  profile.guidedTourTabId = Number.isInteger(Number(profile.guidedTourTabId)) && Number(profile.guidedTourTabId) > 0 ? Number(profile.guidedTourTabId) : null;
  profile.guidedTourSessionId = String(profile.guidedTourSessionId || "").trim().slice(0, 96) || null;
  profile.guidedTourUpdatedAt = profile.guidedTourUpdatedAt ? num(profile.guidedTourUpdatedAt) : null;
  profile.guidedTourHandoff = profile.guidedTourActive ? normalizeGuidedTourHandoff(profile.guidedTourHandoff) : null;
  delete profile[oldProfileKindKey];
  delete profile[oldProfileDateKey];

  const courseLibraries = normalizeCourseLibraries(src.courseLibraries || src.courseGroups);
  const goals = { ...base.goals, ...(src.goals || {}) };
  goals.analyticsTargets = normalizeStudyTargets(src.goals?.analyticsTargets, profile.studyProfile);
  const daily = { ...base.daily, ...(src.daily || {}), tasks: normalizeTasks(src.daily?.tasks) };
  delete daily.rescueCount;

  const state = {
    ...base,
    ...src,
    version: 12,
    profile,
    settings,
    courseLibraries,
    courses: normalizeCourses(src.courses, courseLibraries, profile.studyProfile, goals.analyticsTargets?.customSubjects),
    attention: {
      ...base.attention,
      ...(src.attention || {}),
      active: Boolean(src.attention?.active),
      status: ["off", "starting", "calibrating", "watching", "attention-lost", "paused", "needs-position", "permission-denied", "unsupported", "error"].includes(src.attention?.status) ? src.attention.status : "off",
      reason: src.attention?.reason ? String(src.attention.reason).slice(0, 80) : null,
      lastEventAt: src.attention?.lastEventAt ? num(src.attention.lastEventAt) : null,
      distractionCount: Math.max(0, num(src.attention?.distractionCount)),
      calibratedAt: src.attention?.calibratedAt ? num(src.attention.calibratedAt) : null,
      error: src.attention?.error ? String(src.attention.error).slice(0, 180) : null
    },
    goals,
    daily,
    stats: { ...base.stats, ...(src.stats || {}) },
    analytics: {
      ...base.analytics,
      ...(src.analytics || {}),
      daily: { ...(src.analytics?.daily || {}) },
      focusHistory: normalizeFocusHistory(src.analytics?.focusHistory),
      calendar: { ...base.analytics.calendar, ...(src.analytics?.calendar || {}) }
    },
    rewards: normalizeRewards(src.rewards),
    assistant: { ...base.assistant, ...(src.assistant || {}) },
    protection: {
      tabSwitches: normalizeEvents(src.protection?.tabSwitches),
      blockedAttempts: normalizeEvents(src.protection?.blockedAttempts),
      browsingEvents: normalizeEvents(src.protection?.browsingEvents),
      lastAssistantNoticeAt: num(src.protection?.lastAssistantNoticeAt) || null
    },
    backups: { ...base.backups, ...(src.backups || {}) }
  };

  if (state.focusSession?.active) {
    const focus = state.focusSession;
    const mode = normalizeFocusMode(focus.mode);
    state.focusSession = {
      ...focus,
      mode,
      phase: mode === "breaks" ? (focus.phase === "break" ? "break" : "study") : "study",
      paused: mode === "normal" && Boolean(focus.paused),
      studyDurationMinutes: Math.max(5, Math.min(240, num(focus.studyDurationMinutes, focus.durationMinutes || settings.focusMinutesDefault))),
      breakDurationMinutes: Math.max(0, Math.min(60, num(focus.breakDurationMinutes, settings.focusBreakMinutesDefault))),
      cyclesTotal: Math.max(1, Math.min(13, Math.floor(num(focus.cyclesTotal, Math.max(1, settings.focusBreakCyclesDefault + 1))))),
      cyclesCompleted: Math.max(0, Math.min(12, Math.floor(num(focus.cyclesCompleted)))),
      completedStudyMs: Math.max(0, num(focus.completedStudyMs)),
      scheduleVersion: Number(focus.scheduleVersion) === 2 ? 2 : 1,
      breaksTotal: Math.max(0, Math.min(12, Math.floor(num(focus.breaksTotal, Math.max(0, num(focus.cyclesTotal, 1) - 1))))),
      studyBlocksTotal: Math.max(1, Math.min(13, Math.floor(num(focus.studyBlocksTotal, num(focus.cyclesTotal, 1))))),
      studyBlocksCompleted: Math.max(0, Math.min(13, Math.floor(num(focus.studyBlocksCompleted, num(focus.cyclesCompleted))))),
      studyBlockDurationsMs: Array.isArray(focus.studyBlockDurationsMs) ? focus.studyBlockDurationsMs.slice(0, 13).map((duration) => Math.max(0, num(duration))) : [],
      studyBlockElapsedMs: Math.max(0, num(focus.studyBlockElapsedMs)),
      timingVersion: Number(focus.timingVersion) === 1 ? 1 : 0,
      activeIntervals: normalizeStudyIntervals(focus.activeIntervals),
      activeIntervalStartedAt: Number(focus.timingVersion) === 1 && num(focus.activeIntervalStartedAt) > 0 ? num(focus.activeIntervalStartedAt) : null,
      phaseDurationMs: Math.max(0, num(focus.phaseDurationMs)),
      phaseStartedAt: num(focus.phaseStartedAt, focus.startedAt),
      endsAt: num(focus.endsAt),
      endConfirmationUntil: num(focus.endConfirmationUntil) || null,
      endConfirmationRemainingMs: focus.endConfirmationUntil ? Math.max(0, num(focus.endConfirmationRemainingMs)) : null,
      endConfirmationStudyElapsedMs: focus.endConfirmationUntil ? Math.max(0, num(focus.endConfirmationStudyElapsedMs)) : null
    };
  }

  delete state.jeeMode;
  delete state.recommendations;
  delete state.subjects;
  delete state.courseGroups;
  delete state.notes;
  delete state.flashcards;
  delete state.planner;
  delete state.hydration;
  delete state.settings.waterEnabled;
  delete state.settings.waterGoal;
  delete state.settings.waterIntervalMinutes;
  delete state.goals.water;
  delete state.stats.water;
  delete state.todayGoal;
  state.settings.defaultCourseId = state.courses.some((c) => c.id === state.settings.defaultCourseId) ? state.settings.defaultCourseId : state.courses[0]?.id || null;
  state.goals.studyHours = Math.max(0, num(src.goals?.studyHours, studyTargetSuggestions(profile.studyProfile).dailyMinutes / 60));
  state.goals.chapters = Math.max(0, num(state.goals.chapters, 2));
  state.goals.questions = Math.max(0, num(state.goals.questions, 60));
  if (num(src.version) < 11) state.analytics = backfillActualFocusTime(state.analytics);
  return state;
}
function validDateKey(value) { return /^\d{4}-\d{2}-\d{2}$/.test(String(value || "")); }
function snapshotDailyRecord(state, date, now, timeZone = localTimeZone(), activeDate = dateKeyInTimeZone(now, timeZone)) {
  if (!validDateKey(date)) return state;
  const daily = { ...(state.analytics?.daily || {}) };
  const record = analyticsDay(daily, date);
  if (state.stats?.date === date) {
    record.studyMinutes = Math.max(num(record.studyMinutes), num(state.stats.focusMinutes));
    record.distractionsBlocked = Math.max(num(record.distractionsBlocked), num(state.stats.distractions));
    record.completedSessions = Math.max(num(record.completedSessions), num(state.stats.sessionsCompleted));
  }
  const datedTasks = (state.daily?.tasks || []).filter((task) => task.done && (task.completedDate === date || (!task.completedDate && task.completedAt && dateKeyInTimeZone(task.completedAt, timeZone) === date)));
  const taskById = new Map(record.completedTasks.map((task) => [task.id, task]));
  datedTasks.forEach((task) => taskById.set(String(task.id), { id: String(task.id), title: String(task.title || "Completed task").slice(0, 120), completedAt: num(task.completedAt) || null }));
  record.completedTasks = [...taskById.values()];
  const sessionIds = (state.analytics?.focusHistory || []).filter((session) => session.recordedDate === date).map((session) => String(session.id));
  record.sessionIds = [...new Set([...record.sessionIds, ...sessionIds])];
  if (date === activeDate || date === state.stats?.date) {
    const targetMinutes = Math.max(0, Math.round(num(state.goals?.studyHours) * 60));
    const studyMinutes = Math.max(0, num(record.studyMinutes));
    record.dailyGoal = { targetMinutes, studyMinutes, percent: targetMinutes ? Math.round((studyMinutes / targetMinutes) * 100) : 0, achieved: targetMinutes > 0 && studyMinutes >= targetMinutes };
    record.goalTargets = { dailyMinutes: targetMinutes, weeklyMinutes: Math.max(0, num(state.goals?.analyticsTargets?.weeklyMinutes)), studyDays: Math.max(1, Math.min(7, Math.floor(num(state.goals?.analyticsTargets?.studyDays, studyTargetSuggestions(state.profile?.studyProfile).studyDays)))) };
  }
  daily[date] = record;
  state.analytics = { ...state.analytics, daily };
  return state;
}
export function ensureToday(input = {}, now = Date.now(), timeZone = localTimeZone()) {
  const state = mergeState(input);
  const nowDate = new Date(now);
  const today = dateKeyInTimeZone(nowDate, timeZone);
  const previousDates = new Set([state.daily?.date, state.stats?.date].filter((date) => validDateKey(date) && date !== today));
  previousDates.forEach((date) => snapshotDailyRecord(state, date, now, timeZone, today));
  if (state.stats?.date !== today) {
    const saved = state.analytics?.daily?.[today] || emptyAnalyticsDay();
    state.stats = { date: today, focusMinutes: Math.max(0, num(saved.studyMinutes)), distractions: Math.max(0, num(saved.distractionsBlocked)), sessionsCompleted: Math.max(0, num(saved.completedSessions)) };
  }
  state.daily.date = today;
  snapshotDailyRecord(state, today, now, timeZone, today);
  state.analytics.calendar = { timeZone: timeZone === "Asia/Calcutta" ? "Asia/Kolkata" : timeZone, lastObservedDate: today };
  return state;
}
export function getActiveCourse(state) { const s = mergeState(state); return s.courses.find((c) => c.id === s.settings.defaultCourseId) || s.courses[0] || null; }
export function sessionRemainingMs(session, now = Date.now()) {
  if (!session?.active) return 0;
  if (session.endConfirmationUntil) return session.endConfirmationUntil <= now ? 0 : Math.max(0, num(session.endConfirmationRemainingMs));
  if (session.paused) return Math.max(0, num(session.remainingMs));
  return Math.max(0, num(session.endsAt) - now);
}
export function minutesRemaining(session) { return Math.max(0, Math.ceil(sessionRemainingMs(session) / 60000)); }
export function formatClock(ms = 0) { const total = Math.max(0, Math.ceil(num(ms) / 1000)); const minutes = Math.floor(total / 60); const seconds = total % 60; return String(minutes).padStart(2, "0") + ":" + String(seconds).padStart(2, "0"); }
export function formatDuration(minutes = 0) { const total = Math.max(0, Math.round(num(minutes))); const h = Math.floor(total / 60); const m = total % 60; if (!h) return m + "m"; if (!m) return h + "h"; return h + "h " + m + "m"; }
export function focusPhaseDurationMs(session) {
  if (!session) return 0;
  if (normalizeFocusMode(session.mode) === "breaks") {
    const stored = num(session.phaseDurationMs);
    const fallback = num(session.phase === "break" ? session.breakDurationMinutes : session.studyDurationMinutes) * 60000;
    return Math.max(0, stored > 0 ? stored : fallback);
  }
  return Math.max(0, num(session.durationMinutes) * 60000);
}
export function createBreakStudyBlocks(totalMinutes, breaksCount) {
  const totalMs = Math.round(Number(totalMinutes) * 60000);
  const count = Math.floor(Number(breaksCount)) + 1;
  if (!Number.isFinite(totalMs) || totalMs <= 0 || !Number.isInteger(count) || count < 1 || count > 13) return [];
  const base = Math.floor(totalMs / count);
  const remainder = totalMs - base * count;
  return Array.from({ length: count }, (_, index) => base + (index < remainder ? 1 : 0));
}
export function suggestedBreakSettings(totalMinutes, mode = "normal") {
  const total = Math.max(5, Math.min(240, Math.floor(Number(totalMinutes) || 5)));
  const presets = { 5: [0, 0], 10: [1, 2], 25: [1, 5], 50: [1, 5], 90: [2, 5] };
  const [breaksCount, breakDurationMinutes] = presets[total] || [total < 10 ? 0 : total < 25 ? 1 : Math.max(1, Math.round(total / 45)), total < 10 ? 0 : 5];
  return mode === "breaks"
    ? { breaksCount: Math.max(1, breaksCount), breakDurationMinutes: Math.max(1, breakDurationMinutes) }
    : { breaksCount, breakDurationMinutes };
}
export function validateBreakSchedule(totalMinutes, breaksCount, breakMinutes) {
  const total = Number(totalMinutes);
  const breaks = Number(breaksCount);
  const breakDuration = Number(breakMinutes);
  const maxBreaks = Number.isFinite(total) ? Math.max(0, Math.min(12, Math.floor(total / 5) - 1)) : 0;
  const blocks = createBreakStudyBlocks(total, breaks);
  let message = "";
  if (!Number.isInteger(total) || total < 5 || total > 240) message = "Choose a total focus duration between 5 and 240 minutes.";
  else if (maxBreaks < 1) message = "Focus with Breaks needs at least 10 minutes of total study time to create two study blocks of at least 5 minutes.";
  else if (!Number.isInteger(breaks) || breaks < 0 || breaks > 12) message = "Choose a whole number of breaks from 0 to 12.";
  else if (breaks === 0) message = "Focus with Breaks requires at least 1 scheduled break.";
  else if (breaks > maxBreaks || blocks.some((duration) => duration < 5 * 60000)) message = "Your selected break count creates study blocks that are too short. Increase the focus duration or reduce the number of breaks.";
  else if (!Number.isInteger(breakDuration) || breakDuration < (breaks > 0 ? 1 : 0) || breakDuration > 60) message = breaks > 0 ? "Choose a break duration from 1 to 60 minutes." : "With no breaks, set break duration to 0 minutes.";
  else if (breaks > 0 && breakDuration * 60000 > Math.min(...blocks)) message = "Break duration cannot be longer than an individual study block. Shorten the break or reduce the number of breaks.";
  return { valid: !message, message, maxBreaks, studyBlocksTotal: breaks + 1, studyBlockDurationsMs: blocks };
}
function scheduledBreakStudyElapsedMs(session, now = Date.now()) {
  const blockIndex = Math.min(Math.max(0, num(session?.studyBlocksCompleted)), Math.max(0, num(session?.studyBlocksTotal) - 1));
  const blockDuration = num(session?.studyBlockDurationsMs?.[blockIndex], num(session?.phaseDurationMs));
  const stored = Math.min(blockDuration, num(session?.studyBlockElapsedMs));
  if (session?.phase !== "study" || !session?.active || session.paused || num(session?.endConfirmationUntil) > now) return stored;
  const intervalStart = num(session?.activeIntervalStartedAt);
  if (intervalStart <= 0) return stored;
  const intervalEnd = Math.min(now, num(session?.endsAt, now));
  return Math.min(blockDuration, stored + Math.max(0, intervalEnd - intervalStart));
}
export function focusElapsedMs(session, now = Date.now()) {
  if (!session) return 0;
  const totalMs = Math.max(0, num(session.durationMinutes) * 60000);
  if (normalizeFocusMode(session.mode) === "breaks") {
    if (session.endConfirmationUntil && Number.isFinite(Number(session.endConfirmationStudyElapsedMs))) {
      return Math.min(totalMs, Math.max(0, num(session.endConfirmationStudyElapsedMs)));
    }
    if (Number(session.scheduleVersion) === 2) {
      return Math.min(totalMs, Math.max(0, num(session.completedStudyMs) + scheduledBreakStudyElapsedMs(session, now)));
    }
    const currentStudyMs = session.phase === "study" && session.active
      ? Math.min(focusPhaseDurationMs(session), Math.max(0, now - num(session.phaseStartedAt, now)))
      : 0;
    return Math.min(totalMs, Math.max(0, num(session.completedStudyMs) + currentStudyMs));
  }
  if (session.endConfirmationUntil && Number.isFinite(Number(session.endConfirmationStudyElapsedMs))) {
    return Math.min(totalMs, Math.max(0, num(session.endConfirmationStudyElapsedMs)));
  }
  if (!totalMs) return 0;
  return Math.max(0, Math.min(totalMs, totalMs - sessionRemainingMs(session, now)));
}
export function focusElapsedMinutes(session, now = Date.now()) {
  return Math.max(0, Math.round(focusElapsedMs(session, now) / 60000));
}
export function advanceFocusSessionPhase(session, now = Date.now()) {
  if (!session?.active || normalizeFocusMode(session.mode) !== "breaks" || session.phase === "completed" || session.paused || num(session.endsAt) > now) return null;
  let next = { ...session };
  const transitions = [];
  for (let index = 0; index < 26 && next.active && next.phase !== "completed" && next.endsAt <= now; index += 1) {
    const boundary = num(next.endsAt);
    if (next.phase === "study") {
      if (Number(next.scheduleVersion) === 2) {
        const blockIndex = Math.min(num(next.studyBlocksCompleted), num(next.studyBlocksTotal) - 1);
        const blockDuration = num(next.studyBlockDurationsMs?.[blockIndex], num(next.phaseDurationMs));
        const blockElapsed = Math.min(blockDuration, num(next.studyBlockElapsedMs) + Math.max(0, boundary - num(next.activeIntervalStartedAt, boundary)));
        const completedStudyMs = Math.min(num(next.durationMinutes) * 60000, num(next.completedStudyMs) + blockElapsed);
        const studyBlocksCompleted = Math.min(num(next.studyBlocksTotal), num(next.studyBlocksCompleted) + 1);
        const closedStudy = closeFocusStudyInterval(next, boundary);
        if (studyBlocksCompleted >= num(next.studyBlocksTotal)) {
          next = { ...closedStudy, timingVersion: 1, phase: "completed", phaseStartedAt: boundary, endsAt: boundary, remainingMs: 0, activeIntervalStartedAt: null, completedStudyMs, studyBlockElapsedMs: 0, studyBlocksCompleted, cyclesCompleted: num(next.breaksTotal), endConfirmationUntil: null, endConfirmationRemainingMs: null, endConfirmationStudyElapsedMs: null };
          transitions.push("completed");
          continue;
        }
        next = {
          ...closedStudy,
          phase: "break",
          phaseStartedAt: boundary,
          activeIntervalStartedAt: null,
          phaseDurationMs: num(next.breakDurationMinutes) * 60000,
          endsAt: boundary + num(next.breakDurationMinutes) * 60000,
          remainingMs: num(next.breakDurationMinutes) * 60000,
          completedStudyMs,
          studyBlocksCompleted,
          studyBlockElapsedMs: 0,
          cyclesCompleted: studyBlocksCompleted,
          paused: false
        };
        transitions.push("break");
        continue;
      }
      const studyMs = focusPhaseDurationMs(next) || num(next.studyDurationMinutes) * 60000;
      const closedStudy = closeFocusStudyInterval(next, boundary);
      const completedStudyMs = num(next.completedStudyMs) + studyMs;
      const cyclesCompleted = Math.min(num(next.cyclesTotal), num(next.cyclesCompleted) + 1);
      if (cyclesCompleted >= num(next.cyclesTotal)) {
        next = {
          ...closedStudy,
          timingVersion: 1,
          phase: "completed",
          phaseStartedAt: boundary,
          endsAt: boundary,
          remainingMs: 0,
          completedStudyMs,
          cyclesCompleted,
          paused: false,
          endConfirmationUntil: null,
          endConfirmationRemainingMs: null,
          endConfirmationStudyElapsedMs: null
        };
        transitions.push("completed");
        continue;
      }
      next = {
        ...closedStudy,
        phase: "break",
        phaseStartedAt: boundary,
        activeIntervalStartedAt: null,
        phaseDurationMs: num(next.breakDurationMinutes) * 60000,
        endsAt: boundary + num(next.breakDurationMinutes) * 60000,
        remainingMs: num(next.breakDurationMinutes) * 60000,
        completedStudyMs,
        cyclesCompleted,
        paused: false
      };
      transitions.push("break");
    } else if (num(next.cyclesCompleted) >= num(next.cyclesTotal)) {
      next = { ...next, timingVersion: 1, activeIntervalStartedAt: null, phase: "completed", phaseStartedAt: boundary, endsAt: boundary, remainingMs: 0, endConfirmationUntil: null, endConfirmationRemainingMs: null, endConfirmationStudyElapsedMs: null };
      transitions.push("completed");
    } else {
      if (Number(next.scheduleVersion) === 2) {
        const nextBlockDuration = num(next.studyBlockDurationsMs?.[num(next.studyBlocksCompleted)], 0);
        if (nextBlockDuration <= 0 || num(next.studyBlocksCompleted) >= num(next.studyBlocksTotal)) {
          next = { ...next, timingVersion: 1, activeIntervalStartedAt: null, phase: "completed", phaseStartedAt: boundary, endsAt: boundary, remainingMs: 0, endConfirmationUntil: null, endConfirmationRemainingMs: null, endConfirmationStudyElapsedMs: null };
          transitions.push("completed");
          continue;
        }
        next = {
          ...next,
          timingVersion: 1,
          phase: "study",
          phaseStartedAt: boundary,
          activeIntervalStartedAt: boundary,
          phaseDurationMs: nextBlockDuration,
          endsAt: boundary + nextBlockDuration,
          remainingMs: nextBlockDuration,
          studyBlockElapsedMs: 0,
          paused: false,
          endConfirmationUntil: null,
          endConfirmationRemainingMs: null,
          endConfirmationStudyElapsedMs: null
        };
        transitions.push("study");
        continue;
      }
      const studyMs = num(next.studyDurationMinutes) * 60000;
      next = {
        ...next,
        timingVersion: 1,
        phase: "study",
        phaseStartedAt: boundary,
        activeIntervalStartedAt: boundary,
        phaseDurationMs: studyMs,
        endsAt: boundary + studyMs,
        remainingMs: studyMs,
        paused: false,
        endConfirmationUntil: null,
        endConfirmationRemainingMs: null,
        endConfirmationStudyElapsedMs: null
      };
      transitions.push("study");
    }
  }
  return { session: next, completed: next.phase === "completed", transitions };
}
export function actualStudyMinutesForDate(input = {}, date = todayKey(), now = Date.now()) {
  const state = mergeState(input);
  const stored = Math.max(0, num(state.analytics?.daily?.[date]?.studyMinutes));
  const session = state.focusSession;
  const currentDate = todayKey(new Date(now));
  if (!session?.active || date !== currentDate || todayKey(new Date(num(session.startedAt, now))) !== date) return stored;
  return stored + focusElapsedMinutes(session, now);
}
export function sessionXp(minutes = 0, completed = true) { const base = Math.max(0, Math.round(num(minutes))); return completed ? Math.max(25, base) : 0; }
export function levelForXp(xp = 0) { return Math.max(1, Math.floor(Math.max(0, num(xp)) / 300) + 1); }
export function rankForLevel(level = 1) { return RANKS.find((rank) => level >= rank.minLevel)?.name || "Beginner"; }
export function rewardXpTotal(state = {}) { return (state.rewards?.entries || []).reduce((total, entry) => total + Math.max(0, num(entry.xp)), 0); }
export function dailySystemGoals(state, date = new Date()) {
  const key = todayKey(date);
  const dateValue = new Date(date);
  const templates = [
    [{ id: "study", type: "study", minutes: 150, xp: 80 }, { id: "sessions", type: "sessions", count: 1, xp: 60 }, { id: "clean", type: "clean", minutes: 45, xp: 50 }],
    [{ id: "study", type: "study", minutes: 180, xp: 80 }, { id: "sessions", type: "sessions", count: 2, xp: 60 }],
    [{ id: "study", type: "study", minutes: 240, xp: 80 }, { id: "clean", type: "clean", minutes: 60, xp: 50 }],
    [{ id: "study", type: "study", minutes: 120, xp: 80 }, { id: "sessions", type: "sessions", count: 1, xp: 60 }],
    [{ id: "study", type: "study", minutes: 180, xp: 80 }, { id: "clean", type: "clean", minutes: 45, xp: 50 }],
    [{ id: "study", type: "study", minutes: 210, xp: 80 }, { id: "sessions", type: "sessions", count: 2, xp: 60 }],
    [{ id: "study", type: "study", minutes: 150, xp: 80 }, { id: "sessions", type: "sessions", count: 1, xp: 60 }, { id: "clean", type: "clean", minutes: 30, xp: 50 }]
  ];
  const daily = state.analytics?.daily?.[key] || {};
  const todayStats = state.stats?.date === key ? state.stats : {};
  const studyMinutes = actualStudyMinutesForDate(state, key);
  const verifiedStudyMinutes = num(daily.verifiedStudyMinutes);
  const completedSessions = Math.max(num(daily.completedSessions), num(todayStats.sessionsCompleted));
  const distractions = num(todayStats.distractions, num(daily.distractionsBlocked));
  return (templates[dateValue.getDay()] || templates[1]).map((goal) => {
    const value = goal.type === "sessions" ? completedSessions : goal.type === "clean" ? (distractions > 0 ? 0 : Math.min(studyMinutes, goal.minutes)) : studyMinutes;
    const verifiedValue = goal.type === "sessions" ? completedSessions : goal.type === "clean" ? (distractions > 0 ? 0 : Math.min(verifiedStudyMinutes, goal.minutes)) : verifiedStudyMinutes;
    const target = goal.count || goal.minutes;
    const title = goal.type === "sessions" ? "Complete " + goal.count + " Focus " + (goal.count === 1 ? "Session" : "Sessions") : goal.type === "clean" ? "Stay distraction-free for " + formatDuration(goal.minutes) : "Study " + formatDuration(goal.minutes);
    const display = goal.type === "sessions" ? Math.min(value, target) + " / " + target + " sessions" : goal.type === "clean" && distractions > 0 ? "Distraction recorded today" : formatDuration(Math.min(value, target)) + " / " + formatDuration(target);
    return { ...goal, date: key, title, value, target, display, done: value >= target, awardEligible: verifiedValue >= target, percent: Math.min(100, Math.round((value / Math.max(1, target)) * 100)) };
  });
}
export function awardVerifiedRewards(input = {}) {
  const state = input;
  const rewards = normalizeRewards(state.rewards);
  const entries = [...rewards.entries];
  const awardedGoalKeys = { ...rewards.awardedGoalKeys };
  const award = (key, type, label, xp) => {
    if (awardedGoalKeys[key]) return;
    const awardedAt = Date.now();
    awardedGoalKeys[key] = awardedAt;
    entries.push({ id: uid("reward"), key, type, label, xp, awardedAt });
  };
  const dailyGoals = dailySystemGoals(state);
  dailyGoals.filter((goal) => goal.awardEligible).forEach((goal) => award(goal.date + ":" + goal.id, "system-goal", goal.title, goal.xp));
  if (dailyGoals.length && dailyGoals.every((goal) => goal.awardEligible)) award(todayKey() + ":daily-reward", "daily-reward", "Daily goals complete", 30);
  const streak = num(state.analytics?.streak?.current);
  const today = todayKey();
  const completedToday = num(state.analytics?.daily?.[today]?.completedSessions);
  if (streak >= 2 && completedToday > 0) award(today + ":streak", "streak", streak + "-day consistency bonus", Math.min(50, 10 + streak * 2));
  return { ...state, rewards: normalizeRewards({ awardedGoalKeys, entries }) };
}
export function addSubjectStudy(subjects, subject, minutes, sessionDone = true, completion = null) { const next = normalizeSubjects(subjects); const key = normalizeSubject(subject); const current = next[key]; const newCompletion = completion === null ? current.completion : Math.max(0, Math.min(100, num(completion))); next[key] = { ...current, studyMinutes: current.studyMinutes + Math.max(0, num(minutes)), sessions: current.sessions + (sessionDone ? 1 : 0), completion: Math.max(current.completion, newCompletion) }; return next; }
function streakAfterStudy(streak = {}, date = todayKey()) { const yesterday = new Date(date); yesterday.setDate(yesterday.getDate() - 1); const yKey = todayKey(yesterday); if (streak.lastStudyDate === date) return streak; const current = streak.lastStudyDate === yKey ? num(streak.current) + 1 : 1; return { current, longest: Math.max(num(streak.longest), current), lastStudyDate: date }; }
export function recordFocusAnalytics(analytics, session, elapsedMinutes, completed = false, status = null, now = Date.now()) {
  const date = todayKey(new Date(now));
  const base = { ...defaultAnalytics(), ...(analytics || {}) };
  const daily = { ...(base.daily || {}) };
  const id = session?.id || uid("session");
  const existing = (base.focusHistory || []).find((entry) => String(entry?.id || "") === String(id));
  if (existing) {
    const previousDate = existing.recordedDate || todayKey(new Date(num(existing.endedAt || existing.startedAt, Date.now())));
    const previous = analyticsDay(daily, previousDate);
    const previousMinutes = Math.max(0, num(existing.actualMinutes, num(existing.durationMinutes)));
    previous.sessions = Math.max(0, num(previous.sessions) - 1);
    previous.distractionsBlocked = Math.max(0, num(previous.distractionsBlocked) - num(existing.distractionsBlocked));
    if (existing.actualTracked) {
      previous.studyMinutes = Math.max(0, num(previous.studyMinutes) - previousMinutes);
      previous.subjects = adjustSubjectStudy(previous.subjects, existing.subject, -previousMinutes, existing.completed ? -1 : 0);
    }
    if (existing.completed) {
      previous.verifiedStudyMinutes = Math.max(0, num(previous.verifiedStudyMinutes) - previousMinutes);
      previous.completedSessions = Math.max(0, num(previous.completedSessions) - 1);
    }
    previous.sessionIds = previous.sessionIds.filter((sessionId) => sessionId !== String(id));
  }
  const item = analyticsDay(daily, date);
  const minutes = Math.max(0, num(elapsedMinutes));
  const plannedMinutes = Math.max(0, num(session?.durationMinutes));
  const subject = normalizeSubject(session?.subject);
  const normalizedStatus = ["completed", "incomplete", "interrupted"].includes(String(status || "").toLowerCase()) ? String(status).toLowerCase() : completed ? "completed" : "incomplete";
  item.studyMinutes += minutes;
  item.subjects = adjustSubjectStudy(item.subjects, subject, minutes, completed ? 1 : 0);
  if (completed) {
    item.verifiedStudyMinutes = num(item.verifiedStudyMinutes) + minutes;
    item.completedSessions = num(item.completedSessions) + 1;
  }
  item.sessions = num(item.sessions) + 1;
  item.distractionsBlocked = num(item.distractionsBlocked) + num(session?.distractionsBlocked);
  item.sessionIds = [...new Set([...item.sessionIds, String(id)])];
  daily[date] = item;
  const activeIntervals = activeStudyIntervalsForSession(session, now);
  const historyItem = { id, courseId: session?.courseId || null, courseTitle: session?.courseTitle || "Focus session", subject, startedAt: session?.startedAt || now, endedAt: now, recordedDate: date, actualTracked: true, plannedMinutes, actualMinutes: minutes, durationMinutes: minutes, activeIntervals, completionPercent: Math.round(Math.max(0, Math.min(100, plannedMinutes ? (minutes / plannedMinutes) * 100 : normalizedStatus === "completed" ? 100 : 0))), completed: normalizedStatus === "completed", status: normalizedStatus, xpEarned: sessionXp(minutes, normalizedStatus === "completed"), distractionsBlocked: num(session?.distractionsBlocked) };
  const focusHistory = [historyItem, ...(base.focusHistory || []).filter((entry) => String(entry?.id || "") !== String(id))].slice(0, 300);
  return { daily, focusHistory, streak: completed && minutes > 0 ? streakAfterStudy(base.streak, date) : base.streak || defaultAnalytics().streak };
}
export function recordDistractionAnalytics(analytics, now = Date.now()) { const date = todayKey(new Date(now)); const base = { ...defaultAnalytics(), ...(analytics || {}) }; const daily = { ...(base.daily || {}) }; const item = analyticsDay(daily, date); item.distractionsBlocked += 1; daily[date] = item; return { ...base, daily }; }
export function dateSeries(days = 14, end = new Date()) { return Array.from({ length: days }, (_, index) => { const d = new Date(end); d.setDate(d.getDate() - (days - index - 1)); return todayKey(d); }); }
export function focusGreeting(name = "", now = new Date()) {
  const hour = (now instanceof Date ? now : new Date(now)).getHours();
  const prefix = hour >= 5 && hour < 12 ? "Good morning" : hour >= 12 && hour < 17 ? "Good afternoon" : hour >= 17 && hour < 21 ? "Good evening" : "Good night";
  const cleanName = String(name || "").trim().slice(0, 60);
  return prefix + (cleanName ? ", " + cleanName : "") + (prefix === "Good night" ? " 🌙" : " 👋");
}
export function dashboardHeaderPresentation({ tab = "focus", session = null, course = null, profileName = "", now = new Date() } = {}) {
  const activeTab = String(tab || "focus");
  const focusTabActive = activeTab === "focus";
  const pageHeadings = { courses: "Your study library", analytics: "Track your study progress.", daily: "Daily goals", music: "Study music", settings: "Settings", about: "About Studizen" };
  const pageLabels = { courses: "Courses", analytics: "Analytics", daily: "Daily Goals", music: "Music", settings: "Settings", about: "About" };
  const sessionStatus = session?.paused ? "Focus paused" : "Focus running";
  return {
    eyebrow: focusTabActive ? (session ? sessionStatus : "Ready") : (pageLabels[activeTab] || "Studizen"),
    title: focusTabActive ? focusGreeting(profileName, now) : (pageHeadings[activeTab] || "Studizen"),
    showSessionIndicator: Boolean(session) && !focusTabActive,
    sessionStatus,
    sessionTitle: session?.courseTitle || course?.title || "Current course"
  };
}
export function completedPeriodAnalytics(summary = {}, period = "current-week", now = new Date(), dailyGoalHours = 0, weeklyGoalMinutes = null) {
  const date = now instanceof Date ? new Date(now) : new Date(now);
  const currentDay = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const mondayOffset = (currentDay.getDay() + 6) % 7;
  const weekStart = new Date(currentDay); weekStart.setDate(currentDay.getDate() - mondayOffset);
  let keys = [];
  if (period === "previous-week") {
    const previousWeekEnd = new Date(weekStart); previousWeekEnd.setDate(weekStart.getDate() - 1);
    keys = dateSeries(7, previousWeekEnd);
  } else if (period === "current-month") {
    keys = dateSeries(currentDay.getDate(), currentDay);
  } else if (period === "previous-month") {
    const previousMonthEnd = new Date(currentDay.getFullYear(), currentDay.getMonth(), 0);
    keys = dateSeries(previousMonthEnd.getDate(), previousMonthEnd);
  } else {
    keys = dateSeries(mondayOffset + 1, currentDay);
  }
  const keySet = new Set(keys);
  const sessions = Array.isArray(summary.sessions) ? summary.sessions.filter((session) => keySet.has(session?.recordedDate)) : [];
  const minutes = summary.byDate instanceof Map
    ? keys.reduce((total, key) => total + Math.max(0, num(summary.byDate.get(key))), 0)
    : sessions.reduce((total, session) => total + Math.max(0, num(session?.actualMinutes, num(session?.durationMinutes))), 0);
  const courses = new Map();
  sessions.forEach((session) => {
    const id = String(session?.courseId || session?.courseTitle || "Focus session");
    const entry = courses.get(id) || { id: session?.courseId || null, title: String(session?.courseTitle || "Focus session"), minutes: 0, sessions: 0 };
    entry.minutes += Math.max(0, num(session?.actualMinutes, num(session?.durationMinutes)));
    entry.sessions += 1;
    courses.set(id, entry);
  });
  const usesWeeklyTarget = weeklyGoalMinutes !== null && weeklyGoalMinutes !== undefined;
  const goalMinutes = Math.max(0, usesWeeklyTarget
    ? num(weeklyGoalMinutes) * (period === "previous-month" || period === "current-month" ? keys.length / 7 : 1)
    : num(dailyGoalHours) * 60 * keys.length);
  const completedSessions = sessions.filter((session) => session?.completed === true && session?.status === "completed").length;
  return {
    period,
    keys,
    sessions,
    minutes,
    completedSessions,
    recordedSessions: sessions.length,
    dailyAverageMinutes: keys.length ? Math.round(minutes / keys.length) : 0,
    goalMinutes,
    goalProgress: goalMinutes ? Math.round((minutes / goalMinutes) * 100) : null,
    courseEntries: [...courses.values()].sort((a, b) => b.minutes - a.minutes || b.sessions - a.sessions || a.title.localeCompare(b.title))
  };
}
export function recordedStudyPeriod(sessions = [], dateKeys = [], now = Date.now(), liveSession = null) {
  const keys = [...new Set((Array.isArray(dateKeys) ? dateKeys : []).filter((key) => /^\d{4}-\d{2}-\d{2}$/.test(String(key))))].sort();
  const sourceById = new Map();
  (Array.isArray(sessions) ? sessions : []).forEach((session) => {
    const id = String(session?.id || "");
    if (id && !sourceById.has(id)) sourceById.set(id, session);
  });
  if (liveSession?.active && liveSession.id) sourceById.set(String(liveSession.id), liveSession);

  const byId = new Map();
  const days = keys.map((dateKey) => {
    const daySessions = studySessionsForLocalDay(sessions, dateKey, now, liveSession);
    const milliseconds = daySessions.reduce((sum, session) => sum + session.focusedMilliseconds, 0);
    daySessions.forEach((daySession) => {
      if (daySession.focusedMilliseconds <= 0) return;
      const source = sourceById.get(daySession.id) || {};
      const entry = byId.get(daySession.id) || {
        id: daySession.id,
        courseId: daySession.courseId || source.courseId || null,
        courseTitle: daySession.courseTitle || source.courseTitle || "",
        subject: daySession.subject || "Unassigned",
        mode: daySession.mode || source.mode || "normal",
        startedAt: daySession.startedAt || source.startedAt || 0,
        endedAt: daySession.endedAt || source.endedAt || null,
        completed: source.completed === true && source.status === "completed",
        status: source.status || daySession.status,
        activeIntervals: [],
        focusedMilliseconds: 0
      };
      entry.focusedMilliseconds += daySession.focusedMilliseconds;
      entry.activeIntervals.push(...daySession.activeIntervals);
      byId.set(daySession.id, entry);
    });
    const date = new Date(dateKey + "T12:00:00");
    return {
      dateKey,
      label: keys.length <= 7
        ? date.toLocaleDateString(undefined, { weekday: "short" })
        : String(date.getDate()),
      dateLabel: date.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric", year: "numeric" }),
      milliseconds,
      sessions: daySessions
    };
  });

  const periodSessions = [...byId.values()].map((session) => ({
    ...session,
    activeIntervals: normalizeStudyIntervals(session.activeIntervals),
    actualMinutes: session.focusedMilliseconds / 60000,
    durationMinutes: session.focusedMilliseconds / 60000
  })).sort((a, b) => (b.endedAt || b.startedAt) - (a.endedAt || a.startedAt));
  const bySubject = new Map();
  const byCourse = new Map();
  periodSessions.forEach((session) => {
    const subject = normalizeSubject(session.subject);
    bySubject.set(subject, (bySubject.get(subject) || 0) + session.focusedMilliseconds);
    const courseKey = String(session.courseId || session.courseTitle || "Focus session");
    const course = byCourse.get(courseKey) || { id: session.courseId || null, title: session.courseTitle || "Focus session", milliseconds: 0, sessions: 0 };
    course.milliseconds += session.focusedMilliseconds;
    course.sessions += 1;
    byCourse.set(courseKey, course);
  });
  const minutes = periodSessions.reduce((sum, session) => sum + session.focusedMilliseconds, 0) / 60000;
  return {
    keys,
    days,
    sessions: periodSessions,
    minutes,
    completedSessions: periodSessions.filter((session) => session.completed).length,
    recordedSessions: periodSessions.length,
    dailyAverageMinutes: keys.length ? Math.round(minutes / keys.length) : 0,
    bySubject,
    courseEntries: [...byCourse.values()].map((course) => ({ ...course, minutes: course.milliseconds / 60000 }))
      .sort((a, b) => b.minutes - a.minutes || b.sessions - a.sessions || a.title.localeCompare(b.title))
  };
}
export function historicalStudyTargets(dailyRecords = {}, dateKeys = []) {
  const keys = Array.isArray(dateKeys) ? dateKeys : [];
  if (!keys.length) return { dailyAvailable: false, weeklyAvailable: false, dailyMinutes: null, periodGoalMinutes: null };
  let dailyMinutes = 0;
  let dailyKnown = 0;
  let weeklyEquivalentMinutes = 0;
  let weeklyKnown = 0;
  keys.forEach((dateKey) => {
    const record = dailyRecords?.[dateKey];
    const savedTargets = record?.goalTargets && typeof record.goalTargets === "object" ? record.goalTargets : null;
    const savedDaily = record?.dailyGoal && typeof record.dailyGoal === "object" ? record.dailyGoal : null;
    const hasDailyTarget = savedTargets && Object.hasOwn(savedTargets, "dailyMinutes")
      || savedDaily && Object.hasOwn(savedDaily, "targetMinutes");
    const dailyTarget = savedTargets && Object.hasOwn(savedTargets, "dailyMinutes")
      ? num(savedTargets.dailyMinutes, NaN)
      : savedDaily && Object.hasOwn(savedDaily, "targetMinutes") ? num(savedDaily.targetMinutes, NaN) : NaN;
    if (hasDailyTarget && Number.isFinite(dailyTarget) && dailyTarget >= 0) {
      dailyMinutes += dailyTarget;
      dailyKnown += 1;
    }
    const hasWeeklyTarget = savedTargets && Object.hasOwn(savedTargets, "weeklyMinutes");
    const weeklyTarget = hasWeeklyTarget ? num(savedTargets.weeklyMinutes, NaN) : NaN;
    if (hasWeeklyTarget && Number.isFinite(weeklyTarget) && weeklyTarget >= 0) {
      weeklyEquivalentMinutes += weeklyTarget / 7;
      weeklyKnown += 1;
    } else if (Number.isFinite(dailyTarget) && dailyTarget >= 0 && Number.isFinite(num(savedTargets?.studyDays, NaN))) {
      weeklyEquivalentMinutes += dailyTarget * Math.max(1, Math.min(7, num(savedTargets.studyDays))) / 7;
      weeklyKnown += 1;
    }
  });
  return {
    dailyAvailable: dailyKnown === keys.length,
    weeklyAvailable: weeklyKnown === keys.length,
    dailyMinutes: dailyKnown === keys.length ? dailyMinutes : null,
    periodGoalMinutes: weeklyKnown === keys.length ? weeklyEquivalentMinutes : null
  };
}
export function buildWeeklyStudyReport(input = {}, weekAnchor = new Date(), now = Date.now(), timeZone = localTimeZone()) {
  const state = mergeState(input);
  const anchor = typeof weekAnchor === "string" && validDateKey(weekAnchor) ? weekAnchor : dateKeyInTimeZone(weekAnchor, timeZone);
  if (!validDateKey(anchor)) throw new TypeError("A valid week date is required.");
  const [anchorYear, anchorMonth, anchorDay] = anchor.split("-").map(Number);
  const monday = new Date(Date.UTC(anchorYear, anchorMonth - 1, anchorDay, 12));
  monday.setUTCDate(monday.getUTCDate() - ((monday.getUTCDay() + 6) % 7));
  const keys = Array.from({ length: 7 }, (_, index) => {
    const day = new Date(monday);
    day.setUTCDate(monday.getUTCDate() + index);
    return day.toISOString().slice(0, 10);
  });
  const today = dateKeyInTimeZone(now, timeZone);
  const weekEnd = keys[6];
  const isCurrentWeek = keys[0] <= today && today <= weekEnd;
  const isComplete = weekEnd < today;
  const records = state.analytics?.daily || {};
  const historyByDate = new Map();
  const seenSessions = new Set();
  (state.analytics?.focusHistory || []).forEach((session) => {
    if (!session?.id || seenSessions.has(String(session.id))) return;
    seenSessions.add(String(session.id));
    const date = validDateKey(session.recordedDate) ? session.recordedDate : dateKeyInTimeZone(num(session.endedAt || session.startedAt, now), timeZone);
    if (!keys.includes(date)) return;
    const list = historyByDate.get(date) || [];
    list.push(session);
    historyByDate.set(date, list);
  });
  const targets = resolveStudyTargets(state);
  const dailyComparison = keys.map((date) => {
    const record = records[date] || {};
    const sessions = historyByDate.get(date) || [];
    const historyMinutes = sessions.filter((session) => session.actualTracked === true).reduce((total, session) => total + Math.max(0, num(session.actualMinutes, num(session.durationMinutes))), 0);
    const minutes = Math.max(0, num(record.studyMinutes), historyMinutes);
    const subjectTotals = new Map();
    Object.entries(record.subjects || {}).forEach(([subject, value]) => {
      const amount = Math.max(0, num(value?.studyMinutes));
      if (amount) subjectTotals.set(subject, amount);
    });
    const historySubjects = new Map();
    sessions.filter((session) => session.actualTracked === true).forEach((session) => {
      const subject = normalizeSubject(session.subject, state.profile?.studyProfile);
      historySubjects.set(subject, (historySubjects.get(subject) || 0) + Math.max(0, num(session.actualMinutes, num(session.durationMinutes))));
    });
    historySubjects.forEach((amount, subject) => subjectTotals.set(subject, Math.max(subjectTotals.get(subject) || 0, amount)));
    const dailyTarget = Math.max(0, num(record.goalTargets?.dailyMinutes, num(record.dailyGoal?.targetMinutes, date === today ? targets.dailyMinutes : 0)));
    const achieved = typeof record.dailyGoal?.achieved === "boolean" ? record.dailyGoal.achieved : null;
    const completedTasks = Array.isArray(record.completedTasks) ? record.completedTasks.map((task) => ({ ...task, date })) : [];
    const sessionIds = new Set([...(Array.isArray(record.sessionIds) ? record.sessionIds : []), ...sessions.map((session) => String(session.id))]);
    const dateObject = new Date(date + "T12:00:00.000Z");
    return {
      date,
      label: new Intl.DateTimeFormat(undefined, { weekday: "short", timeZone: "UTC" }).format(dateObject),
      studyMinutes: minutes,
      subjectMinutes: Object.fromEntries(subjectTotals),
      sessions: Math.max(Math.max(0, num(record.sessions)), sessionIds.size),
      completedSessions: Math.max(Math.max(0, num(record.completedSessions)), sessions.filter((session) => session.status === "completed" && session.completed === true).length),
      completedTasks,
      weeklyTargetMinutes: Math.max(0, num(record.goalTargets?.weeklyMinutes)),
      dailyGoal: { targetMinutes: dailyTarget, achieved, percent: dailyTarget ? Math.round((minutes / dailyTarget) * 100) : 0 }
    };
  });
  const subjectMinutes = {};
  dailyComparison.forEach((day) => Object.entries(day.subjectMinutes).forEach(([subject, minutes]) => { subjectMinutes[subject] = (subjectMinutes[subject] || 0) + minutes; }));
  const completedTasks = [...new Map(dailyComparison.flatMap((day) => day.completedTasks).map((task) => [dayTaskKey(task), task])).values()];
  const totalStudyMinutes = dailyComparison.reduce((sum, day) => sum + day.studyMinutes, 0);
  const savedWeeklyTargets = dailyComparison.map((day) => day.weeklyTargetMinutes).filter((minutes) => minutes > 0);
  const weeklyTargetMinutes = Math.max(0, num(isCurrentWeek ? targets.weeklyMinutes : savedWeeklyTargets.at(-1), 0));
  const completedGoalDays = dailyComparison.filter((day) => day.dailyGoal.achieved).length;
  return {
    weekStart: keys[0],
    weekEnd,
    status: isComplete ? "complete" : isCurrentWeek ? "in-progress" : "upcoming",
    isComplete,
    dailyComparison,
    totalStudyMinutes,
    subjectMinutes,
    focusSessions: dailyComparison.reduce((sum, day) => sum + day.sessions, 0),
    completedSessions: dailyComparison.reduce((sum, day) => sum + day.completedSessions, 0),
    completedTasks,
    goalAchievement: {
      completedDays: completedGoalDays,
      trackedDays: dailyComparison.filter((day) => day.dailyGoal.achieved !== null).length,
      weeklyTargetMinutes,
      actualMinutes: totalStudyMinutes,
      percent: weeklyTargetMinutes ? Math.round((totalStudyMinutes / weeklyTargetMinutes) * 100) : 0,
      achieved: weeklyTargetMinutes > 0 ? totalStudyMinutes >= weeklyTargetMinutes : null
    }
  };
}
function dayTaskKey(task) { return String(task?.date || "") + ":" + String(task?.id || ""); }
export function completedFocusAnalytics(input = {}, now = Date.now()) {
  const state = mergeState(input);
  const byDate = new Map(); const bySubject = new Map(); const byCourse = new Map(); const seen = new Set(); const sessions = [];
  let totalMinutes = 0; let longest = null;
  for (const item of Array.isArray(state.analytics?.focusHistory) ? state.analytics.focusHistory : []) {
    if (!item || typeof item !== "object" || item.completed !== true || item.status !== "completed") continue;
    const id = String(item.id || ""); const endedAt = num(item.endedAt, 0); const startedAt = num(item.startedAt, 0); const minutes = Math.max(0, num(item.actualMinutes, num(item.durationMinutes)));
    if (!id || seen.has(id) || !Number.isFinite(startedAt) || startedAt <= 0 || !Number.isFinite(endedAt) || endedAt <= 0 || !Number.isFinite(minutes) || minutes <= 0) continue;
    seen.add(id);
    const date = /^\d{4}-\d{2}-\d{2}$/.test(String(item.recordedDate || "")) ? item.recordedDate : todayKey(new Date(endedAt));
    const subject = normalizeSubject(item.subject, state.profile?.studyProfile);
    const courseKey = String(item.courseId || item.courseTitle || "Focus session");
    const course = byCourse.get(courseKey) || { id: item.courseId || null, title: String(item.courseTitle || "Focus session"), minutes: 0, sessions: 0 };
    const subjectEntry = bySubject.get(subject) || { minutes: 0, sessions: 0 };
    addSessionMinutesByLocalDate(byDate, item.activeIntervals, date, minutes);
    subjectEntry.minutes += minutes; subjectEntry.sessions += 1; bySubject.set(subject, subjectEntry);
    course.minutes += minutes; course.sessions += 1; byCourse.set(courseKey, course);
    const entry = { ...item, actualMinutes: minutes, durationMinutes: minutes, recordedDate: date, subject, endedAt, startedAt };
    sessions.push(entry); totalMinutes += minutes;
    if (!longest || minutes > longest.actualMinutes) longest = entry;
  }
  sessions.sort((a, b) => b.endedAt - a.endedAt);
  const today = todayKey(new Date(now)); const weekKeys = studyWeekForLocalWeek([], new Date(now), now).days.map((day) => day.dateKey); const monthPrefix = today.slice(0, 7);
  const sumDates = (keys) => keys.reduce((sum, key) => sum + (byDate.get(key) || 0), 0);
  const courseEntries = [...byCourse.values()].sort((a, b) => b.minutes - a.minutes || b.sessions - a.sessions || a.title.localeCompare(b.title));
  return { sessions, totalMinutes, completedSessions: sessions.length, averageSessionMinutes: sessions.length ? Math.round(totalMinutes / sessions.length) : 0, longestSession: longest, byDate, bySubject, byCourse, courseEntries, todayMinutes: byDate.get(today) || 0, weekMinutes: sumDates(weekKeys), monthMinutes: [...byDate.entries()].filter(([key]) => key.startsWith(monthPrefix)).reduce((sum, [, minutes]) => sum + minutes, 0), today, weekKeys };
}
export function recordedStudyAnalytics(input = {}, now = Date.now()) {
  const state = mergeState(input);
  const byDate = new Map(); const bySubject = new Map(); const byCourse = new Map(); const seen = new Set(); const sessions = [];
  const profileId = state.profile?.studyProfile;
  const targets = normalizeStudyTargets(state.goals?.analyticsTargets, profileId);
  const customSubjects = [...new Set([...(targets?.customSubjects || []), ...(state.courses || []).map((course) => course.subject), ...(state.analytics?.focusHistory || []).map((item) => item?.subject)].filter(Boolean))];
  let totalMinutes = 0; let longestSession = null;
  for (const item of Array.isArray(state.analytics?.focusHistory) ? state.analytics.focusHistory : []) {
    if (!item || typeof item !== "object" || item.actualTracked !== true) continue;
    const id = String(item.id || "");
    const endedAt = num(item.endedAt, 0); const startedAt = num(item.startedAt, 0);
    const minutes = Math.max(0, num(item.actualMinutes, num(item.durationMinutes)));
    if (!id || seen.has(id) || !Number.isFinite(startedAt) || startedAt <= 0 || !Number.isFinite(endedAt) || endedAt <= 0 || !Number.isFinite(minutes) || minutes <= 0) continue;
    seen.add(id);
    const date = /^\d{4}-\d{2}-\d{2}$/.test(String(item.recordedDate || "")) ? item.recordedDate : todayKey(new Date(endedAt));
    const subject = normalizeSubject(item.subject, profileId, customSubjects);
    const courseKey = String(item.courseId || item.courseTitle || "Focus session");
    const course = byCourse.get(courseKey) || { id: item.courseId || null, title: String(item.courseTitle || "Focus session"), minutes: 0, sessions: 0 };
    const subjectEntry = bySubject.get(subject) || { minutes: 0, sessions: 0 };
    addSessionMinutesByLocalDate(byDate, item.activeIntervals, date, minutes);
    subjectEntry.minutes += minutes; subjectEntry.sessions += 1; bySubject.set(subject, subjectEntry);
    course.minutes += minutes; course.sessions += 1; byCourse.set(courseKey, course);
    const session = { ...item, actualMinutes: minutes, durationMinutes: minutes, recordedDate: date, subject, endedAt, startedAt };
    sessions.push(session); totalMinutes += minutes;
    if (!longestSession || minutes > longestSession.actualMinutes) longestSession = session;
  }
  sessions.sort((a, b) => b.endedAt - a.endedAt);
  const today = todayKey(new Date(now)); const weekKeys = studyWeekForLocalWeek([], new Date(now), now).days.map((day) => day.dateKey); const monthPrefix = today.slice(0, 7);
  const sumDates = (keys) => keys.reduce((sum, key) => sum + (byDate.get(key) || 0), 0);
  const courseEntries = [...byCourse.values()].sort((a, b) => b.minutes - a.minutes || b.sessions - a.sessions || a.title.localeCompare(b.title));
  const completedSessions = sessions.filter((session) => session.completed === true && session.status === "completed").length;
  return { sessions, totalMinutes, completedSessions, recordedSessions: sessions.length, averageSessionMinutes: sessions.length ? Math.round(totalMinutes / sessions.length) : 0, longestSession, byDate, bySubject, byCourse, courseEntries, todayMinutes: byDate.get(today) || 0, weekMinutes: sumDates(weekKeys), monthMinutes: [...byDate.entries()].filter(([key]) => key.startsWith(monthPrefix)).reduce((sum, [, minutes]) => sum + minutes, 0), today, weekKeys };
}
export function productivityScore(state) { const s = mergeState(state); const today = todayKey(); const studyMinutes = actualStudyMinutesForDate(s, today); const daily = s.analytics.daily?.[today] || {}; const completedSessions = Math.max(num(daily.completedSessions), num(s.stats.sessionsCompleted)); const study = Math.min(65, (studyMinutes / Math.max(1, s.goals.studyHours * 60)) * 65); const sessions = Math.min(25, (completedSessions / 2) * 25); const penalty = Math.min(25, s.stats.distractions * 3); return Math.max(0, Math.min(100, Math.round(study + sessions + 10 - penalty))); }
function insightDateKey(value, fallback) {
  const at = num(value, 0);
  return at > 0 ? todayKey(new Date(at)) : fallback;
}
function insightMinutes(item) { return Math.max(0, num(item?.actualMinutes, num(item?.durationMinutes))); }
function insightHash(value = "") {
  let hash = 0;
  for (const char of String(value)) hash = ((hash << 5) - hash + char.charCodeAt(0)) | 0;
  return Math.abs(hash);
}
function insightDateOffset(date, offset) {
  const next = new Date(date);
  next.setDate(next.getDate() + offset);
  return todayKey(next);
}
function insightRangeSummary(daily, keys) {
  const values = keys.map((key) => Math.max(0, num(daily?.[key]?.studyMinutes)));
  return { minutes: values.reduce((sum, value) => sum + value, 0), days: values.filter((value) => value > 0).length };
}

// Uses existing recorded focus history and daily analytics only; it stores no derived insight state.
export function buildTodayInsight(input = {}, now = Date.now()) {
  const state = mergeState(input);
  const today = todayKey(new Date(now));
  const daily = state.analytics?.daily && typeof state.analytics.daily === "object" ? state.analytics.daily : {};
  const history = (Array.isArray(state.analytics?.focusHistory) ? state.analytics.focusHistory : []).filter((item) => item && typeof item === "object");
  const finished = history.filter((item) => ["completed", "incomplete", "interrupted"].includes(String(item.status || "").toLowerCase()) || typeof item.completed === "boolean");
  const todayEntries = finished.filter((item) => String(item.recordedDate || insightDateKey(item.endedAt || item.startedAt, "")) === today);
  const todayCompleted = todayEntries.filter((item) => item.completed === true || String(item.status).toLowerCase() === "completed");
  const todayActual = actualStudyMinutesForDate(state, today, now);
  const todayVerified = Math.max(0, num(daily[today]?.verifiedStudyMinutes));
  const completedCount = Math.max(todayCompleted.length, num(daily[today]?.completedSessions), state.stats?.date === today ? num(state.stats?.sessionsCompleted) : 0);
  const goalMinutes = Math.max(0, num(state.goals?.studyHours, DEFAULT_STUDY_GOALS.studyHours) * 60);
  const candidates = [];
  const add = (priority, key, title, text) => candidates.push({ priority, key, title, text });
  const sessionSubject = (item) => {
    const subject = String(item?.subject || "").trim();
    return subject || "your selected subject";
  };

  const blockedEvents = (Array.isArray(state.protection?.blockedAttempts) ? state.protection.blockedAttempts : []).filter((event) => insightDateKey(event?.at, "") === today).length;
  const recordedBlocks = Math.max(0, num(daily[today]?.distractionsBlocked));
  const statBlocks = state.stats?.date === today ? Math.max(0, num(state.stats?.distractions)) : 0;
  const blockedAttempts = Math.max(recordedBlocks, statBlocks, blockedEvents);
  const hasStoredStudy = Object.values(daily).some((item) => Math.max(0, num(item?.studyMinutes), num(item?.verifiedStudyMinutes)) > 0);

  if (!finished.length && !state.focusSession?.active && !hasStoredStudy && !blockedAttempts) {
    return { title: "Start your first session", text: "Add a course, then complete one focus session to begin building personal study insights.", key: "no-study-data" };
  }
  if (!todayEntries.length && !state.focusSession?.active && todayActual <= 0 && !blockedAttempts) {
    const latest = finished.slice().sort((a, b) => num(b.endedAt || b.startedAt) - num(a.endedAt || a.startedAt))[0];
    const latestMinutes = insightMinutes(latest);
    return {
      title: "No focus time recorded today",
      text: latest?.completed && latestMinutes > 0 ? "Your last completed session was " + formatDuration(latestMinutes) + " in " + sessionSubject(latest) + "." : "Start a focus session today to keep your study record current.",
      key: "no-study-today"
    };
  }
  if (state.focusSession?.active && !todayEntries.length) add(12, "focus-in-progress", "Focus in progress", "Your current " + (state.focusSession.courseTitle || "focus") + " session is now contributing to today's study progress.");
  if (goalMinutes > 0 && todayActual >= goalMinutes) add(14, "goal-complete", "Today's study goal reached", "You've reached your " + formatDuration(goalMinutes) + " study goal with " + formatDuration(todayActual) + " focused today.");
  if (goalMinutes > 0 && todayActual < goalMinutes) {
    const remaining = Math.max(0, goalMinutes - todayActual);
    const percent = Math.min(100, Math.round((todayActual / goalMinutes) * 100));
    if (remaining <= 45 && todayActual > 0) add(16, "goal-near", "Close to today's goal", "You're " + formatDuration(remaining) + " away from today's " + formatDuration(goalMinutes) + " study goal.");
    else if (percent >= 50) add(24, "goal-progress", "Today's goal progress", "You've completed " + percent + "% of today's study goal: " + formatDuration(todayActual) + " of " + formatDuration(goalMinutes) + ".");
  }
  if (blockedAttempts > 0) add(18, "blocked-attempts", "Focus protection is active", "You had " + blockedAttempts + " blocked distraction " + (blockedAttempts === 1 ? "attempt" : "attempts") + " today. Your focus protection is doing its job.");

  const completedBySubject = new Map();
  todayCompleted.forEach((item) => {
    const subject = sessionSubject(item);
    const entry = completedBySubject.get(subject) || { count: 0, minutes: 0 };
    entry.count += 1;
    entry.minutes += insightMinutes(item);
    completedBySubject.set(subject, entry);
  });
  const todaySubjectLeader = [...completedBySubject.entries()].sort((a, b) => b[1].count - a[1].count || b[1].minutes - a[1].minutes)[0];
  if (todaySubjectLeader?.[1].count >= 2) add(20, "subject-sessions", "Focused work today", "You completed " + todaySubjectLeader[1].count + " " + todaySubjectLeader[0] + " sessions today.");
  if (completedCount >= 3) add(22, "sessions-today", "Strong session count", "You completed " + completedCount + " focus sessions today.");
  if (todayCompleted.length === 1) {
    const item = todayCompleted[0];
    add(25, "one-completed", "Completed session", "You completed " + formatDuration(insightMinutes(item)) + " of " + sessionSubject(item) + " today.");
  }
  const longest = todayCompleted.reduce((best, item) => insightMinutes(item) > insightMinutes(best) ? item : best, null);
  if (longest && insightMinutes(longest) > 0) add(28, "longest-session", "Longest completed session", "Your longest completed session today was " + formatDuration(insightMinutes(longest)) + " in " + sessionSubject(longest) + ".");
  const interrupted = todayEntries.filter((item) => String(item.status).toLowerCase() === "interrupted");
  if (interrupted.length) {
    const minutes = interrupted.reduce((sum, item) => sum + insightMinutes(item), 0);
    add(30, "interrupted", "Focus time preserved", "You had " + interrupted.length + " interrupted " + (interrupted.length === 1 ? "session" : "sessions") + " today; " + formatDuration(minutes) + " of focused time is still reflected in your progress.");
  }
  const streak = Math.max(0, num(state.analytics?.streak?.current));
  if (streak >= 2) add(32, "streak", "Study consistency", "You've completed focus sessions on " + streak + " days in a row.");

  const weekKeys = Array.from({ length: 7 }, (_, index) => insightDateOffset(new Date(now), -index));
  const previousWeekKeys = Array.from({ length: 7 }, (_, index) => insightDateOffset(new Date(now), -7 - index));
  const weeklySubjectTotals = new Map();
  const previousSubjectTotals = new Map();
  const courseTotals = new Map();
  finished.forEach((item) => {
    const key = String(item.recordedDate || insightDateKey(item.endedAt || item.startedAt, ""));
    const minutes = insightMinutes(item);
    if (!minutes) return;
    const subject = sessionSubject(item);
    if (weekKeys.includes(key)) weeklySubjectTotals.set(subject, (weeklySubjectTotals.get(subject) || 0) + minutes);
    if (previousWeekKeys.includes(key)) previousSubjectTotals.set(subject, (previousSubjectTotals.get(subject) || 0) + minutes);
    if (weekKeys.includes(key)) {
      const course = String(item.courseTitle || state.courses.find((candidate) => candidate.id === item.courseId)?.title || "").trim();
      if (course) courseTotals.set(course, (courseTotals.get(course) || 0) + minutes);
    }
  });
  const weeklySubjects = [...weeklySubjectTotals.entries()].filter(([, minutes]) => minutes > 0).sort((a, b) => b[1] - a[1]);
  if (weeklySubjects.length) add(38, "most-studied-subject", "Most studied this week", weeklySubjects[0][0] + " was your most studied subject this week with " + formatDuration(weeklySubjects[0][1]) + ".");
  const weeklyTargets = resolveStudyTargets(state);
  const subjectTargetGap = weeklySubjects.length
    ? leastMetSubjectTarget(Object.fromEntries(weeklySubjectTotals), weeklyTargets.subjectTargets, weeklyTargets.studyDays)
    : null;
  if (subjectTargetGap) {
    add(40, "subject-target-gap", "Balance your subject targets", subjectTargetGap.subject + " has " + formatDuration(subjectTargetGap.actualMinutes) + " this week against a " + formatDuration(subjectTargetGap.dailyTargetMinutes) + " daily target (" + formatDuration(subjectTargetGap.targetMinutes) + " across " + weeklyTargets.studyDays + " planned study days).");
  } else if (weeklySubjects.length >= 2) {
    const least = weeklySubjects[weeklySubjects.length - 1];
    add(40, "least-studied-subject", "Balance your subjects", least[0] + " received the least study time among the subjects you worked on this week: " + formatDuration(least[1]) + ".");
  }
  const topCourse = [...courseTotals.entries()].sort((a, b) => b[1] - a[1])[0];
  if (topCourse && topCourse[1] > 0) add(42, "most-studied-course", "Most studied course", topCourse[0] + " received " + formatDuration(topCourse[1]) + " of focused study time this week.");

  const yesterday = insightDateOffset(new Date(now), -1);
  const yesterdayMinutes = Math.max(0, num(daily[yesterday]?.studyMinutes));
  if (todayActual > 0 && yesterdayMinutes > 0) {
    const difference = Math.abs(todayActual - yesterdayMinutes);
    if (difference > 0) add(44, "today-vs-yesterday", "Compared with yesterday", "You've studied " + formatDuration(difference) + " " + (todayActual > yesterdayMinutes ? "more" : "less") + " than yesterday so far.");
  }
  const currentWeek = insightRangeSummary(daily, weekKeys);
  const previousWeek = insightRangeSummary(daily, previousWeekKeys);
  if (currentWeek.days >= 2 && previousWeek.days >= 2 && currentWeek.minutes > 0 && previousWeek.minutes > 0 && currentWeek.minutes !== previousWeek.minutes) {
    const difference = Math.abs(currentWeek.minutes - previousWeek.minutes);
    add(46, "week-comparison", "Weekly study trend", "This week's study time is " + formatDuration(difference) + " " + (currentWeek.minutes > previousWeek.minutes ? "ahead of" : "behind") + " the previous 7 days.");
  }
  const previousLeader = [...previousSubjectTotals.entries()].filter(([, minutes]) => minutes > 0).sort((a, b) => b[1] - a[1])[0];
  if (weeklySubjects[0] && previousLeader && weeklySubjects[0][0] !== previousLeader[0]) add(48, "subject-shift", "Subject focus shift", weeklySubjects[0][0] + " leads this week, while " + previousLeader[0] + " led the previous week.");

  if (!candidates.length) {
    if (todayVerified > 0) return { title: "Study record updated", text: "Your completed focus time is recorded and ready for deeper comparisons as you add more sessions.", key: "completed-fallback" };
    return { title: "Focus time recorded", text: "Your focused time is saved. Complete a session to unlock completion and consistency insights.", key: "actual-fallback" };
  }
  const bestPriority = Math.min(...candidates.map((candidate) => candidate.priority));
  const relevant = candidates.filter((candidate) => candidate.priority <= bestPriority + 24);
  const signature = [today, todayActual, todayVerified, completedCount, goalMinutes, blockedAttempts, streak, history.map((item) => [item.id, item.status, insightMinutes(item), item.endedAt]).join("|")].join(";");
  return relevant[insightHash(signature) % relevant.length];
}
export function goalProgressPercent(state) { const s = mergeState(state); const today = todayKey(); const daily = s.analytics.daily?.[today] || {}; const studyMinutes = actualStudyMinutesForDate(s, today); const completedSessions = Math.max(num(daily.completedSessions), num(s.stats.sessionsCompleted)); const study = s.goals.studyHours ? Math.min(1, studyMinutes / (s.goals.studyHours * 60)) : 0; const sessions = Math.min(1, completedSessions / 2); const streak = (s.analytics.streak?.current || 0) > 0 ? 1 : 0; return Math.round(((study + sessions + streak) / 3) * 100); }
export function recordProtectionEvent(protection, bucket, event = {}) { const p = { tabSwitches: normalizeEvents(protection?.tabSwitches), blockedAttempts: normalizeEvents(protection?.blockedAttempts), browsingEvents: normalizeEvents(protection?.browsingEvents), lastAssistantNoticeAt: protection?.lastAssistantNoticeAt || null }; const key = ["tabSwitches", "blockedAttempts", "browsingEvents"].includes(bucket) ? bucket : "browsingEvents"; p[key] = [...p[key], { at: num(event.at, Date.now()), type: String(event.type || bucket), host: String(event.host || ""), reason: String(event.reason || "") }].slice(-120); return p; }
export function countRecent(events, windowMs = 5 * 60 * 1000, now = Date.now()) { return (Array.isArray(events) ? events : []).filter((event) => now - num(event.at) <= windowMs).length; }
export function nextStudyTask(state) { const s = mergeState(state); const task = s.daily.tasks.find((t) => !t.done); const course = getActiveCourse(s); if (task) return task.title; if (course) return "Continue " + course.title; return "Add one course link and start a 25-minute focus block."; }
export function buildAssistantState(state, reason = "steady") { const s = mergeState(state); const blocked = countRecent(s.protection.blockedAttempts, 10 * 60 * 1000); const switches = countRecent(s.protection.tabSwitches, 5 * 60 * 1000); let mode = ASSISTANT_MESSAGES[reason] ? reason : "steady"; if (blocked >= 3) mode = "blockedAttempts"; else if (switches >= 5) mode = "tabSwitching"; else if ((s.stats.distractions || 0) >= 4) mode = "repeatedDistractions"; const course = getActiveCourse(s); return { mode, suggestion: ASSISTANT_MESSAGES[mode] || ASSISTANT_MESSAGES.steady, nextTask: course ? "Open " + course.title : nextStudyTask(s), lastUpdatedAt: Date.now() }; }
