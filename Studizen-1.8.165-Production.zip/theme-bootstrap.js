(() => {
  const cacheKey = "courseFocusProThemeMode";
  const stateKey = "courseFocusProState";
  const themes = new Set(["light", "dark", "midnight", "amoled", "beige"]);
  const systemDark = () => globalThis.matchMedia?.("(prefers-color-scheme: dark)")?.matches;
  const resolve = (mode) => themes.has(mode) ? mode : mode === "system" ? (systemDark() ? "dark" : "light") : "dark";
  const apply = (mode) => {
    const savedMode = themes.has(mode) || mode === "system" ? mode : "dark";
    document.documentElement.dataset.theme = resolve(savedMode);
    document.documentElement.dataset.themeMode = savedMode;
    try { localStorage.setItem(cacheKey, savedMode); } catch {}
  };

  let cachedMode = "";
  try { cachedMode = localStorage.getItem(cacheKey) || ""; } catch {}
  apply(cachedMode || "dark");

  if (!cachedMode && globalThis.chrome?.storage?.local) {
    chrome.storage.local.get(stateKey).then((data) => {
      const mode = data?.[stateKey]?.settings?.themeMode;
      apply(mode || "dark");
    }).catch(() => {});
  }
})();
