(() => {
  function canonicalYouTubeVideoUrl(raw = "") {
    try {
      const url = new URL(raw, location.href);
      const host = url.hostname.toLowerCase().replace(/^www\./, "");
      let videoId = "";
      if (host === "youtu.be") videoId = url.pathname.split("/").filter(Boolean)[0] || "";
      else if (host === "youtube.com" || host.endsWith(".youtube.com") || host === "youtube-nocookie.com" || host.endsWith(".youtube-nocookie.com")) {
        videoId = url.pathname === "/watch" ? url.searchParams.get("v") || "" : (url.pathname.match(/^\/(?:shorts|embed|live)\/([^/?#]+)/i)?.[1] || "");
      }
      return videoId ? "https://www.youtube.com/watch?v=" + encodeURIComponent(videoId) : "";
    } catch {
      return "";
    }
  }

  function cleanTitle(value = "") {
    return String(value || "").replace(/\s+/g, " ").trim().slice(0, 180);
  }

  function safeTitle(value = "") {
    const title = cleanTitle(value).slice(0, 180);
    if (!title || /^youtube video$/i.test(title) || /^(?:\d{1,2}:)?\d{1,2}:\d{2}$/.test(title) || /^\d+\s*(?:s|sec|secs|second|seconds|min|mins|minute|minutes)$/i.test(title)) return "";
    return title;
  }

  function textValue(value) {
    if (typeof value === "string") return value;
    if (typeof value?.simpleText === "string") return value.simpleText;
    return Array.isArray(value?.runs) ? value.runs.map((run) => run?.text || "").join("") : "";
  }

  function titleFromInitialData(videoUrl) {
    const expectedId = new URL(videoUrl).searchParams.get("v") || new URL(videoUrl).pathname.split("/").filter(Boolean).at(-1) || "";
    if (!expectedId) return { title: "", source: "", reason: "video-id-unavailable" };
    const queue = [window.ytInitialData, window.ytInitialPlayerResponse].filter(Boolean);
    const seen = new Set();
    let visited = 0;
    while (queue.length && visited < 40000) {
      const value = queue.pop();
      if (!value || typeof value !== "object" || seen.has(value)) continue;
      seen.add(value);
      visited += 1;
      if (value.videoId === expectedId) {
        const title = safeTitle(textValue(value.title) || textValue(value.headline) || textValue(value.videoDetails?.title));
        if (title) return { title, source: "matching-youtube-initial-data", reason: "" };
      }
      Object.values(value).forEach((child) => { if (child && typeof child === "object") queue.push(child); });
    }
    return { title: "", source: "", reason: "video-id-not-found-in-youtube-data" };
  }

  function titleForAnchor(anchor) {
    const renderer = anchor?.closest("ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer, ytd-grid-video-renderer, ytd-rich-grid-media, ytd-playlist-video-renderer, yt-lockup-view-model");
    const titleNode = renderer?.querySelector("#video-title, #video-title-link, .yt-lockup-metadata-view-model__title, h3 a[title]");
    const candidates = [titleNode?.getAttribute("title"), titleNode?.innerText, titleNode?.textContent, anchor?.getAttribute("title"), anchor?.querySelector("#video-title")?.textContent];
    const structuredTitle = candidates.map(safeTitle).find(Boolean);
    if (structuredTitle) return { title: structuredTitle, source: "matching-thumbnail-dom", reason: "" };
    return titleFromInitialData(anchor.href);
  }

  function titleForCurrentVideo(videoUrl) {
    const canonicalUrl = canonicalYouTubeVideoUrl(videoUrl);
    if (!canonicalUrl || canonicalYouTubeVideoUrl(location.href) !== canonicalUrl) return "";
    const expectedId = new URL(canonicalUrl).searchParams.get("v") || "";
    const details = window.ytInitialPlayerResponse?.videoDetails;
    if (details?.videoId && details.videoId !== expectedId) return "";
    if (details?.videoId === expectedId) {
      const playerTitle = safeTitle(details.title);
      if (playerTitle) return playerTitle;
    }
    return safeTitle(document.querySelector("h1.ytd-watch-metadata yt-formatted-string, h1.ytd-watch-metadata, #title h1")?.textContent);
  }

  document.addEventListener("contextmenu", (event) => {
    const path = typeof event.composedPath === "function" ? event.composedPath() : [];
    const target = event.target instanceof Element ? event.target : null;
    const anchor = path.find((node) => node instanceof HTMLAnchorElement && node.href)
      || target?.closest("a[href]")
      || null;
    const isPlayerNode = (node) => node instanceof HTMLVideoElement
      || (node instanceof Element && node.matches("video, .html5-video-player, #movie_player"));
    const player = path.some(isPlayerNode) || Boolean(target?.closest("video, .html5-video-player, #movie_player"));
    const url = anchor ? canonicalYouTubeVideoUrl(anchor.href) : (player ? canonicalYouTubeVideoUrl(location.href) : "");
    const titleResult = anchor
      ? titleForAnchor(anchor)
      : (player
        ? { title: titleForCurrentVideo(url), source: "matching-current-video-player-or-heading", reason: "current-video-title-unavailable" }
        : { title: "", source: "", reason: "no-video-anchor-or-player" });
    chrome.runtime.sendMessage({ type: "youtubeContextTarget", payload: { url, title: titleResult.title, titleSource: titleResult.source, pageUrl: location.href } }).catch(() => {});
  }, true);
})();
